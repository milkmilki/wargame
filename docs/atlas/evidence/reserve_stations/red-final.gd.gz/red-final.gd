extends "res://tests/atlas_reserve_stations.gd"
func begin(state: GameState, queued: bool) -> Simulation:
    var sim: Simulation = load("C:/Users/57859/.codex/tmp/atlas-reserve-fix/baseline.gd").new()
    sim.setup(state)
    if queued:
        var ids := {}
        for army in state.armies: ids[army.id] = true
        sim._begin_ai_command_collection(ids)
    return sim
