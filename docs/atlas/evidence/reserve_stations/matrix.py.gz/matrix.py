import hashlib,json,subprocess,time
from pathlib import Path
ROOT=Path('D:/ProjectICreate/Wargame/wargame')
OUT=Path('C:/Users/57859/.codex/tmp/atlas-reserve-fix')
ARCHIVE=Path('D:/ProjectICreate/Wargame-local/20261011-cleanup/.dbg')
GODOT='D:/ProjectICreate/Godot_v4.7.1-stable_win64.exe'
sources={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'scripts/simulation/simulation.gd',ROOT/'scripts/ai/action_candidate.gd',ROOT/'tests/atlas_reserve_movement_probe.gd']}
manifest={'base':'c9120584adbf1a592ace4d44d31c2e58f67e8e5d','sources':sources,'snapshot_sha256':hashlib.sha256((ARCHIVE/'daily-v9/frozen-day180.bin').read_bytes()).hexdigest(),'runs':[]}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
def run(label,variant,peace=False,trace=False):
    script=str(OUT/(f'{variant}-peace'+('-trace' if trace else '')+'.gd')) if peace else (str(OUT/f'{variant}-observe.gd') if trace else (str(OUT/'baseline.gd') if variant=='before' else 'res://scripts/simulation/simulation.gd'))
    args=[GODOT,'--headless','--path',str(ROOT),'--script','res://tests/atlas_reserve_movement_probe.gd','--',f'--simulation={script}',f'--output={OUT/label}.json',f'--days={180 if peace else 35}',f'--peace={str(peace).lower()}',f'--payload={ARCHIVE}/atlas-military-eurasia-mask.bin',f'--snapshot={ARCHIVE}/daily-v9/frozen-day180.bin',f'--codec={ARCHIVE}/state_codec.gd']
    with (OUT/f'{label}.stdout.txt').open('wb') as stdout,(OUT/f'{label}.stderr.txt').open('wb') as stderr:
        p=subprocess.Popen(args,stdout=stdout,stderr=stderr,cwd=ROOT)
        print('START',label,p.pid,flush=True)
        manifest['runs'].append({'label':label,'pid':p.pid,'command':args})
        (OUT/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
        code=p.wait()
    err=(OUT/f'{label}.stderr.txt').read_text(encoding='utf-8',errors='replace')
    if code or 'SCRIPT ERROR' in err or 'ERROR:' in err:
        raise RuntimeError((label,code,err))
    data=json.loads((OUT/f'{label}.json').read_text(encoding='utf-8'))
    print('DONE',label,'mean_ms',round(sum(r['compute_us'] for r in data['rows'])/len(data['rows'])/1000,3),'moving',round(sum(r['moving'] for r in data['rows'])/len(data['rows']),2),flush=True)
for i in range(5):
    for variant in (['before','after'] if i%2==0 else ['after','before']):
        run(f'war-{i}-{variant}',variant)
for variant in ['before','after']:
    run(f'peace-{variant}',variant,True,True)
    run(f'war-trace-{variant}',variant,False,True)
print('MATRIX_COMPLETE',flush=True)
