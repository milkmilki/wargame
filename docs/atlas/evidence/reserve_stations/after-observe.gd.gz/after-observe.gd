extends Simulation
var observed_orders: Array = []
var observed_last: Dictionary = {}
func _record_ai_order(army: Army, candidate: ActionCandidate) -> void:
	var previous: Dictionary=observed_last.get(army.id,{})
	var prior_until:=army.ai_order_until_day
	var prior_lock:=army.defensive_deployment_until_day
	var origin:=army.location_city
	var incoming:=0
	if candidate.reason.begins_with("国家预备队"):
		for other in state.armies:
			if other.id!=army.id and other.owner_nation==army.owner_nation and other.size>0 and other.state==Army.State.MOVING and other.ai_target_city==candidate.target_city: incoming+=1
	super._record_ai_order(army,candidate)
	if army.state!=Army.State.MOVING: return
	var row: Dictionary={"day":state.day,"army":army.id,"owner":army.owner_nation,"from":origin,"target":candidate.target_city,"kind":candidate.kind,"reason":candidate.reason,"at_war":not state.wars_of(army.owner_nation).is_empty(),"prior_commit_until":prior_until,"prior_lock_until":prior_lock,"incoming_to_target":incoming,"previous":previous.duplicate(),"front":army.campaign_front_id,"war":army.campaign_war_id}
	observed_orders.append(row)
	observed_last[army.id]={"day":state.day,"from":origin,"target":candidate.target_city,"reason":candidate.reason}
