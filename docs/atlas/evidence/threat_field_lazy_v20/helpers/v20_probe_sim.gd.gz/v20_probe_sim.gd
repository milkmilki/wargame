extends Simulation
var observed_fields: Array[ThreatField] = []
func _build_parallel_ai_threat(job_index: int) -> void:
	super._build_parallel_ai_threat(job_index)
	observed_fields.append(_parallel_ai_context_jobs[job_index].threat)
