from pathlib import Path
root=Path.cwd(); out=root/'.dbg/threat-lazy-v20'
p=root/'scripts/ai/threat_field.gd'; raw=p.read_bytes()
(out/'threat_field-before.gd.txt').write_bytes(raw)
s=raw.decode().replace('class_name ThreatField\n','').replace(') -> ThreatField:',') -> RefCounted:').replace('var field := ThreatField.new()','var field = load("res://tests/support/eager_threat_reference.gd").new()').replace('var enemy_sources :=','var enemy_sources: Dictionary =').replace('var friendly_sources :=','var friendly_sources: Dictionary =')
(root/'tests/support/eager_threat_reference.gd').write_text(s,encoding='utf-8')
p=root/'run_tests.py'; s=p.read_text(encoding='utf-8'); s=s.replace('"ruler_modifier_table",','"ruler_modifier_table", "threat_field_lazy",',1);p.write_text(s,encoding='utf-8')
