extends SceneTree
func _initialize(): call_deferred("run")
func run():
	var sim = preload("res://.dbg/state_codec.gd").new().restore("res://.dbg/daily-v9/frozen-day180.bin","res://.dbg/v20_probe_sim.gd")
	var rows := []
	var expected: Array = JSON.parse_string(FileAccess.get_file_as_string("res://.dbg/threat-lazy-v20/daily/after-11796.json")).rows
	for offset in range(35):
		sim.observed_fields.clear(); sim._advance_day(false)
		var sources := 0; var influence_entries := 0; var queries := 0; var possible_nodes := 0
		for field in sim.observed_fields:
			possible_nodes += field.get("_frozen_city_ids").size()*2
			queries += field.get("_threat_values").size()+field.get("_support_values").size()
			for key in ["_threat_sources","_support_sources"]:
				for source in field.get(key): sources += 1; influence_entries += source.influence.size()
		var hash_context := HashingContext.new(); hash_context.start(HashingContext.HASH_SHA256)
		hash_context.update(var_to_bytes(NativeSnapshotBuilder.build(sim.state)))
		assert(hash_context.finish().hex_encode() == expected[offset].sha256)
		rows.append({"day":sim.state.day,"fields":sim.observed_fields.size(),"source_maps":sources,"copied_influence_entries":influence_entries,"memoized_node_values":queries,"possible_node_values":possible_nodes})
	FileAccess.open("res://.dbg/threat-lazy-v20/probe.json",FileAccess.WRITE).store_string(JSON.stringify({"pid":OS.get_process_id(),"source_sha256":FileAccess.get_sha256("res://scripts/ai/threat_field.gd"),"rows":rows},"  "))
	print("THREAT_LAZY_PROBE_COMPLETE ",OS.get_process_id()); sim.free(); quit()
