from pathlib import Path
import subprocess
p='run_tests.py'; s=subprocess.check_output(['git','show','HEAD:'+p]).decode().replace('\r\n','\n')
needle='"ruler_modifier_table",';assert s.count(needle)==1
s=s.replace(needle,needle+' "threat_field_lazy",',1)
blob=subprocess.check_output(['git','hash-object','-w','--path='+p,'--stdin'],input=s.encode()).decode().strip()
subprocess.run(['git','update-index','--cacheinfo','100644,'+blob+','+p],check=True)
subprocess.run(['git','add','scripts/ai/threat_field.gd','tests/threat_field_lazy.gd','tests/support/eager_threat_reference.gd','docs/atlas/THREAT_FIELD_LAZY_V20.md'],check=True)
print('Staged only lazy threat field, its tests and documentation.')
