from pathlib import Path
import gzip,hashlib,json,shutil,statistics,subprocess
src=Path('.dbg/threat-lazy-v20'); dest=Path('docs/atlas/evidence/threat_field_lazy_v20'); dest.mkdir(parents=True,exist_ok=True)
def copy_tree(source,target):
 target.mkdir(parents=True,exist_ok=True)
 for p in source.iterdir():
  if not p.is_file():continue
  if p.name=='paired-summary.json':continue
  if p.suffix=='.json':(target/p.name).write_text(json.dumps(json.loads(p.read_text(encoding='utf-8-sig')),separators=(',',':'))+'\n',encoding='utf-8')
  elif p.name.endswith('.gd.txt'):(target/(p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
  else:shutil.copyfile(p,target/p.name)
copy_tree(src/'daily',dest/'daily')
copy_tree(src/'regression',dest/'working')
for p in src.iterdir():
 if p.is_file() and p.suffix in ['.json','.txt'] and not p.name.endswith('.gd.txt'):
  if p.suffix=='.json':(dest/p.name).write_text(json.dumps(json.loads(p.read_text(encoding='utf-8-sig')),separators=(',',':'))+'\n',encoding='utf-8')
  else:shutil.copyfile(p,dest/p.name)
helpers=dest/'helpers';helpers.mkdir(exist_ok=True)
for name in ['v20_threat_compare.py','v20_threat_daily.gd','v20_runtime_compare.py','v20_runtime.gd','v20_probe.gd','v20_probe_sim.gd','state_codec.gd','v17_daily.gd','prepare_v20.py','stage_v20.py','record_v20.py']:
 (helpers/(name+'.gz')).write_bytes(gzip.compress((Path('.dbg')/name).read_bytes(),mtime=0))
pairs=json.loads((src/'daily/paired-summary.json').read_text())
assert len(pairs)==5 and all(a['sha256']==b['sha256'] for p in pairs for a,b in zip(p['before']['rows'],p['after']['rows']))
metrics={}
for k in ['mean_ms','p95_ms','peak_ms']:
 a=statistics.median(p['before'][k] for p in pairs);b=statistics.median(p['after'][k] for p in pairs);metrics[k]={'before':a,'after':b,'reduction_percent':(a-b)/a*100}
for k in ['ai','ai_threat','ai_snapshot','supply','monthly','movement_battles']:
 metrics[k]={v:statistics.median(statistics.mean(row['profile'].get(k,0) for row in p[v]['rows'])/1000 for p in pairs) for v in ['before','after']}
loaded=json.loads((src/'daily/after-11796.json').read_text())['source_hashes']
sources=dest/'sources';sources.mkdir(exist_ok=True)
archives={}
for path,sha in loaded.items():
 raw=Path(path).read_bytes();assert hashlib.sha256(raw).hexdigest()==sha,path
 name=path.replace('/','__')+'.gz';(sources/name).write_bytes(gzip.compress(raw,mtime=0))
 archives[name]={'original_path':path,'sha256':sha}
old=(src/'threat_field-before.gd.txt').read_bytes();(sources/'threat_field-before.gd.gz').write_bytes(gzip.compress(old,mtime=0))
archives['threat_field-before.gd.gz']={'original_path':'scripts/ai/threat_field.gd','sha256':hashlib.sha256(old).hexdigest(),'variant':'before'}
runtime=json.loads((src/'runtime-summary.json').read_text());assert len(runtime['after']['rows'])==35 and all(a['sha256']==b['sha256'] for a,b in zip(runtime['before']['rows'],runtime['after']['rows']))
probe=json.loads((src/'probe.json').read_text());counts={k:{'mean':statistics.mean(r[k] for r in probe['rows']),'max':max(r[k] for r in probe['rows'])} for k in ['fields','source_maps','copied_influence_entries','memoized_node_values','possible_node_values']}
reg=json.loads((src/'regression-summary.json').read_text(encoding='utf-8-sig'));assert len(reg['results'])==21 and all(r['ok'] for r in reg['results'])
staged=Path('.dbg/v20-staged-verify/.dbg/regression'); sr=json.loads((staged/'summary-selected.json').read_text(encoding='utf-8-sig'));assert all(r['ok'] for r in sr['results'])
(dest/'staged').mkdir(exist_ok=True)
for row in sr['results']:shutil.copyfile(staged/(row['test']+'.log'),dest/'staged'/(row['test']+'.log.txt'))
shutil.copyfile(staged/'summary-selected.json',dest/'staged/summary.json')
summary={'date':'2026-10-11','base_commit':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'godot':'4.7.1.stable.official.a13da4feb','scope':'headless simulation computation, not GUI frame rate','configuration':{'seed':1,'nations':40,'nodes':1192,'initial_armies':234,'trade':True,'rulers':True,'mask':{'south':20,'north':55,'west':-15,'east':145}},'days':[181,215],'frozen_file':'.dbg/daily-v9/frozen-day180.bin','frozen_file_sha256':hashlib.sha256(Path('.dbg/daily-v9/frozen-day180.bin').read_bytes()).hexdigest(),'initial_native_sha256':pairs[0]['after']['initial_sha256'],'metrics':metrics,'equal_daily_states':175,'process_pairs':[{v:{k:z for k,z in p[v].items() if k!='rows'} for v in ['before','after']} for p in pairs],'runtime':{'days':35,'before_pid':runtime['before']['pid'],'after_pid':runtime['after']['pid'],'workers':4,'equal_daily_states':35,'note':'Inherited runtime peak counters are not a new main-thread or GUI performance measurement.'},'probe':{'pid':probe['pid'],'counts':counts,'note':'Counts cover synchronous AI construction hook; priority siege contexts outside that hook are not counted. Counts are not runtime RAM measurements.'},'tests':{'new_checks':4990,'working_passed':21,'staged_passed':len(sr['results'])},'source_archives':archives,'limitations':['One seed, 35-day window and one monthly boundary; no 30-year claim.','Private influence dictionaries consume memory; full-map consumers still pay for all node queries.','Working-tree benchmark includes earlier authorized pending implementations; staged-only verification is separate.']}
(dest/'summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
(dest/'.gitattributes').write_text('*.gz binary\n',encoding='utf-8')
print('V20 evidence saved and validated',len(sr['results']),'staged tests',flush=True)
