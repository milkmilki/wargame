from pathlib import Path
import subprocess
name='scripts/simulation/simulation.gd'
base=subprocess.check_output(['git','show','HEAD:'+name]).decode().replace('\r\n','\n')
old=Path('.dbg/forecast-token-v21/simulation-before.gd.txt').read_text(encoding='utf-8-sig')
new=Path('.dbg/forecast-token-v21/simulation-after.gd.txt').read_text(encoding='utf-8-sig')
for method in ['_trade_settlement_token','_trade_summary_settlement_token']:
 def extract(s):
  start=s.index('func '+method+'(');return s[start:s.index('\n\n\n',start)]
 before=extract(old);after=extract(new)
 assert base.count(before)==1,method+' contains other pending changes; inspect before staging'
 base=base.replace(before,after,1)
blob=subprocess.check_output(['git','hash-object','-w','--path='+name,'--stdin'],input=base.encode()).decode().strip()
subprocess.run(['git','update-index','--cacheinfo','100644,'+blob+','+name],check=True)
name='run_tests.py';s=subprocess.check_output(['git','show','HEAD:'+name]).decode().replace('\r\n','\n')
needle='"threat_field_lazy",';assert s.count(needle)==1;s=s.replace(needle,needle+' "forecast_token_packing",',1)
blob=subprocess.check_output(['git','hash-object','-w','--path='+name,'--stdin'],input=s.encode()).decode().strip()
subprocess.run(['git','update-index','--cacheinfo','100644,'+blob+','+name],check=True)
subprocess.run(['git','add','tests/forecast_token_packing.gd','tests/support/forecast_token_reference.gd'],check=True)
print('Staged only two token functions and their tests.')
