from pathlib import Path
r=Path.cwd()
s=(r/'.dbg/v20_runtime_compare.py').read_text(encoding='utf-8-sig').replace('threat-lazy-v20','forecast-token-v21').replace('scripts/ai/threat_field.gd','scripts/simulation/simulation.gd').replace('threat_field-','simulation-').replace('v20_runtime.gd','v21_runtime.gd')
(r/'.dbg/v21_runtime_compare.py').write_text(s,encoding='utf-8')
s=(r/'.dbg/v20_runtime.gd').read_text(encoding='utf-8-sig').replace('threat-lazy-v20','forecast-token-v21').replace('scripts/ai/threat_field.gd','scripts/simulation/simulation.gd')
(r/'.dbg/v21_runtime.gd').write_text(s,encoding='utf-8')
