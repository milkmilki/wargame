from pathlib import Path
p=Path('scripts/simulation/simulation.gd');s=p.read_text(encoding='utf-8-sig')
old='''\tfor city in state.cities:
\t\tfields.append([
\t\t\t"city", city.id, city.food_storage,
\t\t\tcity.garrison_manpower, city.garrison_supply_ratio,
\t\t\tcity_war_disrupted(state, city),
\t\t])'''
new='''\t# Keep integer dependencies exact beyond 2^53; ratios retain float64.
\t# One contiguous record block avoids allocating a small Array per node.
\tvar city_inputs := PackedInt64Array()
\tcity_inputs.resize(state.cities.size() * 4)
\tvar city_ratios := PackedFloat64Array()
\tcity_ratios.resize(state.cities.size())
\tvar city_index := 0
\tfor city in state.cities:
\t\tvar offset := city_index * 4
\t\tcity_inputs[offset] = city.id
\t\tcity_inputs[offset + 1] = city.food_storage
\t\tcity_inputs[offset + 2] = city.garrison_manpower
\t\tcity_inputs[offset + 3] = int(city_war_disrupted(state, city))
\t\tcity_ratios[city_index] = city.garrison_supply_ratio
\t\tcity_index += 1
\tfields.append(["cities_packed64", city_inputs, city_ratios])'''
assert s.count(old)==1;s=s.replace(old,new,1).replace('"trade_settlement_v1"','"trade_settlement_v2_packed_cities"',1)
old='''\tfor city in state.cities:
\t\tfields.append([
\t\t\t"city", city.id, city.garrison_manpower,
\t\t\tcity_war_disrupted(state, city),
\t\t])'''
new='''\tvar city_inputs := PackedInt64Array()
\tcity_inputs.resize(state.cities.size() * 3)
\tvar offset := 0
\tfor city in state.cities:
\t\tcity_inputs[offset] = city.id
\t\tcity_inputs[offset + 1] = city.garrison_manpower
\t\tcity_inputs[offset + 2] = int(city_war_disrupted(state, city))
\t\toffset += 3
\tfields.append(["cities_packed64", city_inputs])'''
assert s.count(old)==1;s=s.replace(old,new,1).replace('"trade_summary_settlement_v1"','"trade_summary_settlement_v2_packed_cities"',1)
p.write_text(s,encoding='utf-8',newline='')
Path('.dbg/forecast-token-v21/simulation-after.gd.txt').write_bytes(p.read_bytes())
Path('.dbg/forecast-token-v21/transform.json').write_text('"packed city records, no changed dependency fields"\n',encoding='utf-8')
