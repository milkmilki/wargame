from pathlib import Path
root=Path.cwd();out=root/'.dbg/forecast-token-v21';out.mkdir(exist_ok=True)
p=root/'scripts/simulation/simulation.gd';raw=p.read_bytes();(out/'simulation-before.gd.txt').write_bytes(raw)
s=raw.decode('utf-8-sig').replace('\r\n','\n');parts=[]
for name in ['_trade_settlement_token','_trade_summary_settlement_token']:
 start=s.index('func '+name+'(');end=s.index('\n\n\n',start)
 part=s[start:end].replace('func '+name+'(','static func '+name+'(\n\tstate: GameState,',1).replace('city_war_disrupted(state, city)','Simulation.city_war_disrupted(state, city)')
 parts.append(part)
(root/'tests/support/forecast_token_reference.gd').write_text('extends RefCounted\n## Original dependency fields copied from bfd5a4d; independent oracle.\n\n'+'\n\n'.join(parts)+'\n',encoding='utf-8')
p=root/'run_tests.py';s=p.read_text(encoding='utf-8');s=s.replace('"threat_field_lazy",','"threat_field_lazy", "forecast_token_packing",',1);p.write_text(s,encoding='utf-8')
