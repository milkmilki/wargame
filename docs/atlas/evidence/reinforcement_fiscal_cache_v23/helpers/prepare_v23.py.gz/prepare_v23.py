from pathlib import Path
r=Path.cwd();out=r/'.dbg/reinforcement-fiscal-v23';out.mkdir(exist_ok=True)
for p in ['scripts/simulation/simulation.gd','scripts/simulation/rules/reinforcement_phase.gd']:(out/(Path(p).stem+'-before.gd.txt')).write_bytes((r/p).read_bytes())
p=r/'run_tests.py';s=p.read_text(encoding='utf-8');s=s.replace('"supply_field_lazy_order",','"supply_field_lazy_order", "reinforcement_fiscal_cache",',1);p.write_text(s,encoding='utf-8')
