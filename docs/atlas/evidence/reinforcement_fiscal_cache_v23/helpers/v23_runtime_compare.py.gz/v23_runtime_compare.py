from pathlib import Path
import hashlib,json,subprocess
root=Path.cwd();out=root/'.dbg/reinforcement-fiscal-v23'
paths=['scripts/simulation/simulation.gd','scripts/simulation/rules/reinforcement_phase.gd']
original={p:(root/p).read_bytes() for p in paths};rows={}
try:
 for v in ['before','after']:
  raw={p:(out/(Path(p).stem+'-'+v+'.gd.txt')).read_bytes() for p in paths}
  for p in paths:(root/p).write_bytes(raw[p])
  with (out/('runtime-'+v+'.stdout.txt')).open('wb') as o,(out/('runtime-'+v+'.stderr.txt')).open('wb') as e:
   child=subprocess.Popen(['D:/ProjectICreate/Godot_v4.7.1-stable_win64.exe','--headless','--path',str(root),'--script','res://.dbg/v23_runtime.gd','--','--'+v],stdout=o,stderr=e,creationflags=subprocess.CREATE_NO_WINDOW)
   print('RUNTIME_START',v,child.pid,flush=True)
   try:code=child.wait(timeout=240)
   except subprocess.TimeoutExpired:child.kill();child.wait();raise
  assert code==0 and not (out/('runtime-'+v+'.stderr.txt')).read_text(encoding='utf-8').strip()
  rows[v]=json.loads((out/('runtime-%s-%d.json'%(v,child.pid))).read_text())
  for p in paths:assert rows[v]['source_hashes'][p]==hashlib.sha256(raw[p]).hexdigest()
 assert rows['before']['initial_sha256']==rows['after']['initial_sha256']
 assert len(rows['before']['rows'])==35 and all(a['sha256']==b['sha256'] for a,b in zip(rows['before']['rows'],rows['after']['rows']))
 assert any(r['worker_count']>1 for r in rows['after']['rows'])
 (out/'runtime-summary.json').write_text(json.dumps(rows,indent=2)+'\n')
 print('RUNTIME_EQUIVALENT 35 days, actual worker path',flush=True)
finally:
 for p in paths:(root/p).write_bytes(original[p])
