from pathlib import Path
import subprocess
name='scripts/simulation/simulation.gd';base=subprocess.check_output(['git','show','HEAD:'+name]).decode().replace('\r\n','\n')
old=Path('.dbg/reinforcement-fiscal-v23/simulation-before.gd.txt').read_text(encoding='utf-8-sig');new=Path('.dbg/reinforcement-fiscal-v23/simulation-after.gd.txt').read_text(encoding='utf-8-sig')
def method(s,n):start=s.index('func '+n+'(');return s[start:s.index('\n\n\n',start)]
before=method(old,'_reinforce_nation');after=method(new,'_reinforce_nation');assert base.count(before)==1;base=base.replace(before,after,1)
helper=method(new,'_prepare_reinforcement_forecast_cache');idx=base.index('## 单国当月补员：')
base=base[:idx]+'## Lazy fiscal adapter for a monthly refill batch; no army mutation here.\n'+helper+'\n\n\n'+base[idx:]
blob=subprocess.check_output(['git','hash-object','-w','--path='+name,'--stdin'],input=base.encode()).decode().strip();subprocess.run(['git','update-index','--cacheinfo','100644,'+blob+','+name],check=True)
name='run_tests.py';s=subprocess.check_output(['git','show','HEAD:'+name]).decode().replace('\r\n','\n');needle='"supply_field_lazy_order",';assert s.count(needle)==1;s=s.replace(needle,needle+' "reinforcement_fiscal_cache",',1)
blob=subprocess.check_output(['git','hash-object','-w','--path='+name,'--stdin'],input=s.encode()).decode().strip();subprocess.run(['git','update-index','--cacheinfo','100644,'+blob+','+name],check=True)
subprocess.run(['git','add','scripts/simulation/rules/reinforcement_phase.gd','tests/reinforcement_fiscal_cache.gd'],check=True)
print('Staged only monthly refill fiscal adapter and tests.')
