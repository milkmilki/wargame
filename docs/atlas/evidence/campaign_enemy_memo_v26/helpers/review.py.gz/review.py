from pathlib import Path
import subprocess,hashlib,json
root=Path('D:/ProjectICreate/Wargame/wargame');stage=Path('C:/Users/57859/.codex/tmp/atlas-v26-staged-verify');rows=subprocess.check_output(['git','ls-files','--stage'],cwd=root).decode().splitlines();checked=0
for row in rows:
 meta,path=row.split('\t',1);blob=meta.split()[1]
 if path.endswith(('.gd','.gdshader','.tscn')) or path in ['project.godot','run_tests.py']:
  expected=subprocess.check_output(['git','cat-file','blob',blob],cwd=root).replace(b'\r\n',b'\n');actual=(stage/path).read_bytes().replace(b'\r\n',b'\n');assert actual==expected,path;checked+=1
report={'indexed_code_files_checked':checked,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip(),'stage_root':str(stage),'staged_paths':subprocess.check_output(['git','diff','--cached','--name-only'],cwd=root).decode().splitlines()}
Path('C:/Users/57859/.codex/tmp/atlas-v26-tools/index-verification.json').write_text(json.dumps(report,indent=2)+'\n');print('C verification code matches index:',checked,'files')
