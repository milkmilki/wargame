from pathlib import Path
import subprocess
out=Path('C:/Users/57859/.codex/tmp/atlas-v26-tools');stage=Path('C:/Users/57859/.codex/tmp/atlas-v26-staged-verify')
with (out/'staged-import.stdout.txt').open('wb') as o,(out/'staged-import.stderr.txt').open('wb') as e:
 p=subprocess.Popen(['D:/ProjectICreate/Godot_v4.7.1-stable_win64.exe','--headless','--path',str(stage),'--editor','--import','--quit'],stdout=o,stderr=e,creationflags=subprocess.CREATE_NO_WINDOW);print('IMPORT_START',p.pid,flush=True);c=p.wait(timeout=300)
 assert c==0,(c,(out/'staged-import.stderr.txt').read_text());err=(out/'staged-import.stderr.txt').read_text();assert 'SCRIPT ERROR' not in err and 'ERROR:' not in err,err;print('IMPORT_PASS',p.pid,flush=True)
