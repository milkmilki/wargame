from pathlib import Path
import subprocess,re
root=Path.cwd();out=root/'.dbg/campaign-enemies-v26';out.mkdir(exist_ok=True);p=root/'scripts/ai/diplomacy_ai.gd';raw=p.read_bytes();(out/'diplomacy_ai-before.gd.txt').write_bytes(raw);s=raw.decode('utf-8-sig').replace('\r\n','\n')
args={'_cached_campaign_siege_requirement':'state,attacker_id,center_id,evaluation_cache','_cached_campaign_reinforcement_threat':'state,attacker_id,center_city_id,evaluation_cache','_cached_alliance_bloc':'state,nation_id,evaluation_cache'}
for name,call in args.items():
 m=re.search(r'static func '+re.escape(name)+r'\([\s\S]*?\n?(?:\) -> [^\n]+:)',s);assert m,name;sig=m.group()
 wrapper=sig+'\n\tvar started := Time.get_ticks_usec()\n\tvar result = _probe'+name+'('+call+')\n\tvar row: Array = _v26_probe.get("'+name+'",[0,0])\n\trow[0] += 1; row[1] += Time.get_ticks_usec()-started\n\t_v26_probe["'+name+'"] = row\n\treturn result\n\n'
 s=s[:m.start()]+wrapper+s[m.start():].replace('static func '+name+'(','static func _probe'+name+'(',1)
s+='\nstatic var _v26_probe := {}\n'
g=(root/'.dbg/v17_daily.gd').read_text(encoding='utf-8-sig').replace('.dbg/forecast-pools-v17/daily/','.dbg/campaign-enemies-v26/').replace('"levels" if OS.get_cmdline_user_args().has("--levels") else "heap"','"functions"')
g=g.replace('var output :=','DiplomacyAI.reset_campaign_v_index_counters()\n\tvar output :=').replace('print("ADMIN_DAILY_COMPLETE ",variant,','print("V26_FUNCTION_PROBE ", JSON.stringify(DiplomacyAI._v26_probe)); print("V26_INDEX_PROBE ",JSON.stringify(DiplomacyAI.campaign_v_index_counters())); print("ADMIN_DAILY_COMPLETE ",variant,')
(root/'.dbg/v26_probe.gd').write_text(g,encoding='utf-8')
try:
 p.write_text(s,encoding='utf-8')
 with (out/'probe.stdout.txt').open('wb') as o,(out/'probe.stderr.txt').open('wb') as e:
  child=subprocess.Popen(['D:/ProjectICreate/Godot_v4.7.1-stable_win64.exe','--headless','--path',str(root),'--script','res://.dbg/v26_probe.gd'],stdout=o,stderr=e,creationflags=subprocess.CREATE_NO_WINDOW);print('PROBE_START',child.pid,flush=True);code=child.wait(timeout=180)
 print('PROBE_EXIT',code);print((out/'probe.stdout.txt').read_text());print((out/'probe.stderr.txt').read_text())
finally:p.write_bytes(raw)
