from pathlib import Path
import gzip,hashlib,json,shutil,statistics,subprocess
root=Path('D:/ProjectICreate/Wargame/wargame');src=root/'.dbg/campaign-enemies-v26';tools=Path('C:/Users/57859/.codex/tmp/atlas-v26-tools');dest=tools/'evidence';dest.mkdir(exist_ok=True)
pairs=json.loads((src/'daily/paired-summary.json').read_text());assert len(pairs)==5 and all(a['sha256']==b['sha256'] for p in pairs for a,b in zip(p['before']['rows'],p['after']['rows']))
working=json.loads((tools/'working/summary-selected.json').read_text());assert len(working['results'])==18 and all(r['ok'] for r in working['results'])
stage=Path('C:/Users/57859/.codex/tmp/atlas-v26-staged-verify/.dbg/regression');staged=json.loads((stage/'summary-selected.json').read_text());assert len(staged['results'])==12 and all(r['ok'] for r in staged['results'])
for folder,target in [(src/'daily',dest/'daily'),(src/'after-probe',dest/'after-probe')]:
 target.mkdir(exist_ok=True)
 for p in folder.iterdir():
  if p.suffix=='.json':(target/p.name).write_text(json.dumps(json.loads(p.read_text()),separators=(',',':'))+'\n')
  elif p.name.endswith('.gd.txt'):(target/(p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
  else:shutil.copyfile(p,target/p.name)
for report,folder,label in [(working,tools/'working','working'),(staged,stage,'staged')]:
 target=dest/label;target.mkdir(exist_ok=True);(target/'summary.json').write_text(json.dumps(report,separators=(',',':'))+'\n')
 for row in report['results']:shutil.copyfile(folder/(row['test']+'.log'),target/(row['test']+'.log.txt'))
for name in ['runtime-summary.json','runtime-before.stdout.txt','runtime-before.stderr.txt','runtime-after.stdout.txt','runtime-after.stderr.txt','red.log.txt','probe.stdout.txt','probe.stderr.txt']:
 p=src/name
 if p.suffix=='.json':(dest/name).write_text(json.dumps(json.loads(p.read_text()),separators=(',',':'))+'\n')
 else:shutil.copyfile(p,dest/name)
for p in src.glob('functions-*.json'):
 data=json.loads(p.read_text());assert all(a['sha256']==b['sha256'] for a,b in zip(data['rows'],pairs[0]['before']['rows']));(dest/p.name).write_text(json.dumps(data,separators=(',',':'))+'\n')
for p in (src/'after-probe').glob('functions-*.json'):
 data=json.loads(p.read_text());assert all(a['sha256']==b['sha256'] for a,b in zip(data['rows'],pairs[0]['after']['rows']))
helperdir=dest/'helpers';helperdir.mkdir(exist_ok=True)
for name in ['v26_probe.py','v26_probe.gd','v26_after_probe.py','v26_after_probe.gd','v26_enemy_compare.py','v26_enemy_daily.gd','v26_runtime_compare.py','v26_runtime.gd','state_codec.gd','v17_daily.gd','prepare_v26.py','stage_v26.py']:
 (helperdir/(name+'.gz')).write_bytes(gzip.compress((root/'.dbg'/name).read_bytes(),mtime=0))
for name in ['import.py','working_runner.py','review.py','record.py']:(helperdir/(name+'.gz')).write_bytes(gzip.compress((tools/name).read_bytes(),mtime=0))
metrics={}
for key in ['mean_ms','p95_ms','peak_ms']:
 a=statistics.median(p['before'][key] for p in pairs);b=statistics.median(p['after'][key] for p in pairs);metrics[key]={'before':a,'after':b,'reduction_percent':(a-b)/a*100}
for key in ['ai','ai_campaign_planning','ai_campaign_coalition','monthly_diplomacy','supply']:
 metrics[key]={v:statistics.median(statistics.mean(r['profile'].get(key,0) for r in p[v]['rows'])/1000 for p in pairs) for v in ['before','after']}
sample=json.loads((src/'daily/after-22720.json').read_text());sourcefolder=dest/'sources';sourcefolder.mkdir(exist_ok=True);archives={}
for path,sha in sample['source_hashes'].items():
 raw=(root/path).read_bytes();assert hashlib.sha256(raw).hexdigest()==sha,path;name=path.replace('/','__')+'.gz';(sourcefolder/name).write_bytes(gzip.compress(raw,mtime=0));archives[name]={'path':path,'sha256':sha}
raw=(src/'diplomacy_ai-before.gd.txt').read_bytes();(sourcefolder/'diplomacy_ai-before.gd.gz').write_bytes(gzip.compress(raw,mtime=0))
runtime=json.loads((src/'runtime-summary.json').read_text());assert len(runtime['after']['rows'])==35 and all(a['sha256']==b['sha256'] for a,b in zip(runtime['before']['rows'],runtime['after']['rows']))
shutil.copyfile(tools/'staged-import.stderr.txt',dest/'staged-import.stderr.txt');(dest/'staged-import.stdout.txt.gz').write_bytes(gzip.compress((tools/'staged-import.stdout.txt').read_bytes(),mtime=0));shutil.copyfile(tools/'index-verification.json',dest/'index-verification.json')
summary={'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip(),'submitted':False,'reason':'D volume has zero free space; cleanup actions were rejected by approval policy. Evidence and complete verification are stored on C.','scope':'headless compute, not GPU frame rate','configuration':{'seed':1,'countries':40,'nodes':1192,'initial_armies':234,'trade':True,'rulers':True,'mask':{'south':20,'north':55,'west':-15,'east':145}},'metrics':metrics,'equal_daily_states':175,'runtime':{'equal_daily_states':35,'before_pid':runtime['before']['pid'],'after_pid':runtime['after']['pid'],'workers':4},'tests':{'checks':503,'working_passed':18,'staged_passed':12,'core_checks':505},'sources':archives,'initial_native_sha256':sample['initial_sha256'],'frozen_sha256':hashlib.sha256((root/'.dbg/daily-v9/frozen-day180.bin').read_bytes()).hexdigest(),'process_pairs':[{v:{k:val for k,val in p[v].items() if k!='rows'} for v in ['before','after']} for p in pairs],'limitations':['One seed, 35 days and one monthly boundary.','Two paired peaks increased; all five paired means decreased.','D verification copy was incomplete; PID35032 import was stopped and excluded.','Initial working child tests passed but summary write failed due to disk full; complete working regression rerun stored on C.','Commit, final repository evidence and graph refresh remain pending.']}
(dest/'summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n');(dest/'.gitattributes').write_text('*.gz binary\n');print('C evidence verified and archived')
