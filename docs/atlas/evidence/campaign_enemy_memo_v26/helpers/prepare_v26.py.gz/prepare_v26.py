from pathlib import Path
p=Path('scripts/ai/diplomacy_ai.gd');s=p.read_text(encoding='utf-8-sig');start=s.index('static func _cached_campaign_reinforcement_threat(');end=s.index('\n\nstatic func _national_power',start);old=s[start:end]
new=old.replace('\tvar threat_by_center := {}','\tvar threat_by_center := {}\n\t# Relations are fixed during this read-only build; armies share their owner.\n\tvar enemy_by_owner := {}',1).replace('\n\t\t\tor not state.is_enemy(attacker_id, army.owner_nation)','',1)
needle='\t\tvar centers := {}';replacement='''		var owner := army.owner_nation
		if not enemy_by_owner.has(owner):
			enemy_by_owner[owner] = state.is_enemy(attacker_id, owner)
		if not bool(enemy_by_owner[owner]):
			continue
		var centers := {}''';assert new.count(needle)==1;new=new.replace(needle,replacement,1)
s=s[:start]+new+s[end:];p.write_text(s,encoding='utf-8');Path('.dbg/campaign-enemies-v26/diplomacy_ai-after.gd.txt').write_bytes(p.read_bytes())
