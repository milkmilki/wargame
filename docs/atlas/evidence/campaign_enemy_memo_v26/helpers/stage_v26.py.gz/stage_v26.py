from pathlib import Path
import subprocess
path='scripts/ai/diplomacy_ai.gd'
before=Path('.dbg/campaign-enemies-v26/diplomacy_ai-before.gd.txt').read_text(encoding='utf-8-sig');assert subprocess.check_output(['git','show','HEAD:'+path]).decode().replace('\r\n','\n')==before.replace('\r\n','\n')
assert Path(path).read_bytes()==Path('.dbg/campaign-enemies-v26/diplomacy_ai-after.gd.txt').read_bytes()
path='run_tests.py';s=subprocess.check_output(['git','show','HEAD:'+path]).decode().replace('\r\n','\n');needle='"trade_packed_fingerprint",';assert s.count(needle)==1;s=s.replace(needle,needle+' "campaign_enemy_memo",',1)
blob=subprocess.check_output(['git','hash-object','-w','--path='+path,'--stdin'],input=s.encode()).decode().strip();subprocess.run(['git','update-index','--cacheinfo','100644,'+blob+','+path],check=True)
w=Path(path).read_text(encoding='utf-8');assert w.count(needle)==1;Path(path).write_text(w.replace(needle,needle+' "campaign_enemy_memo",',1),encoding='utf-8')
subprocess.run(['git','add','scripts/ai/diplomacy_ai.gd','tests/campaign_enemy_memo.gd'],check=True)
print('STAGED v26 only')
