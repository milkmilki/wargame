from pathlib import Path
import subprocess
root=Path.cwd(); out=root/'.dbg/war-manpower-v24'; out.mkdir(exist_ok=True)
p=root/'scripts/ai/diplomacy_ai.gd'; raw=p.read_bytes(); (out/'diplomacy_ai-before.gd.txt').write_bytes(raw)
s=raw.decode('utf-8-sig').replace('\r\n','\n')
start=s.index('static func resource_report('); end=s.index('\n\t_ensure_evaluation_cache_current',start)
sig=s[start:end]; s=s[:start]+s[start:].replace('static func resource_report(','static func _probe_resource_report(',1)
wrapper=sig+'''
	var started := Time.get_ticks_usec()
	var report := _probe_resource_report(state,nation_id,evaluation_cache)
	var row: Array = _v24_probe.get(state.day,[0,0,0,0])
	row[0] += 1; row[1] += Time.get_ticks_usec()-started
	var era := unification_era_factor(state)
	var required := maxi(int(round(lerpf(float(MIN_MANPOWER_RESERVE), float(MIN_MANPOWER_RESERVE) / 5.0, era))), int(ceil(float(report.troops) * lerpf(0.15, TOTAL_WAR_MANPOWER_SHARE, era))))
	required = mini(required,state.manpower_pool_capacity(nation_id))
	if state.nations[nation_id].manpower_pool < required:
		row[2] += 1; row[3] += Time.get_ticks_usec()-started
	_v24_probe[state.day] = row
	return report

static var _v24_probe := {}

'''
s=s[:start]+wrapper+s[start:]
g=(root/'.dbg/v17_daily.gd').read_text(encoding='utf-8-sig').replace('.dbg/forecast-pools-v17/daily/','.dbg/war-manpower-v24/').replace('"levels" if OS.get_cmdline_user_args().has("--levels") else "heap"','"probe"')
g=g.replace('print("ADMIN_DAILY_COMPLETE ",variant,','print("V24_REPORT_PROBE ", JSON.stringify(DiplomacyAI._v24_probe)); print("ADMIN_DAILY_COMPLETE ",variant,')
(root/'.dbg/v24_probe.gd').write_text(g,encoding='utf-8')
try:
 p.write_text(s,encoding='utf-8')
 with (out/'probe.stdout.txt').open('wb') as o,(out/'probe.stderr.txt').open('wb') as e:
  child=subprocess.Popen(['D:/ProjectICreate/Godot_v4.7.1-stable_win64.exe','--headless','--path',str(root),'--script','res://.dbg/v24_probe.gd'],stdout=o,stderr=e,creationflags=subprocess.CREATE_NO_WINDOW)
  print('PROBE_START',child.pid,flush=True); code=child.wait(timeout=180)
 print('PROBE_EXIT',code,flush=True); print((out/'probe.stdout.txt').read_text()); print((out/'probe.stderr.txt').read_text())
finally:p.write_bytes(raw)

