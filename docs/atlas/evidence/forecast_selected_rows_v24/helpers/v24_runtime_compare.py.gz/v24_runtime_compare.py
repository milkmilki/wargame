from pathlib import Path
import hashlib,json,subprocess
root=Path.cwd();out=root/'.dbg/war-manpower-v24';p=root/'scripts/ai/diplomacy_ai.gd';original=p.read_bytes();rows={}
try:
 for v in ['before','after']:
  raw=(out/('diplomacy_ai-'+v+'.gd.txt')).read_bytes();p.write_bytes(raw)
  with (out/('runtime-'+v+'.stdout.txt')).open('wb') as o,(out/('runtime-'+v+'.stderr.txt')).open('wb') as e:
   child=subprocess.Popen(['D:/ProjectICreate/Godot_v4.7.1-stable_win64.exe','--headless','--path',str(root),'--script','res://.dbg/v24_runtime.gd','--','--'+v],stdout=o,stderr=e,creationflags=subprocess.CREATE_NO_WINDOW)
   print('RUNTIME_START',v,child.pid,flush=True)
   try:code=child.wait(timeout=240)
   except subprocess.TimeoutExpired:child.kill();child.wait();raise
  assert code==0 and not (out/('runtime-'+v+'.stderr.txt')).read_text(encoding='utf-8').strip()
  rows[v]=json.loads((out/('runtime-%s-%d.json'%(v,child.pid))).read_text())
  assert rows[v]['source_sha256']==hashlib.sha256(raw).hexdigest()
 assert rows['before']['initial_sha256']==rows['after']['initial_sha256']
 assert len(rows['before']['rows'])==35 and all(a['sha256']==b['sha256'] for a,b in zip(rows['before']['rows'],rows['after']['rows']))
 assert any(r['worker_count']>1 for r in rows['after']['rows'])
 (out/'runtime-summary.json').write_text(json.dumps(rows,indent=2)+'\n')
 print('RUNTIME_EQUIVALENT 35 days, actual worker path',flush=True)
finally:p.write_bytes(original)
