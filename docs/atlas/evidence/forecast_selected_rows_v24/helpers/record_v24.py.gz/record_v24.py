from pathlib import Path
import gzip,hashlib,json,shutil,statistics,subprocess
src=Path('.dbg/war-manpower-v24');dest=Path('docs/atlas/evidence/forecast_selected_rows_v24');dest.mkdir(parents=True,exist_ok=True)
pairs=json.loads((src/'daily/paired-summary.json').read_text());assert len(pairs)==5
assert all(len(p[v]['rows'])==35 for p in pairs for v in ['before','after'])
assert all(a['sha256']==b['sha256'] for p in pairs for a,b in zip(p['before']['rows'],p['after']['rows']))
working=json.loads(Path('.dbg/regression/summary-selected.json').read_text(encoding='utf-8-sig'));assert len(working['results'])==19 and all(r['ok'] for r in working['results'])
stage=Path('.dbg/v24-staged-verify/.dbg/regression');staged=json.loads((stage/'summary-selected.json').read_text(encoding='utf-8-sig'));assert len(staged['results'])==9 and all(r['ok'] for r in staged['results'])
for folder,target in [(src/'daily',dest/'daily')]:
 target.mkdir(exist_ok=True)
 for p in folder.iterdir():
  if p.name=='paired-summary.json':continue
  if p.suffix=='.json':(target/p.name).write_text(json.dumps(json.loads(p.read_text()),separators=(',',':'))+'\n',encoding='utf-8')
  elif p.name.endswith('.gd.txt'):(target/(p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
  else:shutil.copyfile(p,target/p.name)
for report,folder,label in [(working,Path('.dbg/regression'),'working'),(staged,stage,'staged')]:
 target=dest/label;target.mkdir(exist_ok=True)
 (target/'summary.json').write_text(json.dumps(report,separators=(',',':'))+'\n')
 for r in report['results']:shutil.copyfile(folder/(r['test']+'.log'),target/(r['test']+'.log.txt'))
for p in src.iterdir():
 if p.is_file() and p.name in ['runtime-summary.json','runtime-before.stdout.txt','runtime-before.stderr.txt','runtime-after.stdout.txt','runtime-after.stderr.txt','staged-import.stdout.txt','staged-import.stderr.txt','red.log.txt','probe.stdout.txt','probe.stderr.txt','functions.stdout.txt','functions.stderr.txt']:
  if p.suffix=='.json':(dest/p.name).write_text(json.dumps(json.loads(p.read_text()),separators=(',',':'))+'\n')
  else:shutil.copyfile(p,dest/p.name)
# Diagnostics are not performance comparisons; verify the unmodified native trajectory.
for name in ['probe-31432.json','functions-26616.json']:
 data=json.loads((src/name).read_text());assert data['initial_sha256']==pairs[0]['before']['initial_sha256'];assert all(a['sha256']==b['sha256'] for a,b in zip(data['rows'],pairs[0]['before']['rows']))
 (dest/name).write_text(json.dumps(data,separators=(',',':'))+'\n')
helpers=dest/'helpers';helpers.mkdir(exist_ok=True)
for name in ['v24_probe.py','v24_functions.py','v24_scan_compare.py','v24_scan_daily.gd','v24_runtime_compare.py','v24_runtime.gd','state_codec.gd','v17_daily.gd','prepare_v24.py','stage_v24.py','record_v24.py']:
 (helpers/(name+'.gz')).write_bytes(gzip.compress((Path('.dbg')/name).read_bytes(),mtime=0))
metrics={}
for k in ['mean_ms','p95_ms','peak_ms']:
 a=statistics.median(p['before'][k] for p in pairs);b=statistics.median(p['after'][k] for p in pairs);metrics[k]={'before':a,'after':b,'reduction_percent':(a-b)/a*100}
for k in ['monthly','monthly_diplomacy','monthly_reinforcements','war_collect_precheck','ai','supply']:
 metrics['day210_'+k]={v:statistics.median(next(r['profile'].get(k,0)/1000 for r in p[v]['rows'] if r['day']==210) for p in pairs) for v in ['before','after']}
sample=json.loads((src/'daily/after-28592.json').read_text());sources=dest/'sources';sources.mkdir(exist_ok=True);archives={}
for path,sha in sample['source_hashes'].items():
 raw=Path(path).read_bytes();assert hashlib.sha256(raw).hexdigest()==sha,path
 name=path.replace('/','__')+'.gz';(sources/name).write_bytes(gzip.compress(raw,mtime=0));archives[name]={'original_path':path,'sha256':sha}
raw=(src/'diplomacy_ai-before.gd.txt').read_bytes();name='diplomacy_ai-before.gd.gz';(sources/name).write_bytes(gzip.compress(raw,mtime=0));archives[name]={'original_path':'scripts/ai/diplomacy_ai.gd','sha256':hashlib.sha256(raw).hexdigest(),'variant':'before'}
runtime=json.loads((src/'runtime-summary.json').read_text());assert len(runtime['after']['rows'])==35 and all(a['sha256']==b['sha256'] for a,b in zip(runtime['before']['rows'],runtime['after']['rows']))
summary={'date':'2026-10-11','base_commit':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'godot':'4.7.1.stable.official.a13da4feb','scope':'headless computation, not GUI frame rate','configuration':{'seed':1,'nations':40,'nodes':1192,'initial_armies':234,'trade':True,'rulers':True,'mask':{'south':20,'north':55,'west':-15,'east':145}},'days':[181,215],'frozen_file':'.dbg/daily-v9/frozen-day180.bin','frozen_sha256':hashlib.sha256(Path('.dbg/daily-v9/frozen-day180.bin').read_bytes()).hexdigest(),'initial_native_sha256':sample['initial_sha256'],'metrics':metrics,'equal_daily_states':175,'process_pairs':[{v:{k:val for k,val in p[v].items() if k!='rows'} for v in ['before','after']} for p in pairs],'runtime':{'days':35,'equal_daily_states':35,'before_pid':runtime['before']['pid'],'after_pid':runtime['after']['pid'],'workers':4,'note':'Inherited cumulative runtime peak counters are not new main-thread performance evidence.'},'tests':{'new_checks':221,'working_passed':19,'staged_passed':9,'core_checks':505},'source_archives':archives,'limitations':['One seed, 35-day window and one monthly boundary. No long-run or GUI claim.','Two paired daily means increased; all five peaks decreased.','Working benchmark includes earlier pending features; staged validation is separate.','Diagnostic wrappers add overhead and are excluded from performance comparisons.']}
(dest/'summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n',encoding='utf-8');(dest/'.gitattributes').write_text('*.gz binary\n',encoding='utf-8')
print('V24 validated evidence saved')
