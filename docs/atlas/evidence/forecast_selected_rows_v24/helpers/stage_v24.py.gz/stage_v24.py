from pathlib import Path
import subprocess
p='scripts/ai/diplomacy_ai.gd'
before=Path('.dbg/war-manpower-v24/diplomacy_ai-before.gd.txt').read_text(encoding='utf-8-sig')
assert subprocess.check_output(['git','show','HEAD:'+p]).decode().replace('\r\n','\n')==before.replace('\r\n','\n')
assert Path(p).read_bytes()==Path('.dbg/war-manpower-v24/diplomacy_ai-after.gd.txt').read_bytes()
p='run_tests.py';s=subprocess.check_output(['git','show','HEAD:'+p]).decode().replace('\r\n','\n');needle='"reinforcement_fiscal_cache",';assert s.count(needle)==1;s=s.replace(needle,needle+' "forecast_selected_rows",',1)
blob=subprocess.check_output(['git','hash-object','-w','--path='+p,'--stdin'],input=s.encode()).decode().strip();subprocess.run(['git','update-index','--cacheinfo','100644,'+blob+','+p],check=True)
w=Path(p).read_text(encoding='utf-8');assert w.count(needle)==1;Path(p).write_text(w.replace(needle,needle+' "forecast_selected_rows",',1),encoding='utf-8')
subprocess.run(['git','add','scripts/ai/diplomacy_ai.gd','tests/forecast_selected_rows.gd'],check=True)
print('STAGED v24 only')
