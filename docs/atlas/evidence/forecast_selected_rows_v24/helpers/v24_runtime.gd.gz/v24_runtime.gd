extends SceneTree
func _initialize(): call_deferred("run")
func digest(state: GameState) -> String:
	var hash_context := HashingContext.new(); hash_context.start(HashingContext.HASH_SHA256)
	hash_context.update(var_to_bytes(NativeSnapshotBuilder.build(state)))
	return hash_context.finish().hex_encode()
func run():
	var variant := "after" if OS.get_cmdline_user_args().has("--after") else "before"
	var sim: Simulation = preload("res://.dbg/state_codec.gd").new().restore("res://.dbg/daily-v9/frozen-day180.bin")
	root.add_child(sim); sim.paused = true; sim.runtime_stage_profiling_enabled = true
	var output := {"pid":OS.get_process_id(),"variant":variant,"source_sha256":FileAccess.get_sha256("res://scripts/ai/diplomacy_ai.gd"),"initial_sha256":digest(sim.state),"rows":[]}
	for day in range(35):
		assert(await sim.advance_one_day())
		output.rows.append({"day":sim.state.day,"sha256":digest(sim.state),"worker_count":sim.ai_threat_worker_count_last,"runtime_peak_usec":sim.runtime_span_peak_usec.duplicate()})
		if sim.state.day%10 == 0: print("RUNTIME_PROGRESS ",variant," ",sim.state.day)
	FileAccess.open("res://.dbg/war-manpower-v24/runtime-%s-%d.json"%[variant,OS.get_process_id()],FileAccess.WRITE).store_string(JSON.stringify(output,"  "))
	print("RUNTIME_COMPLETE ",variant," ",OS.get_process_id())
	sim.queue_free(); await process_frame; quit()
