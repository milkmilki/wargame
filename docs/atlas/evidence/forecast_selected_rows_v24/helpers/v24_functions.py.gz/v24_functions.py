from pathlib import Path
import subprocess,re
root=Path.cwd(); out=root/'.dbg/war-manpower-v24';p=root/'scripts/ai/diplomacy_ai.gd';raw=p.read_bytes(); s=raw.decode('utf-8-sig').replace('\r\n','\n')
args={'resource_report':'state,nation_id,evaluation_cache','war_food_report':'state,nation_id,target_troops,posture,evaluation_cache,compute_capacity','resource_forecast':'state,nation_id,target_troops,posture,evaluation_cache,override','_resource_forecast_inputs':'state,cache,required_nation','food_posture':'state,nation_id,evaluation_cache'}
for name,call in args.items():
 pattern=r'static func '+re.escape(name)+r'\([\s\S]*?\n?(?:\) -> [^\n]+:)'
 m=re.search(pattern,s); assert m,name;sig=m.group()
 wrapper=sig+'\n\tvar started := Time.get_ticks_usec()\n\tvar result = _probe'+name+'('+call+')\n\tvar row: Array = _v24_probe.get("'+name+'",[0,0])\n\trow[0] += 1; row[1] += Time.get_ticks_usec()-started\n\t_v24_probe["'+name+'"] = row\n\treturn result\n\n'
 s=s[:m.start()]+wrapper+s[m.start():].replace('static func '+name+'(','static func _probe'+name+'(',1)
s += '\nstatic var _v24_probe := {}\n'
g=(root/'.dbg/v17_daily.gd').read_text(encoding='utf-8-sig').replace('.dbg/forecast-pools-v17/daily/','.dbg/war-manpower-v24/').replace('"levels" if OS.get_cmdline_user_args().has("--levels") else "heap"','"functions"')
g=g.replace('var output :=','ResourceForecastRules.profiling_enabled = true; ResourceForecastRules.reset_profile()\n\tvar output :=')
g=g.replace('print("ADMIN_DAILY_COMPLETE ",variant,','print("V24_FUNCTION_PROBE ", JSON.stringify(DiplomacyAI._v24_probe)); print("V24_EVALUATE_PROBE ",JSON.stringify(ResourceForecastRules.profile())); print("ADMIN_DAILY_COMPLETE ",variant,')
(root/'.dbg/v24_functions.gd').write_text(g,encoding='utf-8')
try:
 p.write_text(s,encoding='utf-8')
 with (out/'functions.stdout.txt').open('wb') as o,(out/'functions.stderr.txt').open('wb') as e:
  child=subprocess.Popen(['D:/ProjectICreate/Godot_v4.7.1-stable_win64.exe','--headless','--path',str(root),'--script','res://.dbg/v24_functions.gd'],stdout=o,stderr=e,creationflags=subprocess.CREATE_NO_WINDOW)
  print('FUNCTION_START',child.pid,flush=True); code=child.wait(timeout=180)
 print('FUNCTION_EXIT',code);print((out/'functions.stdout.txt').read_text());print((out/'functions.stderr.txt').read_text())
finally:p.write_bytes(raw)
