from pathlib import Path
p=Path('scripts/ai/diplomacy_ai.gd');s=p.read_text(encoding='utf-8-sig');before=p.read_bytes()
folder=Path('.dbg/war-manpower-v24');assert (folder/'diplomacy_ai-before.gd.txt').read_bytes()==before
s=s.replace('\tvar nation_ids: Array[int] = []\n\tvar selected := {}','\tvar nation_ids: Array[int] = []\n\tvar city_rows: Array[int] = []\n\tvar center_rows: Array[int] = []\n\tvar selected := {}',1)
s=s.replace('\t\tfor id in nation_ids: selected[id] = true','''		var scan_rows := DiplomacyAI._forecast_scan_rows(state,cache)
		for id in nation_ids:
			selected[id] = true
			city_rows.append_array(scan_rows.cities.get(id,[] as Array[int]))
			center_rows.append_array(scan_rows.centers.get(id,[] as Array[int]))
		# Indices retain each original traversal order, including duplicate centers.
		city_rows.sort(); center_rows.sort()''',1)
s=s.replace('var count: int = state.cities.size() if phase==0 else state.administrative_center_city_ids.size() if phase==1 else nation_ids.size()','var count: int = city_rows.size() if phase==0 else center_rows.size() if phase==1 else nation_ids.size()',1)
s=s.replace('0: city(state.cities[cursor])','0: city(state.cities[city_rows[cursor]])',1).replace('1: center(state.administrative_center_city_ids[cursor])','1: center(state.administrative_center_city_ids[center_rows[cursor]])',1)
pos=s.index('## A requested nation needs its entire financial food pool')
s=s[:pos]+'''
## Raw ownership matches the builder's selection, including financial proxy cases.
## The evaluation revision owns this index; never retain it across a new batch.
static func _forecast_scan_rows(state: GameState,cache: Dictionary) -> Dictionary:
	if cache.has("forecast_scan_rows"): return cache.forecast_scan_rows
	var rows := {"cities":{},"centers":{}}
	for index in range(state.cities.size()):
		var owner := state.cities[index].owner_nation
		if not rows.cities.has(owner): rows.cities[owner] = [] as Array[int]
		(rows.cities[owner] as Array[int]).append(index)
	for index in range(state.administrative_center_city_ids.size()):
		var owner := state.cities[state.administrative_center_city_ids[index]].owner_nation
		if not rows.centers.has(owner): rows.centers[owner] = [] as Array[int]
		(rows.centers[owner] as Array[int]).append(index)
	cache.forecast_scan_rows = rows
	return rows

'''+s[pos:]
p.write_text(s,encoding='utf-8');(folder/'diplomacy_ai-after.gd.txt').write_bytes(p.read_bytes())
