extends SceneTree
## 回归测试套件（headless 运行，无需图形）。
##
## 运行:
##   /Users/bytedance/Godot.app/Contents/MacOS/Godot --headless --path <项目> --script res://tests/test_suite.gd
## 或用项目根的 run_tests.sh。
##
## 退出码 0 = 全部通过，1 = 有失败（可接入 CI）。
## 覆盖：世界生成不变量 / 地形惩罚数学 / 战斗与撤退 / 模拟推进 / 确定性复现。

const FamilyFixture = preload("res://tests/ruler_family_fixture.gd")

var _passed: int = 0
var _failed: int = 0
var _fail_msgs: Array[String] = []


func _init() -> void:
	print("==== WorldWar 回归测试 ====\n")

	_test_terrain_multiplier()
	_test_battle_basics()
	_test_administrative_battle_removal()
	_test_retreat_mechanic()
	_test_multi_vs_one()
	_test_starvation_morale()
	_test_persistent_morale()
	_test_simulation_progress()
	_test_post_unification_continuation()
	_test_determinism()
	_test_time_layering()
	_test_trigger_detection()
	_test_three_way_battle()
	_test_three_way_siege()
	_test_multi_army_aggregation()
	_test_three_way_serial()
	_test_crosspass_field_priority()
	_test_capacity_no_block_enemy()
	_test_directional_friendly_capacity()
	_test_march_time_linear()
	_test_siege_food_clock()
	_test_morale_retreat_recovery()
	_test_retreat_transport_footprint()
	_test_edge_retreat_transport_batches()
	_test_besieged_city_retreat_depth()
	_test_supply_morale_and_passive_retreat_battle()
	_test_rolling_supply_settlement()
	_test_edge_holding_state()
	_test_edge_supply_from_both_endpoints()
	_test_warehouse_logistics()
	_test_atomic_territory_transactions()
	_test_capital_capture_capitulation()
	_test_holding_combat_adaptation()
	_test_stable_force_resource_cache_filter()
	_test_resource_cache_refreshes_after_new_nation()
	_test_invalid_loyalty_snapshot_does_not_corrupt_city()
	_test_gold_reserve_budget_and_war_snapshot()
	_test_ruler_economy_integration()
	_test_war_preparation_cancel_cooldown()
	_test_war_preparation_route_block_grace()
	_test_alliance_war_coalitions()
	_test_suzerainty_invariants()
	_test_vassal_tribute()
	_test_enfeoff_ai()
	_test_suzerainty_lifecycle()
	_test_civil_war_relations()
	_test_centralization_decision()
	_test_civil_war_annexation()
	_test_resource_capacity_limits()
	_test_shared_granary_and_relay_supply()
	_test_vassal_governance_output_bonus()
	_test_suzerainty_disconnection_requires_capture()
	_test_external_territory_sovereignty()
	_test_vassal_local_main_command()
	_test_stranded_hostile_army_eviction()
	_test_vassal_wartime_support_and_capital()
	_test_resource_hubs_and_food_mobilization()
	_test_sustainable_force_capacity()
	_test_small_nation_survival_and_emergency_recruitment()
	_test_combat_fairness_and_conservation()
	_test_structured_battle_log()
	_test_equivariant_ordering()
	_test_remaining_combat_risk_closures()

	print("\n==== 结果: %d 通过, %d 失败 ====" % [_passed, _failed])
	for m in _fail_msgs:
		print("  [FAIL] " + m)
	quit(1 if _failed > 0 else 0)

# ------------------------------------------------------------------ 断言辅助

func _check(cond: bool, msg: String) -> void:
	if cond:
		_passed += 1
	else:
		_failed += 1
		_fail_msgs.append(msg)
		print("  [FAIL] " + msg)


func _approx(a: float, b: float, eps: float = 0.0001) -> bool:
	return absf(a - b) <= eps


func _nation_ids_from_rows(rows: Array[Dictionary]) -> Array[int]:
	var result: Array[int] = []
	for row in rows:
		result.append(int(row["nation_id"]))
	return result


func _set_neutral_ruler(nation: Nation) -> void:
	nation.ruler_archetype = RulerProfile.BALANCED
	nation.ruler_traits.clear()
	nation.trade_policy = RulerProfile.POLICY_BALANCED

# ------------------------------------------------------------------ 1. 世界生成
func _test_terrain_multiplier() -> void:
	print("[2] danger 地形：攻击惩罚固定，防御惩罚随驻防时间趋近零")
	var danger := 0.5
	var attack := Combat.attack_multiplier(danger)
	_check(_approx(attack, 0.75), "danger=0.5 时攻击倍率应固定为 0.75，实为 %.3f" % attack)
	var d0 := Combat.defense_multiplier(danger, 0.0)
	var d30 := Combat.defense_multiplier(danger, 30.0)
	var d60 := Combat.defense_multiplier(danger, 60.0)
	var d90 := Combat.defense_multiplier(danger, 90.0)
	_check(_approx(d0, 0.8), "danger=0.5、0 天驻防的防御倍率应为 0.8，实为 %.3f" % d0)
	_check(d0 < d30 and d30 < d60 and d60 < d90 and d90 < 1.0,
		"防御倍率应随驻防时间单调趋近 1：%.3f/%.3f/%.3f/%.3f" % [d0, d30, d60, d90])
	_check(Combat.defense_multiplier(danger, 100000.0) <= 1.0,
		"驻防适应只能消除惩罚，不能产生超过基础值的加成")
	_check(_approx(Combat.attack_multiplier(0.0), 1.0) and _approx(Combat.defense_multiplier(0.0, 0.0), 1.0),
		"danger=0 时攻防均不应受惩罚")
	_check(_approx(Combat.attack_multiplier(danger), attack),
		"攻击倍率不得随驻防时间或其他状态变化")
	# item 9：隘口带连续、无阈值断崖。danger=1.0 达攻击地板 FLOOR；ONSET 处两段取值连续相接。
	_check(
		_approx(
			Combat.attack_multiplier(1.0),
			Combat.CHOKEPOINT_ATTACK_FLOOR
		),
		"danger=1.0 时进攻方攻击倍率应压到地板 %.2f" % Combat.CHOKEPOINT_ATTACK_FLOOR
	)
	# 无「浮点跨阈战力减半」：ONSET 前后各 0.001 的攻击倍率变化必须是小幅（远小于旧的 0.575→0.25 断崖）。
	var just_below := Combat.attack_multiplier(Combat.CHOKEPOINT_DANGER_ONSET - 0.001)
	var at_onset := Combat.attack_multiplier(Combat.CHOKEPOINT_DANGER_ONSET)
	var just_above := Combat.attack_multiplier(Combat.CHOKEPOINT_DANGER_ONSET + 0.001)
	_check(
		absf(just_below - at_onset) < 0.01 and absf(at_onset - just_above) < 0.01,
		"隘口带起点处必须连续：跨 0.001 的攻击倍率变化应<0.01，实为 %.4f/%.4f" % [
			absf(just_below - at_onset), absf(at_onset - just_above)
		]
	)
	# 全程单调不增：danger 越高攻击越受抑（采样覆盖普通段与隘口带）。
	var mono_ok := true
	var prev := Combat.attack_multiplier(0.0)
	for i in range(1, 101):
		var cur := Combat.attack_multiplier(float(i) / 100.0)
		if cur > prev + 1e-9:
			mono_ok = false
		prev = cur
	_check(mono_ok, "攻击倍率必须随 danger 全程单调不增（连续曲线，无回升跳变）")
	# 隘口带内仍强力压制：danger=0.95 的攻击倍率应显著低于普通段 danger=0.5。
	_check(
		Combat.attack_multiplier(0.95) < Combat.attack_multiplier(0.5) - 0.2,
		"极端地形(danger=0.95)仍须强力压制进攻，明显低于中等地形(danger=0.5)"
	)
	# 撤退决策地形红利（派生纯函数）：平地退化为 1；险地利守 >1；久守单调递增。
	_check(_approx(UtilityAI.terrain_hold_bias(0.0, 0.0), 1.0),
		"平地(danger=0)地形据守系数应退化为 1，实为 %.4f" % UtilityAI.terrain_hold_bias(0.0, 0.0))
	_check(UtilityAI.terrain_hold_bias(0.9, 0.0) > 1.0,
		"隘口(danger=0.9)即便零驻防也应利于据守(>1)，实为 %.4f" % UtilityAI.terrain_hold_bias(0.9, 0.0))
	var bias_d0 := UtilityAI.terrain_hold_bias(0.9, 0.0)
	var bias_d30 := UtilityAI.terrain_hold_bias(0.9, 30.0)
	_check(bias_d30 > bias_d0,
		"连续驻防应提升据守红利：30天(%.4f)须高于0天(%.4f)" % [bias_d30, bias_d0])
	# 前线边选值阶段(holding_days=0)：danger 越高据守溢价越高（value_of_edge 敌对前线边
	# 加成基础），且 UtilityAI 别名与 Combat 真源必须一致。
	var premium_flat := Combat.terrain_hold_bias(0.0, 0.0)
	var premium_mid := Combat.terrain_hold_bias(0.3, 0.0)
	var premium_pass := Combat.terrain_hold_bias(0.9, 0.0)
	_check(premium_pass > premium_mid and premium_mid > premium_flat,
		"选边溢价须随 danger 单调递增：平地%.4f<中等%.4f<隘口%.4f" % [
			premium_flat, premium_mid, premium_pass])
	_check(_approx(UtilityAI.terrain_hold_bias(0.9, 0.0), Combat.terrain_hold_bias(0.9, 0.0)),
		"UtilityAI.terrain_hold_bias 必须委托 Combat 真源，取值一致")

# ------------------------------------------------------------------ 3. 战斗基础

func _test_administrative_battle_removal() -> void:
	var battle := Battle.new()
	var army := Army.new()
	army.size = 8000
	army.location_city = 3
	army.state = Army.State.RECOVERING
	army.morale = 0.7
	army.battle_id = 12
	var remaining := Army.new()
	remaining.size = 15000
	battle.side_a.append_array([army, remaining])
	battle.side_b.append(army)
	battle.reinforce_fresh_a.append(army)
	battle.reinforce_fresh_b.append(army)
	battle.routed_a.append(army)
	battle.routed_b.append(army)
	battle.frontline_priority_a[army] = 0
	battle.frontline_priority_b[army] = 0
	battle.remove_army(army)
	battle.remove_army(army)
	_check(not battle.has_army(army) and battle.side_a.has(remaining),
		"行政移除参战关系必须幂等且不影响其他军队")
	_check(battle.reinforce_fresh_a.is_empty() and battle.reinforce_fresh_b.is_empty()
		and battle.routed_a.is_empty() and battle.routed_b.is_empty()
		and battle.frontline_priority_a.is_empty() and battle.frontline_priority_b.is_empty(),
		"行政移除必须清理所有待处理战斗引用")
	_check(army.size == 8000 and army.location_city == 3 and army.battle_id == 12
		and army.state == Army.State.RECOVERING and _approx(army.morale, 0.7),
		"Battle 清理引用不得改变军队兵力、士气、位置或状态")


func _test_battle_basics() -> void:
	print("[3] 战斗基础：多回合、强者胜、size 扣减、必然收敛")
	var rng := RandomNumberGenerator.new()
	rng.seed = 1
	var strong := _make_army(0, 0, 2000, 12)
	var weak := _make_army(1, 1, 200, 10)
	var battle := _make_field_battle([strong], [weak], 0.0, 4)
	var s0 := strong.size
	var rounds := _run_battle(battle, rng)
	_check(rounds >= 1, "战斗应至少进行 1 回合，实为 %d" % rounds)
	_check(rounds < 1000, "战斗必须收敛结束，实为 %d 回合" % rounds)
	_check(battle.winner_side == 1, "2000 兵应战胜 200 兵")
	_check(weak.size < 200, "败方应减员")
	_check(strong.size <= s0, "胜方 size 不应增加")
	_check(strong.size > 0, "压倒性胜方应存活")
	# EU4 式：持续多回合而非一击必杀
	var strong2 := _make_army(0, 0, 1000, 10)
	var even := _make_army(1, 1, 1000, 10)
	var b2 := _make_field_battle([strong2], [even], 0.0, 4)
	rng.seed = 7
	var r2 := _run_battle(b2, rng)
	_check(r2 >= 3, "势均力敌应打多回合（EU4式持久），实为 %d" % r2)
	var mirror_a := _make_army(2, 0, 1000, 10, 10)
	var mirror_b := _make_army(3, 1, 1000, 10, 10)
	var mirror_battle := _make_field_battle(
		[mirror_a],
		[mirror_b],
		0.3,
		4
	)
	rng.seed = 8
	CombatFixture.resolve_round(mirror_battle)
	_check(
		mirror_a.size == mirror_b.size
		and is_equal_approx(
			mirror_a.morale,
			mirror_b.morale
		),
		"同质双方共享战场波动时，单回合伤亡和士气必须严格对称"
	)
# ------------------------------------------------------------------ 4. 撤退机制（士气崩溃保兵）

func _test_retreat_mechanic() -> void:
	print("[4] 撤退：败方常带残兵撤退（士气先于兵力崩溃）")
	var rng := RandomNumberGenerator.new()
	var survived_with_troops := 0
	var trials := 100
	for i in range(trials):
		rng.seed = i
		var a := _make_army(0, 0, 2500, 12)
		var b := _make_army(1, 1, 800, 10)
		var battle := _make_field_battle([a], [b], 0.0, 4)
		_run_battle(battle, rng)
		# 败方(b)若 size>0 即为带残兵撤退
		if battle.winner_side == 1 and b.size > 0:
			survived_with_troops += 1
	var rate := float(survived_with_troops) / float(trials)
	# 士气机制下，败方大多数情况应带残兵撤退而非被全歼
	_check(rate > 0.5, "败方带残兵撤退比例应 >0.5（非总是歼灭），实为 %.2f" % rate)

# ------------------------------------------------------------------ 5b. 多路夹击

func _test_multi_vs_one() -> void:
	print("[5b] N v M：多路夹击应胜过单路守军")
	var rng := RandomNumberGenerator.new(); rng.seed = 3
	# 三路各 800 攻一路 1500：聚合火力 2400 > 1500，多路应胜
	var a1 := _make_army(0, 0, 800, 10)
	var a2 := _make_army(1, 0, 800, 10)
	var a3 := _make_army(2, 0, 800, 10)
	var d := _make_army(3, 1, 1500, 10)
	var battle := _make_field_battle([a1, a2, a3], [d], 0.0, 4)
	var rounds := _run_battle(battle, rng)
	_check(rounds < 1000, "多路战斗应收敛")
	_check(battle.winner_side == 1, "三路聚合火力应战胜单路守军")
	var atk_survivors := 0
	for a in [a1, a2, a3]:
		if a.size > 0:
			atk_survivors += 1
	_check(atk_survivors >= 1, "多路方应有幸存")

# ------------------------------------------------------------------ 5c. 断粮士气惩罚（粮草特色）

func _test_starvation_morale() -> void:
	print("[5c] 断粮方士气衰减更快、更早崩溃（粮草特色）")
	# 对照：完全相同局面与种子，仅 side_b 是否断粮不同。
	var rng1 := RandomNumberGenerator.new(); rng1.seed = 11
	var a1 := _make_army(0, 0, 1000, 10)
	var b1 := _make_army(1, 1, 1000, 10)
	var battle1 := _make_field_battle([a1], [b1], 0.0, 4)
	var rounds_fed := _run_battle(battle1, rng1)

	var rng2 := RandomNumberGenerator.new(); rng2.seed = 11
	var a2 := _make_army(0, 0, 1000, 10)
	var b2 := _make_army(1, 1, 1000, 10)
	b2.starving = true                       # side_b 断粮
	var battle2 := _make_field_battle([a2], [b2], 0.0, 4)
	var rounds_starved := _run_battle(battle2, rng2)

	_check(rounds_starved <= rounds_fed,
		"断粮方所在战斗应更早（或不晚于）结束：饱粮%d回合 vs 断粮%d回合" % [rounds_fed, rounds_starved])
	_check(battle2.winner_side == 1,
		"其他条件相同、side_b 断粮，则 side_a(未断粮) 应获胜")

# ------------------------------------------------------------------ 5d. 持久士气：疲劳老兵 + 战后恢复

func _test_persistent_morale() -> void:
	print("[5d] 持久士气：低士气老兵更快崩溃 + 战后恢复")
	# (a) 同兵力同种子，一方带疲劳士气进场 → 该方应更快崩溃败北。
	var rng1 := RandomNumberGenerator.new(); rng1.seed = 21
	var fresh := _make_army(0, 0, 1000, 10)
	var tired := _make_army(1, 1, 1000, 10)
	tired.morale = 0.3                       # 疲劳老兵
	var battle := _make_field_battle([fresh], [tired], 0.0, 4)
	_run_battle(battle, rng1)
	_check(battle.winner_side == 1, "满士气一方应战胜疲劳(0.3)一方")

	# (b) 战后恢复：满军费、满补给时按统一恢复天数线性回满。
	var gs := preload("res://tests/support/grid_world.gd").new()
	gs.generate_grid_world(12345)
	var sim := Simulation.new()
	sim.setup(gs)
	var probe := gs.armies[0]
	probe.morale = 0.0
	probe.state = Army.State.IDLE
	probe.starving = false
	for _day in range(Combat.MORALE_RECOVERY_DAYS - 1):
		sim._recover_morale()
	var pre_full_recovery_ratio := (
		float(Combat.MORALE_RECOVERY_DAYS - 1)
		/ float(Combat.MORALE_RECOVERY_DAYS)
	)
	_check(
		_approx(probe.morale, probe.max_morale * pre_full_recovery_ratio)
			and probe.morale < probe.max_morale,
		"主战军回满前一日士气比例错误，实为 %.2f/%.2f"
			% [probe.morale, probe.max_morale]
	)
	sim._recover_morale()
	_check(
		_approx(probe.morale, probe.max_morale),
		"主战军满补给时必须在配置的恢复天数后回满士气"
	)
	# 欠饷不再缩放恢复速度，断粮仍阻止恢复。
	probe.max_morale = Army.DEFAULT_MAX_MORALE
	probe.morale = 0.2
	probe.starving = false
	gs.nations[probe.owner_nation].treasury_gold = 0
	gs.nations[probe.owner_nation].military_payment_ratio = 0.0
	sim._recover_morale()
	_check(
		_approx(
			probe.morale,
			0.2
				+ probe.max_morale
					/ float(Combat.MORALE_RECOVERY_DAYS)
		),
		"军费未支付时士气仍应按正常速度恢复"
	)
	# 断粮时不恢复
	probe.morale = 0.2; probe.starving = true
	sim._recover_morale()
	_check(_approx(probe.morale, 0.2), "断粮军队不应恢复士气")
	sim.free()

# ------------------------------------------------------------------ 6. 模拟推进

func _test_simulation_progress() -> void:
	print("[6] 模拟推进：战斗/占领/粮食实际生效")
	var gs := preload("res://tests/support/grid_world.gd").new()
	gs.generate_grid_world(12345)
	for nation_a in range(gs.nations.size()):
		for nation_b in range(nation_a + 1, gs.nations.size()):
			gs.set_diplomatic_relation(
				nation_a, nation_b, GameState.DiplomaticRelation.NEUTRAL
			)
	gs.armies.clear()
	gs.battles.clear()
	for city in gs.cities:
		city.garrison_manpower = 0
	var attacker_id := 0
	var defender_id := 1
	var target_center := gs.administrative_center_of(
		gs.nations[defender_id].capital_city_id
	)
	for index in range(8):
		var attacker := _make_army(
			900000 + index, attacker_id,
			GameState.INITIAL_HEAVY_ARMY_SIZE, 10
		)
		attacker.max_size = GameState.INITIAL_HEAVY_ARMY_SIZE
		attacker.location_city = gs.nations[attacker_id].capital_city_id
		attacker.move_from = attacker.location_city
		attacker.morale = attacker.max_morale
		attacker.supply_ratio = 1.0
		gs.armies.append(attacker)
	for index in range(2):
		var defender := _make_army(
			900100 + index, defender_id,
			GameState.INITIAL_HEAVY_ARMY_SIZE, 10
		)
		defender.max_size = GameState.INITIAL_HEAVY_ARMY_SIZE
		defender.location_city = target_center
		defender.move_from = target_center
		defender.morale = defender.max_morale
		defender.supply_ratio = 1.0
		gs.armies.append(defender)
	gs.set_diplomatic_relation(
		attacker_id, defender_id, GameState.DiplomaticRelation.WAR
	)
	gs.set_war_objective(
		attacker_id, defender_id, target_center, "模拟推进门禁"
	)
	var sim := Simulation.new()
	sim.setup(gs)
	sim.diplomacy_enabled = false
	var captures := 0
	for d in range(2000):
		var before := {}
		for c in gs.cities:
			before[c.id] = c.owner_nation
		sim._advance_day()
		for c in gs.cities:
			if before[c.id] != c.owner_nation:
				captures += 1
		if gs.winner != -1:
			break
	_check(captures > 0, "2000 天内应发生城市易主（战斗+占领生效），实为 %d" % captures)
	# 粮食：至少有城市 food_storage 被消耗过（存在低于半年产出的城）
	_check(gs.day > 0, "天数应推进")
	sim.free()   # 释放 Node，避免泄漏

# ------------------------------------------------------------------ 7. 确定性复现
func _test_post_unification_continuation() -> void:
	print("[6b] 统一后继续推演：保留胜者里程碑但不暂停时间")
	var gs := preload("res://tests/support/grid_world.gd").new()
	gs.generate_grid_world(12666)
	gs.armies.clear()
	gs.battles.clear()
	for city in gs.cities:
		city.owner_nation = 0
		gs.recognized_city_owners[city.id] = 0
	var sim := Simulation.new()
	sim.setup(gs)
	sim.diplomacy_enabled = false
	sim._check_victory()
	var day_before := gs.day
	sim._advance_day()
	_check(
		gs.winner == 0
			and not sim.paused
			and gs.day == day_before + 1,
		"仅剩一国时应记录统一者但继续推进日期，不得自动暂停"
	)
	sim.free()




func _test_determinism() -> void:
	print("[7] 确定性：同种子两次运行状态一致")
	var sig_a := _run_signature(12345, 600)
	var sig_b := _run_signature(12345, 600)
	_check(sig_a == sig_b, "同种子 600 天后签名应一致\n    A=%s\n    B=%s" % [sig_a, sig_b])


func _run_signature(world_seed: int, days: int) -> String:
	var gs := preload("res://tests/support/grid_world.gd").new()
	gs.generate_grid_world(world_seed)
	var sim := Simulation.new()
	sim.setup(gs)
	for d in range(days):
		sim._advance_day()
		if gs.winner != -1:
			break
	# 生成状态签名：各城归属 + 各国兵力
	var parts: Array[String] = []
	for c in gs.cities:
		parts.append(str(c.owner_nation))
	var troops := 0
	for a in gs.armies:
		troops += a.size
	parts.append("T%d" % troops)
	parts.append("D%d" % gs.day)
	sim.free()
	return "|".join(parts)

# ------------------------------------------------------------------ 8. 时间分层

func _test_time_layering() -> void:
	print("[8] 时间分层：经济/注粮按月结算，行军按天渐进")
	# 1. 经济按月结算（非 30×）。总金库口径对国家归属免疫（Σ 城 gold_per_month）。
	var gs := preload("res://tests/support/grid_world.gd").new()
	gs.generate_grid_world(12345)
	var sim := Simulation.new()
	sim.setup(gs)
	var before := 0
	for n in gs.nations:
		before += n.treasury_gold
	for _i in range(29):
		sim._advance_day()
	var mid := 0
	for n in gs.nations:
		mid += n.treasury_gold
	_check(mid == before, "1..29 天不应结算经济：%d -> %d" % [before, mid])
	gs.cities[0].war_disruption_until_day = (
		gs.day + Simulation.CITY_WAR_DISRUPTION_DAYS
	)
	var predicted_flows := Simulation.monthly_gold_flows(gs)
	var expected_balance := 0
	for flow in predicted_flows:
		expected_balance += int(flow["balance"])
	sim._advance_day()   # day==30
	var after := 0
	for n in gs.nations:
		after += n.treasury_gold
	var expected_treasury := before + expected_balance
	_check(after == expected_treasury,
		"day30 应结算月收入并扣战争军费：应 %d，实为 %d"
			% [expected_treasury, after])
	sim.free()

	var morale_state := preload("res://tests/support/grid_world.gd").new()
	morale_state.generate_grid_world(12347)
	morale_state.armies.clear()
	var morale_nation := morale_state.nations[0]
	morale_nation.military_payment_ratio = 1.0
	var morale_probe := morale_state.create_army(
		0,
		morale_nation.capital_city_id,
		5000,
		GameState.INITIAL_HEAVY_ARMY_SIZE
	)
	morale_probe.morale = 0.0
	var morale_sim := Simulation.new()
	morale_sim.setup(morale_state)
	morale_sim.diplomacy_enabled = false
	morale_sim._advance_day()
	_check(
		_approx(
			morale_probe.morale,
			morale_probe.max_morale / float(Combat.MORALE_RECOVERY_DAYS)
		),
		"士气恢复必须进入每日时钟：第1天恢复上限的十分之一"
	)
	for _day in range(Combat.MORALE_RECOVERY_DAYS - 1):
		morale_sim._advance_day()
	_check(
		_approx(morale_probe.morale, morale_probe.max_morale),
		"满军费、满补给军队必须在真实推进第10天回满士气"
	)
	morale_sim.free()

	# 2. 注粮半年一次：隔离单测 _resolve_economy 的 day gate（避开消耗干扰）。
	var gs2 := preload("res://tests/support/grid_world.gd").new()
	gs2.generate_grid_world(12345)
	var sim2 := Simulation.new()
	sim2.setup(gs2)
	var nation0 := gs2.nations[0]
	var capital := gs2.cities[nation0.capital_city_id]
	var disrupted_food_city := gs2.cities_of(0)[0]
	disrupted_food_city.war_disruption_until_day = (
		Simulation.CITY_WAR_DISRUPTION_DAYS
	)
	var f0 := capital.food_storage
	var nation0_garrison_demand := (
		Simulation.nation_monthly_garrison_food_demand(gs2, 0)
	)
	var nation0_production := 0
	for city in gs2.cities_of(0):
		nation0_production += Simulation.city_food_output(
			gs2,
			city
		)
	gs2.day = 30
	sim2._resolve_economy()
	_check(
		capital.food_storage == f0 - nation0_garrison_demand,
		"day30 不注粮但应支付守军粮耗：应 %d，实为 %d"
			% [f0 - nation0_garrison_demand, capital.food_storage]
	)
	gs2.day = 180
	sim2._resolve_economy()
	var expected_food_after_half_year := (
		f0 + nation0_production - nation0_garrison_demand * 2
	)
	_check(capital.food_storage == expected_food_after_half_year,
		"day180 全国粮食产出汇入首都并支付两次月度守军粮耗：应 %d，实为 %d"
			% [expected_food_after_half_year, capital.food_storage])
	sim2.free()

	var garrison_state := preload("res://tests/support/grid_world.gd").new()
	garrison_state.generate_grid_world(12346)
	garrison_state.armies.clear()
	var productive_city := garrison_state.cities[0]
	productive_city.gold_per_month = 11
	productive_city.food_per_half_year = 101
	var base_output := productive_city.food_per_half_year
	var food_guard := _make_army(899, 0, 15000, 10, 10)
	food_guard.location_city = productive_city.id
	food_guard.move_from = productive_city.id
	food_guard.state = Army.State.IDLE
	garrison_state.armies.append(food_guard)
	var city_output := Simulation.city_food_output(
		garrison_state,
		productive_city
	)
	var minimum_output := int(floor(
		float(base_output)
			* (
				1.0
				- Simulation.CITY_GARRISON_FOOD_PENALTY_MAX
			)
	))
	_check(
		city_output < base_output
		and city_output >= minimum_output,
		"驻城军应降低城市产粮且减产不得超过30%%：base=%d actual=%d"
			% [base_output, city_output]
	)
	food_guard.on_edge = true
	food_guard.move_to = 1
	var edge_output := Simulation.city_food_output(
		garrison_state,
		productive_city
	)
	_check(
		edge_output == base_output,
		"驻边军不应降低城市产粮：base=%d actual=%d"
			% [base_output, edge_output]
	)
	productive_city.war_disruption_until_day = (
		Simulation.CITY_WAR_DISRUPTION_DAYS
	)
	garrison_state.day = (
		Simulation.CITY_WAR_DISRUPTION_DAYS - 1
	)
	_check(
		Simulation.city_food_output(
			garrison_state,
			productive_city
		) == 50
		and Simulation.city_gold_output(
			garrison_state,
			productive_city
		) == 5,
		"城市战争破坏期内粮食和金钱产量必须降为50%%"
	)
	garrison_state.day = Simulation.CITY_WAR_DISRUPTION_DAYS
	_check(
		Simulation.city_food_output(
			garrison_state,
			productive_city
		) == base_output
		and Simulation.city_gold_output(
			garrison_state,
			productive_city
		) == productive_city.gold_per_month,
		"城市战争结束满一年后应恢复完整粮食和金钱产量"
	)
	var restored_resource_report := DiplomacyAI.resource_report(
		garrison_state,
		productive_city.owner_nation
	)
	garrison_state.day = (
		Simulation.CITY_WAR_DISRUPTION_DAYS - 1
	)
	var disrupted_resource_report := DiplomacyAI.resource_report(
		garrison_state,
		productive_city.owner_nation
	)
	_check(
		float(disrupted_resource_report[
			"monthly_gold_income"
		]) < float(restored_resource_report[
			"monthly_gold_income"
		])
		and float(disrupted_resource_report[
			"monthly_food_production"
		]) < float(restored_resource_report[
			"monthly_food_production"
		]),
		"外交与军备预算必须使用战争破坏后的实际粮金产出"
	)

	# 3. 行军不瞬移：单日 step 上界 = 1/MARCH_DAYS_MIN = 1/10 = 0.1（规格 R1，distance=1 最快）。
	var gs3 := preload("res://tests/support/grid_world.gd").new()
	gs3.generate_grid_world(12345)
	var sim3 := Simulation.new()
	sim3.setup(gs3)
	sim3._advance_day()
	var moving := 0
	var max_prog := 0.0
	for a in gs3.armies:
		if a.state == Army.State.MOVING and a.move_to != -1:
			moving += 1
			max_prog = maxf(max_prog, a.move_progress)
	_check(moving > 0, "首日应有军队开拔行军，实为 %d" % moving)
	_check(max_prog <= 0.1 + 1e-6, "行军单日 step 应 <= 0.1（最快边 10 天），最大进度 %.4f" % max_prog)
	sim3.free()

# ------------------------------------------------------------------ 10. 触发判定（位置驱动）

func _test_trigger_detection() -> void:
	print("[10] 触发判定：相向接触/同向追上触发，相距远/同族不触发")
	# 1. 相向接触 → 触发（X from0 dir+1, Y from1 dir-1，位置交错）
	_check(_detect_count(0.5, 0, 1, 0, 0.5, 1) == 1, "相向接触应触发战斗")
	# 2. 同向后军追上前军 → 触发（回归旧 bug；均 from0 dir+1，gap0.05≤EPS）
	_check(_detect_count(0.50, 0, 1, 0, 0.45, 0) == 1, "同向追上（gap0.05≤EPS）应触发")
	# 3. 相距远 → 不触发（边内可能不开战；均 from0 dir+1，gap0.70>EPS）
	_check(_detect_count(0.20, 0, 1, 0, 0.90, 0) == 0, "同向相距远（gap0.70>EPS）不应触发")
	# 4. 同 nation → 不触发（非敌对）
	_check(_detect_count(0.50, 0, 0, 0, 0.50, 0) == 0, "同族不应触发战斗")


## 在真实边 (0,1) 上布两军并检测，返回新生成战斗数。
##  X: nation nx, from cx(0=city0/1=city1), progress px；Y: nation ny, from cy, progress py。
func _detect_count(px: float, nx: int, ny: int, cx: int, py: float, cy: int) -> int:
	var gs := preload("res://tests/support/grid_world.gd").new()
	gs.generate_grid_world(12345)
	var sim := Simulation.new()
	sim.setup(gs)
	gs.armies.clear()
	gs.battles.clear()
	_place_army_on_edge(gs, 0, nx, cx, 1 - cx, px)
	_place_army_on_edge(gs, 1, ny, cy, 1 - cy, py)
	sim._detect_encounters()
	var n := gs.battles.size()
	sim.free()
	return n

# ------------------------------------------------------------------ 11. 三方战斗（不并肩敌对）

func _test_three_way_battle() -> void:
	print("[11] 三方战斗：最近敌对对先战，各侧单一 nation，第三方不并肩")
	var gs := preload("res://tests/support/grid_world.gd").new()
	gs.generate_grid_world(12345)
	var sim := Simulation.new()
	sim.setup(gs)
	gs.armies.clear()
	gs.battles.clear()
	# 三支互相敌对同向军队（同边 0→1）。A-B 最近（gap0.01）为交战核心。
	var a := _place_army_on_edge(gs, 0, 0, 0, 1, 0.50)
	var b := _place_army_on_edge(gs, 1, 1, 0, 1, 0.49)
	var c := _place_army_on_edge(gs, 2, 2, 0, 1, 0.44)
	var c_prog_before := c.move_progress
	sim._detect_encounters()
	sim._block_passthrough()
	_check(gs.battles.size() == 1, "三方同边应仅形成 1 场核心战斗，实为 %d" % gs.battles.size())
	if gs.battles.size() == 1:
		var bt: Battle = gs.battles[0]
		_check(_single_nation(bt.side_a), "side_a 应单一 nation（不并肩敌对）")
		_check(_single_nation(bt.side_b), "side_b 应单一 nation（不并肩敌对）")
		_check(bt.has_army(a) and bt.has_army(b), "最近敌对对 A-B 应为交战核心")
	# 第三敌国 C：不并肩加入（battle_id 仍 -1），且被卡位不得穿过（未越过交战线 0.50）
	_check(c.battle_id == -1, "真三方 C 与两侧皆异族，不应并入任一侧")
	_check(c.move_progress <= 0.50 + 0.0001, "C 应被卡位、不得穿过交战线（progress %.3f）" % c.move_progress)
	_check(c.move_progress <= c_prog_before + 0.0001, "卡位不应把 C 前拉（仅阻止越过）")
	sim.free()


## 一侧成员是否全为同一 nation（空侧视为真）。
func _single_nation(side: Array) -> bool:
	if side.is_empty():
		return true
	var n: int = side[0].owner_nation
	for a in side:
		if a.owner_nation != n:
			return false
	return true

# ------------------------------------------------------------------ 12. 三方占领（一城一围城方）

func _test_three_way_siege() -> void:
	print("[12] 三方占领：一城一围城方，敌对他国不并肩，同族可汇合")
	var gs := preload("res://tests/support/grid_world.gd").new()
	gs.generate_grid_world(12345)
	var sim := Simulation.new()
	sim.setup(gs)
	var city := gs.cities[63]        # 右下象限 nation3 属城，自带 IDLE 守军
	var edge := gs.edge_of(62, 63)
	_check(edge != null, "边 (62,63) 应存在")
	var city_guard := _make_army(99, city.owner_nation, 1000, 10)
	city_guard.location_city = city.id
	city_guard.move_from = city.id
	city_guard.state = Army.State.IDLE
	gs.armies.append(city_guard)

	# A(nation0) 建立围城
	var a := _make_army(100, 0, 1000, 10)
	a.move_from = 62; a.move_to = 63
	sim._start_or_join_siege(a, city, edge)
	var siege := sim._siege_battle_of(city)
	_check(siege != null and siege.side_b_defends_city, "A 抵达应建带守军 SIEGE")

	# B(nation1) 敌对他国来袭：守军仍在 → 从目标城撤回，不并肩
	gs.cities[62].owner_nation = 1   # 为 B 提供与目标城直接相邻的合法本国退路
	var b := _make_army(101, 1, 1000, 10)
	b.move_from = 62; b.move_to = 63
	sim._start_or_join_siege(b, city, edge)
	_check(siege.side_a.size() == 1, "敌对他国 B 不应并肩围城，side_a 仍为 1")
	_check(b.battle_id == -1 and b.state == Army.State.RETREATING and b.move_from == city.id,
		"B 应从已抵达的目标城连续撤回，不得瞬移回来源城")

	# A2(nation0) 同族多路汇合
	var a2 := _make_army(102, 0, 1000, 10)
	a2.move_from = 62; a2.move_to = 63
	sim._start_or_join_siege(a2, city, edge)
	_check(siege.side_a.size() == 2, "同族 A2 应并入 side_a（多路汇合），实为 %d" % siege.side_a.size())
	_check(_single_nation(siege.side_a), "side_a 应全为 nation0")

	# 全局不变量：所有 SIEGE 的 side_a 恒单一 nation
	var ok := true
	for bt in gs.battles:
		if bt.kind == Battle.Kind.SIEGE and not _single_nation(bt.side_a):
			ok = false
	_check(ok, "全局不变量：每场 SIEGE 的 side_a 必单一 nation")
	sim.free()

# ------------------------------------------------------------------ 13. 多军聚合 + 战力累加 + 增援士气

func _test_multi_army_aggregation() -> void:
	print("[13] 多军聚合：同国靠后友军并入 + 攻击Σ累加 + 防御反拆分漏洞 + 增援回气 + 同点必触发")

	# (a) 增援按 ETA 抵达（item 4）：初始只有接触的核心对开战(1v1)；靠后友军(离战线 0.30)
	#     不瞬间参战，须继续行军逼近己方战线到 REINFORCEMENT_RADIUS 内才加入，最终聚合成 2v2。
	var gs := preload("res://tests/support/grid_world.gd").new(); gs.generate_grid_world(12345)
	var sim := Simulation.new(); sim.setup(gs)
	gs.armies.clear(); gs.battles.clear()
	var a0 := _place_army_on_edge(gs, 0, 0, 0, 1, 0.50)   # A0 n0 norm0.50（接触核心）
	var a1 := _place_army_on_edge(gs, 1, 0, 0, 1, 0.20)   # A1 n0 norm0.20（离战线 0.30，未抵达）
	_place_army_on_edge(gs, 2, 1, 1, 0, 0.50)             # B0 n1 norm0.50（接触核心）
	_place_army_on_edge(gs, 3, 1, 1, 0, 0.20)             # B1 n1 norm0.80（离战线 0.30，未抵达）
	sim._detect_encounters()
	_check(gs.battles.size() == 1, "应仅 1 场战斗，实为 %d" % gs.battles.size())
	if gs.battles.size() == 1:
		var bt0: Battle = gs.battles[0]
		# 初始：仅接触核心对开战，靠后友军尚未抵达 → 1v1（item4 远援不瞬时）。
		_check(bt0.side_a.size() == 1 and bt0.side_b.size() == 1,
			"初始应仅核心对开战 1v1，实为 %dv%d" % [bt0.side_a.size(), bt0.side_b.size()])
		_check(a1.battle_id == -1, "未抵达的靠后友军不应在战斗中")
		# 手动把靠后友军推进到战线附近（模拟 ETA 兑现：0.20→0.40，距 0.50 战线 0.10<半径）。
		a1.move_progress = 0.40
		gs.armies[3].move_progress = 1.0 - 0.40   # B1 对称推进到 norm0.40 附近
		sim._detect_encounters()
		_check(bt0.side_a.size() == 2 and _single_nation(bt0.side_a),
			"靠后友军抵达后 side_a 应聚合 2 支同 n0，实为 %d" % bt0.side_a.size())
		_check(bt0.side_b.size() == 2 and _single_nation(bt0.side_b),
			"靠后友军抵达后 side_b 应聚合 2 支同 n1，实为 %d" % bt0.side_b.size())
	_check(a0.battle_id != -1, "核心军 A0 应在战斗中")
	sim.free()

	# (b) 攻击力 Σ 累加：拆成 2 支（各 1000）与合成 1 支（2000）对同一守军的伤害应相等
	var loss_split := _one_round_side_b_loss([_make_army(0, 0, 1000, 10), _make_army(1, 0, 1000, 10)], [_make_army(2, 1, 3000, 10)], 90)
	var loss_single := _one_round_side_b_loss([_make_army(0, 0, 2000, 10)], [_make_army(2, 1, 3000, 10)], 90)
	_check(loss_split == loss_single, "攻击Σ累加：拆分(%d) 应等于合成(%d)" % [loss_split, loss_single])

	# (c) 防御反拆分漏洞：守军拆成 2×500(def12) 与 1×1000(def12) 承受同一火力，总伤应近似相等
	var loss_def_single := _one_round_side_b_loss([_make_army(0, 0, 2000, 10)], [_make_army(2, 1, 1000, 10, 12)], 91)
	var loss_def_split := _one_round_side_b_loss([_make_army(0, 0, 2000, 10)], [_make_army(2, 1, 500, 10, 12), _make_army(3, 1, 500, 10, 12)], 91)
	_check(absi(loss_def_single - loss_def_split) <= 2, "防御反拆分：单支(%d) 与拆分(%d) 总伤应近似（差≤2）" % [loss_def_single, loss_def_split])

	# 援军到场先保留自身士气，下次野战回合按全侧容量合并。
	var gs2 := preload("res://tests/support/grid_world.gd").new(); gs2.generate_grid_world(12345)
	var sim2 := Simulation.new(); sim2.setup(gs2)
	var tired := _make_army(0, 0, 1000, 10); tired.morale = 0.30
	var defender := _make_army(1, 1, 1000, 10)
	var battle := _make_field_battle([tired], [defender], 0.0, 4)
	var fresh := _make_army(2, 0, 1000, 10); fresh.morale = 1.0
	fresh.move_from = 0; fresh.move_to = 1; fresh.move_progress = 0.5
	sim2._join_field_battle(battle, fresh, battle.edge)
	_check(battle.side_a.size() == 2, "增援后 side_a 应为 2 支")
	_check(battle.reinforce_fresh_a.has(fresh), "援军应登记为本 tick 新增，待统一结算")
	_check(_approx(tired.morale, 0.30, 0.001), "结算前疲劳友军士气不应立即变化，实为 %.3f" % tired.morale)
	_check(_approx(float(battle.shared_morale_summary(battle.side_a).effective), 0.65), "援军合并后的有效士气应为0.65")
	CombatFixture.resolve_round(battle)
	_check(tired.morale < 0.65 and _approx(tired.morale, fresh.morale), "增援后应共享士气且没有额外提振")
	# (d2) 防拆分套利：把 1000 援军拆成 2×500 依次加入，回气总量应与单支 1000 完全一致。
	var tired2 := _make_army(10, 0, 1000, 10); tired2.morale = 0.30
	var battle2 := _make_field_battle([tired2], [_make_army(11, 1, 1000, 10)], 0.0, 4)
	var f1 := _make_army(12, 0, 500, 10); f1.morale = 1.0
	var f2 := _make_army(13, 0, 500, 10); f2.morale = 1.0
	f1.move_from = 0; f1.move_to = 1; f1.move_progress = 0.5
	f2.move_from = 0; f2.move_to = 1; f2.move_progress = 0.5
	sim2._join_field_battle(battle2, f1, battle2.edge)
	sim2._join_field_battle(battle2, f2, battle2.edge)
	CombatFixture.resolve_round(battle2)
	_check(_approx(tired2.morale, tired.morale, 0.000000001), "拆分援军的共享士气应与单支一致")
	sim2.free()

	# (e) 不同数量组合：3v2 与 2v3 均应各形成 1 场并正确聚合
	_check_combo(3, 2)
	_check_combo(2, 3)

	# (f) 同点必触发：两敌军归一化位置完全重合，必开战
	var gs3 := preload("res://tests/support/grid_world.gd").new(); gs3.generate_grid_world(12345)
	var sim3 := Simulation.new(); sim3.setup(gs3)
	gs3.armies.clear(); gs3.battles.clear()
	_place_army_on_edge(gs3, 0, 0, 0, 1, 0.50)   # n0 norm0.50
	_place_army_on_edge(gs3, 1, 1, 1, 0, 0.50)   # n1 norm0.50（重合）
	sim3._detect_encounters()
	_check(gs3.battles.size() == 1, "敌对双方同点(重合)必触发战斗，实为 %d" % gs3.battles.size())
	sim3.free()


## 跑 1 回合，返回 side_b 的总减员（固定种子对照用）。
func _one_round_side_b_loss(side_a: Array, side_b: Array, seed_val: int) -> int:
	var rng := RandomNumberGenerator.new(); rng.seed = seed_val
	var b := _make_field_battle(side_a, side_b, 0.0, 4)
	var before := b.side_size(b.side_b)
	CombatFixture.resolve_round(b)
	return before - b.side_size(b.side_b)


## 在真实边上放 na_count 支 n0 与 nb_count 支 n1（位置紧邻），断言恰 1 场且各侧聚合正确。
func _check_combo(na_count: int, nb_count: int) -> void:
	var gs := preload("res://tests/support/grid_world.gd").new(); gs.generate_grid_world(12345)
	var sim := Simulation.new(); sim.setup(gs)
	gs.armies.clear(); gs.battles.clear()
	var id := 0
	for i in range(na_count):
		_place_army_on_edge(gs, id, 0, 0, 1, 0.50 - i * 0.02)   # n0 from0，norm≈0.50↓
		id += 1
	for j in range(nb_count):
		_place_army_on_edge(gs, id, 1, 1, 0, 0.50 - j * 0.02)   # n1 from1，norm≈0.50↑
		id += 1
	sim._detect_encounters()
	_check(gs.battles.size() == 1, "%dv%d 应仅 1 场，实为 %d" % [na_count, nb_count, gs.battles.size()])
	if gs.battles.size() == 1:
		var bt: Battle = gs.battles[0]
		var count_n0 := 0
		var count_n1 := 0
		for army in bt.side_a + bt.side_b:
			if army.owner_nation == 0:
				count_n0 += 1
			elif army.owner_nation == 1:
				count_n1 += 1
		_check(
			count_n0 == na_count and count_n1 == nb_count,
			"%dv%d 聚合应保持各国成员数 %d/%d，实为 %d/%d（不绑定 A/B 侧位）"
				% [
					na_count,
					nb_count,
					na_count,
					nb_count,
					count_n0,
					count_n1,
				]
		)
	sim.free()

# ------------------------------------------------------------------ 14. 三方卡位串行（同点必战、不得穿过）

func _test_three_way_serial() -> void:
	print("[14] 三方串行：第三敌国卡位不得穿过交战点，A-B 分胜负后立即与幸存者接战")
	var gs := preload("res://tests/support/grid_world.gd").new(); gs.generate_grid_world(12345)
	var sim := Simulation.new(); sim.setup(gs)
	gs.armies.clear(); gs.battles.clear()
	var a := _place_army_on_edge(gs, 0, 0, 0, 1, 0.50)   # n0 norm0.50
	var b := _place_army_on_edge(gs, 1, 1, 1, 0, 0.50)   # n1 norm0.50（与 A 重合，必战）
	var c := _place_army_on_edge(gs, 2, 2, 0, 1, 0.55)   # n2 norm0.55（已越过交战线 0.50）

	# 步骤 1：A-B 开战；C 被卡位、拉回至交战线（不得穿过），且未并入任一侧
	sim._detect_encounters()
	sim._block_passthrough()
	_check(gs.battles.size() == 1 and gs.battles[0].has_army(a) and gs.battles[0].has_army(b), "A-B 应形成 1 场核心战斗")
	_check(c.battle_id == -1, "第三敌国 C 不应并入两方制战斗")
	_check(c.move_progress < 0.55 - 0.0001 and _approx(c.move_progress, 0.50, 0.001),
		"C 应被卡回交战线(0.50)、不得穿过，实为 %.3f" % c.move_progress)

	# 步骤 2：强制 A-B 分胜负（守军 B 覆灭）→ A 幸存；再检测应让 C 与 A 立即接战（串行化）
	b.size = 0
	sim._resolve_battles()
	_check(gs.battles.is_empty(), "A-B 结束后活跃战斗应清空")
	_check(a.state == Army.State.MOVING and a.battle_id == -1, "胜方 A 应恢复 MOVING 待续战")
	sim._detect_encounters()
	_check(gs.battles.size() == 1, "分胜负后 C 应立即与幸存者 A 接战（串行），实为 %d 场" % gs.battles.size())
	if gs.battles.size() == 1:
		_check(gs.battles[0].has_army(a) and gs.battles[0].has_army(c), "新战斗应为 A vs C")
		_check(c.state == Army.State.FIGHTING, "C 应进入战斗（不再穿过）")
	sim.free()

	# 完全同构多方接战不存在镜像等变的单值核心对。改变军队 ID 或数组顺序时，
	# 必须一致地延迟决策，不能回退到先出现的 pair。
	var core_nations := {}
	var ambiguous_frozen := true
	for perm in [[10, 11, 12], [12, 11, 10], [11, 12, 10]]:
		var gs2 := preload("res://tests/support/grid_world.gd").new(); gs2.generate_grid_world(12345)
		var sim2 := Simulation.new(); sim2.setup(gs2)
		gs2.armies.clear(); gs2.battles.clear()
		for nation_id in range(3):
			gs2.nations[nation_id].capital_city_id = 0
		# 三支军物理状态及势力镜像轨道锚点完全相同，所有候选 pair 等价。
		var symmetric_edge := gs2.edge_of(0, 1)
		var symmetric_armies: Array[Army] = [
			_place_army_on_edge(
				gs2, perm[0], 0, 0, 1, 0.50
			),
			_place_army_on_edge(
				gs2, perm[1], 1, 1, 0, 0.50
			),
			_place_army_on_edge(
				gs2, perm[2], 2, 1, 0, 0.50
			),
		]
		sim2._detect_encounters()
		sim2._advance_movement()
		for symmetric_army in symmetric_armies:
			if not _approx(
				sim2._norm_pos(symmetric_army, symmetric_edge),
				0.50
			):
				ambiguous_frozen = false
		var key := "none"
		if gs2.battles.size() >= 1:
			var bt := gs2.battles[0]
			# 记录核心对的「势力对」（物理归属），与具体 id 无关。
			var na2: int = bt.side_a[0].owner_nation if not bt.side_a.is_empty() else -1
			var nb2: int = bt.side_b[0].owner_nation if not bt.side_b.is_empty() else -1
			var lo := mini(na2, nb2); var hi := maxi(na2, nb2)
			key = "%d-%d" % [lo, hi]
		core_nations[key] = true
		sim2.free()
	_check(
		core_nations.size() == 1
			and core_nations.has("none")
			and not ambiguous_frozen,
		"完全同构三国接战应一致脱离，不能永久冻结或按 ID 任取核心对：%s"
			% str(core_nations.keys())
	)

	# 同一国家的多支等价军不构成“核心国家对”歧义。生产故障中的
	# 2v1 形状必须直接聚合开战，不能把三军永久冻结在接触面。
	var gs3 := preload("res://tests/support/grid_world.gd").new(); gs3.generate_grid_world(12345)
	var sim3 := Simulation.new(); sim3.setup(gs3)
	gs3.armies.clear(); gs3.battles.clear()
	var attackers: Array[Army] = [
		_place_army_on_edge(gs3, 173, 0, 0, 1, 0.45),
		_place_army_on_edge(gs3, 243, 0, 0, 1, 0.45),
	]
	for attacker in attackers:
		attacker.size = 4727
		attacker.max_size = GameState.INITIAL_HEAVY_ARMY_SIZE
	var defender := _place_army_on_edge(gs3, 500, 1, 1, 0, 0.45)
	defender.size = 15000
	defender.max_size = 15000
	sim3._detect_encounters()
	var symmetric_two_vs_one := (
		gs3.battles.size() == 1
		and gs3.battles[0].side_a.size() + gs3.battles[0].side_b.size() == 3
	)
	for participant in attackers + [defender]:
		symmetric_two_vs_one = (
			symmetric_two_vs_one
			and participant.state == Army.State.FIGHTING
			and not participant.encounter_blocked
		)
	_check(
		symmetric_two_vs_one,
		"完全同构 2v1 必须按国家对聚合成一场战斗，不得冻结"
	)
	sim3.free()


# ------------------------------------------------------------------ 16. 相向错身

func _test_crosspass_field_priority() -> void:
	print("[16] 相向错身：两敌军同在一条边相向而行，先到边末端者应野战交火而非离边攻城")

	# 找一条敌对相邻边（c1 属 nation != c2 属 nation）
	var gs := preload("res://tests/support/grid_world.gd").new(); gs.generate_grid_world(12345)
	var sim := Simulation.new(); sim.setup(gs)
	var c1 := -1; var c2 := -1
	for e in gs.edges:
		if gs.cities[e.city_a].owner_nation != gs.cities[e.city_b].owner_nation:
			c1 = e.city_a; c2 = e.city_b; break
	_check(c1 != -1, "应存在一条敌对相邻边")
	var edge := gs.edge_of(c1, c2)
	gs.armies.clear(); gs.battles.clear()

	# R：c1→c2，已推进到边末端 0.99（下一 tick 将到达 c2 敌城）
	var R := _make_army(1, gs.cities[c1].owner_nation, 1000, 10)
	R.state = Army.State.MOVING; R.move_from = c1; R.move_to = c2; R.move_progress = 0.99; R.on_edge = true
	edge.passing_count += 1; gs.armies.append(R)
	# G：c2→c1，刚上边 0.0（相向）
	var G := _make_army(2, gs.cities[c2].owner_nation, 1000, 10)
	G.state = Army.State.MOVING; G.move_from = c2; G.move_to = c1; G.move_progress = 0.0; G.on_edge = true
	edge.passing_count += 1; gs.armies.append(G)

	sim._advance_movement()

	var has_field := false; var has_siege := false
	for b in gs.battles:
		if b.finished: continue
		if b.kind == Battle.Kind.FIELD: has_field = true
		if b.kind == Battle.Kind.SIEGE: has_siege = true
	_check(has_field, "相向两军应触发野战 FIELD（先到边末端者不得离边攻城穿过）")
	_check(not has_siege, "不应变成攻城 SIEGE（那意味着 R 错身进城了）")
	_check(R.state == Army.State.FIGHTING and G.state == Army.State.FIGHTING, "R、G 均应进入 FIGHTING")
	_check(R.battle_id == G.battle_id and R.battle_id != -1, "R、G 应在同一场野战")

	sim.free()

	# 野战胜方已越过道路终点时，败方溃退军不能在下一 tick 重复拉起 FIELD。
	# 溃退军应先落入目标城，随后胜方进城并与守军统一触发 SIEGE。
	var endpoint_state := preload("res://tests/support/grid_world.gd").new()
	endpoint_state.generate_grid_world(1601)
	endpoint_state.armies.clear()
	endpoint_state.battles.clear()
	var endpoint_from := -1
	var endpoint_city := -1
	for endpoint_edge in endpoint_state.edges:
		if (
			endpoint_state.cities[
				endpoint_edge.city_a
			].owner_nation
			!= endpoint_state.cities[
				endpoint_edge.city_b
			].owner_nation
		):
			endpoint_from = endpoint_edge.city_a
			endpoint_city = endpoint_edge.city_b
			break
	var endpoint_edge := endpoint_state.edge_of(
		endpoint_from,
		endpoint_city
	)
	var endpoint_attacker := _make_army(
		1601,
		endpoint_state.cities[endpoint_from].owner_nation,
		5000,
		10
	)
	endpoint_attacker.state = Army.State.MOVING
	endpoint_attacker.location_city = endpoint_from
	endpoint_attacker.move_from = endpoint_from
	endpoint_attacker.move_to = endpoint_city
	endpoint_attacker.move_progress = 1.10
	endpoint_attacker.on_edge = true
	var endpoint_retreater := _make_army(
		1602,
		endpoint_state.cities[endpoint_city].owner_nation,
		3000,
		10
	)
	endpoint_retreater.state = Army.State.RETREATING
	endpoint_retreater.location_city = endpoint_city
	endpoint_retreater.move_from = endpoint_from
	endpoint_retreater.move_to = endpoint_city
	endpoint_retreater.move_progress = 1.0
	endpoint_retreater.on_edge = true
	var endpoint_guard := _make_army(
		1603,
		endpoint_state.cities[endpoint_city].owner_nation,
		5000,
		10
	)
	endpoint_guard.location_city = endpoint_city
	endpoint_guard.move_from = endpoint_city
	endpoint_state.armies.append_array([
		endpoint_attacker,
		endpoint_retreater,
		endpoint_guard,
	])
	endpoint_edge.passing_count = 2
	endpoint_edge.occupied = true
	var endpoint_sim := Simulation.new()
	root.add_child(endpoint_sim)
	endpoint_sim.setup(endpoint_state)
	endpoint_sim._advance_movement()
	var endpoint_siege := endpoint_sim._siege_battle_of(
		endpoint_state.cities[endpoint_city]
	)
	var endpoint_field_exists := endpoint_state.battles.any(
		func(battle: Battle) -> bool:
			return (
				not battle.finished
				and battle.kind == Battle.Kind.FIELD
			)
	)
	_check(
		endpoint_siege != null
			and endpoint_siege.has_army(
				endpoint_attacker
			)
			and not endpoint_siege.has_army(endpoint_retreater)
			and endpoint_siege.has_army(endpoint_guard)
			and not endpoint_field_exists,
		"道路野战胜方越过终点后应进城触发州治野战，溃退军不得重新参战"
	)
	endpoint_sim.free()

# ------------------------------------------------------------------ 17. 五千容量边错身：敌军不占本国方向容量

func _test_capacity_no_block_enemy() -> void:
	print("[17] 五千容量边：敌军先占边，迎战方不得被交通容量挡在城里错身穿过")

	var gs := preload("res://tests/support/grid_world.gd").new(); gs.generate_grid_world(12345)
	var sim := Simulation.new(); sim.setup(gs)
	var c1 := -1; var c2 := -1
	for e in gs.edges:
		if gs.cities[e.city_a].owner_nation != gs.cities[e.city_b].owner_nation:
			c1 = e.city_a; c2 = e.city_b; break
	_check(c1 != -1, "应存在一条敌对相邻边")
	var edge := gs.edge_of(c1, c2)
	edge.max_manpower = Edge.MIN_MANPOWER
	edge.distance = 3; edge.danger = 0.0
	gs.armies.clear(); gs.battles.clear()

	# R 是主战军编制，但任意正容量道路都允许其完整进入。
	var R := _make_army(1, gs.cities[c1].owner_nation, 1000, 10)
	R.max_size = GameState.INITIAL_HEAVY_ARMY_SIZE
	R.state = Army.State.MOVING; R.move_from = c1; R.move_to = -1
	R.location_city = c1; R.path = [c2] as Array[int]
	gs.armies.append(R)
	sim._begin_next_leg(R)
	_check(R.on_edge and R.move_to == c2, "R 应占用五千运输边 (on_edge)")
	_check(edge.passing_count == 1, "边容量应已打满 passing_count=1")

	# G 从 c2 出发迎战：容量已满，但对手在边上 → 必须放行，不得被卡在城里
	var G := _make_army(2, gs.cities[c2].owner_nation, 1000, 10)
	G.state = Army.State.MOVING; G.move_from = c2; G.move_to = -1
	G.location_city = c2; G.path = [c1] as Array[int]
	gs.armies.append(G)
	sim._begin_next_leg(G)
	_check(G.on_edge and G.move_to == c1,
		"迎战方 G 应无视 capacity 进入敌军所在边（on_edge=%s move_to=%d），而非被卡在城里" % [G.on_edge, G.move_to])

	# 推进若干 tick：两军相向应野战，不得错身成攻城
	var has_field := false; var has_siege := false
	for i in range(200):
		sim._advance_movement()
		for b in gs.battles:
			if b.finished: continue
			if b.kind == Battle.Kind.FIELD: has_field = true
			if b.kind == Battle.Kind.SIEGE: has_siege = true
		if has_field or has_siege: break
	_check(has_field, "单槽边相向两军应野战 FIELD")
	_check(not has_siege, "不应错身成攻城 SIEGE（迎战方被挡在城里的旧 bug）")

	sim.free()

# ------------------------------------------------------------------ 17b. 分方向友军容量

func _test_directional_friendly_capacity() -> void:
	print("[17b] 军事二值通行：正容量不限同向军队，0容量断路")
	var gs := preload("res://tests/support/grid_world.gd").new()
	gs.generate_grid_world(1717)
	var sim := Simulation.new()
	sim.setup(gs)
	gs.armies.clear()
	gs.battles.clear()
	var from_city := -1
	var to_city := -1
	for edge in gs.edges:
		if gs.cities[edge.city_a].owner_nation == gs.cities[edge.city_b].owner_nation:
			from_city = edge.city_a
			to_city = edge.city_b
			break
	var edge := gs.edge_of(from_city, to_city)
	edge.max_manpower = 15000
	edge.passing_count = 0
	var nation_id := gs.cities[from_city].owner_nation

	var first := _make_army(1700, nation_id, 13021, 10)
	first.max_size = GameState.INITIAL_HEAVY_ARMY_SIZE
	first.state = Army.State.MOVING
	first.location_city = from_city
	first.move_from = from_city
	first.path = [to_city] as Array[int]
	gs.armies.append(first)
	sim._begin_next_leg(first)
	_check(first.on_edge and first.move_to == to_city, "首支同向友军应进入边")

	var same_direction := _make_army(1701, nation_id, 1000, 10)
	same_direction.max_size = GameState.INITIAL_HEAVY_ARMY_SIZE
	same_direction.state = Army.State.MOVING
	same_direction.location_city = from_city
	same_direction.move_from = from_city
	same_direction.path = [to_city] as Array[int]
	gs.armies.append(same_direction)
	sim._begin_next_leg(same_direction)
	_check(
		same_direction.on_edge
			and same_direction.move_to == to_city,
		"任意正容量道路必须允许第二支同向主战军同时进入"
	)

	var reverse := _make_army(1702, nation_id, 1000, 10)
	reverse.state = Army.State.MOVING
	reverse.location_city = to_city
	reverse.move_from = to_city
	reverse.path = [from_city] as Array[int]
	gs.armies.append(reverse)
	sim._begin_next_leg(reverse)
	_check(reverse.on_edge and reverse.move_to == from_city,
		"同国反方向使用独立容量，应允许进入")

	var enemy_nation := (nation_id + 1) % gs.nations.size()
	var enemy := _make_army(1703, enemy_nation, 1000, 10)
	enemy.state = Army.State.MOVING
	enemy.location_city = from_city
	enemy.move_from = from_city
	enemy.path = [to_city] as Array[int]
	gs.armies.append(enemy)
	sim._begin_next_leg(enemy)
	_check(enemy.on_edge and enemy.move_to == to_city,
		"敌军不得占用本国同方向 capacity，必须允许追逐/接战")
	_check(edge.passing_count == 4,
		"正向双主战军、反向友军和敌军应能同时位于道路上")

	gs.armies.clear()
	gs.battles.clear()
	edge.passing_count = 0
	edge.occupied = false
	edge.max_manpower = Edge.TERRAIN_LOW_MANPOWER
	var low_road_heavy := _make_army(
		1720,
		nation_id,
		15000,
		10
	)
	low_road_heavy.max_size = GameState.INITIAL_HEAVY_ARMY_SIZE
	low_road_heavy.state = Army.State.MOVING
	low_road_heavy.location_city = from_city
	low_road_heavy.move_from = from_city
	low_road_heavy.path = [to_city] as Array[int]
	gs.armies.append(low_road_heavy)
	sim._begin_next_leg(low_road_heavy)
	var low_road_waiter := _make_army(
		1721,
		nation_id,
		5000,
		10
	)
	low_road_waiter.max_size = Edge.MIN_MANPOWER
	low_road_waiter.state = Army.State.MOVING
	low_road_waiter.location_city = from_city
	low_road_waiter.move_from = from_city
	low_road_waiter.path = [to_city] as Array[int]
	gs.armies.append(low_road_waiter)
	sim._begin_next_leg(low_road_waiter)
	_check(
		low_road_heavy.on_edge
			and low_road_waiter.on_edge
			and low_road_waiter.move_to == to_city,
		"10000正面道路必须允许15000主战军与后续军队同时通行"
	)

	gs.armies.clear()
	gs.battles.clear()
	edge.passing_count = 0
	edge.occupied = false
	edge.max_manpower = Edge.TERRAIN_STANDARD_MANPOWER
	var standard_road_holder := _make_army(
		1730,
		nation_id,
		5000,
		10
	)
	standard_road_holder.max_size = Edge.MIN_MANPOWER
	standard_road_holder.state = Army.State.MOVING
	standard_road_holder.location_city = from_city
	standard_road_holder.move_from = from_city
	standard_road_holder.path = [to_city] as Array[int]
	gs.armies.append(standard_road_holder)
	sim._begin_next_leg(standard_road_holder)
	standard_road_holder.state = Army.State.HOLDING
	var standard_road_attacker := _make_army(
		1731,
		nation_id,
		15000,
		10
	)
	standard_road_attacker.max_size = Edge.STANDARD_MANPOWER
	standard_road_attacker.state = Army.State.MOVING
	standard_road_attacker.location_city = from_city
	standard_road_attacker.move_from = from_city
	standard_road_attacker.path = [to_city] as Array[int]
	gs.armies.append(standard_road_attacker)
	sim._begin_next_leg(standard_road_attacker)
	_check(
		standard_road_holder.on_edge
		and standard_road_attacker.on_edge,
		"20000 容量边应同时容纳5000驻边残编军和15000进攻主战军"
	)
	var standard_road_overflow := _make_army(
		1732,
		nation_id,
		5000,
		10
	)
	standard_road_overflow.max_size = Edge.MIN_MANPOWER
	standard_road_overflow.state = Army.State.MOVING
	standard_road_overflow.location_city = from_city
	standard_road_overflow.move_from = from_city
	standard_road_overflow.path = [to_city] as Array[int]
	gs.armies.append(standard_road_overflow)
	sim._begin_next_leg(standard_road_overflow)
	_check(
		standard_road_overflow.on_edge
			and standard_road_overflow.move_to == to_city,
		"正容量道路已有轻主战军时，额外同向军仍应立即进入"
	)

	var blocked_from := gs.nations[nation_id].capital_city_id
	var blocked_to: int = gs.neighbors(blocked_from)[0]
	for neighbor in gs.neighbors(blocked_from):
		gs.edge_of(blocked_from, neighbor).max_manpower = 0
	var blocked := _make_army(1704, nation_id, 1000, 10)
	blocked.state = Army.State.MOVING
	blocked.location_city = blocked_from
	blocked.move_from = blocked_from
	blocked.path = [blocked_to] as Array[int]
	gs.armies.append(blocked)
	sim._begin_next_leg(blocked)
	_check(
		blocked.state == Army.State.IDLE
		and not blocked.on_edge
		and blocked.path.is_empty(),
		"0 容量边必须使旧行军路径失效，不能让军队永久排队"
	)
	var blocked_field := Pathfinding.dijkstra_field(gs, blocked_from)
	_check(
		float(blocked_field["dist"][blocked_to]) == INF,
		"军事寻路必须跳过 0 容量边"
	)
	sim.free()


# ------------------------------------------------------------------ 17c. 正式高度图主战军二值通行

func _test_march_time_linear() -> void:
	print("[18] R1 行军：10 天起步，按真实距离线性增长且不封顶")
	# 边界：distance=1 → 10 天；此后每单位增加 5 天。
	_check(_approx(Simulation.march_days(1), 10.0), "distance=1 应 10 天，实为 %.1f" % Simulation.march_days(1))
	_check(_approx(Simulation.march_days(5), 30.0), "distance=5 应 30 天，实为 %.1f" % Simulation.march_days(5))
	_check(_approx(Simulation.march_days(3), 20.0), "distance=3 应 20 天（线性中点），实为 %.1f" % Simulation.march_days(3))
	# 非法距离夹到下界；超长距离继续增长，不能被 30 天截平。
	_check(Simulation.march_days(0) >= 10.0, "distance=0 应夹到下界 >=10，实为 %.1f" % Simulation.march_days(0))
	_check(
		_approx(Simulation.march_days(99), 500.0),
		"distance=99 应按线性关系得到500天，不得被30天封顶，实为 %.1f"
			% Simulation.march_days(99)
	)
	# 单调性：长度越大，时间不减。
	var mono := true
	for d in range(1, 8):
		if Simulation.march_days(d + 1) < Simulation.march_days(d):
			mono = false
	_check(mono, "行军时间应随距离单调不减")
	# 端到端：distance=1 的边，10 个 tick 恰好走完（progress>=1）。
	var gs := preload("res://tests/support/grid_world.gd").new()
	gs.generate_grid_world(999)
	var sim := Simulation.new()
	sim.setup(gs)
	var c1 := -1; var c2 := -1
	for e in gs.edges:
		if gs.cities[e.city_a].owner_nation == gs.cities[e.city_b].owner_nation:
			c1 = e.city_a; c2 = e.city_b; break
	var edge := gs.edge_of(c1, c2)
	edge.distance = 1; edge.danger = 0.0; edge.max_manpower = 45000
	gs.armies.clear(); gs.battles.clear()
	var mover := _make_army(1, gs.cities[c1].owner_nation, 500, 10)
	mover.state = Army.State.MOVING; mover.move_from = c1; mover.move_to = c2
	mover.location_city = c1; mover.on_edge = true; mover.move_progress = 0.0
	gs.armies.append(mover)
	for i in range(9):
		mover.move_progress += 1.0 / Simulation.march_days(edge.distance)
	_check(mover.move_progress < 1.0, "9 天（<10）不应走完 distance=1 的边，progress=%.3f" % mover.move_progress)
	mover.move_progress += 1.0 / Simulation.march_days(edge.distance)
	_check(mover.move_progress >= 1.0 - 1e-6, "10 天应走完 distance=1 的边，progress=%.3f" % mover.move_progress)
	sim.free()

# ------------------------------------------------------------------ 19. R2 围城时间标定

func _test_siege_food_clock() -> void:
	print("[20] R3 粮草：被围约 90 天耗尽 + 补给孤岛 + 粮尽城防大幅降")
	var gs := preload("res://tests/support/grid_world.gd").new()
	gs.generate_grid_world(2024)
	var sim := Simulation.new()
	sim.setup(gs)
	# 找一条敌对边，让攻方从 c1 围攻守方城 c2。
	var c1 := -1; var c2 := -1
	for e in gs.edges:
		if gs.cities[e.city_a].owner_nation != gs.cities[e.city_b].owner_nation:
			c1 = e.city_a; c2 = e.city_b; break
	var city := gs.cities[c2]
	_set_single_warehouse(gs, city.owner_nation, c2, 90) # 首都被围：90 粮 → 90 天
	gs.armies.clear(); gs.battles.clear()
	# 手工建立一场围城（守军强、攻方弱，长期不破城，只观察粮草时钟）。
	var edge := gs.edge_of(c1, c2)
	var siege := gs.new_battle(Battle.Kind.SIEGE)
	siege.edge = edge; siege.city = city
	siege.contact_dist_a = float(maxi(edge.distance, 1)); siege.contact_dist_b = 0.0
	var atk := _make_army(90, gs.cities[c1].owner_nation, 100, 10)   # 弱攻，不破城
	atk.state = Army.State.FIGHTING; atk.battle_id = siege.id
	siege.side_a.append(atk)
	# 守军困在被围城 c2 内（补给孤岛：只能吃本城存粮）。
	var garr := _make_army(91, gs.cities[c2].owner_nation, 200, 10)
	garr.is_city_garrison = true # This fixture tests the virtual city siege clock.
	garr.state = Army.State.FIGHTING; garr.battle_id = siege.id; garr.location_city = c2
	siege.side_b.append(garr); siege.side_b_defends_city = true
	gs.armies = [atk, garr] as Array[Army]
	# 补给孤岛：被围城不能作供给源，且被围守军只能吃本城存粮。
	_check(gs.city_under_siege(c2), "c2 应处于被围状态")
	var supply := Pathfinding.nearest_supply_city(gs, garr)
	_check(supply.size() >= 1 and supply[0] == c2,
		"被围守军补给源应锁死为本城 c2（补给孤岛），实为 %s" % str(supply))
	# 真实调度中的第 30 天会先月度补给再每日围城消耗；守军不能被重复扣粮。
	for i in range(29):
		sim._drain_siege_food()
	sim._resolve_supply()
	sim._drain_siege_food()
	_check(city.food_storage == 60,
		"围城 30 天应只消耗每日 30 粮，不得叠加守军月耗；实为 %d" % city.food_storage)
	city.food_storage = 90
	# 每日耗粮：跑 89 天应仍有粮，第 90 天耗尽。
	for i in range(89):
		sim._drain_siege_food()
	_check(city.food_storage == 1, "被围 89 天应剩 1 粮（90-89），实为 %d" % city.food_storage)
	sim._drain_siege_food()
	_check(city.food_storage == 0, "被围 90 天粮草应耗尽，实为 %d" % city.food_storage)
	# 再耗不会变负。
	sim._drain_siege_food()
	_check(city.food_storage == 0, "耗尽后不应变负，实为 %d" % city.food_storage)
	# 粮尽后守军补给源断绝（本城无粮，且被围无法外求）→ 返回 -1。
	var supply_starved := Pathfinding.nearest_supply_city(gs, garr)
	_check(supply_starved.is_empty() or supply_starved[0] == -1,
		"粮尽后被围守军应断绝补给（补给孤岛），实为 %s" % str(supply_starved))
	_check(
		Combat.SIEGE_STARVE_DEF_MULT < 1.0,
		"粮尽必须降低城市守军战斗效率"
	)
	sim.free()

# ------------------------------------------------------------------ 21. item 7 弱攻不再机制撤离

func _test_morale_retreat_recovery() -> void:
	print("[22] 士气崩溃：向首都纵深撤退 + 驻城耗粮恢复 + 满士气/粮尽解锁")
	var gs := preload("res://tests/support/grid_world.gd").new()
	gs.generate_grid_world(777)
	var sim := Simulation.new()
	sim.setup(gs)
	gs.armies.clear()
	gs.battles.clear()
	for nation in gs.nations:
		nation.manpower_pool = 0

	# 撤退路线不得把敌城当作中间节点；起点刚失守时仍允许直接离开敌城。
	var route_state := preload("res://tests/support/grid_world.gd").new()
	route_state.generate_grid_world(778)
	for city in route_state.cities:
		city.owner_nation = 1
	route_state.cities[0].owner_nation = 0
	route_state.cities[2].owner_nation = 0
	var route_army := _make_army(499, 0, 100, 10)
	route_army.location_city = 0
	route_army.move_from = 0
	var blocked_route := Pathfinding.nearest_friendly_city(route_state, route_army, 0)
	_check(blocked_route.is_empty(),
		"友城之间仅能穿越敌城时应判定无撤退路线，实为 %s" % str(blocked_route))
	route_state.cities[1].owner_nation = 0
	var friendly_route := Pathfinding.nearest_friendly_city(route_state, route_army, 0)
	_check(friendly_route == [1],
		"中间节点恢复为本国后应撤至最近友城 1，实为 %s" % str(friendly_route))
	route_state.cities[0].owner_nation = 1
	var hostile_start_route := Pathfinding.nearest_friendly_city(route_state, route_army, 0)
	_check(hostile_start_route == [1],
		"起点刚失守时应允许离开敌城进入最近友城 1，实为 %s" % str(hostile_start_route))
	var ally_state := preload("res://tests/support/grid_world.gd").new()
	ally_state.generate_grid_world(779)
	ally_state.armies.clear()
	for ally_city in ally_state.cities:
		ally_city.owner_nation = 1
	ally_state.cities[1].owner_nation = 2
	ally_state.cities[2].owner_nation = 0
	ally_state.set_diplomatic_relation(
		0,
		2,
		GameState.DiplomaticRelation.ALLIED
	)
	var ally_retreat := _make_army(498, 0, 1000, 10)
	ally_retreat.location_city = 0
	ally_retreat.move_from = 0
	ally_retreat.morale = 0.0
	ally_state.armies.append(ally_retreat)
	var ally_route := Pathfinding.nearest_friendly_city(
		ally_state,
		ally_retreat,
		0
	)
	_check(
		ally_route == [1],
		"败军应优先撤入最近的盟友城市，实为 %s"
			% str(ally_route)
	)
	var ally_sim := Simulation.new()
	ally_sim.setup(ally_state)
	ally_sim._start_morale_retreat_from_city(
		ally_retreat,
		0,
		0
	)
	var ally_guard := 0
	while (
		ally_retreat.state == Army.State.RETREATING
		and ally_guard < 40
	):
		ally_sim._advance_movement()
		ally_guard += 1
	_check(
		ally_retreat.state == Army.State.RECOVERING
		and ally_retreat.location_city == 1,
		"败军抵达盟友城市后应进入恢复状态"
	)
	ally_sim.free()

	# 找同国相邻边；军队在靠近 c2 的 80% 位置崩溃，应继续到更近的 c2，而非固定退回 c1。
	var c1 := -1
	var c2 := -1
	for e in gs.edges:
		if gs.cities[e.city_a].owner_nation == gs.cities[e.city_b].owner_nation:
			c1 = e.city_a
			c2 = e.city_b
			break
	var edge := gs.edge_of(c1, c2)
	var broken := _make_army(500, gs.cities[c1].owner_nation, 1000, 10)
	broken.morale = 0.0
	broken.state = Army.State.FIGHTING
	broken.move_from = c1
	broken.move_to = c2
	broken.move_progress = 0.8
	broken.location_city = c1
	broken.on_edge = true
	edge.passing_count = 1
	gs.armies.append(broken)

	sim._finish_field([] as Array[Army], [broken] as Array[Army])
	_check(broken.state == Army.State.RETREATING, "零士气败军应进入 RETREATING")
	_check(broken.move_to == c2 and _approx(broken.move_progress, 0.8),
		"应从真实位置走向更近端点 c2，且不能瞬移；move_to=%d progress=%.2f" % [broken.move_to, broken.move_progress])
	sim._ai_assign_targets()
	_check(broken.state == Army.State.RETREATING, "撤退途中不得被 AI 重新分配进攻目标")

	var guard := 0
	while broken.state == Army.State.RETREATING and guard < 240:
		sim._advance_movement()
		guard += 1
	var recovery_city := broken.location_city
	_check(
		broken.state == Army.State.RECOVERING
		and recovery_city >= 0
		and gs.cities[recovery_city].owner_nation == broken.owner_nation
		and not gs.city_under_siege(recovery_city),
		"败军应沿首都纵深抵达安全本国城并进入 RECOVERING，state=%d city=%d"
			% [broken.state, recovery_city]
	)
	_check(
		gs.army_at_city(recovery_city) == broken,
		"RECOVERING 军队应计入最终恢复城守军，不能被视为空城"
	)
	sim._ai_assign_targets()
	_check(broken.state == Army.State.RECOVERING, "恢复驻守期间不得执行下一步行动")

	# RECOVERING 不走普通补给扣粮，只由恢复结算消费本城资源，避免双重扣除。
	_set_single_warehouse(gs, broken.owner_nation, recovery_city, 100)
	sim._resolve_supply()
	_check(gs.cities[recovery_city].food_storage == 100, "RECOVERING 不应被普通补给重复扣粮")
	for _day in range(Combat.MORALE_RECOVERY_DAYS - 1):
		sim._recover_morale()
	_check(
		_approx(
			broken.morale,
			broken.max_morale
				* float(Combat.MORALE_RECOVERY_DAYS - 1)
				/ float(Combat.MORALE_RECOVERY_DAYS)
		)
			and broken.state == Army.State.RECOVERING,
		"恢复驻军回满前一日必须保持RECOVERING且未满士气"
	)
	sim._recover_morale()
	var full_recovery_food_demand := int(floor(
		float(ceil(
			float(broken.max_size) * Simulation.RECOVERY_FOOD_PER_CAPITA
		))
			* float(Combat.MORALE_RECOVERY_DAYS)
			/ float(Simulation.DAYS_PER_MONTH)
			+ 0.000001
	))
	_check(
		broken.state == Army.State.IDLE
			and _approx(broken.morale, broken.max_morale)
			and gs.cities[recovery_city].food_storage
				== 100 - full_recovery_food_demand,
		"恢复驻军必须按配置天数回满并解除驻守；应耗%d粮，实为morale=%.2f food=%d"
			% [
				full_recovery_food_demand,
				broken.morale,
				gs.cities[recovery_city].food_storage,
			]
	)

	# 对照：资源不足时按比例恢复，粮尽立即解除驻守，但保留未满士气。
	gs.armies.clear()
	var starved := _make_army(501, broken.owner_nation, 1000, 10)
	starved.morale = 0.0
	starved.state = Army.State.RECOVERING
	starved.location_city = recovery_city
	starved.move_from = recovery_city
	starved.supply_food_debt = 3.0
	gs.armies.append(starved)
	_set_single_warehouse(gs, starved.owner_nation, recovery_city, 2)
	sim._recover_morale()
	_check(gs.cities[recovery_city].food_storage == 0, "恢复资源不足时应耗尽本城剩余粮食")
	_check(starved.state == Army.State.IDLE, "城内恢复资源耗尽后应解除强制驻守")
	_check(
		starved.morale > 0.0
			and starved.morale
				< starved.max_morale
					/ float(Combat.MORALE_RECOVERY_DAYS),
		"资源不足应按供给比例部分恢复，实为 %.3f" % starved.morale)

	# 城市恢复期间若易主，旧城主驻军必须被统一驱逐，不能滞留敌城。
	starved.state = Army.State.RECOVERING
	var old_owner := starved.owner_nation
	_set_warehouses(
		gs,
		old_owner,
		[c1, recovery_city] as Array[int],
		[100, 0] as Array[int],
		c1
	)
	var historical_owner := gs.recognized_owner_of(recovery_city)
	var captor := _make_army(502, (old_owner + 1) % GameState.NATION_COUNT, 1200, 10)
	gs.armies.append(captor)
	sim._capture_city(captor, gs.cities[recovery_city])
	_check(starved.size <= 0 or starved.state == Army.State.RETREATING,
		"恢复驻军所在城市易主后应重新撤退（无友城则溃散），state=%d size=%d" % [starved.state, starved.size])
	_check(not (starved.state == Army.State.RECOVERING and gs.cities[recovery_city].owner_nation != old_owner),
		"RECOVERING 军队不得滞留敌方城市")
	_check(
		gs.recognized_owner_of(recovery_city) == historical_owner
		and gs.cities[recovery_city].owner_nation != historical_owner,
		"占领只能改变当前归属，省份初始底色归属必须保持不变"
	)

	# 城破后所有旧守军状态都必须离城；后到援军应立即作为攻方触发新战斗。
	var capture_state := preload("res://tests/support/grid_world.gd").new()
	capture_state.generate_grid_world(780)
	capture_state.armies.clear()
	capture_state.battles.clear()
	for capture_city in capture_state.cities:
		capture_city.owner_nation = 1
		capture_state.recognized_city_owners[capture_city.id] = 1
		capture_city.occupation_sponsor_nation = -1
		capture_city.loyalty_target_nation = 1
		capture_city.is_capital = false
		capture_city.has_warehouse = false
		capture_city.food_storage = 0
	var capture_origin := 0
	var captured_city_id := 1
	var retreat_city_id := 2
	capture_state.cities[capture_origin].owner_nation = 0
	capture_state.recognized_city_owners[capture_origin] = 0
	capture_state.cities[capture_origin].loyalty_target_nation = 0
	_set_single_warehouse(capture_state, 0, capture_origin, 100)
	_set_single_warehouse(capture_state, 1, 63, 100)
	_set_warehouses(capture_state, 2, [] as Array[int], [] as Array[int])
	_set_warehouses(capture_state, 3, [] as Array[int], [] as Array[int])
	capture_state.refresh_derived()
	_check(
		capture_state.territory_structure_valid(),
		"城市易主与守军驱逐夹具在攻城前必须满足领土结构不变量"
	)
	capture_state.set_diplomatic_relation(
		0,
		1,
		GameState.DiplomaticRelation.WAR
	)
	var capture_sim := Simulation.new()
	capture_sim.setup(capture_state)
	var city_captor := _make_army(510, 0, 5000, 10)
	city_captor.location_city = capture_origin
	city_captor.move_from = capture_origin
	var captured_recovering := _make_army(511, 1, 3000, 10)
	captured_recovering.state = Army.State.RECOVERING
	captured_recovering.location_city = captured_city_id
	captured_recovering.move_from = captured_city_id
	var captured_waiting := _make_army(512, 1, 3000, 10)
	captured_waiting.state = Army.State.RETREATING
	captured_waiting.location_city = captured_city_id
	captured_waiting.move_from = captured_city_id
	captured_waiting.move_to = -1
	captured_waiting.path = [retreat_city_id]
	var captured_fighting := _make_army(513, 1, 3000, 10)
	captured_fighting.state = Army.State.FIGHTING
	captured_fighting.battle_id = 999
	captured_fighting.location_city = captured_city_id
	captured_fighting.move_from = captured_city_id
	capture_state.armies.append_array([
		city_captor,
		captured_recovering,
		captured_waiting,
		captured_fighting,
	])
	capture_sim._capture_city(
		city_captor,
		capture_state.cities[captured_city_id],
		0
	)
	var old_defenders_left_city := true
	for old_defender in [
		captured_recovering,
		captured_waiting,
		captured_fighting,
	]:
		old_defenders_left_city = (
			old_defenders_left_city
			and (
				old_defender.size <= 0
				or (
					old_defender.state
						== Army.State.RETREATING
					and old_defender.on_edge
					and old_defender.move_from
						== captured_city_id
				)
			)
		)
	_check(
		old_defenders_left_city,
		"城市易主后，恢复/等待撤退/残留战斗状态的旧守军必须立即离开城市节点"
	)
	var illegal_recovery := _make_army(514, 1, 2000, 10)
	illegal_recovery.location_city = captured_city_id
	illegal_recovery.move_from = captured_city_id
	capture_state.armies.append(illegal_recovery)
	capture_sim._start_recovering(
		illegal_recovery,
		captured_city_id
	)
	_check(
		illegal_recovery.size <= 0
			or (
				illegal_recovery.state
					== Army.State.RETREATING
				and illegal_recovery.on_edge
			),
		"敌军不得在无通行权的敌占城市开始恢复士气"
	)
	var late_relief := _make_army(515, 1, 5000, 10)
	late_relief.state = Army.State.MOVING
	late_relief.location_city = retreat_city_id
	late_relief.move_from = retreat_city_id
	late_relief.move_to = captured_city_id
	late_relief.move_progress = 1.0
	late_relief.on_edge = true
	capture_state.armies.append(late_relief)
	capture_sim._arrive_at_node(late_relief)
	var recapture_battle := capture_sim._siege_battle_of(
		capture_state.cities[captured_city_id]
	)
	_check(
		recapture_battle != null
			and recapture_battle.has_army(late_relief)
			and recapture_battle.has_army(city_captor)
			and late_relief.state == Army.State.FIGHTING
			and city_captor.state == Army.State.FIGHTING,
		"旧城主后到援军抵达已失守城市时，必须立即与新占领军触发战斗"
	)
	capture_sim.free()

	# 真实地图 68 城复现：占领军已下达后续移动命令，但受容量限制尚未上边。
	# 其 MOVING 只是任务状态，物理上仍在城内，敌军抵达时必须作为守军参战。
	var city68_state := preload("res://tests/support/grid_world.gd").new()
	city68_state.generate_world(12345)
	city68_state.armies.clear()
	city68_state.battles.clear()
	var city68_id := 68
	var city68_source: int = city68_state.neighbors(
		city68_id
	)[0]
	city68_state.cities[city68_id].owner_nation = 1
	city68_state.cities[city68_source].owner_nation = 0
	city68_state.set_diplomatic_relation(
		0,
		1,
		GameState.DiplomaticRelation.WAR
	)
	var city68_holder := _make_army(
		516,
		1,
		5000,
		10
	)
	city68_holder.state = Army.State.MOVING
	city68_holder.location_city = city68_id
	city68_holder.move_from = city68_id
	city68_holder.move_to = -1
	city68_holder.path = [city68_source] as Array[int]
	var city68_stale_fighter := _make_army(
		518,
		1,
		5000,
		10
	)
	city68_stale_fighter.state = Army.State.FIGHTING
	city68_stale_fighter.battle_id = 999
	city68_stale_fighter.location_city = city68_id
	city68_stale_fighter.move_from = city68_id
	var city68_relief := _make_army(
		517,
		0,
		5000,
		10
	)
	city68_relief.state = Army.State.MOVING
	city68_relief.location_city = city68_source
	city68_relief.move_from = city68_source
	city68_relief.move_to = city68_id
	city68_relief.move_progress = 1.0
	city68_relief.on_edge = true
	var city68_edge := city68_state.edge_of(
		city68_source,
		city68_id
	)
	city68_edge.passing_count = 1
	city68_edge.occupied = true
	city68_state.armies.append_array([
		city68_holder,
		city68_stale_fighter,
		city68_relief,
	])
	var city68_sim := Simulation.new()
	city68_sim.setup(city68_state)
	city68_sim._arrive_at_node(city68_relief)
	var city68_battle := city68_sim._siege_battle_of(
		city68_state.cities[city68_id]
	)
	_check(
		city68_battle != null
			and city68_battle.side_b_defends_city
			and city68_battle.has_army(city68_holder)
			and city68_battle.has_army(
				city68_stale_fighter
			)
			and city68_battle.has_army(city68_relief)
			and city68_holder.state == Army.State.FIGHTING
			and city68_stale_fighter.battle_id
				== city68_battle.id
			and city68_relief.state == Army.State.FIGHTING,
		"真实地图68城：容量等待或失效战斗状态的占领军必须迎战后到敌军"
	)
	_check(
		not city68_relief.on_edge
			and city68_relief.is_at_city_node(city68_id)
			and city68_relief.move_from == city68_source
			and city68_relief.move_to == city68_id,
		"抵达68城后必须识别为城市节点军队，同时保留围城补给边锚点"
	)
	city68_sim.free()

	# 多支恢复驻军必须全部加入守城，破城所需兵力的守军项取总兵力（而非只取第一支）。
	gs.armies.clear()
	gs.battles.clear()
	var siege_edge: Edge = null
	for candidate_edge in gs.edges:
		if (
			gs.cities[candidate_edge.city_a].owner_nation
				!= gs.cities[candidate_edge.city_b].owner_nation
		):
			siege_edge = candidate_edge
			break
	var siege_from := siege_edge.city_a
	var siege_to := siege_edge.city_b
	var city_owner := gs.cities[siege_to].owner_nation
	var g1 := _make_army(503, city_owner, 300, 10)
	var g2 := _make_army(504, city_owner, 200, 10)
	for garrison in [g1, g2]:
		garrison.state = Army.State.RECOVERING
		garrison.location_city = siege_to
		garrison.move_from = siege_to
		gs.armies.append(garrison)
	var invader := _make_army(
		505, gs.cities[siege_from].owner_nation, 1000, 10
	)
	invader.move_from = siege_from
	invader.move_to = siege_to
	gs.armies.append(invader)
	sim._start_or_join_siege(
		invader, gs.cities[siege_to], siege_edge
	)
	_check(
		g1.state == Army.State.RETREATING
			and g2.state == Army.State.RETREATING,
		"恢复中的普通野战军不得重新参战，应在围城建立时继续撤往其他友城"
	)
	if not gs.battles.is_empty():
		var recovery_siege: Battle = gs.battles[0]
		_check(
			not recovery_siege.has_army(g1)
				and not recovery_siege.has_army(g2),
			"恢复军不得阻塞虚拟守军攻城阶段"
		)
	sim.free()


func _test_retreat_transport_footprint() -> void:
	print("[22a] 撤退二值通行：残余主战军可沿5000窄路撤退且不拆编")
	var gs := preload("res://tests/support/grid_world.gd").new()
	gs.generate_grid_world(783)
	gs.armies.clear()
	gs.battles.clear()
	for city in gs.cities:
		city.owner_nation = 1
	gs.cities[0].owner_nation = 0
	gs.cities[1].owner_nation = 0
	gs.nations[0].capital_city_id = 1
	for edge in gs.edges:
		edge.max_manpower = 0
		edge.passing_count = 0
		edge.occupied = false
	var narrow_edge := gs.edge_of(0, 1)
	narrow_edge.max_manpower = Edge.MIN_MANPOWER
	narrow_edge.distance = 1
	narrow_edge.travel_time_multiplier = 1.0
	narrow_edge.danger = 0.0

	var remnant := _make_army(497, 0, 4000, 10, 10)
	remnant.max_size = GameState.INITIAL_HEAVY_ARMY_SIZE
	remnant.max_morale = Army.DEFAULT_MAX_MORALE
	remnant.morale = Combat.MORALE_FLOOR
	remnant.location_city = 0
	remnant.move_from = 0
	gs.armies.append(remnant)
	var group := gs.create_battle_group(0)
	_check(
		gs.assign_army_to_battle_group(remnant, group.id),
		"前置：残余主战军应保留合法战团身份"
	)

	var sim := Simulation.new()
	sim.setup(gs)
	sim._retreat_defender(remnant, gs.cities[0])
	_check(
		remnant.size == 4000
			and remnant.state == Army.State.RETREATING
			and remnant.forced_retreat
			and remnant.on_edge
			and remnant.move_from == 0
			and remnant.move_to == 1
			and narrow_edge.passing_count == 1,
		"残余4000人的15000编制主战军应立即进入5000容量退路，不得溃散或卡住"
	)
	_check(
		gs.armies.size() == 1
			and gs.armies[0] == remnant
			and remnant.max_size == GameState.INITIAL_HEAVY_ARMY_SIZE
			and remnant.max_morale == Army.DEFAULT_MAX_MORALE
			and remnant.is_main_battle_role()
			and remnant.battle_group_id == group.id,
		"撤退运输不得拆军或降编，必须保持单一Army、主战军与战团语义"
	)

	var guard := 0
	while remnant.state == Army.State.RETREATING and guard < 40:
		sim._advance_movement()
		guard += 1
	var group_members := gs.battle_group_members(0, group.id)
	_check(
		remnant.state == Army.State.RECOVERING
			and remnant.location_city == 1
			and remnant.size == 4000
			and not remnant.on_edge
			and narrow_edge.passing_count == 0,
		"残余主战军应沿5000窄路抵达友方首都并进入RECOVERING"
	)
	_check(
		gs.armies.size() == 1
			and gs.armies[0] == remnant
			and remnant.max_size == GameState.INITIAL_HEAVY_ARMY_SIZE
			and remnant.is_main_battle_role()
			and remnant.battle_group_id == group.id
			and group_members.size() == 1
			and group_members[0] == remnant,
		"完成撤退后仍须是原来的唯一主战军Army及原战团成员"
	)
	sim.free()


func _test_edge_retreat_transport_batches() -> void:
	print("[22a2] 边上撤退：端点择路无视正容量大小")
	var gs := preload("res://tests/support/grid_world.gd").new()
	gs.generate_grid_world(784)
	gs.armies.clear()
	gs.battles.clear()
	for city in gs.cities:
		city.owner_nation = 1
	# 两端都是无通行权城市；每端各接一座本国安全城市。
	# 主战军位于 0→1 的 20% 处。正容量不再增加运输批次，因此
	# 0 端总成本为 2+20，1 端为 8+5，应选择端点 1。
	gs.cities[8].owner_nation = 0
	gs.cities[2].owner_nation = 0
	# 让首都暂不可达，使战略撤退的两个候选同属 own-city tier，
	# 确保本用例真正由总运输距离而非首都纵深优先级裁决。
	gs.nations[0].capital_city_id = 16
	for edge in gs.edges:
		edge.max_manpower = 0
		edge.passing_count = 0
		edge.occupied = false
	var current_edge := gs.edge_of(0, 1)
	current_edge.max_manpower = Edge.MIN_MANPOWER
	current_edge.distance = 10
	current_edge.travel_time_multiplier = 1.0
	current_edge.danger = 0.0
	var left_exit := gs.edge_of(0, 8)
	left_exit.max_manpower = Edge.STANDARD_MANPOWER
	left_exit.distance = 20
	left_exit.travel_time_multiplier = 1.0
	left_exit.danger = 0.0
	var right_exit := gs.edge_of(1, 2)
	right_exit.max_manpower = Edge.STANDARD_MANPOWER
	right_exit.distance = 5
	right_exit.travel_time_multiplier = 1.0
	right_exit.danger = 0.0

	var main_army := _place_army_on_edge(gs, 498, 0, 0, 1, 0.2)
	main_army.max_size = GameState.INITIAL_HEAVY_ARMY_SIZE
	var strategic := Pathfinding.strategic_retreat_route_from_edge(
		gs, main_army
	)
	var repatriation := (
		Pathfinding.nearest_home_route_from_edge_for_repatriation(
			gs, main_army
		)
	)
	_check(
		int(strategic.get("endpoint", -1)) == 1
			and strategic.get("path", []) == [2]
			and _approx(float(strategic.get("distance", INF)), 13.0),
		"战略撤退应无视正容量大小并选择真实更快的1端：%s"
			% str(strategic)
	)
	_check(
		int(repatriation.get("endpoint", -1)) == 1
			and repatriation.get("path", []) == [2]
			and _approx(float(repatriation.get("distance", INF)), 13.0),
		"外交遣返应与战略撤退使用同一二值通行成本：%s"
			% str(repatriation)
	)


func _test_besieged_city_retreat_depth() -> void:
	print("[22b] 撤退纵深：双围城不得在相邻城市之间横跳，必须向首都方向后撤")
	var gs := preload("res://tests/support/grid_world.gd").new()
	gs.generate_grid_world(782)
	gs.armies.clear()
	gs.battles.clear()
	for city in gs.cities:
		city.owner_nation = 1
	var front_a := 0
	var front_b := 1
	var rear_a := 8
	var rear_b := 9
	var capital := 16
	for city_id in [front_a, front_b, rear_a, rear_b, capital]:
		gs.cities[city_id].owner_nation = 0
	for edge in gs.edges:
		edge.max_manpower = (
			Edge.STANDARD_MANPOWER
			if GameState.edge_key(edge.city_a, edge.city_b) in [
				GameState.edge_key(front_a, front_b),
				GameState.edge_key(front_a, rear_a),
				GameState.edge_key(front_b, rear_b),
				GameState.edge_key(rear_a, rear_b),
				GameState.edge_key(rear_a, capital),
			]
			else 0
		)
	gs.nations[0].capital_city_id = capital
	for front in [front_a, front_b]:
		var siege := gs.new_battle(Battle.Kind.SIEGE)
		siege.city = gs.cities[front]
	var army_a := _make_army(510, 0, 1000, 10)
	var army_b := _make_army(511, 0, 1000, 10)
	army_a.morale = 0.1
	army_b.morale = 0.1
	gs.armies.append_array([army_a, army_b])
	var sim := Simulation.new()
	sim.setup(gs)
	sim._start_morale_retreat_from_city(army_a, front_a, front_a)
	sim._start_morale_retreat_from_city(army_b, front_b, front_b)
	_check(
		army_a.state == Army.State.RETREATING
		and army_a.move_to == rear_a
		and not army_a.path.has(front_b)
		and army_b.state == Army.State.RETREATING
		and army_b.move_to == rear_b
		and not army_b.path.has(front_a),
		"双围城败军必须分别向首都纵深撤至%d/%d，不得互撤至%d/%d：A=%d path=%s B=%d path=%s"
			% [rear_a, rear_b, front_b, front_a, army_a.move_to, str(army_a.path), army_b.move_to, str(army_b.path)]
	)
	sim.free()


func _test_gold_reserve_budget_and_war_snapshot() -> void:
	print("[31b] Expenditure reserve and real wartime income")
	var gs := preload("res://tests/support/grid_world.gd").new()
	gs.generate_grid_world(7105)
	for nation in gs.nations:
		_set_neutral_ruler(nation)
	for a in range(gs.nations.size()):
		for b in range(a + 1, gs.nations.size()):
			gs.set_diplomatic_relation(a, b, GameState.DiplomaticRelation.NEUTRAL)
	var peace := Simulation.gold_reserve_policy(gs, 0)
	var input: Dictionary = peace.forecast.input
	_check(int(peace.reserve_months) == 36 and int(peace.reserve_target) == int(input.necessary_gold) * 36, "reserve based on necessary expenditure")
	gs.set_diplomatic_relation(0, 1, GameState.DiplomaticRelation.WAR)
	var war := Simulation.gold_reserve_policy(gs, 0)
	_check(int(war.reserve_months) == 6, "wartime reserve months")
	for city in gs.cities_of(0):
		city.gold_per_month = 0
	var after := Simulation.gold_reserve_policy(gs, 0)
	_check(int(after.budget_monthly_balance) == int(Simulation.monthly_gold_flows(gs)[0].balance), "loss uses actual revenue, not frozen income")
	gs.nations[0].treasury_gold = 1000000
	var funded := Simulation.gold_reserve_policy(gs, 0)
	_check(not funded.has("required_upkeep_savings"), "funded war does not demobilize for soft preference")
	gs.set_diplomatic_relation(0, 1, GameState.DiplomaticRelation.NEUTRAL)
	_check(int(Simulation.gold_reserve_policy(gs, 0).reserve_months) == 36, "peace restores preference")


func _test_ruler_economy_integration() -> void:
	print("[31c] 君主经济：产出、军费与财政报告使用同一有效口径")
	var gs := preload("res://tests/support/grid_world.gd").new()
	gs.generate_grid_world(7106)
	gs.armies.clear()
	for nation in gs.nations:
		_set_neutral_ruler(nation)
		nation.trade_policy = RulerProfile.POLICY_ISOLATION
	for edge in gs.edges:
		edge.max_manpower = 0
	for nation_a in range(gs.nations.size()):
		for nation_b in range(nation_a + 1, gs.nations.size()):
			gs.set_diplomatic_relation(
				nation_a, nation_b, GameState.DiplomaticRelation.NEUTRAL
			)
	for city in gs.cities:
		city.gold_per_month = 0
		city.manpower_per_month = 0
		city.food_per_half_year = 0
	var nation := gs.nations[0]
	nation.ruler_archetype = RulerProfile.INEPT
	var nation_cities := gs.cities_of(0)
	var city: City = null
	for candidate in nation_cities:
		if not candidate.is_dock:
			city = candidate
			break
	_check(city != null, "君主经济测试需要一座国0陆城")
	if city == null:
		return
	city.gold_per_month = 10
	city.manpower_per_month = 10
	city.food_per_half_year = 100
	var army_city := city
	for candidate in nation_cities:
		if not candidate.is_dock and candidate != city:
			army_city = candidate
			break
	var army := gs.create_army(
		0,
		army_city.id,
		5000,
		GameState.INITIAL_HEAVY_ARMY_SIZE
	)
	var base_upkeep := GameState.army_monthly_upkeep(army.max_size)
	var expected_gold := int(floor(
		10.0
	))
	var expected_food := int(floor(
		100.0 * RulerProfile.food_output_multiplier(nation)
	))
	var expected_manpower := int(floor(
		10.0 * RulerProfile.manpower_output_multiplier(nation)
	))
	var expected_upkeep := int(ceil(
		float(base_upkeep) * RulerProfile.upkeep_multiplier(nation)
	)) + Simulation.nation_monthly_garrison_upkeep(gs, 0)
	var flows := Simulation.monthly_gold_flows(gs)
	var flow: Dictionary = flows[0]
	_check(
		Simulation.city_gold_output(gs, city) == expected_gold
		and Simulation.city_food_output(gs, city) == expected_food
		and Simulation.city_manpower_output(gs, city) == expected_manpower
		and int(flow["military_upkeep"]) == expected_upkeep,
		"非中性君主的城市产出与军费预测必须逐项落地且取整一致"
	)
	var reserve := Simulation.gold_reserve_policy(gs, 0, flows)
	_check(
		int(reserve["reserve_months"])
			== Simulation.PEACE_GOLD_RESERVE_MONTHS
				+ RulerProfile.reserve_months_bonus(nation),
		"财政储备月数必须叠加当前君主加法修正"
	)
	nation.manpower_pool = 0
	var before_manpower := nation.manpower_pool
	var before_gold := nation.treasury_gold
	var sim := Simulation.new()
	sim.setup(gs)
	gs.day = Simulation.DAYS_PER_MONTH
	sim._resolve_economy()
	_check(
		nation.manpower_pool - before_manpower == expected_manpower
		and nation.treasury_gold - before_gold
			== int(flow["balance"]),
		"非中性君主的实际月结必须与产出和有效军费预测同源"
	)
	_check(not sim.has_method("_demobilize_for_gold_security"), "财政缩编入口已删除")
	sim.free()

# ------------------------------------------------------------------ 23. 自由/溃逃状态：断粮降士气 + 被动接战

func _test_supply_morale_and_passive_retreat_battle() -> void:
	print("[23] 状态机：断粮降士气触发溃逃 + 溃逃军只被动接战 + 获胜后继续撤退")
	var gs := preload("res://tests/support/grid_world.gd").new()
	gs.generate_grid_world(909)
	var sim := Simulation.new()
	sim.setup(gs)
	gs.armies.clear()
	gs.battles.clear()

	var c1 := -1
	var c2 := -1
	for edge in gs.edges:
		if gs.cities[edge.city_a].owner_nation == gs.cities[edge.city_b].owner_nation:
			c1 = edge.city_a
			c2 = edge.city_b
			break
	var nation := gs.cities[c1].owner_nation
	for city in gs.cities:
		if city.owner_nation == nation:
			city.food_storage = 0

	# 自由行军军队完全断粮：士气按 0.20/月 滚动逐日损失（item 10），而非结算日一次性跳变。
	var hungry := _place_army_on_edge(gs, 600, nation, c1, c2, 0.4)
	hungry.morale = 0.10
	sim._resolve_supply()   # 月度只写 supply_ratio（全断粮→0），不再直接扣士气
	_check(_approx(hungry.supply_ratio, 0.0),
		"全断粮月度结算应把 supply_ratio 记为 0，实为 %.3f" % hungry.supply_ratio)
	sim._apply_supply_pressure()   # 第 1 天：只损失 0.20/30，绝不应一天崩溃
	var per_day := Simulation.SUPPLY_MORALE_LOSS_MAX / float(Simulation.DAYS_PER_MONTH)
	_check(_approx(hungry.morale, 0.10 - per_day) and hungry.state != Army.State.RETREATING,
		"断粮首日应仅损失 %.4f 士气且不立即溃逃，实为 morale=%.4f state=%d" % [
			per_day, hungry.morale, hungry.state])
	# 继续滚动足够多天（0.10 需约 15 天耗尽），最终士气归零并触发溃逃。
	for _i in range(19):
		sim._apply_supply_pressure()
	_check(_approx(hungry.morale, 0.0), "持续全断粮约 15 天后士气应降至 0，实为 %.4f" % hungry.morale)
	_check(hungry.state == Army.State.RETREATING and hungry.forced_retreat,
		"自由军士气滚动降至 0 后应自动进入溃逃状态")

	# 两支敌对溃逃军即使同点也不主动互战。
	gs.armies.clear()
	gs.battles.clear()
	var r1 := _place_army_on_edge(gs, 601, 0, c1, c2, 0.5)
	var r2 := _place_army_on_edge(gs, 602, 1, c2, c1, 0.5)
	for retreater in [r1, r2]:
		retreater.state = Army.State.RETREATING
		retreater.forced_retreat = true
		retreater.morale = 0.8
	sim._detect_encounters()
	_check(gs.battles.is_empty(), "两支溃逃军均非主动方，同点也不应互相开战")

	# 加入一支正常 MOVING 敌军后，可主动截击溃逃军。
	gs.armies.erase(r2)
	var pursuer := _place_army_on_edge(gs, 603, 1, c2, c1, 0.5)
	pursuer.morale = 1.0
	r1.path = [c2] as Array[int]   # 原撤退命令，接战后必须保留
	sim._detect_encounters()
	_check(gs.battles.size() == 1 and r1.state == Army.State.FIGHTING,
		"正常军接触溃逃军时应触发被动接战")
	_check(r1.forced_retreat, "溃逃军进入被动战斗后必须保留强制撤退标记")

	# 强制追击方覆灭：溃逃军虽获胜，也只能继续 RETREATING，不能转普通 MOVING。
	pursuer.size = 0
	sim._resolve_battles()
	_check(r1.state == Army.State.RETREATING and r1.forced_retreat,
		"溃逃军被动接战获胜后应继续撤退，不得恢复自由行军")
	_check(r1.path == [c2], "被动接战获胜后应保留原撤退路径")
	sim.free()

# ------------------------------------------------------------------ 23b. item10 补给滚动结算：相位无关 + 恢复消退
func _test_rolling_supply_settlement() -> void:
	print("[23b] 补给滚动结算：断粮影响逐日累积、月初月末相位无关、恢复后惩罚消退")
	var sim := Simulation.new()
	var per_day := Simulation.SUPPLY_MORALE_LOSS_MAX / float(Simulation.DAYS_PER_MONTH)

	# --- (a) 逐日累积：全断粮 shortage=1，N 天后士气恰降 N*per_day，绝非结算日一次性跳变 ---
	var a := _make_army(700, 0, 1000, 10)
	a.morale = 1.0
	for _i in range(10):
		sim._accrue_supply_pressure(a, 1.0)
	_check(_approx(a.morale, 1.0 - 10.0 * per_day),
		"全断粮 10 天应逐日累积损失 %.4f 士气，实为 %.4f" % [10.0 * per_day, 1.0 - a.morale])

	# --- (b) 相位无关：同为「断粮 10 天」，无论落在 30 天窗口的月初还是月末，结果一致 ---
	var early := _make_army(701, 0, 1000, 10); early.morale = 1.0
	var late := _make_army(702, 0, 1000, 10); late.morale = 1.0
	for day in range(1, 31):
		sim._accrue_supply_pressure(early, 1.0 if day <= 10 else 0.0)   # 月初断 10 天
		sim._accrue_supply_pressure(late, 1.0 if day > 20 else 0.0)     # 月末断 10 天
	_check(_approx(early.morale, late.morale),
		"断粮同为 10 天，月初(%.4f)与月末(%.4f)结果应一致（相位无关）" % [early.morale, late.morale])
	_check(_approx(early.morale, 1.0 - 10.0 * per_day),
		"断粮 10 天后士气应为 %.4f，实为 %.4f" % [1.0 - 10.0 * per_day, early.morale])

	# --- (c) 恢复消退：断粮压低士气后 shortage 归零，惩罚停止、士气不再下降、饥饿标记清除 ---
	var recov := _make_army(703, 0, 1000, 10); recov.morale = 1.0
	for _i in range(5):
		sim._accrue_supply_pressure(recov, 1.0)
	var dipped := recov.morale
	_check(recov.starving and dipped < 1.0 - 4.0 * per_day + 0.0001,
		"断粮 5 天应显著压低士气并标记饥饿，实为 %.4f" % dipped)
	for _i in range(5):
		sim._accrue_supply_pressure(recov, 0.0)   # 补给恢复
	_check(_approx(recov.morale, dipped) and not recov.starving,
		"补给恢复后断粮惩罚应停止、饥饿清除、士气不再下降（%.4f→%.4f）" % [dipped, recov.morale])

	# --- (d) 减员整人化：小额日债累积到满 1 人才扣，size 不因逐日 ceil 而放大流失 ---
	var attrit := _make_army(704, 0, 400, 10); attrit.morale = 1.0   # 400 人日债 = 400*0.5/30 ≈ 6.667
	sim._accrue_supply_pressure(attrit, 1.0)   # 第 1 天：债≈6.667 → 扣 6，余 0.667
	_check(attrit.size == 394
		and _approx(attrit.supply_debt, 400.0 * Simulation.STARVE_RATE / 30.0 - 6.0),
		"400 人全断粮首日应减 6 人(floor(6.67))并留 0.667 债，实为 size=%d debt=%.4f" % [
			attrit.size, attrit.supply_debt])

	# --- (e) 部分缺粮：shortage=0.5 施压等于全断粮的一半（线性、可解释）---
	var half := _make_army(705, 0, 1000, 10); half.morale = 1.0
	sim._accrue_supply_pressure(half, 0.5)
	_check(_approx(half.morale, 1.0 - 0.5 * per_day),
		"半缺粮单日士气损失应为全断粮之半 %.5f，实为 %.5f" % [0.5 * per_day, 1.0 - half.morale])

	# --- (f) 溃逃边沿：士气自正值跌破 0 的当日返回 true（触发溃逃），此后不重复触发 ---
	var brk := _make_army(706, 0, 1000, 10)
	brk.state = Army.State.MOVING
	brk.morale = per_day * 0.5   # 不足一日损失，本日必然跌破 0
	var triggered := sim._accrue_supply_pressure(brk, 1.0)
	_check(triggered and _approx(brk.morale, 0.0),
		"士气自正值当日跌至 0 应返回溃逃触发，实为 trigger=%s morale=%.5f" % [str(triggered), brk.morale])
	var retrigger := sim._accrue_supply_pressure(brk, 1.0)
	_check(not retrigger, "士气已在 0 的军队不应重复触发溃逃")
	sim.free()

# ------------------------------------------------------------------ 24. 攻城顺序：先正面战斗，后围城；守军排除当前城撤退

func _test_edge_holding_state() -> void:
	print("[25] HOLDING：AI 进入高 danger 边、固定位置、补给控制适应")
	var gs := preload("res://tests/support/grid_world.gd").new()
	gs.generate_grid_world(5150)
	var sim := Simulation.new()
	sim.setup(gs)
	gs.armies.clear()
	gs.battles.clear()
	gs.uses_heightmap = true

	var c1 := -1
	var c2 := -1
	for edge in gs.edges:
		if gs.cities[edge.city_a].owner_nation != gs.cities[edge.city_b].owner_nation:
			c1 = edge.city_a
			c2 = edge.city_b
			break
	var own_nation := gs.cities[c1].owner_nation
	var enemy_nation := gs.cities[c2].owner_nation
	for city in gs.cities:
		city.owner_nation = own_nation
		city.is_capital = false
		city.has_warehouse = false
		city.is_food_hub = false
		city.is_manpower_hub = false
	for edge in gs.edges:
		edge.max_manpower = 0
		edge.danger = 0.0
	gs.cities[c2].owner_nation = enemy_nation
	gs.nations[own_nation].capital_city_id = -1
	var hold_edge := gs.edge_of(c1, c2)
	hold_edge.danger = 0.9
	hold_edge.max_manpower = 45000
	gs.cities[c1].is_food_hub = true
	var city_guard := _make_army(
		799,
		gs.cities[c1].owner_nation,
		5000,
		10
	)
	city_guard.max_size = GameState.INITIAL_HEAVY_ARMY_SIZE
	city_guard.state = Army.State.IDLE
	city_guard.location_city = c1
	city_guard.move_from = c1
	var holder := _make_army(800, gs.cities[c1].owner_nation, 1000, 10)
	holder.max_size = GameState.INITIAL_HEAVY_ARMY_SIZE
	holder.state = Army.State.IDLE
	holder.location_city = c1
	holder.move_from = c1
	gs.armies.append_array([city_guard, holder])

	var hold_order := ActionCandidate.make(
		ActionCandidate.Kind.HOLD,
		100.0,
		"驻边状态测试",
		c2
	)
	var hold_order_executed := (
		hold_order != null
		and hold_order.kind == ActionCandidate.Kind.HOLD
		and sim._execute_ai_candidate(holder, hold_order)
	)
	_check(
		hold_order_executed
			and holder.state == Army.State.MOVING
			and holder.move_to == c2,
		"主战军应能执行明确的驻边命令")
	_check(_approx(holder.hold_target_progress, Simulation.HOLDING_TARGET_PROGRESS),
		"驻防目标应位于从己方端点出发的35%%位置")
	var guard := 0
	while holder.state == Army.State.MOVING and guard < 40:
		sim._advance_movement()
		guard += 1
	_check(
		holder.state == Army.State.HOLDING
		and _approx(holder.move_progress, Simulation.HOLDING_TARGET_PROGRESS),
		"抵达己方侧驻防点后应进入 HOLDING，state=%d progress=%.2f"
			% [holder.state, holder.move_progress]
	)
	_check(holder.on_edge and hold_edge.passing_count == 1,
		"HOLDING 必须继续登记为道路上的军队")
	var fixed_pos := holder.move_progress
	for i in range(5):
		sim._advance_movement()
	_check(_approx(holder.move_progress, fixed_pos), "HOLDING 位置不得随日推进")

	holder.holding_days = 10
	holder.supply_ratio = 1.0
	sim._advance_holding_adaptation()
	_check(holder.holding_days == 11, "满补给驻防每天应累计 1 天")
	holder.supply_ratio = 0.5
	sim._advance_holding_adaptation()
	_check(holder.holding_days == 11, "部分补给时驻防适应应暂停")
	holder.supply_ratio = 0.0
	sim._advance_holding_adaptation()
	_check(holder.holding_days == 9, "完全断粮每天应衰减 2 天适应，实为 %d" % holder.holding_days)

	holder.supply_ratio = 1.0
	holder.holding_days = 179
	sim._advance_holding_adaptation()
	_check(holder.state == Army.State.HOLDING and holder.holding_days == 180,
		"驻防达到 180 天后仍应保持 HOLDING，不得因时间自动推进")
	for i in range(30):
		sim._advance_holding_adaptation()
	_check(holder.state == Army.State.HOLDING and holder.holding_days == 210,
		"驻防没有时间上限，满补给时适应天数应持续累计")
	holder.morale = 0.0
	sim._retreat(holder)
	_check(holder.state == Army.State.RETREATING and holder.holding_days == 0,
		"驻防军撤退时必须清零适应度")
	sim.free()

# ------------------------------------------------------------------ 26. 边上双端点补给

func _test_edge_supply_from_both_endpoints() -> void:
	print("[26] 边上补给：按真实位置比较双端点，当前边接敌不切断友方端点")
	var gs := preload("res://tests/support/grid_world.gd").new()
	gs.generate_grid_world(6160)
	gs.armies.clear()
	gs.battles.clear()
	var a := -1
	var b := -1
	for edge in gs.edges:
		if gs.cities[edge.city_a].owner_nation == gs.cities[edge.city_b].owner_nation:
			a = edge.city_a
			b = edge.city_b
			break
	var road := gs.edge_of(a, b)
	road.distance = 5
	road.danger = 0.2
	var nation := gs.cities[a].owner_nation
	_set_warehouses(gs, nation, [a, b] as Array[int], [100, 100] as Array[int], a)
	var army := _make_army(810, nation, 1000, 10)
	army.state = Army.State.HOLDING
	army.move_from = a
	army.move_to = b
	army.move_progress = 0.8
	army.on_edge = true
	gs.armies.append(army)

	var near_b := Pathfinding.nearest_supply_city(gs, army)
	_check(near_b[0] == b and _approx(float(near_b[1]), 0.12),
		"位于 80%% 位置应从更近端点 B 取粮，实为 %s" % str(near_b))
	gs.cities[b].food_storage = 0
	var fallback_a := Pathfinding.nearest_supply_city(gs, army)
	_check(fallback_a[0] == a and _approx(float(fallback_a[1]), 0.48),
		"B 无粮时应回退从 A 取粮，实为 %s" % str(fallback_a))

	var enemy := _make_army(811, (nation + 1) % GameState.NATION_COUNT, 500, 10)
	enemy.state = Army.State.MOVING
	enemy.move_from = b
	enemy.move_to = a
	enemy.move_progress = 0.1
	enemy.on_edge = true
	gs.armies.append(enemy)
	var contested := Pathfinding.nearest_supply_city(gs, army)
	_check(contested[0] == a and _approx(float(contested[1]), 0.48),
		"当前边出现敌军时仍应从相连友方端点 A 取粮，实为 %s" % str(contested))

# ------------------------------------------------------------------ 26b. 粮仓最小损耗路线 + 首都失守

func _test_warehouse_logistics() -> void:
	print("[26b] 粮仓机制：最小损耗路线、多粮仓扩展、首都失守迁都与缴获")
	var gs := preload("res://tests/support/grid_world.gd").new()
	gs.generate_grid_world(6262)
	var sim := Simulation.new()
	sim.setup(gs)
	gs.armies.clear()
	gs.battles.clear()

	# 两条均为两段的本国路线：0→2 danger 高，0→16 danger 低，应选择后者。
	for city in gs.cities:
		city.owner_nation = 0
	_set_warehouses(gs, 0, [2, 16] as Array[int], [100, 100] as Array[int], 2)
	for pair in [[0, 1], [1, 2]]:
		var risky := gs.edge_of(pair[0], pair[1])
		risky.distance = 1
		risky.danger = 0.5
	for pair in [[0, 8], [8, 16]]:
		var safe := gs.edge_of(pair[0], pair[1])
		safe.distance = 1
		safe.danger = 0.0
	var probe := _make_army(812, 0, 1000, 10)
	probe.state = Army.State.IDLE
	probe.location_city = 0
	probe.move_from = 0
	gs.armies.append(probe)
	var supply := Pathfinding.nearest_supply_city(gs, probe)
	_check(supply[0] == 16 and _approx(float(supply[1]), 0.2),
		"同距离时应选择 danger 更低的粮仓 16，实为 %s" % str(supply))
	sim._prepare_supply_network_caches()
	var cached_supply := sim._cached_supply_sources(
		probe,
		sim._daily_supply_source_cache,
		sim._daily_supply_network_cache,
		sim._stable_supply_city_source_cache
	)
	var stable_nation_cache: Dictionary = (
		sim._stable_supply_city_source_cache[0]
	)
	_check(
		cached_supply == Pathfinding.supply_sources(gs, probe)
			and stable_nation_cache.has(0),
		"驻城补给来源缓存结果必须与直接路径计算一致"
	)
	sim._prepare_supply_network_caches()
	_check(
		(sim._stable_supply_city_source_cache[0] as Dictionary).has(0),
		"补给网络与围城状态未变时，驻城来源必须跨日保留"
	)
	var second_probe := _make_army(814, 0, 1000, 10)
	second_probe.state = Army.State.IDLE
	second_probe.location_city = 1
	second_probe.move_from = 1
	sim._cached_supply_sources(
		second_probe,
		sim._daily_supply_source_cache,
		sim._daily_supply_network_cache,
		sim._stable_supply_city_source_cache
	)
	sim._invalidate_supply_city_sources_for_siege_changes({0: true})
	stable_nation_cache = sim._stable_supply_city_source_cache[0]
	_check(
		not stable_nation_cache.has(0)
			and stable_nation_cache.has(1),
		"围城变化必须只失效对应城市的驻城补给来源"
	)
	sim._invalidate_supply_city_sources_for_siege_changes({})
	gs.ownership_revision += 1
	sim._prepare_supply_network_caches()
	_check(
		not sim._stable_supply_city_source_cache.has(0),
		"补给网络依赖版本变化必须失效对应国家的全部驻城来源"
	)

	# 独立世界验证首都失守：30% 库存汇入胜方首都，败方立即投降后迁都。
	var gs2 := preload("res://tests/support/grid_world.gd").new()
	gs2.generate_grid_world(6363)
	var sim2 := Simulation.new()
	sim2.setup(gs2)
	gs2.armies.clear()
	gs2.battles.clear()
	var old_capital_id := gs2.nations[0].capital_city_id
	var old_capital := gs2.cities[old_capital_id]
	old_capital.food_storage = 100
	var captor_capital := gs2.cities[gs2.nations[1].capital_city_id]
	captor_capital.food_storage = 500
	for nation_a in range(gs2.nations.size()):
		for nation_b in range(nation_a + 1, gs2.nations.size()):
			gs2.set_diplomatic_relation(
				nation_a,
				nation_b,
				GameState.DiplomaticRelation.NEUTRAL
			)
	gs2.set_diplomatic_relation(
		0,
		1,
		GameState.DiplomaticRelation.WAR
	)
	var captor := _make_army(813, 1, 1000, 10)
	gs2.armies.append(captor)
	sim2._capture_city(captor, old_capital)
	var new_capital_id := gs2.nations[0].capital_city_id
	_check(old_capital.owner_nation == 1 and not old_capital.has_warehouse
		and old_capital.food_storage == 0,
		"失守首都应注销旧粮仓并清空原库存")
	_check(captor_capital.food_storage == 530,
		"胜方首都应获得 30%% 粮食缴获：预期 530，实为 %d" % captor_capital.food_storage)
	_check(new_capital_id != old_capital_id and new_capital_id != -1
		and gs2.cities[new_capital_id].owner_nation == 0
		and gs2.cities[new_capital_id].is_capital
		and gs2.cities[new_capital_id].has_warehouse,
		"败方应在剩余城市中迁都并建立新粮仓，实为 %d" % new_capital_id)
	_check(
		not gs2.is_enemy(0, 1)
			and not gs2.diplomatic_history.is_empty()
			and int(
				gs2.diplomatic_history[-1].get(
					"surrendering_nation",
					-1
				)
			) == 0,
		"首都失守必须立即投降，不得等待月度和平意愿结算"
	)
	sim.free()
	sim2.free()


func _test_atomic_territory_transactions() -> void:
	print("[26c] 原子领土事务：行政设施、库存、回滚与无实控法理国")

	# 公开薄封装必须独立完成旧控制者行政状态修复；调用方不得先摘首都/粮仓。
	var transfer_state := preload("res://tests/support/grid_world.gd").new()
	transfer_state.generate_grid_world(63630)
	var former_owner := 1
	var recipient := 0
	var recipient_warehouse := transfer_state.warehouse_cities_of(recipient)[0]
	recipient_warehouse.food_storage = 500
	var old_capital_id := transfer_state.nations[former_owner].capital_city_id
	var old_capital := transfer_state.cities[old_capital_id]
	old_capital.food_storage = 100
	var extra_warehouse: City = null
	for candidate in transfer_state.land_cities_of(former_owner):
		if not candidate.is_capital and not candidate.has_warehouse:
			extra_warehouse = candidate
			break
	_check(extra_warehouse != null, "原子领土事务回归必须找到普通城市作为附加粮仓")
	if extra_warehouse != null:
		extra_warehouse.has_warehouse = true
		extra_warehouse.food_storage = 70
		transfer_state.nations[former_owner].warehouse_city_ids.append(
			extra_warehouse.id
		)
		transfer_state.refresh_derived()
		var warehouse_revision := transfer_state.ownership_revision
		var warehouse_result: Dictionary = (
			transfer_state.transfer_city_control(
				extra_warehouse.id,
				recipient,
				recipient,
				GameState.TerritoryStockDisposition.MOVE_TO_NEW_POOL,
				"atomic_warehouse_capture"
			)
		)
		_check(
			bool(warehouse_result.get("ok", false))
				and bool(warehouse_result.get("changed", false))
				and warehouse_result.get("changed_city_ids", [])
					== [extra_warehouse.id]
				and transfer_state.ownership_revision == warehouse_revision + 1
				and extra_warehouse.owner_nation == recipient
				and transfer_state.recognized_owner_of(extra_warehouse.id)
					== former_owner
				and extra_warehouse.occupation_sponsor_nation == recipient
				and not extra_warehouse.has_warehouse
				and extra_warehouse.food_storage == 0
				and not transfer_state.nations[former_owner]
					.warehouse_city_ids.has(extra_warehouse.id)
				and recipient_warehouse.food_storage == 570
				and transfer_state.territory_structure_valid(),
			(
				"transfer_city_control 直接攻占粮仓必须摘除旧索引，"
				+ "并按 MOVE_TO_NEW_POOL 将库存全额转入新控制者粮池"
			)
		)

	var capital_revision := transfer_state.ownership_revision
	var capital_result: Dictionary = transfer_state.transfer_city_control(
		old_capital_id,
		recipient,
		recipient,
		GameState.TerritoryStockDisposition.CAPTURE_SPOILS,
		"atomic_capital_capture"
	)
	var relocated_capital := transfer_state.nations[former_owner].capital_city_id
	_check(
		bool(capital_result.get("ok", false))
			and bool(capital_result.get("changed", false))
			and capital_result.get("changed_city_ids", []) == [old_capital_id]
			and transfer_state.ownership_revision == capital_revision + 1
			and old_capital.owner_nation == recipient
			and transfer_state.recognized_owner_of(old_capital_id) == former_owner
			and old_capital.occupation_sponsor_nation == recipient
			and not old_capital.is_capital
			and not old_capital.has_warehouse
			and old_capital.food_storage == 0
			and relocated_capital >= 0
			and relocated_capital != old_capital_id
			and transfer_state.cities[relocated_capital].owner_nation == former_owner
			and transfer_state.cities[relocated_capital].is_capital
			and transfer_state.cities[relocated_capital].has_warehouse
			and recipient_warehouse.food_storage == 600
			and transfer_state.territory_structure_valid(),
		(
			"transfer_city_control 直接攻占首都必须自动迁都，并按 "
			+ "CAPTURE_SPOILS 仅将 30% 库存计入新控制者粮池"
		)
	)

	# 旧国仅剩一座首都时，直接攻占必须清空首都/粮仓索引；它可以继续
	# 保有该城法理，且这种“无实控但有法理”的状态应是合法中间态。
	var landless_state := preload("res://tests/support/grid_world.gd").new()
	landless_state.generate_grid_world(63631)
	var landless_capital_id := landless_state.nations[former_owner].capital_city_id
	for city in landless_state.cities:
		if city.owner_nation != former_owner or city.id == landless_capital_id:
			continue
		city.owner_nation = recipient
		landless_state.recognized_city_owners[city.id] = recipient
		city.occupation_sponsor_nation = -1
		city.loyalty_target_nation = recipient
	landless_state.cities[landless_capital_id].food_storage = 90
	landless_state.refresh_derived()
	_check(
		landless_state.territory_structure_valid(),
		"最后一城攻占夹具在事务前必须结构合法"
	)
	var landless_result: Dictionary = landless_state.transfer_city_control(
		landless_capital_id,
		recipient,
		recipient,
		GameState.TerritoryStockDisposition.DESTROY,
		"atomic_last_city_capture"
	)
	var occupied_last_city := landless_state.cities[landless_capital_id]
	_check(
		bool(landless_result.get("ok", false))
			and bool(landless_result.get("changed", false))
			and occupied_last_city.owner_nation == recipient
			and landless_state.recognized_owner_of(landless_capital_id)
				== former_owner
			and occupied_last_city.occupation_sponsor_nation == recipient
			and not occupied_last_city.is_capital
			and not occupied_last_city.has_warehouse
			and occupied_last_city.food_storage == 0
			and landless_state.cities_of(former_owner).is_empty()
			and not landless_state.nations[former_owner].alive
			and landless_state.nations[former_owner].capital_city_id == -1
			and landless_state.nations[former_owner].warehouse_city_ids.is_empty()
			and landless_state.territory_structure_valid(),
		(
			"最后一座实控城被占后旧国必须清空行政索引；"
			+ "法理仍属于无实控国时 territory_structure_valid 必须为 true；result=%s"
			% [landless_result]
		)
	)

	# 批量事务必须先完整验证，再一次提交。即使第一项合法，只要后项非法
	# 或调用方使用了过期 revision，全部领土/行政/库存状态都必须逐字段不变。
	var rollback_state := preload("res://tests/support/grid_world.gd").new()
	rollback_state.generate_grid_world(63632)
	for rollback_a in range(rollback_state.nations.size()):
		for rollback_b in range(
			rollback_a + 1, rollback_state.nations.size()
		):
			rollback_state.set_diplomatic_relation(
				rollback_a,
				rollback_b,
				GameState.DiplomaticRelation.NEUTRAL
			)
	var overlay_region := _enfeoffable_region(rollback_state, recipient, 3)
	FamilyFixture.ensure_candidates(rollback_state, recipient)
	var overlay_subject := rollback_state.enfeoff(
		recipient, overlay_region
	)
	var proposed_suzerainty := rollback_state.suzerainty.duplicate(true)
	if proposed_suzerainty.has(overlay_subject):
		proposed_suzerainty[overlay_subject]["tribute_rate"] = 0.5
	_check(
		overlay_subject >= 0
			and proposed_suzerainty != rollback_state.suzerainty
			and rollback_state.suzerainty_structure_valid()
			and rollback_state.territory_structure_valid(),
		"政治 overlay 回滚夹具必须由真实分封建立，且事务前结构合法"
	)
	var rollback_targets: Array[City] = []
	for candidate in rollback_state.land_cities_of(former_owner):
		if not candidate.is_capital and not candidate.has_warehouse:
			rollback_targets.append(candidate)
			if rollback_targets.size() == 2:
				break
	_check(rollback_targets.size() == 2, "原子回滚夹具必须找到两座普通城市")
	if rollback_targets.size() == 2:
		var invalid_operations: Array[Dictionary] = [
			{
				"city_id": rollback_targets[0].id,
				"controller_id": recipient,
				"sponsor_id": recipient,
			},
			{
				"city_id": rollback_targets[1].id,
				"controller_id": rollback_state.nations.size(),
			},
		]
		var invalid_before := _territory_fingerprint(rollback_state)
		var invalid_result: Dictionary = (
			rollback_state.apply_territory_transaction(
				invalid_operations,
				{},
				-1,
				proposed_suzerainty
			)
		)
		_check(
			not bool(invalid_result.get("ok", true))
				and not bool(invalid_result.get("changed", true))
				and not bool(invalid_result.get("territory_changed", true))
				and not bool(invalid_result.get("political_changed", true))
				and not str(invalid_result.get("error", "")).is_empty()
				and invalid_result.get("changed_city_ids", []).is_empty()
				and _territory_fingerprint(rollback_state) == invalid_before,
			(
				"批量事务后项非法时，proposed_suzerainty 与全部领土/外交/"
				+ "资源/军队/revision 状态必须零变化"
			)
		)

		var conflict_operations: Array[Dictionary] = [{
			"city_id": rollback_targets[0].id,
			"controller_id": recipient,
			"sponsor_id": recipient,
		}]
		var conflict_before := _territory_fingerprint(rollback_state)
		var conflict_result: Dictionary = (
			rollback_state.apply_territory_transaction(
				conflict_operations,
				{},
				rollback_state.ownership_revision + 1,
				proposed_suzerainty
			)
		)
		_check(
			not bool(conflict_result.get("ok", true))
				and not bool(conflict_result.get("changed", true))
				and not bool(conflict_result.get("territory_changed", true))
				and not bool(conflict_result.get("political_changed", true))
				and not str(conflict_result.get("error", "")).is_empty()
				and conflict_result.get("changed_city_ids", []).is_empty()
				and _territory_fingerprint(rollback_state) == conflict_before,
			(
				"expected_ownership_revision 冲突必须在提交政治 overlay 前失败，"
				+ "且完整政治事务指纹不变"
			)
		)

		# 外交 operation 也必须与领土/政治共用 phase 1 校验与 phase 2 提交：
		# 多边成功只加一次 revision；stale 或末项非法时完整指纹零变化。
		rollback_state.set_diplomatic_relation(
			0, 1, GameState.DiplomaticRelation.WAR
		)
		rollback_state.set_diplomatic_relation(
			0, 2, GameState.DiplomaticRelation.WAR
		)
		var diplomatic_revision_before := rollback_state.diplomacy_revision
		var diplomatic_batch: Array[Dictionary] = [
			{
				"nation_a": 0,
				"nation_b": 1,
				"relation": GameState.DiplomaticRelation.NEUTRAL,
				"truce_days": GameState.DEFAULT_TRUCE_DAYS,
			},
			{
				"nation_a": 0,
				"nation_b": 2,
				"relation": GameState.DiplomaticRelation.NEUTRAL,
				"truce_days": GameState.DEFAULT_TRUCE_DAYS,
			},
		]
		var diplomatic_result := rollback_state.apply_territory_transaction(
			[] as Array[Dictionary], {}, rollback_state.ownership_revision,
			null, diplomatic_batch, rollback_state.diplomacy_revision
		)
		_check(
			bool(diplomatic_result.get("ok", false))
				and bool(diplomatic_result.get("diplomacy_changed", false))
				and rollback_state.diplomacy_revision
					== diplomatic_revision_before + 1
				and rollback_state.relation_between(0, 1)
					== GameState.DiplomaticRelation.NEUTRAL
				and rollback_state.relation_between(0, 2)
					== GameState.DiplomaticRelation.NEUTRAL
				and rollback_state.truce_until(0, 1)
					== rollback_state.day + GameState.DEFAULT_TRUCE_DAYS
				and rollback_state.truce_until(0, 2)
					== rollback_state.day + GameState.DEFAULT_TRUCE_DAYS,
			"同批多条合法外交 operation 必须一次提交且 diplomacy revision 只加一"
		)
		var stale_diplomacy_before := _territory_fingerprint(rollback_state)
		var stale_diplomacy_result := (
			rollback_state.apply_territory_transaction(
				[] as Array[Dictionary], {}, rollback_state.ownership_revision,
				null, diplomatic_batch,
				rollback_state.diplomacy_revision + 1
			)
		)
		_check(
			not bool(stale_diplomacy_result.get("ok", true))
				and _territory_fingerprint(rollback_state)
					== stale_diplomacy_before,
			"stale diplomacy revision 必须在事务入口拒绝且完整状态零变化"
		)
		var invalid_diplomacy_batch := diplomatic_batch.duplicate(true)
		invalid_diplomacy_batch.append({
			"nation_a": 1,
			"nation_b": 2,
			"relation": 999,
		})
		var invalid_diplomacy_before := _territory_fingerprint(rollback_state)
		var invalid_diplomacy_result := (
			rollback_state.apply_territory_transaction(
				[] as Array[Dictionary], {}, rollback_state.ownership_revision,
				null, invalid_diplomacy_batch,
				rollback_state.diplomacy_revision
			)
		)
		_check(
			not bool(invalid_diplomacy_result.get("ok", true))
				and _territory_fingerprint(rollback_state)
					== invalid_diplomacy_before,
			"外交批次末项非法时必须回滚此前合法 operation 并保持完整状态零变化"
		)

	var noop_city := rollback_state.cities[rollback_state.nations[recipient].capital_city_id]
	var noop_before := _territory_fingerprint(rollback_state)
	var noop_result: Dictionary = rollback_state.transfer_city_control(
		noop_city.id, noop_city.owner_nation, -1
	)
	_check(
		bool(noop_result.get("ok", false))
			and not bool(noop_result.get("changed", true))
			and str(noop_result.get("error", "x")).is_empty()
			and noop_result.get("changed_city_ids", []).is_empty()
			and _territory_fingerprint(rollback_state) == noop_before,
		"合法幂等 transfer 必须返回 ok=true changed=false 且完整指纹不变"
	)

	# 忠诚恢复区域包含附加粮仓时，事务先把随城库存归回旧共享粮池，
	# 再严格按事务前粮池库存和产能比例划转一次。
	var restore_state := preload("res://tests/support/grid_world.gd").new()
	restore_state.generate_grid_world(63633)
	restore_state.armies.clear()
	restore_state.battles.clear()
	var restore_parent := 0
	var restore_target := 1
	var pool_subject := 2
	for relation_a in range(restore_state.nations.size()):
		for relation_b in range(relation_a + 1, restore_state.nations.size()):
			restore_state.set_diplomatic_relation(
				relation_a, relation_b, GameState.DiplomaticRelation.NEUTRAL
			)
	restore_state.set_diplomatic_relation(
		restore_parent, pool_subject, GameState.DiplomaticRelation.ALLIED
	)
	restore_state.set_diplomatic_relation(
		restore_parent, restore_target, GameState.DiplomaticRelation.WAR
	)
	restore_state.set_diplomatic_relation(
		pool_subject, restore_target, GameState.DiplomaticRelation.WAR
	)
	restore_state.suzerainty[pool_subject] = {
		"overlord_id": restore_parent,
		"tribute_rate": GameState.DEFAULT_TRIBUTE_RATE,
		"created_day": 0,
		"last_centralization_day": -1,
		"civil_war": false,
	}
	for warehouse_id in (
		restore_state.nations[pool_subject].warehouse_city_ids.duplicate()
	):
		restore_state.cities[warehouse_id].has_warehouse = false
		restore_state.cities[warehouse_id].food_storage = 0
	restore_state.nations[pool_subject].warehouse_city_ids.clear()
	for city in restore_state.cities:
		city.food_per_half_year = 0
		city.food_storage = 0
	var restore_city: City = null
	for candidate in restore_state.land_cities_of(restore_parent):
		if not candidate.is_capital and not candidate.has_warehouse:
			restore_city = candidate
			break
	var subject_output_city := restore_state.land_cities_of(pool_subject)[0]
	_check(
		restore_city != null,
		"忠诚恢复附加粮仓回归必须找到一座非首都迁移城市"
	)
	if restore_city != null:
		preload("res://tests/state_rebellion_fixture.gd").isolate_city_as_state(restore_state, restore_city.id)
		var restore_parent_capital := restore_state.cities[
			restore_state.nations[restore_parent].capital_city_id
		]
		var restore_target_capital := restore_state.cities[
			restore_state.nations[restore_target].capital_city_id
		]
		restore_parent_capital.food_storage = 700
		restore_target_capital.food_storage = 200
		restore_city.has_warehouse = true
		restore_city.food_storage = 300
		restore_city.food_per_half_year = 40
		restore_city.loyalty_target_nation = restore_target
		restore_state.nations[restore_parent].warehouse_city_ids.append(
			restore_city.id
		)
		subject_output_city.food_per_half_year = 60
		restore_state.refresh_derived()
		var parent_holder_before := restore_state.food_pool_holder(restore_parent)
		var target_holder_before := restore_state.food_pool_holder(restore_target)
		var parent_pool_stock_before := 0
		for warehouse in restore_state.warehouse_cities_of(parent_holder_before):
			parent_pool_stock_before += warehouse.food_storage
		var target_pool_stock_before := 0
		for warehouse in restore_state.warehouse_cities_of(target_holder_before):
			target_pool_stock_before += warehouse.food_storage
		var shared_food_output_before := 0
		for member_id in restore_state.food_pool_members(parent_holder_before):
			for pool_city in restore_state.land_cities_of(member_id):
				shared_food_output_before += pool_city.food_per_half_year
		var moved_food_output_before := restore_city.food_per_half_year
		var expected_food_transfer := int(floor(
			float(parent_pool_stock_before)
				* float(moved_food_output_before)
				/ float(shared_food_output_before)
		))
		var global_food_before := 0
		for city in restore_state.cities:
			global_food_before += city.food_storage
		var restored := restore_state.restore_regional_loyalty_target(
			restore_parent, restore_target, [restore_city.id] as Array[int]
		)
		var parent_pool_stock_after := 0
		for warehouse in restore_state.warehouse_cities_of(
			restore_state.food_pool_holder(restore_parent)
		):
			parent_pool_stock_after += warehouse.food_storage
		var target_pool_stock_after := 0
		for warehouse in restore_state.warehouse_cities_of(
			restore_state.food_pool_holder(restore_target)
		):
			target_pool_stock_after += warehouse.food_storage
		var global_food_after := 0
		for city in restore_state.cities:
			global_food_after += city.food_storage
		var accepted_food_transfer := mini(
			expected_food_transfer,
			maxi(
				restore_state.food_storage_capacity(restore_target)
					- target_pool_stock_before,
				0
			)
		)
		_check(
			restored
				and parent_holder_before == restore_parent
				and restore_state.food_pool_members(parent_holder_before)
					== ([restore_parent, pool_subject] as Array[int])
				and parent_pool_stock_before == 1000
				and target_pool_stock_before == 200
				and shared_food_output_before == 100
				and moved_food_output_before == 40
				and expected_food_transfer == 400
				and restore_city.owner_nation == restore_target
				and restore_state.recognized_owner_of(restore_city.id)
					== restore_parent
				and restore_city.occupation_sponsor_nation == restore_target
				and not restore_city.has_warehouse
				and restore_city.food_storage == 0
				and not restore_state.nations[restore_parent]
					.warehouse_city_ids.has(restore_city.id)
				and not restore_state.nations[restore_target]
					.warehouse_city_ids.has(restore_city.id)
				and parent_pool_stock_after
					== parent_pool_stock_before - accepted_food_transfer
				and target_pool_stock_after
					== target_pool_stock_before + accepted_food_transfer
				and parent_pool_stock_after + target_pool_stock_after
					== parent_pool_stock_before + target_pool_stock_before
				and global_food_after == global_food_before
				and restore_state.nations[parent_holder_before].granary_food
					== parent_pool_stock_after
				and restore_state.nations[
					restore_state.food_pool_holder(restore_target)
				].granary_food == target_pool_stock_after
				and restore_state.suzerainty_structure_valid()
				and restore_state.territory_structure_valid(),
			(
				"restore_regional_loyalty_target 必须先归回迁移粮仓库存，"
				+ "再按事务前共享粮池 1000×40/100 只划转一次；"
				+ "before=%d old/new=%d/%d after=%d"
			) % [
				global_food_before,
				parent_pool_stock_after,
				target_pool_stock_after,
				global_food_after,
			]
		)

	# 三个小粮仓不能因逐仓比例向下取整而少扣；超额请求则返回可扣总量。
	var withdraw_state := preload("res://tests/support/grid_world.gd").new()
	withdraw_state.generate_grid_world(63634)
	var withdraw_owner := 0
	var withdraw_ids: Array[int] = [
		withdraw_state.nations[withdraw_owner].capital_city_id,
	]
	for candidate in withdraw_state.land_cities_of(withdraw_owner):
		if not withdraw_ids.has(candidate.id):
			withdraw_ids.append(candidate.id)
		if withdraw_ids.size() == 3:
			break
	_check(withdraw_ids.size() == 3, "多粮仓扣粮夹具必须找到三座本国城市")
	if withdraw_ids.size() == 3:
		_set_warehouses(
			withdraw_state, withdraw_owner, withdraw_ids,
			[1, 1, 1] as Array[int], withdraw_ids[0]
		)
		withdraw_state.refresh_derived()
		var withdrawn := withdraw_state._withdraw_food_from_warehouses(
			withdraw_state.nations[withdraw_owner], 2
		)
		var remaining_food := 0
		for warehouse in withdraw_state.warehouse_cities_of(withdraw_owner):
			remaining_food += warehouse.food_storage
		var overdrawn := withdraw_state._withdraw_food_from_warehouses(
			withdraw_state.nations[withdraw_owner], 5
		)
		var final_food := 0
		for warehouse in withdraw_state.warehouse_cities_of(withdraw_owner):
			final_food += warehouse.food_storage
		_check(
			withdrawn == 2
				and remaining_food == 1
				and overdrawn == 1
				and final_food == 0,
			(
				"[1,1,1] 多粮仓扣 2 必须精确剩 1；超额再扣应只返回 1，"
				+ "实为 withdrawn=%d remaining=%d overdrawn=%d final=%d"
			) % [withdrawn, remaining_food, overdrawn, final_food]
		)

	# 通过真实忠诚恢复入口覆盖同一尾数场景：旧池 [1,1,1] 按 2/3
	# 产能划出 2，目标池只能收到实际扣除的 2，全局库存保持 3。
	var tiny_restore_state := preload("res://tests/support/grid_world.gd").new()
	tiny_restore_state.generate_grid_world(63635)
	tiny_restore_state.armies.clear()
	tiny_restore_state.battles.clear()
	var tiny_parent := 0
	var tiny_target := 1
	for relation_a in range(tiny_restore_state.nations.size()):
		for relation_b in range(
			relation_a + 1, tiny_restore_state.nations.size()
		):
			tiny_restore_state.set_diplomatic_relation(
				relation_a, relation_b, GameState.DiplomaticRelation.NEUTRAL
			)
	tiny_restore_state.set_diplomatic_relation(
		tiny_parent, tiny_target, GameState.DiplomaticRelation.WAR
	)
	for city in tiny_restore_state.cities:
		city.food_per_half_year = 0
		city.food_storage = 0
	var tiny_parent_cities := tiny_restore_state.land_cities_of(tiny_parent)
	var tiny_warehouse_ids: Array[int] = [
		tiny_restore_state.nations[tiny_parent].capital_city_id,
	]
	for candidate in tiny_parent_cities:
		if not tiny_warehouse_ids.has(candidate.id):
			tiny_warehouse_ids.append(candidate.id)
		if tiny_warehouse_ids.size() == 3:
			break
	var tiny_restore_city: City = null
	var tiny_retained_city: City = null
	for candidate in tiny_parent_cities:
		if tiny_warehouse_ids.has(candidate.id):
			continue
		if tiny_restore_city == null:
			tiny_restore_city = candidate
		elif tiny_retained_city == null:
			tiny_retained_city = candidate
			break
	_check(
		tiny_warehouse_ids.size() == 3
			and tiny_restore_city != null
			and tiny_retained_city != null,
		"忠诚恢复尾数回归必须找到三座粮仓及两座产能城市"
	)
	if (
		tiny_warehouse_ids.size() == 3
		and tiny_restore_city != null
		and tiny_retained_city != null
	):
		_set_warehouses(
			tiny_restore_state, tiny_parent, tiny_warehouse_ids,
			[1, 1, 1] as Array[int], tiny_warehouse_ids[0]
		)
		tiny_restore_city.food_per_half_year = 2
		preload("res://tests/state_rebellion_fixture.gd").isolate_city_as_state(tiny_restore_state, tiny_restore_city.id)
		tiny_restore_city.loyalty_target_nation = tiny_target
		tiny_retained_city.food_per_half_year = 1
		tiny_restore_state.refresh_derived()
		var tiny_target_stock_before := 0
		for warehouse in tiny_restore_state.warehouse_cities_of(tiny_target):
			tiny_target_stock_before += warehouse.food_storage
		var tiny_global_before := 0
		for city in tiny_restore_state.cities:
			tiny_global_before += city.food_storage
		var tiny_restored := tiny_restore_state.restore_regional_loyalty_target(
			tiny_parent, tiny_target,
			[tiny_restore_city.id] as Array[int]
		)
		var tiny_parent_stock_after := 0
		for warehouse in tiny_restore_state.warehouse_cities_of(tiny_parent):
			tiny_parent_stock_after += warehouse.food_storage
		var tiny_target_stock_after := 0
		for warehouse in tiny_restore_state.warehouse_cities_of(tiny_target):
			tiny_target_stock_after += warehouse.food_storage
		var tiny_global_after := 0
		for city in tiny_restore_state.cities:
			tiny_global_after += city.food_storage
		_check(
			tiny_restored
				and tiny_restore_city.owner_nation == tiny_target
				and tiny_parent_stock_after == 1
				and tiny_target_stock_after == tiny_target_stock_before + 2
				and tiny_global_before == 3
				and tiny_global_after == tiny_global_before
				and tiny_restore_state.territory_structure_valid(),
			(
				"忠诚恢复从 [1,1,1] 旧粮池划出 2 时必须全局守恒；"
				+ "before=%d parent=%d target=%d after=%d"
			) % [
				tiny_global_before, tiny_parent_stock_after,
				tiny_target_stock_after, tiny_global_after,
			]
		)


func _test_capital_capture_capitulation() -> void:
	print("[26c] 首都失陷：已控州整体确认、州外保留、立即投降")
	var surrender_state := preload("res://tests/support/grid_world.gd").new()
	surrender_state.generate_grid_world(6365)
	surrender_state.armies.clear()
	surrender_state.battles.clear()
	var captured_capital_id := int(
		surrender_state.administrative_center_city_ids[0]
	)
	var captured_region := surrender_state.administrative_members(
		captured_capital_id
	)
	var retained_city_id := -1
	var victor_city_id := -1
	var third_city_id := -1
	for candidate in surrender_state.cities:
		if candidate.is_dock or captured_region.has(candidate.id):
			continue
		if retained_city_id < 0:
			retained_city_id = candidate.id
		elif victor_city_id < 0:
			victor_city_id = candidate.id
		elif third_city_id < 0:
			third_city_id = candidate.id
			break
	for city in surrender_state.cities:
		city.owner_nation = 2
		city.is_capital = false
		city.has_warehouse = false
		city.food_storage = 0
		surrender_state.recognized_city_owners[city.id] = 2
	surrender_state.cities[victor_city_id].owner_nation = 0
	surrender_state.recognized_city_owners[victor_city_id] = 0
	var loser_city_ids := captured_region.duplicate()
	loser_city_ids.append(retained_city_id)
	for loser_city in loser_city_ids:
		surrender_state.cities[loser_city].owner_nation = 1
		surrender_state.recognized_city_owners[loser_city] = 1
	_set_single_warehouse(surrender_state, 0, victor_city_id, 100)
	_set_single_warehouse(surrender_state, 1, captured_capital_id, 100)
	_set_single_warehouse(surrender_state, 2, third_city_id, 100)
	_set_warehouses(
		surrender_state,
		3,
		[] as Array[int],
		[] as Array[int]
	)
	for nation_a in range(surrender_state.nations.size()):
		for nation_b in range(
			nation_a + 1,
			surrender_state.nations.size()
		):
			surrender_state.set_diplomatic_relation(
				nation_a,
				nation_b,
				GameState.DiplomaticRelation.NEUTRAL
			)
	surrender_state.set_diplomatic_relation(
		0,
		1,
		GameState.DiplomaticRelation.WAR
	)
	surrender_state.refresh_derived()
	var surrender_sim := Simulation.new()
	surrender_sim.setup(surrender_state)
	var capital_captor := _make_army(814, 0, 5000, 10)
	capital_captor.location_city = victor_city_id
	capital_captor.move_from = victor_city_id
	surrender_state.armies.append(capital_captor)
	var expected_capital_transfers := (
		surrender_sim._capital_capture_transfer_city_ids(
			1, captured_capital_id, 0
		)
	)
	var capital_capture_revision_before := surrender_state.ownership_revision
	surrender_sim._capture_city(
		capital_captor,
		surrender_state.cities[captured_capital_id]
	)
	var captured_capital_transferred := (
		surrender_state.cities[captured_capital_id].owner_nation == 0
		and surrender_state.recognized_owner_of(captured_capital_id) == 0
		and surrender_state.cities[captured_capital_id].loyalty_target_nation == 0
		and surrender_state.cities[captured_capital_id].rebellion_progress == 0
		and surrender_state.cities[captured_capital_id].rebellion_cooldown_until_day
			> surrender_state.day
	)
	var captured_region_transferred := true
	for transferred_city in expected_capital_transfers:
		captured_region_transferred = (
			captured_region_transferred
			and surrender_state.cities[transferred_city].owner_nation == 0
			and surrender_state.recognized_owner_of(transferred_city) == 0
			and surrender_state.cities[
				transferred_city
			].occupation_sponsor_nation == -1
		)
	var outside_city_retained := (
		surrender_state.cities[retained_city_id].owner_nation == 1
		and surrender_state.recognized_owner_of(retained_city_id) == 1
		and surrender_state.cities[retained_city_id].occupation_sponsor_nation == -1
	)
	var capital_surrender_recorded := (
		not surrender_state.diplomatic_history.is_empty()
		and int(
			surrender_state.diplomatic_history[-1].get(
				"surrendering_nation",
				-1
			)
		) == 1
	)
	_check(
		captured_capital_transferred
			and captured_region_transferred
			and outside_city_retained,
		"首都州治失陷后该州须整体归胜方，州外城市保留给战败国"
	)
	_check(
		expected_capital_transfers == captured_region
			and surrender_state.ownership_revision
				== capital_capture_revision_before + 2,
		(
			"首都所在州须原子提交，随后和平结算独立提交"
			+ "（revision %d→%d）"
		) % [
			capital_capture_revision_before,
			surrender_state.ownership_revision,
		]
	)
	_check(
		not surrender_state.is_enemy(0, 1)
			and surrender_state.truce_until(0, 1)
				> surrender_state.day
			and capital_surrender_recorded,
		"首都失陷当日必须直接结束战争并记录战败国投降"
	)
	_check(
		surrender_state.nations[1].capital_city_id == retained_city_id
			and surrender_state.cities[
				surrender_state.nations[1].capital_city_id
			].owner_nation == 1
			and surrender_state.cities[
				surrender_state.nations[1].capital_city_id
			].is_capital
			and surrender_state.cities[
				surrender_state.nations[1].capital_city_id
			].has_warehouse,
		"战败国应迁都到州外保留城市并继续存续"
	)
	# 被实际攻陷的首都已永久确认并进入冷却，后续忠诚月不能把它当作
	# 和平期临时占领，重新“恢复”给旧法理国。
	for stable_city in surrender_state.cities:
		if stable_city.id == captured_capital_id:
			continue
		stable_city.loyalty_target_nation = stable_city.owner_nation
		stable_city.loyalty = RebellionSystem.LOYALTY_DEFAULT
		stable_city.rebellion_progress = 0
	var peaceful_return_event := false
	for _loyalty_month in range(
		RebellionSystem.REBELLION_PROGRESS_MONTHS
	):
		surrender_state.day += Simulation.DAYS_PER_MONTH
		for event_value in RebellionSystem.resolve_month(
			surrender_state
		):
			var loyalty_event: Dictionary = event_value
			peaceful_return_event = (
				peaceful_return_event
				or (
					str(loyalty_event.get("kind", ""))
						== "loyalty_target_restored"
					and int(loyalty_event.get("target_id", -1))
						== captured_capital_id
				)
			)
	var permanent_cession_held := not peaceful_return_event
	permanent_cession_held = (
		permanent_cession_held
		and surrender_state.cities[captured_capital_id].owner_nation == 0
		and surrender_state.recognized_owner_of(captured_capital_id) == 0
		and surrender_state.cities[captured_capital_id].loyalty_target_nation == 0
	)
	for transferred_city in expected_capital_transfers:
		permanent_cession_held = (
			permanent_cession_held
			and surrender_state.cities[transferred_city].owner_nation == 0
			and surrender_state.recognized_owner_of(transferred_city) == 0
		)
	permanent_cession_held = (
		permanent_cession_held
		and surrender_state.cities[retained_city_id].owner_nation == 1
		and surrender_state.recognized_owner_of(retained_city_id) == 1
	)
	_check(
		permanent_cession_held
			and not surrender_state.is_enemy(0, 1)
			and surrender_state.territory_structure_valid(),
		"首都州割让永久确认后推进三个忠诚月不得和平归还，州外城市仍属旧国"
	)
	surrender_sim.free()

	# 领土事务 API 的直接契约：先转实控再转法理，以及一体化永久主权
	# 转移，都必须把 owner/legal/政治目标收敛并清理叛乱状态。
	var permanent_api_state := preload("res://tests/support/grid_world.gd").new()
	permanent_api_state.generate_grid_world(6367)
	for api_a in range(permanent_api_state.nations.size()):
		for api_b in range(api_a + 1, permanent_api_state.nations.size()):
			permanent_api_state.set_diplomatic_relation(
				api_a, api_b, GameState.DiplomaticRelation.NEUTRAL
			)
	permanent_api_state.set_diplomatic_relation(
		0, 1, GameState.DiplomaticRelation.WAR
	)
	permanent_api_state.day = 123
	var api_targets: Array[City] = []
	for candidate in permanent_api_state.land_cities_of(1):
		if candidate.is_capital or candidate.has_warehouse:
			continue
		api_targets.append(candidate)
		if api_targets.size() >= 2:
			break
	_check(api_targets.size() == 2, "永久领土事务 API 回归必须找到两座普通城市")
	if api_targets.size() == 2:
		var title_city := api_targets[0]
		title_city.rebellion_progress = (
			RebellionSystem.REBELLION_PROGRESS_MONTHS
		)
		title_city.rebellion_cooldown_until_day = -1
		var control_result: Dictionary = permanent_api_state.transfer_city_control(
			title_city.id, 0, 0
		)
		_check(
			bool(control_result.get("ok", false))
				and bool(control_result.get("changed", false))
				and control_result.get("changed_city_ids", [])
					== [title_city.id]
				and title_city.owner_nation == 0
				and permanent_api_state.recognized_owner_of(
					title_city.id
				) == 1
				and title_city.occupation_sponsor_nation == 0
				and permanent_api_state.territory_structure_valid(),
			"transfer_city_control 必须只改变战争实控并保留法理与有效 sponsor"
		)
		var title_result: Dictionary = (
			permanent_api_state.transfer_city_legal_title(
				title_city.id, 0, true
			)
		)
		_check(
			bool(title_result.get("ok", false))
				and bool(title_result.get("changed", false))
				and title_result.get("changed_city_ids", [])
					== [title_city.id]
				and title_city.owner_nation == 0
				and permanent_api_state.recognized_owner_of(
					title_city.id
				) == 0
				and title_city.loyalty_target_nation == 0
				and title_city.occupation_sponsor_nation == -1
				and title_city.rebellion_progress == 0
				and title_city.rebellion_cooldown_until_day
					> permanent_api_state.day
				and permanent_api_state.territory_structure_valid(),
			"transfer_city_legal_title 永久确认后必须同步政治归属并清除临时占领"
		)
		var sovereignty_city := api_targets[1]
		sovereignty_city.rebellion_progress = (
			RebellionSystem.REBELLION_PROGRESS_MONTHS
		)
		sovereignty_city.rebellion_cooldown_until_day = -1
		var sovereignty_result: Dictionary = (
			permanent_api_state.transfer_city_sovereignty(
				sovereignty_city.id, 0, "direct_test_transfer"
			)
		)
		_check(
			bool(sovereignty_result.get("ok", false))
				and bool(sovereignty_result.get("changed", false))
				and sovereignty_result.get("changed_city_ids", [])
					== [sovereignty_city.id]
				and sovereignty_city.owner_nation == 0
				and permanent_api_state.recognized_owner_of(
					sovereignty_city.id
				) == 0
				and sovereignty_city.loyalty_target_nation == 0
				and sovereignty_city.occupation_sponsor_nation == -1
				and sovereignty_city.rebellion_progress == 0
				and sovereignty_city.rebellion_cooldown_until_day
					> permanent_api_state.day
				and permanent_api_state.territory_structure_valid(),
			"transfer_city_sovereignty 必须原子完成实控、法理和政治目标的永久转移"
		)

	# 首都失陷投降后，和平结算检测剩余合法飞地，并把飞地整体转交给
	# 与其陆路边界最多的周边国家；主体领土仍归战败国。
	var enclave_state := preload("res://tests/support/grid_world.gd").new()
	enclave_state.generate_grid_world(6366)
	enclave_state.armies.clear()
	enclave_state.battles.clear()
	for city in enclave_state.cities:
		city.owner_nation = 2
		city.is_capital = false
		city.has_warehouse = false
		city.food_storage = 0
		enclave_state.recognized_city_owners[city.id] = 2
	enclave_state.cities[0].owner_nation = 0
	enclave_state.recognized_city_owners[0] = 0
	# B 主体链 1-2-3-4 连通；城16 是与主体断开的孤立飞地（只连中立国2）。
	for c in [1, 2, 3, 4, 16]:
		enclave_state.cities[c].owner_nation = 1
		enclave_state.recognized_city_owners[c] = 1
	for road in [[0, 1], [1, 2], [2, 3], [3, 4], [16, 17], [16, 24]]:
		var enclave_edge := enclave_state.edge_of(int(road[0]), int(road[1]))
		if enclave_edge != null:
			enclave_edge.max_manpower = Edge.STANDARD_MANPOWER
	_set_single_warehouse(enclave_state, 0, 0, 100)
	_set_single_warehouse(enclave_state, 1, 1, 100)
	_set_single_warehouse(enclave_state, 2, 63, 100)
	_set_warehouses(
		enclave_state,
		3,
		[] as Array[int],
		[] as Array[int]
	)
	for enclave_a in range(enclave_state.nations.size()):
		for enclave_b in range(enclave_a + 1, enclave_state.nations.size()):
			enclave_state.set_diplomatic_relation(
				enclave_a,
				enclave_b,
				GameState.DiplomaticRelation.NEUTRAL
			)
	enclave_state.set_diplomatic_relation(
		0, 1, GameState.DiplomaticRelation.WAR
	)
	enclave_state.refresh_derived()
	var enclave_sim := Simulation.new()
	enclave_sim.setup(enclave_state)
	var enclave_captor := _make_army(816, 0, 5000, 10)
	enclave_captor.location_city = 0
	enclave_captor.move_from = 0
	enclave_state.armies.append(enclave_captor)
	enclave_sim._capture_city(enclave_captor, enclave_state.cities[1])
	var enclave_capital := enclave_state.nations[1].capital_city_id
	_check(
		enclave_state.cities[16].owner_nation == 2
			and enclave_state.recognized_owner_of(16) == 2
			and enclave_state.cities[16].occupation_sponsor_nation == -1
			and enclave_state.cities[4].owner_nation == 1,
		(
			"投降后合法飞地城16必须转交周边国家，"
			+ "主体城4也保留：城16归属=%d 法理=%d 首都=%d"
		) % [
			enclave_state.cities[16].owner_nation,
			enclave_state.recognized_owner_of(16),
			enclave_capital,
		]
	)
	_check(
		enclave_state.territory_structure_valid(),
		"首都投降转交合法飞地后领土结构不变量必须成立"
	)
	enclave_sim.free()

# ------------------------------------------------------------------ 27. 驻防战斗适应 + 增援稀释

func _test_holding_combat_adaptation() -> void:
	print("[27] 驻防战斗：快照驻防侧、防御适应、增援稀释、胜后恢复 HOLDING")
	# 同种子同军力：驻防 90 天仅提高防御倍率，应让守方损失更少；攻击惩罚保持相同。
	var atk0 := _make_army(820, 0, 1000, 10)
	var def0 := _make_army(821, 1, 1000, 10)
	var b0 := _make_field_battle([atk0], [def0], 1.0, 4)
	b0.holding_side = 2
	b0.holding_days = 0.0
	var rng0 := RandomNumberGenerator.new()
	rng0.seed = 88
	CombatFixture.resolve_round(b0)

	var atk90 := _make_army(822, 0, 1000, 10)
	var def90 := _make_army(823, 1, 1000, 10)
	var b90 := _make_field_battle([atk90], [def90], 1.0, 4)
	b90.holding_side = 2
	b90.holding_days = 90.0
	var rng90 := RandomNumberGenerator.new()
	rng90.seed = 88
	CombatFixture.resolve_round(b90)
	_check(def90.size > def0.size,
		"长期驻防应减少守方伤亡：0天=%d，90天=%d" % [1000 - def0.size, 1000 - def90.size])
	_check(atk90.size == atk0.size,
		"驻防时间不得改变守军攻击惩罚；攻击方伤亡应一致：%d/%d" % [atk0.size, atk90.size])

	var gs := preload("res://tests/support/grid_world.gd").new()
	gs.generate_grid_world(7170)
	var sim := Simulation.new()
	sim.setup(gs)
	gs.armies.clear()
	gs.battles.clear()
	var c1 := 0
	var c2 := 1
	var edge := gs.edge_of(c1, c2)
	edge.danger = 1.0
	var holder := _place_army_on_edge(gs, 830, 0, c1, c2, 0.5)
	holder.state = Army.State.HOLDING
	holder.holding_days = 60
	var enemy := _place_army_on_edge(gs, 831, 1, c2, c1, 0.5)
	sim._detect_encounters()
	var battle: Battle = gs.battles[0]
	var holder_side := 1 if battle.side_a.has(holder) else 2
	_check(battle.holding_side == holder_side and _approx(battle.holding_days, 60.0),
		"野战应快照驻防侧及 60 天适应，side=%d days=%.1f" % [battle.holding_side, battle.holding_days])

	var reinforcement := _place_army_on_edge(gs, 832, 0, c1, c2, 0.5)
	sim._join_field_battle(battle, reinforcement, edge)
	_check(_approx(battle.holding_days, 30.0),
		"同兵力非驻防增援应把 60 天适应稀释到 30 天，实为 %.1f" % battle.holding_days)

	enemy.size = 0
	sim._resolve_battles()
	_check(holder.state == Army.State.HOLDING and holder.holding_days == 60,
		"原驻防军获胜后应恢复 HOLDING 并保留自身适应")
	_check(reinforcement.state == Army.State.MOVING,
		"普通增援获胜后应恢复 MOVING，不应免费获得 HOLDING")
	sim.free()

# ------------------------------------------------------------------ 28. 溃逃接战 + 位置连续性

func _test_stable_force_resource_cache_filter() -> void:
	print("[29a] AI 资源缓存：只复用快照后仍稳定的索引，动态报告必须重算")
	var sim := Simulation.new()
	var marker := {"value": 7}
	var snapshot_cache := {
		"nation_aggregates_built": true,
		"frontier_matrix_built": true,
		"monthly_gold_flows": marker,
		"power:0": marker,
		"troops:0": marker,
		"full_troops:0": marker,
		"owned_cities:0": marker,
		"wars:0": marker,
		"allies:0": marker,
		"coalition:0": marker,
		"frontier:0:1": marker,
		"borders:0": marker,
		"resource:0": marker,
		"food:0:0:1000:0": marker,
		"food_stock:0": marker,
		"food_posture:0": marker,
		"mobilization:0:0": marker,
		"garrison_by_city": marker,
		"threat:0:1": marker,
	}
	var stable := sim._stable_force_resource_cache_from_snapshot(
		snapshot_cache
	)
	var expected_stable := [
		"frontier_matrix_built", "monthly_gold_flows",
		"wars:0", "allies:0", "frontier:0:1",
		"borders:0",
	]
	var stable_keys := stable.keys()
	stable_keys.sort()
	expected_stable.sort()
	_check(
		stable_keys == expected_stable,
		"军制缓存白名单只应保留稳定索引，实为 %s" % [stable_keys]
	)
	_check(
		stable["frontier:0:1"] == marker
		and not stable.has("nation_aggregates_built")
		and not stable.has("power:0")
		and not stable.has("troops:0")
		and not stable.has("full_troops:0")
		and not stable.has("owned_cities:0")
		and not stable.has("coalition:0")
		and not stable.has("resource:0")
		and not stable.has("food:0:0:1000:0")
		and not stable.has("food_stock:0")
		and not stable.has("food_posture:0")
		and not stable.has("mobilization:0:0")
		and not stable.has("garrison_by_city")
		and not stable.has("threat:0:1"),
		"国库/粮食/姿态/驻军等快照后可变报告不得跨阶段复用"
	)
	sim.free()


func _test_war_preparation_cancel_cooldown() -> void:
	print("[32a2] 备战冷却：取消备战后冷却期内不得重开，冷却期满后恢复；集结超时尽力而战")
	# 用可复现的 AI 世界：推进到有备战意愿的时代，找出一个「本可发起 PREPARE_WAR」的国家，
	# 给它盖上取消冷却戳后，同一评估里它必须不再出现 PREPARE_WAR；冷却期满后门控解除。
	var gs := preload("res://tests/support/grid_world.gd").new()
	gs.generate_world(12345, 12)
	gs.day = DiplomacyAI.WAR_FATIGUE_REFERENCE_DAYS * 5 / 2
	var baseline: Array[Dictionary] = []
	DiplomacyAI._collect_war_actions(gs, baseline, {}, {})
	var prep_nation := -1
	for action in baseline:
		if int(action.get("kind", -1)) == DiplomacyAI.Action.PREPARE_WAR:
			prep_nation = int(action.get("a", -1))
			break
	# 若该世界此刻无人发起备战，跳过（不同版本平衡下可能无备战意愿），避免脆弱断言。
	if prep_nation < 0:
		_check(true, "该世界此刻无备战意愿，跳过冷却门控用例（非失败）")
		return

	# 盖冷却戳：冷却期内同一评估必须不再为该国产生 PREPARE_WAR。
	gs.nations[prep_nation].war_preparation_cancelled_day = gs.day
	var cooled: Array[Dictionary] = []
	DiplomacyAI._collect_war_actions(gs, cooled, {}, {})
	var prepares_in_cooldown := false
	for action in cooled:
		if (
			int(action.get("kind", -1)) == DiplomacyAI.Action.PREPARE_WAR
			and int(action.get("a", -1)) == prep_nation
		):
			prepares_in_cooldown = true
	_check(not prepares_in_cooldown, "取消备战冷却期内该国不得重新发起 PREPARE_WAR")

	# 冷却期满：把取消戳推到冷却窗口之外，门控解除，该国可再次评估备战。
	gs.nations[prep_nation].war_preparation_cancelled_day = (
		gs.day - DiplomacyAI.WAR_PREPARATION_CANCEL_COOLDOWN_DAYS - 1
	)
	var recovered: Array[Dictionary] = []
	DiplomacyAI._collect_war_actions(gs, recovered, {}, {})
	var prepares_after := false
	for action in recovered:
		if (
			int(action.get("kind", -1)) == DiplomacyAI.Action.PREPARE_WAR
			and int(action.get("a", -1)) == prep_nation
		):
			prepares_after = true
	_check(prepares_after, "冷却期满后该国必须恢复发起 PREPARE_WAR 的能力")


func _test_war_preparation_route_block_grace() -> void:
	print("[32a3] 备战稳定性：断路自动换薄弱目标；全线封闭与边境屯兵均不得取消")
	var gs := preload("res://tests/support/grid_world.gd").new()
	gs.generate_grid_world(32041)
	# All fallback states belong to one business region; this fixture tests roads.
	gs.region_ids.fill(0)
	gs.region_analysis_revision += 1
	for a in range(gs.nations.size()):
		for b in range(a + 1, gs.nations.size()):
			gs.set_diplomatic_relation(
				a, b, GameState.DiplomaticRelation.NEUTRAL
			)
	gs.day = DiplomacyAI.MIN_NEUTRAL_DAYS
	var objective := DiplomacyAI.select_war_objective(gs, 0, 1)
	var objective_center := int(objective.get("city_id", -1))
	var objective_city := int(objective.get("tactical_city_id", -1))
	_check(objective_city >= 0, "测试世界应能为国0选出对国1的进攻目标")
	if objective_city < 0:
		return
	var staging := DiplomacyAI.staging_cities_for_objective(
		gs, 0, objective_city
	)
	_check(not staging.is_empty(), "初始应存在合法集结城市")
	if staging.is_empty():
		return
	var sim := Simulation.new()
	sim.setup(gs)
	var nation := gs.nations[0]
	nation.war_preparation_target_nation = 1
	nation.war_preparation_objective_city = objective_city
	nation.war_preparation_objective_center_city = objective_center
	nation.war_preparation_started_day = gs.day
	nation.war_preparation_unready_since_day = -1

	# 只阻断原目标：应生成“保持备战并换目标”动作，而非取消。
	var closed_edges: Array[Edge] = []
	for staging_city in staging:
		var edge := gs.edge_of(staging_city, objective_city)
		if edge != null:
			edge.max_manpower = 0
			closed_edges.append(edge)
	gs.road_network_revision += 1
	var retarget_actions: Array[Dictionary] = []
	DiplomacyAI._collect_existing_war_preparation(
		gs, 0, retarget_actions, {}
	)
	var retarget_action: Dictionary = {}
	for action in retarget_actions:
		if int(action.get("kind", -1)) == DiplomacyAI.Action.RETARGET_WAR_PREPARATION:
			retarget_action = action
			break
	_check(
		not retarget_action.is_empty()
			and int(retarget_action["objective_city"]) != objective_city
			and int(retarget_action["objective_center_city"]) >= 0,
		"原目标道路封闭后必须保持对同国备战并改选可达州内战术城市"
	)
	var started_day := nation.war_preparation_started_day
	var mobilization_target := nation.war_mobilization_target_troops
	var retargeted := (
		not retarget_action.is_empty()
		and sim._execute_diplomatic_action(retarget_action)
	)
	_check(
		retargeted
			and nation.war_preparation_started_day == started_day
			and nation.war_mobilization_target_troops == mobilization_target,
		"改换目标必须原子保留原备战开始日和已完成动员，不得重开一轮备战"
	)

	# 封闭攻击者与目标国之间的全部道路，并把备战时钟推过360天。
	# 即使永久无路也只能等待拓扑恢复，不能由道路状态触发取消。
	for edge in gs.edges:
		var owner_a := gs.cities[edge.city_a].owner_nation
		var owner_b := gs.cities[edge.city_b].owner_nation
		if (owner_a == 0 and owner_b == 1) or (owner_a == 1 and owner_b == 0):
			edge.max_manpower = 0
	gs.day = started_day + DiplomacyAI.WAR_PREPARATION_MAX_DAYS + 30
	var blocked_actions: Array[Dictionary] = []
	DiplomacyAI._collect_existing_war_preparation(gs, 0, blocked_actions, {})
	var blocked_cancel := false
	for action in blocked_actions:
		blocked_cancel = (
			blocked_cancel
			or int(action.get("kind", -1))
				== DiplomacyAI.Action.CANCEL_WAR_PREPARATION
		)
	_check(
		blocked_actions.is_empty() and not blocked_cancel,
		"全线道路永久封闭且超过集结上限时也不得取消备战"
	)

	# 边境屯兵数量只影响军事部署，不参与是否保持备战的门控。
	var border_army: Army = null
	for army in gs.armies:
		if army.owner_nation == 1:
			border_army = army
			break
	if border_army != null:
		border_army.size = border_army.max_size
		border_army.location_city = objective_city
		border_army.move_from = objective_city
	var massed_actions: Array[Dictionary] = []
	DiplomacyAI._collect_existing_war_preparation(gs, 0, massed_actions, {})
	var massed_cancel := false
	for action in massed_actions:
		massed_cancel = (
			massed_cancel
			or int(action.get("kind", -1))
				== DiplomacyAI.Action.CANCEL_WAR_PREPARATION
		)
	_check(
		not massed_cancel,
		"敌方边境屯兵增减不得触发取消备战"
	)
	sim.free()


func _test_alliance_war_coalitions() -> void:
	print("[32b] 联盟战争：整体宣战、战时入盟、集团议和与分国军事AI")
	var gs := preload("res://tests/support/grid_world.gd").new()
	gs.generate_grid_world(32021)
	for nation_a in range(gs.nations.size()):
		for nation_b in range(nation_a + 1, gs.nations.size()):
			gs.set_diplomatic_relation(
				nation_a,
				nation_b,
				GameState.DiplomaticRelation.NEUTRAL
			)
	gs.set_diplomatic_relation(
		0, 3, GameState.DiplomaticRelation.ALLIED
	)
	gs.set_diplomatic_relation(
		1, 2, GameState.DiplomaticRelation.ALLIED
	)
	var sim := Simulation.new()
	sim.setup(gs)
	var objective := DiplomacyAI.select_war_objective(gs, 0, 1)
	var objective_city := int(objective.get("tactical_city_id", -1))
	var objective_center := int(objective.get("city_id", -1))
	var declared := sim._execute_diplomatic_action({
		"kind": DiplomacyAI.Action.DECLARE_WAR,
		"a": 0,
		"b": 1,
		"objective_city": objective_city,
		"objective_center_city": objective_center,
		"objective_reason": "联盟集团战争回归",
		"mobilization_armies": 0,
		"reason": "联盟整体宣战",
	})
	var complete_war_matrix := declared
	for attacker in [0, 3]:
		for defender in [1, 2]:
			complete_war_matrix = (
				complete_war_matrix
				and gs.is_enemy(attacker, defender)
				and int(
					gs.war_objective(attacker, defender).get(
						"city_id",
						-1
					)
				) == objective_center
			)
	_check(
		complete_war_matrix
			and gs.alliance_bloc(0) == [0, 3]
			and gs.alliance_bloc(1) == [1, 2],
		"联盟宣战必须形成集团间完整敌对矩阵，并向所有攻击成员传播共同目标"
	)
	gs.day += DiplomacyAI.MIN_WAR_DAYS
	var coalition_assessment := DiplomacyAI.peace_assessment(
		gs,
		0,
		1
	)
	_check(
		coalition_assessment["bloc_a"] == [0, 3]
			and coalition_assessment["bloc_b"] == [1, 2]
			and (
				coalition_assessment["breakdown_a"]["member_scores"]
				as Dictionary
			).size() == 2
			and (
				coalition_assessment["breakdown_b"]["member_scores"]
				as Dictionary
			).size() == 2,
		"联盟和平意愿必须聚合双方全部成员，不能只读取议和代表国"
	)
	var coalition_plan := CoalitionCampaignFront.new()
	coalition_plan.center_city_id = objective_center
	coalition_plan.war_id = int(gs.war_objective(0, 1).get("war_id", -1))
	gs.register_campaign_front(
		coalition_plan, [0, 3] as Array[int], 0
	)
	_check(
		gs.campaign_front_for(3, objective_center) == coalition_plan,
		"接壤联盟成员必须共享同一州战线对象"
	)
	var coalition_peace := sim._execute_diplomatic_action({
		"kind": DiplomacyAI.Action.MAKE_PEACE,
		"a": 0,
		"b": 1,
		"reason": "联盟整体议和回归",
	})
	var complete_peace_matrix := coalition_peace
	for former_attacker in [0, 3]:
		for former_defender in [1, 2]:
			complete_peace_matrix = (
				complete_peace_matrix
				and not gs.is_enemy(
					former_attacker,
					former_defender
				)
				and gs.truce_until(
					former_attacker,
					former_defender
				) > gs.day
				and gs.war_objective(
					former_attacker,
					former_defender
				).is_empty()
			)
	_check(
		complete_peace_matrix,
		"联盟议和必须原子结束集团间全部战争关系、目标并设置统一停战期"
	)
	sim.free()

	# 和平计划必须把外交与战果确认放进同一事务；两类 revision 各只递增一次。
	var atomic_fixture := _make_atomic_coalition_peace_fixture(32025)
	var atomic_state: GameState = atomic_fixture["state"]
	var atomic_sim: Simulation = atomic_fixture["simulation"]
	var atomic_city_id := int(atomic_fixture["occupied_city_id"])
	var atomic_plan := atomic_sim._plan_coalition_peace(0, 1)
	var atomic_ownership_revision := atomic_state.ownership_revision
	var atomic_diplomacy_revision := atomic_state.diplomacy_revision
	var atomic_peace := atomic_sim._commit_coalition_peace_plan(atomic_plan)
	_check(
		bool(atomic_peace.get("changed", false))
			and atomic_state.recognized_owner_of(atomic_city_id) == 0
			and atomic_state.cities[atomic_city_id].owner_nation == 0
			and atomic_state.cities[
				atomic_city_id
			].occupation_sponsor_nation == -1
			and atomic_state.relation_between(0, 1)
				== GameState.DiplomaticRelation.NEUTRAL
			and atomic_state.truce_until(0, 1)
				== atomic_state.day + GameState.DEFAULT_TRUCE_DAYS
			and atomic_state.ownership_revision
				== atomic_ownership_revision + 1
			and atomic_state.diplomacy_revision
				== atomic_diplomacy_revision + 1,
		"集团和平必须用一笔事务同时确认领土并结束战争，两类 revision 各递增一次"
	)
	atomic_sim.free()

	# stale diplomacy revision 必须在事务入口拒绝；和平的所有外围收尾也不得发生。
	var stale_fixture := _make_atomic_coalition_peace_fixture(32026)
	var stale_state: GameState = stale_fixture["state"]
	var stale_sim: Simulation = stale_fixture["simulation"]
	var stale_plan := stale_sim._plan_coalition_peace(0, 1)
	stale_plan["expected_diplomacy_revision"] = (
		int(stale_plan["expected_diplomacy_revision"]) + 1
	)
	var stale_before := _coalition_peace_fingerprint(stale_state, stale_sim)
	var stale_result := stale_sim._commit_coalition_peace_plan(stale_plan)
	_check(
		not bool(stale_result.get("changed", true))
			and _coalition_peace_fingerprint(stale_state, stale_sim)
				== stale_before,
		(
			"stale diplomacy revision 必须让整笔和平零变化：外交/停战、目标、"
			+ "叛乱、军队/战斗、动员、财政快照及两个 revision 均不得提前收尾"
		)
	)
	stale_sim.free()

	# 即使合法领土操作已排在计划中，末尾非法外交 operation 也必须整批回滚。
	var invalid_fixture := _make_atomic_coalition_peace_fixture(32027)
	var invalid_state: GameState = invalid_fixture["state"]
	var invalid_sim: Simulation = invalid_fixture["simulation"]
	var invalid_plan := invalid_sim._plan_coalition_peace(0, 1)
	var invalid_diplomacy_operations: Array[Dictionary] = []
	invalid_diplomacy_operations.assign(
		invalid_plan["diplomatic_operations"]
	)
	invalid_diplomacy_operations.append({
		"nation_a": 0,
		"nation_b": 2,
		"relation": 999,
		"truce_days": GameState.DEFAULT_TRUCE_DAYS,
	})
	invalid_plan["diplomatic_operations"] = invalid_diplomacy_operations
	var invalid_before := _coalition_peace_fingerprint(
		invalid_state, invalid_sim
	)
	var invalid_result := invalid_sim._commit_coalition_peace_plan(
		invalid_plan
	)
	_check(
		not bool(invalid_result.get("changed", true))
			and _coalition_peace_fingerprint(invalid_state, invalid_sim)
				== invalid_before,
		"和平计划末尾含非法 operation 时必须拒绝整批提交并保持完整状态指纹不变"
	)
	invalid_sim.free()

	# 最终统计必须读取每城最后一条 operation，而不是 collector 中途命中数。
	var statistics_state := preload("res://tests/support/grid_world.gd").new()
	statistics_state.generate_grid_world(32028)
	statistics_state.armies.clear()
	statistics_state.battles.clear()
	var statistics_city_id := -1
	for candidate in statistics_state.land_cities_of(0):
		if not candidate.is_capital and not candidate.has_warehouse:
			statistics_city_id = candidate.id
			break
	preload("res://tests/state_rebellion_fixture.gd").isolate_city_as_state(statistics_state, statistics_city_id)
	var statistics_rebel := statistics_state.start_regional_rebellion(
		0, [statistics_city_id] as Array[int]
	)
	statistics_state.day += (
		RebellionSystem.REGIONAL_REBELLION_MIN_WAR_DAYS
	)
	var statistics_sim := Simulation.new()
	statistics_sim.setup(statistics_state)
	var statistics_plan := statistics_sim._plan_coalition_peace(
		0, statistics_rebel
	)
	var final_reason := ""
	for operation_value in statistics_plan.get("operations", []):
		var operation: Dictionary = operation_value
		if int(operation.get("city_id", -1)) == statistics_city_id:
			final_reason = str(operation.get("reason", ""))
	_check(
		statistics_city_id >= 0
			and statistics_rebel >= 0
			and not final_reason.is_empty(),
		"和平统计必须按 operation_by_city 最终 reason 计数，同城后续阶段不得重复虚报"
	)
	statistics_sim.free()

	# 无城 sponsor 仍可参与另一场未结战争。0-1 和平不得把 sponsor=2、legal=3
	# 的独立占领串案 normalize，即使 2 已经没有任何城市。
	var sponsor_fixture := _make_atomic_coalition_peace_fixture(32029)
	var sponsor_state: GameState = sponsor_fixture["state"]
	var sponsor_sim: Simulation = sponsor_fixture["simulation"]
	var isolated_city: City = null
	for candidate in sponsor_state.land_cities_of(3):
		if not candidate.is_capital and not candidate.has_warehouse:
			isolated_city = candidate
			break
	assert(isolated_city != null)
	isolated_city.owner_nation = 0
	isolated_city.occupation_sponsor_nation = 2
	sponsor_state.set_diplomatic_relation(
		2, 3, GameState.DiplomaticRelation.WAR
	)
	var sponsor_removal_ops: Array[Dictionary] = []
	for sponsor_city in sponsor_state.cities_of(2):
		sponsor_removal_ops.append({
			"city_id": sponsor_city.id,
			"controller_id": 3,
			"legal_owner_id": 3,
			"sponsor_id": -1,
			"reset_political_target": true,
			"stock_policy": GameState.TerritoryStockDisposition.MOVE_TO_NEW_POOL,
			"reason": "landless_sponsor_fixture",
		})
	var sponsor_removed := sponsor_state.apply_territory_transaction(
		sponsor_removal_ops
	)
	var sponsor_plan := sponsor_sim._plan_coalition_peace(0, 1)
	var sponsor_city_planned := false
	for operation_value in sponsor_plan.get("operations", []):
		var operation: Dictionary = operation_value
		sponsor_city_planned = (
			sponsor_city_planned
			or int(operation.get("city_id", -1)) == isolated_city.id
		)
	_check(
		bool(sponsor_removed.get("ok", false))
			and sponsor_state.cities_of(2).is_empty()
			and sponsor_state.is_enemy(2, 3)
			and not sponsor_city_planned,
		"无城 sponsor 与法理国的另一场 WAR 必须阻止本次集团和平串案归还占领"
	)
	sponsor_sim.free()

	# 嵌套叛乱同时镇压必须把所有 rebel 直接解析到最终母国，不能让中间
	# rebel 在 finalizer 阶段通过吞并其子叛军重新获得军队或资源。
	var nested_state := preload("res://tests/support/grid_world.gd").new()
	nested_state.generate_grid_world(32030)
	nested_state.armies.clear()
	nested_state.battles.clear()
	for nested_a in range(nested_state.nations.size()):
		for nested_b in range(nested_a + 1, nested_state.nations.size()):
			nested_state.set_diplomatic_relation(
				nested_a, nested_b, GameState.DiplomaticRelation.NEUTRAL
			)
	var nested_core_one := nested_state.land_cities_of(0)[0].id
	var nested_core_two := nested_state.land_cities_of(1)[0].id
	nested_state.rebellions[1] = {
		"parent_id": 0,
		"started_day": 0,
		"core_city_ids": [nested_core_one] as Array[int],
		"recognized": false,
		"active": true,
	}
	nested_state.rebellions[2] = {
		"parent_id": 1,
		"started_day": 0,
		"core_city_ids": [nested_core_two] as Array[int],
		"recognized": false,
		"active": true,
	}
	# 直接注入旧版可产生的嵌套叛乱外交快照，验证新规则上线后仍能清理
	# 历史坏状态；当前公共入口会拒绝活跃叛军之间新建战争。
	nested_state.diplomatic_relations["0:1"] = (
		GameState.DiplomaticRelation.WAR
	)
	nested_state.diplomatic_relations["1:2"] = (
		GameState.DiplomaticRelation.WAR
	)
	nested_state.diplomatic_relations["0:2"] = (
		GameState.DiplomaticRelation.ALLIED
	)
	nested_state.day = RebellionSystem.REGIONAL_REBELLION_MIN_WAR_DAYS
	var nested_sim := Simulation.new()
	nested_sim.setup(nested_state)
	var nested_owners: Array[int] = []
	var nested_legal: Array[int] = []
	var nested_sponsors: Array[int] = []
	nested_owners.resize(nested_state.cities.size())
	nested_legal.resize(nested_state.cities.size())
	nested_sponsors.resize(nested_state.cities.size())
	for nested_city in nested_state.cities:
		nested_owners[nested_city.id] = nested_city.owner_nation
		nested_legal[nested_city.id] = nested_state.recognized_owner_of(
			nested_city.id
		)
		nested_sponsors[nested_city.id] = nested_city.occupation_sponsor_nation
	var nested_draft := {
		"owners": nested_owners,
		"legal": nested_legal,
		"sponsors": nested_sponsors,
		"operation_by_city": {},
		"proposed_suzerainty": nested_state.suzerainty.duplicate(true),
	}
	var nested_rebellion_plan := nested_sim._plan_coalition_rebellion_peace(
		nested_draft,
		[Vector2i(0, 1), Vector2i(1, 2)] as Array[Vector2i]
	)
	var nested_annexations: Array[Vector2i] = []
	nested_annexations.assign(nested_rebellion_plan.get("annexations", []))
	_check(
		bool(nested_rebellion_plan.get("ok", false))
			and nested_annexations == (
				[Vector2i(0, 1), Vector2i(0, 2)] as Array[Vector2i]
			),
		"嵌套双叛乱同时镇压必须将每个 rebel 直接规划给最终母国 absorber"
	)
	var nested_peace := nested_sim._make_coalition_peace(0, 1)
	_check(
		bool(nested_peace.get("changed", false))
			and not nested_state.nations[1].alive
			and not nested_state.nations[2].alive
			and nested_state.cities_of(1).is_empty()
			and nested_state.cities_of(2).is_empty()
			and not bool((nested_state.rebellions[1] as Dictionary).get(
				"active", true
			))
			and not bool((nested_state.rebellions[2] as Dictionary).get(
				"active", true
			))
			and nested_state.territory_structure_valid(),
		"嵌套双叛乱提交后两个 rebel 都必须归最终母国且中间 rebel 不得复活"
	)
	nested_sim.free()

	# 地方叛乱的 parent/rebel 即使不是本次议和代表，也必须随所属集团
	# 一并结算；否则 relation 已和平而 rebellion 仍 active，会立刻破坏结构。
	var rebellion_peace_state := preload("res://tests/support/grid_world.gd").new()
	rebellion_peace_state.generate_grid_world(32024)
	rebellion_peace_state.armies.clear()
	rebellion_peace_state.battles.clear()
	for rebellion_a in range(rebellion_peace_state.nations.size()):
		for rebellion_b in range(
			rebellion_a + 1, rebellion_peace_state.nations.size()
		):
			rebellion_peace_state.set_diplomatic_relation(
				rebellion_a,
				rebellion_b,
				GameState.DiplomaticRelation.NEUTRAL
			)
	var rebellion_core := -1
	for rebellion_city in rebellion_peace_state.land_cities_of(0):
		if not rebellion_city.is_capital and not rebellion_city.has_warehouse:
			rebellion_core = rebellion_city.id
			break
	preload("res://tests/state_rebellion_fixture.gd").isolate_city_as_state(rebellion_peace_state, rebellion_core)
	var coalition_rebel := rebellion_peace_state.start_regional_rebellion(
		0, [rebellion_core] as Array[int]
	)
	rebellion_peace_state.set_diplomatic_relation(
		0, 2, GameState.DiplomaticRelation.ALLIED
	)
	rebellion_peace_state.set_diplomatic_relation(
		coalition_rebel, 3, GameState.DiplomaticRelation.ALLIED
	)
	for parent_side in [0, 2]:
		for rebel_side in [coalition_rebel, 3]:
			rebellion_peace_state.set_diplomatic_relation(
				parent_side,
				rebel_side,
				GameState.DiplomaticRelation.WAR
			)
	rebellion_peace_state.day += (
		RebellionSystem.REGIONAL_REBELLION_MIN_WAR_DAYS
	)
	var rebellion_peace_sim := Simulation.new()
	rebellion_peace_sim.setup(rebellion_peace_state)
	var representative_peace := rebellion_peace_sim._make_coalition_peace(
		2, 3
	)
	_check(
		rebellion_core >= 0
			and coalition_rebel >= 0
			and bool(representative_peace.get("changed", false))
			and not bool(
				(rebellion_peace_state.rebellions[coalition_rebel]
					as Dictionary).get("active", true)
			)
			and not rebellion_peace_state.is_enemy(0, coalition_rebel)
			and rebellion_peace_state.recognized_owner_of(rebellion_core)
				== rebellion_peace_state.cities[rebellion_core].owner_nation
			and rebellion_peace_state.cities[
				rebellion_core
			].occupation_sponsor_nation == -1
			and rebellion_peace_state.rebellion_structure_valid()
			and rebellion_peace_state.territory_structure_valid(),
		(
			"代表国 2/3 的集团议和必须同时结算非代表 parent/rebel 0/%d，"
			+ "结束 active rebellion 并保持领土结构合法"
		) % coalition_rebel
	)
	rebellion_peace_sim.free()

	var join_state := preload("res://tests/support/grid_world.gd").new()
	join_state.generate_grid_world(32022)
	for join_a in range(join_state.nations.size()):
		for join_b in range(join_a + 1, join_state.nations.size()):
			join_state.set_diplomatic_relation(
				join_a,
				join_b,
				GameState.DiplomaticRelation.NEUTRAL
			)
	join_state.set_diplomatic_relation(
		0,
		1,
		GameState.DiplomaticRelation.WAR
	)
	var join_target := join_state.cities_of(1)[0].id
	join_state.set_war_objective(
		0,
		1,
		join_target,
		"既有战争目标"
	)
	var join_sim := Simulation.new()
	join_sim.setup(join_state)
	var joined := join_sim._execute_diplomatic_action({
		"kind": DiplomacyAI.Action.FORM_ALLIANCE,
		"a": 0,
		"b": 2,
		"reason": "战争中结盟回归",
	})
	_check(
		joined
			and join_state.is_enemy(2, 1)
			and int(
				join_state.war_objective(2, 1).get(
					"city_id",
					-1
				)
			) == join_state.administrative_center_of(join_target)
			and join_state.nations[2]
				.war_mobilization_target_troops > 0,
		"战争中结盟必须让新盟友立即参战、继承共同目标并启动本国动员"
	)
	join_sim.free()


# ------------------------------------------------------------------ 32c. 宗藩数据模型不变量（增量 A）

func _test_resource_cache_refreshes_after_new_nation() -> void:
	var state := preload("res://tests/support/grid_world.gd").new()
	state.generate_world(260920, 12)
	var simulation := Simulation.new()
	simulation.setup(state)
	var frozen_gold_flows: Array[Dictionary] = (
		simulation._forecast_trade_and_gold_flows(true)["gold_flows"]
	)
	var stale_cache := {
		"monthly_gold_flows": frozen_gold_flows,
	}
	var subject_id := -1
	for overlord_id in range(state.nations.size()):
		var region := _enfeoffable_region(state, overlord_id, 3)
		if region.is_empty():
			continue
		FamilyFixture.ensure_candidates(state, overlord_id)
		subject_id = state.enfeoff(overlord_id, region)
		if subject_id >= 0:
			break
	_check(subject_id >= 0, "资源缓存回归夹具必须成功新增藩王")
	if subject_id < 0:
		return
	var report := DiplomacyAI.resource_report(
		state, subject_id, stale_cache
	)
	_check(
		not report.is_empty()
		and (stale_cache["monthly_gold_flows"] as Array).size()
			== state.nations.size(),
		"新增国家后必须整体刷新按国家索引的财政评估缓存"
	)
	_check(DiplomacyAI.resource_forecast(state, subject_id).has("gold_min"), "new nation gets fresh resource forecast")

	simulation.free()


func _test_suzerainty_invariants() -> void:
	print("[32c] 宗藩：分封守恒、对外关系继承、共同体一体化与结构不变量")
	var gs := preload("res://tests/support/grid_world.gd").new()
	gs.generate_grid_world(32031)
	# 归零到全中立，再布置：0 与 1 交战、0 与 3 结盟，第三方 2 保持中立。
	for a in range(gs.nations.size()):
		for b in range(a + 1, gs.nations.size()):
			gs.set_diplomatic_relation(a, b, GameState.DiplomaticRelation.NEUTRAL)
	gs.set_diplomatic_relation(0, 1, GameState.DiplomaticRelation.WAR)
	gs.set_diplomatic_relation(0, 3, GameState.DiplomaticRelation.ALLIED)

	# 选国 0 的完整非首都州分封。
	var overlord_id := 0
	var enfeoff_cities := _enfeoffable_region(gs, overlord_id, 2)

	# 分封前快照，用于守恒校验（人力/金钱/粮食全体系总量不变）。
	var pre_manpower := gs.nations[overlord_id].manpower_pool
	var pre_gold := gs.nations[overlord_id].treasury_gold
	gs.refresh_derived()
	var pre_food := gs.nations[overlord_id].granary_food
	var pre_land_count := gs.land_cities_of(overlord_id).size()

	FamilyFixture.ensure_candidates(gs, overlord_id)
	var subject_id := gs.enfeoff(overlord_id, enfeoff_cities)
	_check(
		subject_id == gs.nations.size() - 1 and subject_id > 0,
		"分封应新建一个完整藩王 Nation 并返回其 id"
	)

	# 领土迁移：迁出城市 owner 与法理归属都归藩王，宗主领土相应减少。
	var territory_ok := gs.land_cities_of(overlord_id).size() == pre_land_count - enfeoff_cities.size()
	for city_id in enfeoff_cities:
		territory_ok = (
			territory_ok
			and gs.cities[city_id].owner_nation == subject_id
			and gs.recognized_owner_of(city_id) == subject_id
		)
	_check(territory_ok, "分封必须迁移城市实控与法理归属，且宗主领土相应减少")

	# 资源守恒：宗主+藩王人力/金钱/粮食总量与分封前相等（floor 不超发）。
	gs.refresh_derived()
	var post_manpower := gs.nations[overlord_id].manpower_pool + gs.nations[subject_id].manpower_pool
	var post_gold := gs.nations[overlord_id].treasury_gold + gs.nations[subject_id].treasury_gold
	var post_food := gs.nations[overlord_id].granary_food + gs.nations[subject_id].granary_food
	_check(
		post_manpower == pre_manpower
			and post_gold == pre_gold
			and post_food == pre_food,
		"分封划转人力/金钱/粮食必须全体系守恒（实为 mp=%d/%d gold=%d/%d food=%d/%d）"
			% [post_manpower, pre_manpower, post_gold, pre_gold, post_food, pre_food]
	)

	# 藩王获得独立首都，但首都是「共享粮仓」的零库存补给中继节点（无独立粮仓）：
	# 粮食归宗主根池，藩王 granary/warehouse 为空、首都 has_warehouse=false。
	var capital_id := gs.nations[subject_id].capital_city_id
	_check(
		capital_id >= 0
			and gs.cities[capital_id].owner_nation == subject_id
			and gs.cities[capital_id].is_capital
			and not gs.cities[capital_id].has_warehouse
			and gs.cities[capital_id].food_storage == 0
			and gs.nations[subject_id].warehouse_city_ids.is_empty()
			and gs.nations[subject_id].granary_food == 0,
		"藩王首都必须是零库存补给中继节点（粮食归共享粮仓，藩王无独立粮仓）"
	)
	# 共享粮仓：藩王的粮食产出重定向到宗主根池；宗主 granary 承载全体系粮食。
	var overlord_food_before := gs.nations[overlord_id].granary_food
	var deposited := gs.deposit_food(subject_id, 100)
	gs.refresh_derived()
	_check(
		gs.food_pool_holder(subject_id) == overlord_id
			and deposited
			and gs.nations[overlord_id].granary_food == overlord_food_before + 100
			and gs.nations[subject_id].granary_food == 0,
		"藩王粮食产出必须归集到宗藩体系根粮池（food_pool_holder=宗主）"
	)

	# 宗藩关系 SSoT 与查询接口。
	_check(
		gs.overlord_of(subject_id) == overlord_id
			and gs.subjects_of(overlord_id) == [subject_id]
			and gs.is_vassal(subject_id)
			and gs.is_overlord(overlord_id)
			and not gs.is_vassal(overlord_id)
			and gs.suzerainty_root(subject_id) == overlord_id
			and gs.suzerainty_root(overlord_id) == overlord_id,
		"宗藩查询接口必须正确反映有向关系"
	)
	_check(
		gs.external_territory_recipient(subject_id) == overlord_id
			and gs.external_territory_recipient(overlord_id)
				== overlord_id,
		"和平藩王的对外领土收益必须上收到宗主，宗主保持自身主权"
	)
	var record := gs.suzerainty_record(subject_id)
	_check(
		_approx(float(record["tribute_rate"]), GameState.DEFAULT_TRIBUTE_RATE)
			and int(record["created_day"]) == gs.day,
		"宗藩关系记录必须写入默认贡赋率与创建日"
	)

	# 对外关系继承：藩王与宗主结盟；继承宗主对第三方的关系（敌 1→WAR，中立 2→NEUTRAL）。
	_check(
		gs.is_allied(subject_id, overlord_id)
			and gs.is_enemy(subject_id, 1)
			and gs.relation_between(subject_id, 2) == GameState.DiplomaticRelation.NEUTRAL
			and gs.is_allied(subject_id, 3),
		"藩王必须与宗主结盟并继承宗主对第三方的对外关系"
	)

	# 对外共同体一体化：宗主与藩王同属一个 alliance_bloc；suzerainty_members 一致。
	var bloc := gs.alliance_bloc(overlord_id)
	_check(
		bloc.has(overlord_id) and bloc.has(subject_id),
		"宗主与藩王必须落在同一个对外军事共同体 alliance_bloc 内"
	)
	_check(
		gs.suzerainty_members(subject_id) == [overlord_id, subject_id]
			and gs.suzerainty_members(overlord_id) == [overlord_id, subject_id],
		"suzerainty_members 必须聚合同一宗主根下全部成员"
	)

	# 结构不变量成立。
	_check(gs.suzerainty_structure_valid(), "分封后宗藩结构不变量必须成立")

	# 分封不创造或转移野战军；藩王之后用自身资源组建主战军团。
	var vassal_army_count := 0
	for army in gs.armies:
		if army.owner_nation == subject_id and army.size > 0:
			vassal_army_count += 1
	_check(
		vassal_army_count == 0
			and gs.nations[subject_id].battle_groups.is_empty(),
		"分封不得凭空创造或转移野战军（军队=%d 战团=%d）"
			% [vassal_army_count, gs.nations[subject_id].battle_groups.size()]
	)
	_check(
		gs._battle_group_structure_valid(),
		"分封赐军后战团结构不变量必须成立"
	)
	# 宗主 MAIN 战团不随分封转隶。
	var group_state := preload("res://tests/support/grid_world.gd").new()
	group_state.generate_grid_world(32032)
	var group_overlord := 0
	var group_region := _enfeoffable_region(group_state, group_overlord)
	var group_move_city := group_region[0]
	var overlord_groups_before := group_state.nations[group_overlord].battle_groups.size()
	FamilyFixture.ensure_candidates(group_state, group_overlord)
	var group_subject := group_state.enfeoff(group_overlord, [group_move_city])
	_check(
		group_subject > 0
			and group_state.nations[group_subject].battle_groups.is_empty()
			and group_state.nations[group_overlord].battle_groups.size() == overlord_groups_before
			and group_state._battle_group_structure_valid()
			and group_state.suzerainty_structure_valid(),
		"分封后宗主保留全部 MAIN 战团、藩王无战团、结构不变量成立（宗主战团 %d→%d）"
			% [overlord_groups_before, group_state.nations[group_overlord].battle_groups.size()]
	)

	# 和平割地可能只确认州治，使旧藩仍实控并法理持有属府、却失去最后一座
	# 法理州治。领土事务必须在同一提交中解除该宗藩边，不能把坏状态留到
	# 下一次分封才由结构断言发现。
	var centerless_state := preload("res://tests/support/grid_world.gd").new()
	centerless_state.generate_grid_world(32034)
	var centerless_region := _enfeoffable_region(centerless_state, 0, 2)
	FamilyFixture.ensure_candidates(centerless_state, 0)
	var centerless_subject := centerless_state.enfeoff(0, centerless_region)
	var centerless_record := centerless_state.suzerainty_record(
		centerless_subject
	).duplicate(true)
	var subject_center := -1
	for city_id in centerless_region:
		if centerless_state.is_zhou_city(city_id):
			subject_center = city_id
			break
	var center_transfer := centerless_state.apply_territory_transaction([{
		"city_id": subject_center,
		"controller_id": 0,
		"legal_owner_id": 0,
		"sponsor_id": -1,
		"reset_political_target": true,
		"stock_policy": GameState.TerritoryStockDisposition.MOVE_TO_NEW_POOL,
		"reason": "centerless_vassal_regression",
	}] as Array[Dictionary])
	_check(
		centerless_subject > 0
			and subject_center >= 0
			and bool(center_transfer.get("ok", false))
			and not centerless_state.land_cities_of(centerless_subject).is_empty()
			and not centerless_state.suzerainty.has(centerless_subject)
			and centerless_state.food_pool_holder(centerless_subject)
				== centerless_subject
			and centerless_state.suzerainty_structure_valid()
			and centerless_state.territory_structure_valid(),
		"藩王失去最后法理州治但仍有属府时，领土事务必须同步解除宗藩边"
	)
	centerless_state.suzerainty[centerless_subject] = centerless_record
	centerless_state.set_diplomatic_relation(
		0, centerless_subject, GameState.DiplomaticRelation.ALLIED
	)
	var stale_edge_repaired := centerless_state.prune_dead_suzerainty()
	_check(
		stale_edge_repaired
			and not centerless_state.suzerainty.has(centerless_subject)
			and centerless_state.suzerainty_structure_valid()
			and centerless_state.territory_structure_valid(),
		"每日宗藩清理必须修复旧档或旧事务遗留的无法理州治藩属边"
	)

	# 宗主所有既有主战军保持原归属，藩王从零建军。
	var transfer_state := preload("res://tests/support/grid_world.gd").new()
	transfer_state.generate_grid_world(32033)
	var transfer_overlord := 0
	var transfer_region := _enfeoffable_region(
		transfer_state, transfer_overlord, 3
	)
	var owners_before: Dictionary = {}
	for army in transfer_state.armies:
		owners_before[army.id] = army.owner_nation
	var transfer_army_count_before := (
		transfer_state.armies.size()
	)
	var transfer_groups_before := transfer_state.nations[
		transfer_overlord
	].battle_groups.size()
	FamilyFixture.ensure_candidates(transfer_state, transfer_overlord)
	var transfer_subject := transfer_state.enfeoff(
		transfer_overlord,
		transfer_region
	)
	var owners_unchanged := true
	for army in transfer_state.armies:
		if int(owners_before.get(army.id, -1)) != army.owner_nation:
			owners_unchanged = false
			break
	_check(
		transfer_subject > 0
			and owners_unchanged
			and transfer_state.armies.size()
				== transfer_army_count_before
			and transfer_state.nations[
				transfer_overlord
			].battle_groups.size()
				== transfer_groups_before
			and transfer_state.nations[
				transfer_subject
			].battle_groups.is_empty()
			and transfer_state
				._battle_group_structure_valid(),
		"分封不得转移或凭空补充正规军，宗主既有军队与指挥单位保持完整"
	)

	# 非法输入：空区、含宗主首都、非宗主领土、清空宗主领土——均返回 -1 且无副作用。
	var nation_count_before := gs.nations.size()
	var overlord_capital := gs.nations[overlord_id].capital_city_id
	var reject_empty := gs.enfeoff(overlord_id, [] as Array[int])
	var reject_capital := gs.enfeoff(overlord_id, [overlord_capital] as Array[int])
	var foreign_city := gs.land_cities_of(2)[0].id
	var reject_foreign := gs.enfeoff(overlord_id, [foreign_city] as Array[int])
	var occupied_city := gs.land_cities_of(overlord_id)[0]
	if occupied_city.id == overlord_capital:
		occupied_city = gs.land_cities_of(overlord_id)[1]
	var occupied_legal_owner := gs.recognized_owner_of(occupied_city.id)
	gs.recognized_city_owners[occupied_city.id] = 2
	var reject_occupied := gs.enfeoff(
		overlord_id,
		[occupied_city.id] as Array[int]
	)
	gs.recognized_city_owners[occupied_city.id] = occupied_legal_owner
	var all_overlord_cities: Array[int] = []
	for city in gs.land_cities_of(overlord_id):
		all_overlord_cities.append(city.id)
	var reject_drain := gs.enfeoff(overlord_id, all_overlord_cities)
	_check(
		reject_empty == -1
			and reject_capital == -1
			and reject_foreign == -1
			and reject_occupied == -1
			and reject_drain == -1
			and gs.nations.size() == nation_count_before,
		(
			"非法分封（空区/含首都/非本国城/临时占领地/清空领土）"
			+ "必须被拒绝且不建国"
		)
	)
	_check(gs.suzerainty_structure_valid(), "非法分封被拒后宗藩结构仍须合法")

# ------------------------------------------------------------------ 32d. 贡赋月度结算（增量 B）

func _test_vassal_tribute() -> void:
	print("[32d] 宗藩：贡赋按当月税收比例上缴、全体系守恒、逐级支持多级")
	var gs := preload("res://tests/support/grid_world.gd").new()
	gs.generate_grid_world(32041)
	for a in range(gs.nations.size()):
		for b in range(a + 1, gs.nations.size()):
			gs.set_diplomatic_relation(a, b, GameState.DiplomaticRelation.NEUTRAL)
	# 构造两级宗藩：0 为根宗主，1 为其藩王，2 为 1 的次级藩王（多级逐级上缴）。
	gs.set_diplomatic_relation(0, 1, GameState.DiplomaticRelation.ALLIED)
	gs.set_diplomatic_relation(1, 2, GameState.DiplomaticRelation.ALLIED)
	gs.suzerainty[1] = {
		"overlord_id": 0,
		"tribute_rate": 0.25,
		"created_day": 0,
		"last_centralization_day": -1,
		"civil_war": false,
	}
	gs.suzerainty[2] = {
		"overlord_id": 1,
		"tribute_rate": 0.50,
		"created_day": 0,
		"last_centralization_day": -1,
		"civil_war": false,
	}
	_check(
		gs.external_territory_recipient(2) == 0,
		"多级和平宗藩中，次级藩王的对外领土收益必须逐级上收到根宗主"
	)
	gs.suzerainty[1]["civil_war"] = true
	gs.set_diplomatic_relation(0, 1, GameState.DiplomaticRelation.WAR)
	_check(
		gs.external_territory_recipient(2) == 1,
		"中间藩王反叛后，其子树对外领土收益必须止于反叛方，不得越过内战边"
	)
	var civil_war_flows := Simulation.monthly_gold_flows(gs)
	for civil_war_nation in gs.nations:
		civil_war_nation.treasury_gold = 1000
	var civil_war_treasuries := [
		gs.nations[0].treasury_gold,
		gs.nations[1].treasury_gold,
		gs.nations[2].treasury_gold,
	]
	var civil_war_income: Array[int] = [0, 400, 200]
	var subordinate_rate := Simulation.effective_tribute_rate(gs, 2)
	var subordinate_tribute := int(floor(
		float(civil_war_income[2]) * subordinate_rate
	))
	var civil_war_sim := Simulation.new()
	civil_war_sim.setup(gs)
	civil_war_sim._resolve_tribute(civil_war_income)
	_check(
		is_zero_approx(Simulation.effective_tribute_rate(gs, 1))
			and subordinate_rate > 0.0
			and int(civil_war_flows[1]["tribute_paid"]) == 0
			and int(civil_war_flows[0]["tribute_received"]) == 0
			and int(civil_war_flows[2]["tribute_paid"]) > 0
			and int(civil_war_flows[1]["tribute_received"]) > 0
			and gs.nations[0].treasury_gold == civil_war_treasuries[0]
			and gs.nations[1].treasury_gold
				== civil_war_treasuries[1] + subordinate_tribute
			and gs.nations[2].treasury_gold
				== civil_war_treasuries[2] - subordinate_tribute,
		(
			"内战只应暂停反叛藩王向直属宗主的贡赋，反叛子树内部和平贡赋仍须结算："
			+ "rates=%.2f/%.2f flows=%s treasuries=%d/%d/%d"
		) % [
			Simulation.effective_tribute_rate(gs, 1),
			Simulation.effective_tribute_rate(gs, 2),
			str(civil_war_flows),
			gs.nations[0].treasury_gold,
			gs.nations[1].treasury_gold,
			gs.nations[2].treasury_gold,
		]
	)
	civil_war_sim.free()
	gs.suzerainty[1]["civil_war"] = false
	gs.set_diplomatic_relation(0, 1, GameState.DiplomaticRelation.ALLIED)
	_check(
		_approx(Simulation.effective_tribute_rate(gs, 1), 0.25),
		"内战结束后贡赋率必须恢复宗藩记录中的基础税率"
	)
	var sim := Simulation.new()
	sim.setup(gs)

	# 纯函数层：给定当月税收，验证守恒与逐级比例（floor）。
	for nation in gs.nations:
		nation.treasury_gold = 1000
	var gold_income: Array[int] = []
	gold_income.resize(gs.nations.size())
	gold_income.fill(0)
	gold_income[1] = 400   # 藩王 1 当月税收
	gold_income[2] = 200   # 次级藩王 2 当月税收
	var total_before := 0
	for nation in gs.nations:
		total_before += nation.treasury_gold
	sim._resolve_tribute(gold_income)
	var total_after := 0
	for nation in gs.nations:
		total_after += nation.treasury_gold
	# 1 上缴 floor(400*0.25)=100 给 0；2 上缴 floor(200*0.5)=100 给 1。
	_check(
		gs.nations[0].treasury_gold == 1000 + 100
			and gs.nations[1].treasury_gold == 1000 - 100 + 100
			and gs.nations[2].treasury_gold == 1000 - 100
			and total_after == total_before,
		"贡赋必须按当月税收比例逐级上缴且金钱全体系守恒（0=%d 1=%d 2=%d）"
			% [gs.nations[0].treasury_gold, gs.nations[1].treasury_gold, gs.nations[2].treasury_gold]
	)

	# 贡赋不得把藩王国库抽成负数：税收极高但国库很低时按国库封顶。
	gs.nations[2].treasury_gold = 30
	var poor_income: Array[int] = []
	poor_income.resize(gs.nations.size())
	poor_income.fill(0)
	poor_income[2] = 1000   # floor(1000*0.5)=500，但国库只有 30
	sim._resolve_tribute(poor_income)
	_check(
		gs.nations[2].treasury_gold == 0,
		"贡赋按国库余额封顶，不得使藩王国库为负（实为 %d）" % gs.nations[2].treasury_gold
	)

	# 财政派生必须与真实月结算同源：城市税收 + 贡赋流入 - 贡赋流出 - 军费。
	for nation in gs.nations:
		nation.treasury_gold = 100000
	var predicted_flows := Simulation.monthly_gold_flows(
		gs
	)
	var treasury_before_month: Array[int] = []
	var reports_match_flows := true
	var report_cache := {}
	for nation in gs.nations:
		treasury_before_month.append(nation.treasury_gold)
		var report := DiplomacyAI.resource_report(
			gs,
			nation.id,
			report_cache
		)
		var flow: Dictionary = predicted_flows[nation.id]
		reports_match_flows = (
			reports_match_flows
			and int(report["monthly_city_gold_income"])
				== int(flow["city_income"])
			and int(report["monthly_tribute_income"])
				== int(flow["tribute_received"])
			and int(report["monthly_tribute_expense"])
				== int(flow["tribute_paid"])
			and int(report["monthly_gold_balance"])
				== int(flow["balance"])
		)
	sim._resolve_economy()
	var settlement_matches_prediction := true
	for nation in gs.nations:
		settlement_matches_prediction = (
			settlement_matches_prediction
			and nation.treasury_gold
				- treasury_before_month[nation.id]
				== int(predicted_flows[nation.id]["balance"])
		)
	_check(
		reports_match_flows
			and settlement_matches_prediction,
		"前端/AI财政派生必须逐国等于真实月结算国库变化（含多级贡赋）"
	)

	# 端到端：完整推进一个月，藩王必有正税收并向宗主净转移金钱。
	var e2e := preload("res://tests/support/grid_world.gd").new()
	e2e.generate_grid_world(32042)
	for a in range(e2e.nations.size()):
		for b in range(a + 1, e2e.nations.size()):
			e2e.set_diplomatic_relation(a, b, GameState.DiplomaticRelation.NEUTRAL)
	var e2e_cities := _enfeoffable_region(e2e, 0, 3)
	FamilyFixture.ensure_candidates(e2e, 0)
	var e2e_subject := e2e.enfeoff(0, e2e_cities, 0.25)
	var e2e_sim := Simulation.new()
	e2e_sim.diplomacy_enabled = false   # 隔离外交/AI 噪声，只观察经济结算
	e2e_sim.setup(e2e)
	var overlord_before := e2e.nations[0].treasury_gold
	var total_system_before := e2e.nations[0].treasury_gold + e2e.nations[e2e_subject].treasury_gold
	for _i in range(Simulation.DAYS_PER_MONTH):
		e2e_sim._advance_day()
	# 军费只在体系内部支付给“无主”开销，宗藩间的贡赋转移本身仍守恒：
	# 校验宗主收到的贡赋 > 0（藩王有税收且已上缴）。
	var overlord_gain := e2e.nations[0].treasury_gold - overlord_before
	var total_system_after := e2e.nations[0].treasury_gold + e2e.nations[e2e_subject].treasury_gold
	_check(
		e2e_subject > 0 and overlord_gain > 0 and total_system_after >= total_system_before,
		"端到端一个月后宗主应收到藩王贡赋（overlord_gain=%d）" % overlord_gain
	)

	# 长期财政压力：藩王月亏、宗主靠贡赋恰好覆盖军费且国库始终为 0。
	# 关闭新增人力，隔离粮食充足且现金不足时不发生财政裁军的规则。
	var crisis := preload("res://tests/support/grid_world.gd").new()
	crisis.generate_grid_world(32043)
	crisis.armies.clear()
	crisis.battles.clear()
	crisis.uses_heightmap = true
	for a in range(crisis.nations.size()):
		for b in range(a + 1, crisis.nations.size()):
			crisis.set_diplomatic_relation(
				a,
				b,
				GameState.DiplomaticRelation.NEUTRAL
			)
	for nation in crisis.nations:
		_set_neutral_ruler(nation)
		nation.trade_policy = RulerProfile.POLICY_ISOLATION
		nation.warehouse_city_ids.clear()
		nation.battle_groups.clear()
		nation.next_battle_group_id = 0
	for city in crisis.cities:
		city.owner_nation = 0
		crisis.recognized_city_owners[city.id] = 0
		city.gold_per_month = 0
		city.manpower_per_month = 0
		city.is_capital = false
		city.has_warehouse = false
		city.food_storage = 0
	var overlord_id := 0
	var subject_id := 1
	var overlord_city := 0
	var subject_city := 1
	crisis.cities[subject_city].owner_nation = subject_id
	crisis.recognized_city_owners[subject_city] = subject_id
	crisis.cities[subject_city].gold_per_month = 10
	crisis.nations[overlord_id].capital_city_id = overlord_city
	crisis.nations[subject_id].capital_city_id = subject_city
	crisis.cities[overlord_city].is_capital = true
	crisis.cities[overlord_city].has_warehouse = true
	crisis.cities[overlord_city].food_storage = 1000000
	crisis.nations[overlord_id].warehouse_city_ids = [
		overlord_city
	] as Array[int]
	crisis.cities[subject_city].is_capital = true
	crisis.set_diplomatic_relation(
		overlord_id,
		subject_id,
		GameState.DiplomaticRelation.ALLIED
	)
	crisis.suzerainty[subject_id] = {
		"overlord_id": overlord_id,
		"tribute_rate": 0.25,
		"created_day": 0,
		"last_centralization_day": -1,
		"civil_war": false,
	}
	# 本夹具只验证贡赋与军费缩编；封闭路网以隔离新增贸易税，维持
	# “宗主恰好收支为零”的既有前置条件。
	for crisis_edge in crisis.edges:
		crisis_edge.max_manpower = 0
	crisis.refresh_derived()
	var subject_city_income := Simulation.city_gold_output(
		crisis,
		crisis.cities[subject_city]
	)
	var subject_tribute := int(floor(
		float(subject_city_income)
		* Simulation.effective_tribute_rate(
			crisis,
			subject_id
		)
	))
	var overlord_army := crisis.create_army(
		overlord_id,
		overlord_city,
		subject_tribute
			* GameState.WAR_GOLD_TROOPS_PER_UNIT,
		GameState.INITIAL_HEAVY_ARMY_SIZE
	)
	var subject_light_a := crisis.create_army(
		subject_id,
		subject_city,
		GameState.INITIAL_HEAVY_ARMY_SIZE,
		GameState.INITIAL_HEAVY_ARMY_SIZE
	)
	var subject_light_b := crisis.create_army(
		subject_id,
		subject_city,
		GameState.INITIAL_HEAVY_ARMY_SIZE,
		GameState.INITIAL_HEAVY_ARMY_SIZE
	)
	var subject_heavy := crisis.create_army(
		subject_id,
		subject_city,
		GameState.INITIAL_HEAVY_ARMY_SIZE,
		GameState.INITIAL_HEAVY_ARMY_SIZE
	)
	for nation in crisis.nations:
		nation.treasury_gold = 0
		nation.manpower_pool = 0
		nation.food_demand_ema = 0.0
	var crisis_sim := Simulation.new()
	crisis_sim.diplomacy_enabled = false
	crisis_sim.setup(crisis)
	var initial_flows := Simulation.monthly_gold_flows(
		crisis
	)
	var initial_subject_upkeep := int(
		initial_flows[subject_id]["military_upkeep"]
	)
	var expected_subject_deficit := -int(
		initial_flows[subject_id]["balance"]
	)
	var overlord_treasuries: Array[int] = []
	var subject_treasuries: Array[int] = []
	var subject_unpaid: Array[int] = []
	var subject_upkeep_after_ai: Array[int] = []
	var subject_demobilized: Array[bool] = []
	var overlord_demobilized: Array[bool] = []
	for month_index in range(6):
		crisis.day = (
			(month_index + 1)
			* Simulation.DAYS_PER_MONTH
		)
		crisis_sim._resolve_economy()
		overlord_treasuries.append(
			crisis.nations[overlord_id].treasury_gold
		)
		subject_treasuries.append(
			crisis.nations[subject_id].treasury_gold
		)
		subject_unpaid.append(
			crisis.nations[
				subject_id
			].unpaid_military_upkeep
		)
		var subject_view := AiWorldView.build(
			crisis,
			subject_id
		)
		var subject_snapshot := StrategicMapSnapshot.build(
			subject_view
		)
		var subject_threat := ThreatField.build(
			subject_view
		)
		subject_demobilized.append(
			crisis_sim._ai_manage_force_structure(
				subject_view,
				subject_snapshot,
				subject_threat,
				CityDefensePlan.build(
					subject_view,
					subject_snapshot,
					subject_threat
				)
			)
		)
		subject_upkeep_after_ai.append(
			Simulation.effective_monthly_military_upkeep(
				crisis, subject_id
			)
		)
		var overlord_view := AiWorldView.build(
			crisis,
			overlord_id
		)
		var overlord_snapshot := StrategicMapSnapshot.build(
			overlord_view
		)
		var overlord_threat := ThreatField.build(
			overlord_view
		)
		overlord_demobilized.append(
			crisis_sim._ai_manage_force_structure(
				overlord_view,
				overlord_snapshot,
				overlord_threat,
				CityDefensePlan.build(
					overlord_view,
					overlord_snapshot,
					overlord_threat
				)
			)
		)
	var subject_treasury_grows := true
	var no_repeat_demobilization := true
	var overlord_never_demobilizes := true
	for month_index in range(6):
		overlord_never_demobilizes = (
			overlord_never_demobilizes
			and not overlord_demobilized[month_index]
		)
		if month_index > 0:
			no_repeat_demobilization = (
				no_repeat_demobilization
				and not subject_demobilized[month_index]
			)
			subject_treasury_grows = (
				subject_treasury_grows
				and subject_treasuries[month_index]
					> subject_treasuries[month_index - 1]
			)
	_check(
		int(initial_flows[overlord_id]["balance"])
				== -int(initial_flows[overlord_id]["garrison_upkeep"])
			and int(initial_flows[overlord_id]["field_army_upkeep"]) == 0
			and expected_subject_deficit > 0
			and not subject_demobilized[0] and no_repeat_demobilization
			and overlord_never_demobilizes
			and subject_upkeep_after_ai[0] == initial_subject_upkeep
			and subject_unpaid[0]
				== expected_subject_deficit
			and subject_unpaid[1] == expected_subject_deficit
			and overlord_treasuries == [0, 0, 0, 0, 0, 0]
			and (
				subject_treasury_grows
				or subject_city_income == 0
			),
		"长期贡赋财政：现金不足不裁军，军费缺口保持真实且国库不为负"
	)
	print(
		"  [32d-finance] 城收=%d 贡赋=%d 藩王军费=%d→%d 月亏=%d "
		% [
			subject_city_income,
			subject_tribute,
			initial_subject_upkeep,
			subject_upkeep_after_ai[0],
			expected_subject_deficit,
		]
		+ "藩王国库=%s 未付=%s 缩编=%s 宗主国库=%s 宗主缩编=%s"
		% [
			str(subject_treasuries),
			str(subject_unpaid),
			str(subject_demobilized),
			str(overlord_treasuries),
			str(overlord_demobilized),
		]
	)
	sim.free()
	e2e_sim.free()
	crisis_sim.free()


# ------------------------------------------------------------------ 32e. 区域财政评估与分封 AI

func _test_enfeoff_ai() -> void:
	print("[32e] 宗藩：区域粮食/财政收益、封地道路连续性、AI 分封触发与门控")
	# 1. 静态边境军移除后，旧防务负担字段恒为零；财政反事实只比较
	# 治理增产后的预计贡赋与当前直辖收入。
	var gs := preload("res://tests/support/grid_world.gd").new()
	gs.generate_grid_world(32051)
	for a in range(gs.nations.size()):
		for b in range(a + 1, gs.nations.size()):
			gs.set_diplomatic_relation(a, b, GameState.DiplomaticRelation.WAR)
	var region: Array[int] = []
	for city in gs.land_cities_of(0):
		if city.is_capital:
			continue
		# 只收接敌的边疆城，确保区域有正的应然防务需求可供校验。
		if DiplomacyAI._city_is_frontier(gs, 0, city.id):
			region.append(city.id)
		if region.size() >= 3:
			break
	var expected_food_output := 0.0
	var expected_direct_gold := 0
	var expected_vassal_gold := 0
	for city_id in region:
		expected_food_output += float(gs.cities[city_id].food_per_half_year) / 6.0
		var city_gold := Simulation.city_gold_output(
			gs,
			gs.cities[city_id]
		)
		expected_direct_gold += city_gold
		expected_vassal_gold += int(floor(
			float(city_gold)
			* Simulation
				.VASSAL_GOVERNANCE_OUTPUT_MULTIPLIER
		))
	var expected_tribute := int(floor(
		float(expected_vassal_gold)
		* GameState.DEFAULT_TRIBUTE_RATE
	))
	var burden := DiplomacyAI.evaluate_region_burden(gs, 0, region)
	var expected_required_garrison := 0
	for city_id in region:
		if gs.is_zhou_city(city_id):
			expected_required_garrison += gs.city_garrison_capacity(city_id)
	_check(
		_approx(float(burden["monthly_food_output"]), expected_food_output)
			and float(burden["burden_ratio"]) >= 0.0
			and int(burden["direct_gold_income"])
				== expected_direct_gold
			and int(burden["projected_vassal_gold_income"])
				== expected_vassal_gold
			and int(burden["projected_tribute_income"])
				== expected_tribute
			and int(burden["monthly_fiscal_benefit"])
				== (
					int(burden["garrison_gold_upkeep"]) + expected_tribute
					- expected_direct_gold
				),
		"区域负担画像必须同源计算粮食负担与分封财政反事实"
	)
	_check(
		int(burden["required_defense_troops"])
			== expected_required_garrison
			and int(burden["monthly_food_demand"]) >= 0,
		"候选区域必须按州治容量评估长期守军负担（troops=%d ratio=%.3f）"
			% [int(burden["required_defense_troops"]), float(burden["burden_ratio"])]
	)
	# 内陆州治仍有基础守军成本，但行政半径内不产生距离附加粮耗。
	var inland_gs := preload("res://tests/support/grid_world.gd").new()
	inland_gs.generate_grid_world(32051)
	# 全国和平且同属一主的语境下，任取一座四邻皆本国的内陆城，防务需求必为 0。
	var inland_region: Array[int] = []
	for city in inland_gs.land_cities_of(0):
		var all_domestic := true
		for neighbor in inland_gs.neighbors(city.id):
			if inland_gs.cities[neighbor].owner_nation != 0:
				all_domestic = false
				break
		if all_domestic and not city.is_capital:
			inland_region = [city.id]
			break
	if not inland_region.is_empty():
		var inland_burden := DiplomacyAI.evaluate_region_burden(inland_gs, 0, inland_region)
		var inland_required := (
			inland_gs.city_garrison_capacity(inland_region[0])
			if inland_gs.is_zhou_city(inland_region[0]) else 0
		)
		_check(
			int(inland_burden["required_defense_troops"])
				== inland_required,
			"内陆区域仍须按其州治身份承担基础守军"
		)

	# 2. _grow_enfeoff_region 道路连续性：返回区域必须道路连通且全属本国非首都。
	var grow_state := preload("res://tests/support/grid_world.gd").new()
	grow_state.generate_grid_world(32052)
	var grown := DiplomacyAI._grow_enfeoff_region(grow_state, 0)
	var continuity_ok := true
	if grown.size() >= 2:
		# 每座城至少与区域内另一城有正容量边（连通性必要条件）。
		var grown_set := {}
		for cid in grown:
			grown_set[cid] = true
		for cid in grown:
			if grow_state.cities[cid].owner_nation != 0 or grow_state.cities[cid].is_capital:
				continuity_ok = false
				break
			var linked := false
			for neighbor in grow_state.neighbors(cid):
				if grown_set.has(neighbor):
					var e := grow_state.edge_of(cid, neighbor)
					if e != null and e.max_manpower > 0:
						linked = true
						break
			if not linked:
				continuity_ok = false
				break
	_check(continuity_ok, "生成的候选封地必须道路连续且全属本国非首都城")

	# 3. AI 门控与触发：战时不分封（新规则）；和平时若有高负担远边疆区则可触发。
	var ai_state := preload("res://tests/support/grid_world.gd").new()
	ai_state.generate_grid_world(32053)
	for a in range(ai_state.nations.size()):
		for b in range(a + 1, ai_state.nations.size()):
			ai_state.set_diplomatic_relation(a, b, GameState.DiplomaticRelation.NEUTRAL)
	# 先制造中央全面外战：此时不得分封（战时把前线连弱藩王一起甩出会崩溃）。
	for other in range(1, ai_state.nations.size()):
		ai_state.set_diplomatic_relation(0, other, GameState.DiplomaticRelation.WAR)
	var war_actions: Array[Dictionary] = []
	DiplomacyAI._collect_enfeoff_actions(ai_state, war_actions, {}, {})
	var war_triggered := false
	for act in war_actions:
		if int(act.get("kind", -1)) == DiplomacyAI.Action.ENFEOFF and int(act.get("a", -1)) == 0:
			war_triggered = true
	_check(not war_triggered, "战时（中央有实战前线）不得分封")

	# 恢复和平：全部关系回中立，此时才允许分封。
	for other in range(1, ai_state.nations.size()):
		ai_state.set_diplomatic_relation(0, other, GameState.DiplomaticRelation.NEUTRAL)
	var peace_actions: Array[Dictionary] = []
	DiplomacyAI._collect_enfeoff_actions(ai_state, peace_actions, {}, {})
	var triggered := false
	var triggered_region: Array[int] = []
	for act in peace_actions:
		if int(act.get("kind", -1)) == DiplomacyAI.Action.ENFEOFF and int(act.get("a", -1)) == 0:
			triggered = true
			for cv in act.get("region_cities", []):
				triggered_region.append(int(cv))
	# 和平时是否触发取决于是否有过阈的远边疆区；若未触发，须是被负担比/留核心合法挡下。
	var gate_region := DiplomacyAI._grow_enfeoff_region(ai_state, 0)
	var gate_reason_ok := true
	if not triggered and gate_region.size() >= DiplomacyAI.ENFEOFF_MIN_REGION_CITIES:
		var gate_burden := DiplomacyAI.evaluate_region_burden(ai_state, 0, gate_region)
		gate_reason_ok = (
				(
					float(gate_burden["burden_ratio"])
						< DiplomacyAI
						.ENFEOFF_FOOD_BURDEN_RATIO_THRESHOLD
					and int(
						gate_burden[
							"monthly_fiscal_benefit"
						]
					) <= 0
				)
			or ai_state.land_cities_of(0).size() - gate_region.size()
				< DiplomacyAI.ENFEOFF_MIN_OVERLORD_CITIES_AFTER
		)
	_check(
		(triggered and triggered_region.size() >= DiplomacyAI.ENFEOFF_MIN_REGION_CITIES)
			or gate_reason_ok,
			"和平时分封要么由财政/粮食收益触发，要么被双收益/留核心门控合法挡下"
	)

	# 4. 财政路径独立触发：把候选区粮产抬高到低负担、直辖金产压低。
	# 分封不转移野战军，因此单靠军费不得虚构正收益。
	var finance_state := preload("res://tests/support/grid_world.gd").new()
	finance_state.generate_grid_world(32054)
	for a in range(finance_state.nations.size()):
		for b in range(a + 1, finance_state.nations.size()):
			finance_state.set_diplomatic_relation(
				a,
				b,
				GameState.DiplomaticRelation.NEUTRAL
			)
	var finance_region := DiplomacyAI._grow_enfeoff_region(
		finance_state,
		0
	)
	var finance_retained_city := -1
	for city in finance_state.land_cities_of(0):
		if not finance_region.has(city.id):
			finance_retained_city = city.id
			break
	for city_id in finance_region:
		finance_state.cities[city_id].gold_per_month = 0
		finance_state.cities[
			city_id
		].food_per_half_year = 100000
	if not finance_region.is_empty():
		for index in range(3):
			finance_state._spawn_conjured_army(
				0,
				finance_region[
					index % finance_region.size()
				]
			)
	var finance_report := (
		DiplomacyAI.evaluate_region_burden(
			finance_state,
			0,
			finance_region
		)
	)
	var finance_actions: Array[Dictionary] = []
	DiplomacyAI._collect_enfeoff_actions(
		finance_state,
		finance_actions,
		{},
		{}
	)
	var finance_triggered := false
	var finance_reason := ""
	for action in finance_actions:
		if (
			int(action.get("kind", -1))
				== DiplomacyAI.Action.ENFEOFF
			and int(action.get("a", -1)) == 0
		):
			finance_triggered = true
			finance_reason = str(action.get("reason", ""))
	_check(finance_retained_city >= 0, "分封后宗主必须保留直属领地")

	# 5. 治理压力路径：旧双收益否决已被治理压力规则补全。若候选区虽财政为负、
	# 粮食负担低，但存在超行政半径且低忠的远地压力，则仍可因治理收益而分封。
	var loss_state := preload("res://tests/support/grid_world.gd").new()
	loss_state.generate_grid_world(32055)
	for a in range(loss_state.nations.size()):
		for b in range(a + 1, loss_state.nations.size()):
			loss_state.set_diplomatic_relation(
				a,
				b,
				GameState.DiplomaticRelation.NEUTRAL
			)
	_enfeoffable_region(loss_state, 0, 3)
	var loss_region := DiplomacyAI._grow_enfeoff_region(
		loss_state,
		0
	)
	var loss_retained_city := -1
	for city in loss_state.land_cities_of(0):
		if not loss_region.has(city.id):
			loss_retained_city = city.id
			break
	for city_id in loss_region:
		loss_state.cities[city_id].gold_per_month = 100
		loss_state.cities[
			city_id
		].food_per_half_year = 100000
	var loss_report := DiplomacyAI.evaluate_region_burden(
		loss_state,
		0,
		loss_region
	)
	var loss_governance := DiplomacyAI.evaluate_region_governance_pressure(
		loss_state,
		0,
		loss_region,
		RebellionSystem.capital_hops(loss_state, 0)
	)
	var loss_actions: Array[Dictionary] = []
	DiplomacyAI._collect_enfeoff_actions(
		loss_state,
		loss_actions,
		{},
		{}
	)
	var loss_triggered := false
	var loss_reason := ""
	for action in loss_actions:
		if (
			int(action.get("kind", -1))
				== DiplomacyAI.Action.ENFEOFF
			and int(action.get("a", -1)) == 0
		):
			loss_triggered = true
			loss_reason = str(action.get("reason", ""))
	_check(
		loss_region.size()
			>= DiplomacyAI.ENFEOFF_MIN_REGION_CITIES
			and loss_retained_city >= 0
			and int(loss_report["monthly_fiscal_benefit"])
				< 0
			and float(loss_report["burden_ratio"])
				< DiplomacyAI
					.ENFEOFF_FOOD_BURDEN_RATIO_THRESHOLD
			and int(loss_governance["pressured_city_count"]) >= 1
			and float(loss_governance["pressure_score"])
				>= DiplomacyAI.ENFEOFF_GOVERNANCE_PRESSURE_THRESHOLD
			and loss_triggered
			and loss_reason.contains("治理压力"),
		(
			"财政月增益为负且粮食负担低时，远地治理压力高仍可触发分封"
			+ "（region=%d fiscal=%d burden=%.3f pressured=%d pressure=%.3f triggered=%s reason=%s）"
		) % [
			loss_region.size(),
			int(loss_report["monthly_fiscal_benefit"]),
			float(loss_report["burden_ratio"]),
			int(loss_governance["pressured_city_count"]),
			float(loss_governance["pressure_score"]),
			str(loss_triggered),
			loss_reason,
		]
	)

	# 5b. 真正的负面对照：财政为负、粮食负担低且治理压力也低于阈值时，AI 不得分封。
	var shallow_state := preload("res://tests/support/grid_world.gd").new()
	for nation_id in range(3):
		var shallow_nation := Nation.new()
		shallow_nation.id = nation_id
		shallow_nation.alive = true
		shallow_nation.ruler_archetype = RulerProfile.BALANCED
		shallow_nation.trade_policy = RulerProfile.POLICY_BALANCED
		shallow_nation.capital_city_id = 0 if nation_id == 0 else -1
		shallow_nation.treasury_gold = 1000
		shallow_nation.manpower_pool = 100000
		shallow_nation.military_payment_ratio = 1.0
		shallow_state.nations.append(shallow_nation)
	for city_id in range(11):
		var shallow_city := City.new()
		shallow_city.id = city_id
		shallow_city.name = "浅压城%d" % city_id
		shallow_city.short_name = String.chr(0x4E00 + city_id)
		shallow_city.owner_nation = 0 if city_id < 9 else 1
		shallow_city.map_position = Vector2(float(city_id) / 20.0, 0.5)
		shallow_city.coord = Vector2i(city_id, 0)
		shallow_city.loyalty = 75.0
		shallow_city.loyalty_target_nation = shallow_city.owner_nation
		shallow_city.gold_per_month = 10
		shallow_city.manpower_per_month = 10
		shallow_city.food_per_half_year = 600
		shallow_city.is_capital = city_id == 0
		shallow_city.has_warehouse = city_id == 0
		if (
			shallow_city.owner_nation == 1
			and shallow_state.nations[1].capital_city_id < 0
		):
			shallow_state.nations[1].capital_city_id = city_id
			shallow_city.is_capital = true
			shallow_city.has_warehouse = true
		shallow_state.cities.append(shallow_city)
		shallow_state.adjacency[city_id] = [] as Array[int]
	for city_id in range(shallow_state.cities.size() - 1):
		var shallow_edge := Edge.new()
		shallow_edge.city_a = city_id
		shallow_edge.city_b = city_id + 1
		shallow_edge.max_manpower = Edge.STANDARD_MANPOWER
		shallow_edge.distance = 1
		shallow_state.edge_lookup[
			shallow_state.edge_key(shallow_edge.city_a, shallow_edge.city_b)
		] = shallow_edge
		(shallow_state.adjacency[shallow_edge.city_a] as Array[int]).append(
			shallow_edge.city_b
		)
		(shallow_state.adjacency[shallow_edge.city_b] as Array[int]).append(
			shallow_edge.city_a
		)
	for city_id in shallow_state.adjacency.keys():
		(shallow_state.adjacency[city_id] as Array[int]).sort()
	shallow_state.recognized_city_owners.resize(shallow_state.cities.size())
	for city in shallow_state.cities:
		shallow_state.recognized_city_owners[city.id] = city.owner_nation
	# Keep singleton administrative states for this enfeoffment fixture, then
	# restore the formal edge list used by territorial-border analysis.
	shallow_state.rebuild_administrative_regions()
	for city_id in range(shallow_state.cities.size() - 1):
		shallow_state.edges.append(
			shallow_state.edge_of(city_id, city_id + 1)
		)
	for a in range(shallow_state.nations.size()):
		for b in range(a + 1, shallow_state.nations.size()):
			shallow_state.set_diplomatic_relation(
				a,
				b,
				GameState.DiplomaticRelation.NEUTRAL
			)
	_enfeoffable_region(shallow_state, 0, 3)
	var shallow_region := DiplomacyAI._grow_enfeoff_region(
		shallow_state,
		0
	)
	var shallow_retained_city := -1
	for city in shallow_state.land_cities_of(0):
		if not shallow_region.has(city.id):
			shallow_retained_city = city.id
			break
	for city_id in shallow_region:
		shallow_state.cities[city_id].gold_per_month = 100
		shallow_state.cities[city_id].food_per_half_year = 100000
	var shallow_report := DiplomacyAI.evaluate_region_burden(
		shallow_state,
		0,
		shallow_region
	)
	var shallow_governance := DiplomacyAI.evaluate_region_governance_pressure(
		shallow_state,
		0,
		shallow_region,
		RebellionSystem.capital_hops(shallow_state, 0)
	)
	var shallow_actions: Array[Dictionary] = []
	DiplomacyAI._collect_enfeoff_actions(
		shallow_state,
		shallow_actions,
		{},
		{}
	)
	var shallow_triggered := false
	for action in shallow_actions:
		if (
			int(action.get("kind", -1))
				== DiplomacyAI.Action.ENFEOFF
			and int(action.get("a", -1)) == 0
		):
			shallow_triggered = true
	_check(
		shallow_region.size()
			>= DiplomacyAI.ENFEOFF_MIN_REGION_CITIES
			and shallow_retained_city >= 0
			and int(shallow_report["monthly_fiscal_benefit"])
				< 0
			and float(shallow_report["burden_ratio"])
				< DiplomacyAI
					.ENFEOFF_FOOD_BURDEN_RATIO_THRESHOLD
			and int(shallow_governance["pressured_city_count"]) >= 1
			and float(shallow_governance["pressure_score"])
				< DiplomacyAI.ENFEOFF_GOVERNANCE_PRESSURE_THRESHOLD
			and not shallow_triggered,
		(
			"财政月增益为负且粮食负担低、治理压力也低时，AI 不得分封"
			+ "（region=%d fiscal=%d burden=%.3f pressured=%d pressure=%.3f triggered=%s）"
		) % [
			shallow_region.size(),
			int(shallow_report["monthly_fiscal_benefit"]),
			float(shallow_report["burden_ratio"]),
			int(shallow_governance["pressured_city_count"]),
			float(shallow_governance["pressure_score"]),
			str(shallow_triggered),
		]
	)

	# 6. 直接验证执行链：手动构造一个满足全部前置的分封并执行，校验不变量。
	if not triggered:
		triggered_region = gate_region
	if triggered_region.size() >= DiplomacyAI.ENFEOFF_MIN_REGION_CITIES:
		var sim := Simulation.new()
		sim.setup(ai_state)
		var executed := sim._execute_diplomatic_action({
			"kind": DiplomacyAI.Action.ENFEOFF,
			"a": 0,
			"b": 0,
			"region_cities": triggered_region,
			"reason": "回归：和平期远边疆分封执行链",
		})
		var new_subject := ai_state.overlord_of(ai_state.nations.size() - 1)
		_check(
			executed
				and ai_state.is_overlord(0)
				and ai_state.subjects_of(0).size() == 1
				and new_subject == 0
				and ai_state.suzerainty_structure_valid()
				and ai_state._battle_group_structure_valid(),
			"AI 分封动作执行后必须真实建立宗藩关系并保持全部结构不变量"
		)
		sim.free()


# ------------------------------------------------------------------ 32f. 宗藩生命周期：纽带保护与死亡清理

func _test_suzerainty_lifecycle() -> void:
	print("[32f] 宗藩：退盟不得解除宗藩纽带、死亡国悬空记录清理、多级上移")
	# 1. 退盟保护：AI 不得对宗主-藩王对产出 LEAVE_ALLIANCE 动作。
	var gs := preload("res://tests/support/grid_world.gd").new()
	gs.generate_grid_world(32061)
	for a in range(gs.nations.size()):
		for b in range(a + 1, gs.nations.size()):
			gs.set_diplomatic_relation(a, b, GameState.DiplomaticRelation.NEUTRAL)
	var region := _enfeoffable_region(gs, 0, 3)
	FamilyFixture.ensure_candidates(gs, 0)
	var subject := gs.enfeoff(0, region)
	_check(subject > 0 and gs.is_suzerainty_pair(0, subject), "分封应建立宗主-藩王对")
	var leave_actions: Array[Dictionary] = []
	DiplomacyAI._collect_leave_alliance_actions(gs, leave_actions, {}, {})
	var breaks_bond := false
	for act in leave_actions:
		var la := int(act.get("a", -1))
		var lb := int(act.get("b", -1))
		if gs.is_suzerainty_pair(la, lb):
			breaks_bond = true
	_check(not breaks_bond, "普通退盟不得解除宗主-藩王的 ALLIED 纽带")

	# 2. 死亡藩王清理：藩王失去全部城市后其宗藩记录必须被移除。
	var dv := preload("res://tests/support/grid_world.gd").new()
	dv.generate_grid_world(32062)
	for a in range(dv.nations.size()):
		for b in range(a + 1, dv.nations.size()):
			dv.set_diplomatic_relation(a, b, GameState.DiplomaticRelation.NEUTRAL)
	var dv_region := _enfeoffable_region(dv, 0, 3)
	FamilyFixture.ensure_candidates(dv, 0)
	var dead_vassal := dv.enfeoff(0, dv_region)
	# 用一笔合法事务把藩王的实控与法理同步交回宗主，模拟藩王被灭。
	var dv_transfer := _transfer_all_owned_cities_for_fixture(
		dv, dead_vassal, 0, "dead_vassal_fixture"
	)
	var dv_pruned_after_transaction := dv.prune_dead_suzerainty()
	_check(
		bool(dv_transfer.get("ok", false))
			and bool(dv_transfer.get("changed", false))
			and bool(dv_transfer.get("political_changed", false))
			and not dv_pruned_after_transaction
			and not dv.is_vassal(dead_vassal)
			and dv.suzerainty_structure_valid()
			and dv.territory_structure_valid(),
		"死亡藩王必须由领土事务原子清理，后续 prune 幂等且不变量成立"
	)

	# 3. 死亡宗主：多级链中，宗主被灭后其藩王上移到祖父（保持链连续）。
	var mv := preload("res://tests/support/grid_world.gd").new()
	mv.generate_grid_world(32063)
	for a in range(mv.nations.size()):
		for b in range(a + 1, mv.nations.size()):
			mv.set_diplomatic_relation(a, b, GameState.DiplomaticRelation.NEUTRAL)
	# 手工构造三级链：2 是 0 的藩王，3 是 2 的藩王（0→2→3）。
	mv.set_diplomatic_relation(0, 2, GameState.DiplomaticRelation.ALLIED)
	mv.set_diplomatic_relation(2, 3, GameState.DiplomaticRelation.ALLIED)
	# 最终 3 会越过死亡中间节点改投 0；预先建立的普通联盟边使最终图
	# 在领土事务提交后仍满足宗藩关系约束。
	mv.set_diplomatic_relation(0, 3, GameState.DiplomaticRelation.ALLIED)
	mv.suzerainty[2] = {
		"overlord_id": 0,
		"tribute_rate": 0.25, "created_day": 0, "last_centralization_day": -1,
		"civil_war": false,
	}
	mv.suzerainty[3] = {
		"overlord_id": 2,
		"tribute_rate": 0.25, "created_day": 0, "last_centralization_day": -1,
		"civil_war": false,
	}
	# 灭掉中间宗主 2：一笔事务同步其全部城市的实控与法理。
	var mv_transfer := _transfer_all_owned_cities_for_fixture(
		mv, 2, 0, "dead_middle_overlord_fixture"
	)
	var mv_pruned_after_transaction := mv.prune_dead_suzerainty()
	_check(
		bool(mv_transfer.get("ok", false))
			and bool(mv_transfer.get("changed", false))
			and bool(mv_transfer.get("political_changed", false))
			and not mv_pruned_after_transaction
			and not mv.is_vassal(2)
			and mv.overlord_of(3) == 0
			and mv.relation_between(3, 0) == GameState.DiplomaticRelation.ALLIED
			and mv.suzerainty_structure_valid()
			and mv.territory_structure_valid(),
		"中间宗主消亡后其藩王必须上移到祖父并保持 ALLIED 与不变量（overlord_of(3)=%d）"
			% mv.overlord_of(3)
	)

	# 4. 无祖父的和平藩王独立后必须把零库存中继首都升格为自身粮仓。
	var independent := preload("res://tests/support/grid_world.gd").new()
	independent.generate_grid_world(32064)
	for a in range(independent.nations.size()):
		for b in range(a + 1, independent.nations.size()):
			independent.set_diplomatic_relation(
				a,
				b,
				GameState.DiplomaticRelation.NEUTRAL
			)
	var independent_region := _enfeoffable_region(independent, 0, 3)
	FamilyFixture.ensure_candidates(independent, 0)
	var independent_subject := independent.enfeoff(
		0,
		independent_region
	)
	var independent_transfer := _transfer_all_owned_cities_for_fixture(
		independent, 0, 1, "dead_root_overlord_fixture"
	)
	var independent_pruned_after_transaction := (
		independent.prune_dead_suzerainty()
	)
	var independent_capital := (
		independent.nations[
			independent_subject
		].capital_city_id
	)
	var independent_food_before := independent.cities[
		independent_capital
	].food_storage
	var independent_deposit := independent.deposit_food(
		independent_subject,
		10
	)
	_check(
		bool(independent_transfer.get("ok", false))
			and bool(independent_transfer.get("changed", false))
			and bool(independent_transfer.get("political_changed", false))
			and not independent_pruned_after_transaction
			and not independent.is_vassal(
				independent_subject
			)
			and independent.cities[
				independent_capital
			].has_warehouse
			and independent.nations[
				independent_subject
			].warehouse_city_ids == (
				[independent_capital] as Array[int]
			)
			and independent_deposit
			and independent.cities[
				independent_capital
			].food_storage == independent_food_before + 10,
		"和平藩王因宗主死亡独立后，首都必须升格粮仓且后续产粮可入库"
	)


# ------------------------------------------------------------------ 32g. 削藩内战：内战态关系与共同体解散（增量 C1）

func _test_civil_war_relations() -> void:
	print("[32g] 削藩内战：内战态宗藩WAR、共同体解散、状态机与不变量")
	var gs := preload("res://tests/support/grid_world.gd").new()
	gs.generate_grid_world(32071)
	for a in range(gs.nations.size()):
		for b in range(a + 1, gs.nations.size()):
			gs.set_diplomatic_relation(a, b, GameState.DiplomaticRelation.NEUTRAL)
	var region := _enfeoffable_region(gs, 0, 3)
	FamilyFixture.ensure_candidates(gs, 0)
	var subject := gs.enfeoff(0, region)
	_check(
		subject > 0
			and not gs.is_in_civil_war(subject)
			and gs.is_allied(0, subject)
			and gs.alliance_bloc(0).has(subject),
		"分封后：非内战、宗藩ALLIED、同属一个对外共同体"
	)

	# 发起削藩内战：宗藩转 WAR、共同体解散、不变量在内战态下成立。
	var started := gs.start_civil_war(subject)
	_check(
		started
			and gs.is_in_civil_war(subject)
			and gs.is_enemy(0, subject)
			and not gs.alliance_bloc(0).has(subject)
			and gs.suzerainty_structure_valid()
			and gs.territory_structure_valid()
			and gs._battle_group_structure_valid(),
		"内战态：宗藩必须WAR、对外共同体解散、结构不变量仍成立"
	)
	# 内战期间宗藩关系仍在（仅关系态变化，非撤藩）。
	_check(
		gs.overlord_of(subject) == 0 and gs.is_vassal(subject),
		"内战期间宗藩关系记录必须保留（内战≠撤藩）"
	)
	# 重复发起应失败（幂等保护）。
	_check(not gs.start_civil_war(subject), "已在内战中不得重复发起")

	# 阵营内战不可用普通停战入口结束；必须走真实首都胜负事务。
	_check(not gs.end_civil_war(subject) and gs.is_enemy(0, subject),
		"阵营内战不得通过普通停战入口清除敌对关系")
	var civil_sim := Simulation.new()
	civil_sim.setup(gs)
	var capital := gs.cities[gs.nations[subject].capital_city_id]
	var captor: Army = null
	for army in gs.armies:
		if army.owner_nation == 0 and army.size > 0:
			captor = army
			break
	_check(captor != null, "阵营内战结束回归须找到宗主攻城军")
	if captor != null:
		captor.location_city = capital.id
		captor.move_from = capital.id
		captor.move_to = -1
		captor.on_edge = false
		captor.state = Army.State.IDLE
		captor.battle_id = -1
		captor.path.clear()
		captor.occupation_claimant_nation = 0
		civil_sim._capture_city(captor, capital, -1)
	_check(
		not gs.nations[subject].alive
			and not gs.is_in_civil_war(subject)
			and not gs.is_enemy(0, subject)
			and capital.owner_nation == 0
			and VassalConflict.for_nation(gs, 0).is_empty()
			and gs.suzerainty_structure_valid()
			and gs.territory_structure_valid()
			and gs._battle_group_structure_valid(),
		"真实攻破首领首都结束阵营内战：吞并败方、释放战争、不变量成立"
	)
	civil_sim.free()

	# 内战中宗主死亡：藩王应脱离（无祖父则独立），内战标记清除。
	var dg := preload("res://tests/support/grid_world.gd").new()
	dg.generate_grid_world(32072)
	for a in range(dg.nations.size()):
		for b in range(a + 1, dg.nations.size()):
			dg.set_diplomatic_relation(a, b, GameState.DiplomaticRelation.NEUTRAL)
	var dg_region := _enfeoffable_region(dg, 0, 3)
	FamilyFixture.ensure_candidates(dg, 0)
	var dg_sub := dg.enfeoff(0, dg_region)
	dg.start_civil_war(dg_sub)
	# 宗主 0 全境失守：同一事务同步实控、法理、库存与最终宗藩图。
	var dg_transfer := _transfer_all_owned_cities_for_fixture(
		dg, 0, dg_sub, "civil_war_dead_overlord_fixture"
	)
	var dg_pruned_after_transaction := dg.prune_dead_suzerainty()
	_check(
		bool(dg_transfer.get("ok", false))
			and bool(dg_transfer.get("changed", false))
			and bool(dg_transfer.get("political_changed", false))
			and not dg_pruned_after_transaction
			and not dg.is_vassal(dg_sub)
			and dg.suzerainty_structure_valid()
			and dg.territory_structure_valid(),
		(
			"内战中宗主消亡必须由领土事务原子完成：藩王脱离宗藩、"
			+ "内战标记随记录清除，后续 prune 幂等"
		)
	)

	# 内战宗藩对不得被联盟批量议和误停战（回归：撤藩不变量后期偶发失败根因）。
	# 构造宗主 0 与内战藩王 1 分属对立联盟集团：0 ALLIED 2、1 ALLIED 3、2↔3 外部 WAR。
	# bloc(0)={0,2} 与 bloc(1)={1,3} 因 2↔3 议和时会遍历到内战对 0↔1（WAR），
	# 若在此停战会抹掉 WAR 却留 civil_war 标记 → 违反不变量第2条，潜伏到后续撤藩才爆。
	var cw := preload("res://tests/support/grid_world.gd").new()
	cw.generate_grid_world(32073)
	for a in range(cw.nations.size()):
		for b in range(a + 1, cw.nations.size()):
			cw.set_diplomatic_relation(a, b, GameState.DiplomaticRelation.NEUTRAL)
	cw.suzerainty[1] = {
		"overlord_id": 0,
		"tribute_rate": GameState.DEFAULT_TRIBUTE_RATE,
		"created_day": 0,
		"last_centralization_day": -1,
		"civil_war": true,
	}
	cw.set_diplomatic_relation(0, 1, GameState.DiplomaticRelation.WAR)
	cw.set_diplomatic_relation(0, 2, GameState.DiplomaticRelation.ALLIED)
	cw.set_diplomatic_relation(1, 3, GameState.DiplomaticRelation.ALLIED)
	cw.set_diplomatic_relation(0, 3, GameState.DiplomaticRelation.WAR)
	cw.set_diplomatic_relation(2, 1, GameState.DiplomaticRelation.WAR)
	cw.set_diplomatic_relation(2, 3, GameState.DiplomaticRelation.WAR)
	cw.refresh_derived()
	_check(
		cw.alliance_bloc(0, false) == [0, 2]
			and cw.alliance_bloc(1, false) == [1, 3]
			and cw.suzerainty_structure_valid(),
		"复现前置：内战宗主与藩王分属对立联盟集团，初始结构合法"
	)
	var cw_sim := Simulation.new()
	cw_sim.setup(cw)
	var civil_city := cw.land_cities_of(1)[0]
	var civil_occupation_city: City = null
	for candidate in cw.land_cities_of(1):
		if (
			candidate.id != civil_city.id
			and not candidate.is_capital
			and not candidate.has_warehouse
		):
			civil_occupation_city = candidate
			break
	_check(
		civil_occupation_city != null,
		"削藩内战和平隔离回归必须找到一座普通藩王城市"
	)
	var civil_control_changed := false
	if civil_occupation_city != null:
		var civil_control_result: Dictionary = cw.transfer_city_control(
			civil_occupation_city.id, 0, 0
		)
		civil_control_changed = bool(
			civil_control_result.get("changed", false)
		)
		# 同时做成断联占领，确保普通和平的 restore 与 recognize 两条
		# 领土结算路径都不得越权处理被排除的削藩内战战果。
		for neighbor in cw.neighbors(civil_occupation_city.id):
			var occupation_edge := cw.edge_of(
				civil_occupation_city.id, neighbor
			)
			if occupation_edge != null:
				occupation_edge.max_manpower = 0
	var civil_besieger: Army = null
	var allied_defender: Army = null
	for army in cw.armies:
		if army.owner_nation == 0 and civil_besieger == null:
			civil_besieger = army
		elif (
			army.owner_nation == 3
			and allied_defender == null
		):
			allied_defender = army
	var civil_siege := cw.new_battle(
		Battle.Kind.SIEGE
	)
	civil_siege.city = civil_city
	civil_siege.side_b_defends_city = true
	civil_siege.side_a.append(civil_besieger)
	civil_siege.side_b.append(allied_defender)
	civil_besieger.state = Army.State.FIGHTING
	civil_besieger.battle_id = civil_siege.id
	allied_defender.state = Army.State.FIGHTING
	allied_defender.battle_id = civil_siege.id
	# 触发外部战争 2↔3 的联盟议和（主对非内战对，绕过收集器层门控，直击执行层）。
	var cw_peace := cw_sim._make_coalition_peace(2, 3)
	_check(
		bool(cw_peace.get("changed", false))
			and cw.relation_between(2, 3) == GameState.DiplomaticRelation.NEUTRAL,
		"外部战争 2↔3 仍正常经联盟议和停战"
	)
	_check(
		civil_control_changed
			and cw.relation_between(0, 1) == GameState.DiplomaticRelation.WAR
			and cw.is_in_civil_war(1)
			and civil_occupation_city != null
			and civil_occupation_city.owner_nation == 0
			and cw.recognized_owner_of(civil_occupation_city.id) == 1
			and civil_occupation_city.occupation_sponsor_nation == 0
			and cw.suzerainty_structure_valid()
			and cw.territory_structure_valid(),
		(
			"普通集团议和必须排除仍在继续的削藩内战 0↔1：关系保持 WAR，"
			+ "断联内战占领既不恢复也不确认法理，结构不变量成立"
		)
	)
	_check(
		cw.battles.has(civil_siege)
			and not civil_siege.finished
			and civil_siege.side_a.has(civil_besieger)
			and not civil_siege.side_b.has(
				allied_defender
			)
			and civil_besieger.battle_id
				== civil_siege.id
			and allied_defender.battle_id == -1,
		"外部盟友议和只能移出该盟友守军，仍为 WAR 的削藩围城必须继续"
	)
	# 内战战果结算由内战自身负责；结束该内战后再做统一和平归一化，
	# 不需要挂起或重放刚才那场普通战争的领土事务。
	var civil_war_ended := cw.end_civil_war(1)
	var normalized_after_civil_war := cw.normalize_peaceful_occupations()
	_check(
		civil_war_ended
			and normalized_after_civil_war.is_empty()
			and civil_occupation_city.owner_nation == 1
			and cw.recognized_owner_of(civil_occupation_city.id) == 1
			and civil_occupation_city.occupation_sponsor_nation == -1
			and cw.territory_structure_valid(),
		"削藩内战结束后统一归一化必须清理其临时占领，不依赖普通和平重放"
	)
	cw_sim.free()



# ------------------------------------------------------------------ 32h. 削藩决策与反抗判据（增量 C2）

func _test_centralization_decision() -> void:
	print("[32h] 削藩：财政收益主判据、高威胁例外、反抗比、和平撤藩守恒")
	# 构造宗主 0 + 藩王：把藩王大部分军队清掉，制造宗主压倒性优势→藩王接受。
	var gs := preload("res://tests/support/grid_world.gd").new()
	gs.generate_grid_world(32081)
	for a in range(gs.nations.size()):
		for b in range(a + 1, gs.nations.size()):
			gs.set_diplomatic_relation(a, b, GameState.DiplomaticRelation.NEUTRAL)
	var region := _enfeoffable_region(gs, 0, 3)
	FamilyFixture.ensure_candidates(gs, 0)
	var subject := gs.enfeoff(0, region)
	_check(subject > 0, "分封应成功建立藩王")

	# 削弱藩王：清空其大部分军队，使反抗比远低于阈值 → 预判为「接受」。
	var removed := 0
	for army in gs.armies:
		if army.owner_nation == subject and removed < 100:
			army.size = 0
			removed += 1
	var weak_ratio := DiplomacyAI.vassal_resist_ratio(gs, subject)
	var weak_fiscal := (
		DiplomacyAI
			.evaluate_centralization_fiscal_benefit(
				gs,
				subject
			)
	)
	var expected_direct_income := 0
	for city in gs.cities_of(subject):
		expected_direct_income += (
			Simulation.city_gold_output_before_governance(
				gs,
				city
			)
		)
	var weak_gold_flow := Simulation.monthly_gold_flows(gs)[
		subject
	]
	_check(
		weak_ratio
			< DiplomacyAI.CENTRALIZE_RESIST_RATIO_THRESHOLD
			and int(weak_fiscal["projected_direct_income"])
				== expected_direct_income
			and int(weak_fiscal["inherited_subordinate_tribute"])
				== int(weak_gold_flow["tribute_received"])
			and int(weak_fiscal["lost_subject_tribute"])
				== int(weak_gold_flow["tribute_paid"])
			and int(weak_fiscal["inherited_military_upkeep"])
				== int(weak_gold_flow["military_upkeep"])
			and int(weak_fiscal["monthly_fiscal_benefit"])
				== (
					expected_direct_income
					+ int(weak_gold_flow["tribute_received"])
					- int(weak_gold_flow["tribute_paid"])
					- int(weak_gold_flow["military_upkeep"])
				),
		"撤藩财政反事实须同源计算直辖收入、下级贡赋、原贡赋与接收军费"
	)
	# 分封保护期内不得削藩：刚分封（created_day==0）时评估应无削藩动作，杜绝「封了又撤」横跳。
	var fresh_actions: Array[Dictionary] = []
	DiplomacyAI._collect_centralization_actions(gs, fresh_actions, {}, {})
	var fresh_has_centralize := false
	for act in fresh_actions:
		if int(act.get("kind", -1)) == DiplomacyAI.Action.CENTRALIZE and int(act.get("b", -1)) == subject:
			fresh_has_centralize = true
	_check(
		not fresh_has_centralize,
		"分封保护期内不得对新藩王削藩（防止分封↔撤回反复横跳）"
	)
	# 越过分封保护期后方可削藩：把世界日推进到超过 CENTRALIZE_MIN_VASSAL_AGE_DAYS。
	gs.day = DiplomacyAI.CENTRALIZE_MIN_VASSAL_AGE_DAYS + 1
	var actions: Array[Dictionary] = []
	DiplomacyAI._collect_centralization_actions(gs, actions, {}, {})
	var accept_action := {}
	for act in actions:
		if int(act.get("kind", -1)) == DiplomacyAI.Action.CENTRALIZE and int(act.get("b", -1)) == subject:
			accept_action = act
	_check(
		int(weak_fiscal["monthly_fiscal_benefit"]) > 0
			and not accept_action.is_empty()
			and int(
				accept_action.get(
					"monthly_fiscal_benefit",
					0
				)
			) > 0
			and not bool(accept_action.get("resist", true)),
		"撤藩财政收益为正且藩王弱小时，应产出和平撤藩动作"
	)

	# 战时不得削藩：给宗主制造实战外战，动作应消失。
	gs.set_diplomatic_relation(0, 1, GameState.DiplomaticRelation.WAR)
	var war_actions: Array[Dictionary] = []
	DiplomacyAI._collect_centralization_actions(gs, war_actions, {}, {})
	var war_has_centralize := false
	for act in war_actions:
		if int(act.get("kind", -1)) == DiplomacyAI.Action.CENTRALIZE and int(act.get("a", -1)) == 0:
			war_has_centralize = true
	_check(not war_has_centralize, "宗主正陷外战时不得削藩")
	gs.set_diplomatic_relation(0, 1, GameState.DiplomaticRelation.NEUTRAL)

	# 和平撤藩执行：资源守恒（撤藩前后宗主+藩王 人力/金钱 总量不变）、藩王被吸收。
	var pre_manpower := gs.nations[0].manpower_pool + gs.nations[subject].manpower_pool
	var pre_gold := gs.nations[0].treasury_gold + gs.nations[subject].treasury_gold
	var subject_cities := gs.land_cities_of(subject).size()
	var overlord_cities_before := gs.land_cities_of(0).size()
	var sim := Simulation.new()
	sim.setup(gs)
	var executed := sim._execute_diplomatic_action({
		"kind": DiplomacyAI.Action.CENTRALIZE,
		"a": 0,
		"b": subject,
		"resist": false,
		"reason": "回归：和平撤藩",
	})
	_check(
		executed
			and not gs.is_vassal(subject)
			and not gs.nations[subject].alive
			and gs.land_cities_of(0).size() == overlord_cities_before + subject_cities
			and gs.nations[0].manpower_pool == pre_manpower
			and gs.nations[0].treasury_gold == pre_gold
			and gs.suzerainty_structure_valid()
			and gs._battle_group_structure_valid(),
		"和平撤藩：藩王全境并回宗主、资源守恒、宗藩记录清除、不变量成立"
	)
	sim.free()

	# 征服者藩王面对削藩必定反抗；执行入口不得相信缓存动作中的
	# resist=false，并按普通削藩火星兵数量的两倍动员。
	var conqueror_state := preload("res://tests/support/grid_world.gd").new()
	conqueror_state.generate_grid_world(32084)
	for a in range(conqueror_state.nations.size()):
		for b in range(a + 1, conqueror_state.nations.size()):
			conqueror_state.set_diplomatic_relation(
				a, b, GameState.DiplomaticRelation.NEUTRAL
			)
	var conqueror_region := _enfeoffable_region(conqueror_state, 0, 3)
	FamilyFixture.ensure_candidates(conqueror_state, 0)
	var conqueror_subject := conqueror_state.enfeoff(0, conqueror_region)
	_ensure_civil_war_fixture_contact(conqueror_state, 0, conqueror_subject)
	conqueror_state.nations[conqueror_subject].ruler_archetype = (
		RulerProfile.CONQUEROR
	)
	conqueror_state.day = DiplomacyAI.CENTRALIZE_MIN_VASSAL_AGE_DAYS + 1
	var conqueror_actions: Array[Dictionary] = []
	DiplomacyAI._collect_centralization_actions(
		conqueror_state, conqueror_actions, {}, {}
	)
	var conqueror_action: Dictionary = {}
	for action in conqueror_actions:
		if (
			int(action.get("kind", -1)) == DiplomacyAI.Action.CENTRALIZE
			and int(action.get("b", -1)) == conqueror_subject
		):
			conqueror_action = action
			break
	var conqueror_land := conqueror_state.land_cities_of(
		conqueror_subject
	).size()
	var expected_conqueror_uprising := (
		2 * int(ceil(0.1 * float(conqueror_land)))
	)
	var conqueror_armies_before := conqueror_state.armies.size()
	var stale_conqueror_action := (
		conqueror_action.duplicate(true)
		if not conqueror_action.is_empty()
		else {
			"kind": DiplomacyAI.Action.CENTRALIZE,
			"a": 0,
			"b": conqueror_subject,
			"reason": "征服者强制反抗回归",
		}
	)
	stale_conqueror_action["resist"] = false
	var conqueror_sim := Simulation.new()
	conqueror_sim.setup(conqueror_state)
	var conqueror_executed := conqueror_sim._execute_diplomatic_action(
		stale_conqueror_action
	)
	_check(
		conqueror_subject >= 0
			and conqueror_executed
			and conqueror_state.is_in_civil_war(conqueror_subject)
			and conqueror_state.armies.size() - conqueror_armies_before
				== expected_conqueror_uprising
			and conqueror_state.suzerainty_structure_valid()
			and conqueror_state._battle_group_structure_valid(),
		(
			"征服者藩王被削藩必须开战，并动员普通数量两倍的火星兵"
			+ "（期望%d，实增%d）"
		) % [
			expected_conqueror_uprising,
			conqueror_state.armies.size() - conqueror_armies_before,
		]
	)
	conqueror_sim.free()

	# 财政亏损且威胁不高时不得撤藩，防止移除军力优势门槛后周期性无条件削藩。
	var loss_state := preload("res://tests/support/grid_world.gd").new()
	loss_state.generate_grid_world(32083)
	for a in range(loss_state.nations.size()):
		for b in range(a + 1, loss_state.nations.size()):
			loss_state.set_diplomatic_relation(
				a,
				b,
				GameState.DiplomaticRelation.NEUTRAL
			)
	var loss_region := _enfeoffable_region(loss_state, 0, 3)
	FamilyFixture.ensure_candidates(loss_state, 0)
	var loss_subject := loss_state.enfeoff(
		0,
		loss_region
	)
	for city in loss_state.cities_of(loss_subject):
		city.gold_per_month = 0
	loss_state.day = (
		DiplomacyAI.CENTRALIZE_MIN_VASSAL_AGE_DAYS + 1
	)
	var loss_fiscal := (
		DiplomacyAI
			.evaluate_centralization_fiscal_benefit(
				loss_state,
				loss_subject
			)
	)
	var loss_ratio := DiplomacyAI.vassal_resist_ratio(
		loss_state,
		loss_subject
	)
	var loss_actions: Array[Dictionary] = []
	DiplomacyAI._collect_centralization_actions(
		loss_state,
		loss_actions,
		{},
		{}
	)
	var loss_has_centralize := false
	for action in loss_actions:
		if (
			int(action.get("kind", -1))
				== DiplomacyAI.Action.CENTRALIZE
			and int(action.get("b", -1))
				== loss_subject
		):
			loss_has_centralize = true
	_check(
		int(loss_fiscal["monthly_fiscal_benefit"]) <= 0
			and loss_ratio
				< DiplomacyAI
					.CENTRALIZE_POLITICAL_THREAT_RATIO_THRESHOLD
			and not loss_has_centralize,
		"撤藩财政亏损且政治威胁未达高危阈值时，不得削藩"
	)

	# 高威胁例外：大藩王即使撤藩财政亏损、军力强于宗主，仍应触发削藩并反抗。
	var rs := preload("res://tests/support/grid_world.gd").new()
	rs.generate_grid_world(32082)
	for a in range(rs.nations.size()):
		for b in range(a + 1, rs.nations.size()):
			rs.set_diplomatic_relation(a, b, GameState.DiplomaticRelation.NEUTRAL)
	var rs_region := _enfeoffable_region(rs, 0, 3)
	FamilyFixture.ensure_candidates(rs, 0)
	var rs_sub := rs.enfeoff(0, rs_region)
	for city in rs.cities_of(rs_sub):
		city.gold_per_month = 0
	var rs_group := rs.create_battle_group(rs_sub)
	var rs_army := rs.create_army(
		rs_sub,
		rs.nations[rs_sub].capital_city_id,
		GameState.INITIAL_HEAVY_ARMY_SIZE,
		GameState.INITIAL_HEAVY_ARMY_SIZE
	)
	rs.assign_army_to_battle_group(rs_army, rs_group.id)
	# 削弱宗主自身军队，使藩王超过高威胁阈值；旧的 1.5 倍军力优势门槛在此必定失败。
	var rs_removed := 0
	for army in rs.armies:
		if army.owner_nation == 0 and rs_removed < 100:
			army.size = 0
			rs_removed += 1
	rs.day = (
		DiplomacyAI.CENTRALIZE_MIN_VASSAL_AGE_DAYS + 1
	)
	var rs_fiscal := (
		DiplomacyAI
			.evaluate_centralization_fiscal_benefit(
				rs,
				rs_sub
			)
	)
	var strong_ratio := DiplomacyAI.vassal_resist_ratio(rs, rs_sub)
	# 削藩反抗现由 RebellionSystem 统一判断：除军力外，还必须满足
	# 低忠诚持续三个月与双方叛乱冷却。显式构造该政治成熟状态。
	for city in rs.land_cities_of(rs_sub):
		city.loyalty = RebellionSystem.LOYALTY_REBEL
		city.rebellion_progress = RebellionSystem.REBELLION_PROGRESS_MONTHS
	rs.nations[0].last_rebellion_day = -1
	rs.nations[rs_sub].last_rebellion_day = -1
	var rs_actions: Array[Dictionary] = []
	DiplomacyAI._collect_centralization_actions(
		rs,
		rs_actions,
		{},
		{}
	)
	var resist_action := {}
	for action in rs_actions:
		if (
			int(action.get("kind", -1))
				== DiplomacyAI.Action.CENTRALIZE
			and int(action.get("b", -1)) == rs_sub
		):
			resist_action = action
	var rs_sim := Simulation.new()
	rs_sim.setup(rs)
	var rs_exec := (
		rs_sim._execute_diplomatic_action(resist_action)
		if not resist_action.is_empty()
		else false
	)
	_check(
		int(rs_fiscal["monthly_fiscal_benefit"]) < 0
			and strong_ratio
				>= DiplomacyAI
					.CENTRALIZE_POLITICAL_THREAT_RATIO_THRESHOLD
			and not resist_action.is_empty()
			and bool(resist_action.get("resist", false))
			and str(
				resist_action.get("reason", "")
			).contains("政治威胁比")
			and rs_exec
			and rs.is_in_civil_war(rs_sub)
			and rs.is_enemy(0, rs_sub)
			and rs.is_vassal(rs_sub)
			and rs.suzerainty_structure_valid(),
		"高威胁大藩王须绕过财政亏损触发削藩，并以反抗进入内战"
	)
	rs_sim.free()


# ------------------------------------------------------------------ 32i. 削藩内战通吃结算（增量 C3）

func _test_civil_war_annexation() -> void:
	print("[32i] 削藩内战：宗主占藩王首都吞并、藩王占宗主首都继承体系")
	# 情形一：宗主赢——占藩王首都→吞并藩王全境。
	var gs := preload("res://tests/support/grid_world.gd").new()
	gs.generate_grid_world(32091)
	for a in range(gs.nations.size()):
		for b in range(a + 1, gs.nations.size()):
			gs.set_diplomatic_relation(a, b, GameState.DiplomaticRelation.NEUTRAL)
	var region := _enfeoffable_region(gs, 0, 8)
	FamilyFixture.ensure_candidates(gs, 0)
	var subject := gs.enfeoff(0, region)
	# 本制度仅支持单层宗藩；由宗主真实分封另一直属藩王，并以低忠站反叛方。
	var child_region := _enfeoffable_region(gs, 0)
	FamilyFixture.ensure_candidates(gs, 0)
	var child_subject := gs.enfeoff(0, child_region)
	for city in gs.land_cities_of(child_subject):
		city.loyalty = 0.0
	_ensure_civil_war_fixture_contact(gs, 0, subject)
	_check(
		child_subject > subject
			and gs.overlord_of(child_subject) == 0
			and RebellionSystem.vassal_loyalty(gs, child_subject) <= RebellionSystem.LOYALTY_REBEL,
		"削藩兼并测试须通过真实分封建立低忠直属藩王"
	)
	gs.start_civil_war(subject)
	_check(
		gs.external_territory_recipient(subject) == subject,
		"削藩内战反叛方已脱离和平主权链，对外领土接收者必须是自己"
	)
	# 用合法世界上的 stale revision 在任何提交前拒绝兼并。这里包含同阵营
	# 藩王，能捕获先改宗藩树/外交、再因领土事务失败而半提交。
	var rejected_annex_before := _territory_fingerprint(gs)
	var rejected_annex := gs.annex_nation(
		0, subject, gs.ownership_revision + 1
	)
	_check(
		not rejected_annex
			and _territory_fingerprint(gs) == rejected_annex_before
			and gs.is_in_civil_war(subject)
			and gs.overlord_of(subject) == 0
			and gs.overlord_of(child_subject) == 0
			and VassalConflict.for_nation(gs, subject).get("rebels", []).has(child_subject)
			and gs.suzerainty_structure_valid()
			and gs.territory_structure_valid()
			and gs._battle_group_structure_valid(),
		(
			"annex_nation 的领土 revision 冲突必须返回 false，且宗藩树/"
			+ "外交/军队/资源/领土完整回滚"
		)
	)
	# stock_policy_overrides 是刻意受限的兼并入口：不能借它改写败方
	# 当前未实控的城市，也不能注入事务不认识的库存策略。任一非法项
	# 必须在 planner 阶段整笔拒绝且没有副作用。
	var invalid_override_before := _territory_fingerprint(gs)
	var rejected_foreign_override := gs.annex_nation(
		0,
		subject,
		-1,
		{
			gs.nations[0].capital_city_id: (
				GameState.TerritoryStockDisposition.CAPTURE_SPOILS
			),
		}
	)
	var rejected_policy_override := gs.annex_nation(
		0,
		subject,
		-1,
		{gs.nations[subject].capital_city_id: 999}
	)
	_check(
		not rejected_foreign_override
			and not rejected_policy_override
			and _territory_fingerprint(gs) == invalid_override_before,
		(
			"annex_nation 库存 override 仅允许败方当前实控城市和四种"
			+ "合法策略，非法项必须零副作用拒绝"
		)
	)
	# 把反叛藩王压缩到只剩首都一城：旧实现会先提交单城占领，令
	# 领土事务提前删除死亡藩王的内战边，随后再也识别不到通吃。
	var subject_capital_id := gs.nations[subject].capital_city_id
	var subject_collapse_operations: Array[Dictionary] = []
	for subject_city in gs.cities_of(subject):
		if subject_city.id == subject_capital_id:
			continue
		subject_collapse_operations.append({
			"city_id": subject_city.id,
			"controller_id": 0,
			"legal_owner_id": 0,
			"sponsor_id": -1,
			"reset_political_target": true,
			"stock_policy": (
				GameState.TerritoryStockDisposition.MOVE_TO_NEW_POOL
			),
			"reason": "civil_capture_last_capital_fixture",
		})
	var subject_collapsed := gs.apply_territory_transaction(
		subject_collapse_operations
	)
	var subject_capital := gs.cities[subject_capital_id]
	subject_capital.food_storage = 100
	gs.refresh_derived()
	_check(
		bool(subject_collapsed.get("ok", false))
			and gs.cities_of(subject).size() == 1
			and subject_capital.owner_nation == subject
			and subject_capital.has_warehouse
			and gs.overlord_of(child_subject) == 0
			and gs.is_in_civil_war(subject),
		"宗主胜回归夹具须保留内战藩王最后一座首都及其同阵营藩王"
	)
	var overlord_cities_before := gs.land_cities_of(0).size()
	var subject_cities := gs.land_cities_of(subject).size()
	var overlord_food_before := gs.nations[0].granary_food
	var allied_rebel_food_before := gs.nations[child_subject].granary_food
	var capture_revision_before := gs.ownership_revision
	var sim := Simulation.new()
	sim.setup(gs)
	var overlord_captor: Army = null
	for candidate in gs.armies:
		if candidate.owner_nation == 0 and candidate.size > 0:
			overlord_captor = candidate
			break
	_check(overlord_captor != null, "宗主胜回归须找到宗主攻城军")
	if overlord_captor != null:
		overlord_captor.location_city = subject_capital_id
		overlord_captor.move_from = subject_capital_id
		overlord_captor.move_to = -1
		overlord_captor.move_progress = 0.0
		overlord_captor.on_edge = false
		overlord_captor.state = Army.State.IDLE
		overlord_captor.battle_id = -1
		overlord_captor.path.clear()
		overlord_captor.occupation_claimant_nation = 0
		sim._capture_city(overlord_captor, subject_capital, -1)
	_check(
		not gs.is_vassal(subject)
			and not gs.nations[subject].alive
			and gs.overlord_of(child_subject) == 0
			and gs.is_allied(0, child_subject)
			and gs.land_cities_of(0).size() == overlord_cities_before + subject_cities
			and subject_capital.owner_nation == 0
			and not subject_capital.has_warehouse
			and subject_capital.food_storage == 0
			and gs.nations[0].granary_food == (
				overlord_food_before
				+ allied_rebel_food_before
				+ int(floor(
					100.0 * GameState.TERRITORY_CAPTURE_SPOILS_RATE
				))
			)
			and gs.ownership_revision == capture_revision_before + 1
			and gs.suzerainty_structure_valid()
			and gs.territory_structure_valid()
			and gs._battle_group_structure_valid(),
		(
			"宗主真实攻破藩王最后首都：单次事务吞并、同阵营藩王改投，"
			+ "首都库存仅获30%、存活藩王粮池完整重聚且不变量成立"
		)
	)
	sim.free()

	# 兼并原语必须分别迁移实控与法理，并终止兼并后失去敌对性的战斗。
	var atomic := preload("res://tests/support/grid_world.gd").new()
	atomic.generate_grid_world(32093)
	for a in range(atomic.nations.size()):
		for b in range(a + 1, atomic.nations.size()):
			atomic.set_diplomatic_relation(
				a,
				b,
				GameState.DiplomaticRelation.NEUTRAL
			)
	atomic.set_diplomatic_relation(
		0,
		1,
		GameState.DiplomaticRelation.WAR
	)
	var captured_legal_city := atomic.land_cities_of(1)[0]
	captured_legal_city.owner_nation = 0
	var third_party_legal_city := atomic.land_cities_of(1)[1]
	atomic.recognized_city_owners[
		third_party_legal_city.id
	] = 2
	third_party_legal_city.occupation_sponsor_nation = 1
	var absorber_army: Army = null
	var absorbed_army: Army = null
	for army in atomic.armies:
		if army.owner_nation == 0 and absorber_army == null:
			absorber_army = army
		elif (
			army.owner_nation == 1
			and absorbed_army == null
		):
			absorbed_army = army
	var stale_claim_army: Army = atomic.armies[0]
	stale_claim_army.occupation_claimant_nation = 1
	var internal_battle := atomic.new_battle(
		Battle.Kind.FIELD
	)
	internal_battle.side_a.append(absorber_army)
	internal_battle.side_b.append(absorbed_army)
	absorber_army.state = Army.State.FIGHTING
	absorber_army.battle_id = internal_battle.id
	absorbed_army.state = Army.State.FIGHTING
	absorbed_army.battle_id = internal_battle.id
	var atomic_annexed := atomic.annex_nation(0, 1)
	_check(
		atomic_annexed
			and atomic.recognized_owner_of(
			captured_legal_city.id
		) == 0
			and third_party_legal_city.owner_nation == 0
			and atomic.recognized_owner_of(
				third_party_legal_city.id
			) == 2
			and third_party_legal_city
				.occupation_sponsor_nation == 0
			and internal_battle.finished
			and absorber_army.battle_id == -1
			and absorbed_army.battle_id == -1
			and absorber_army.owner_nation == 0
			and absorbed_army.owner_nation == 0
			and stale_claim_army
				.occupation_claimant_nation == 0,
		"兼并须独立迁移实控/法理/占领声明，并原子解除已变成同国的战斗"
	)

	# 情形二：藩王赢——占宗主首都→夺取宗主全境，其余藩王转投，胜者成新顶点。
	var vs := preload("res://tests/support/grid_world.gd").new()
	vs.generate_grid_world(32092)
	for a in range(vs.nations.size()):
		for b in range(a + 1, vs.nations.size()):
			vs.set_diplomatic_relation(a, b, GameState.DiplomaticRelation.NEUTRAL)
	# 宗主 0 分封两个藩王：winner 与 sibling。
	var r1 := _enfeoffable_region(vs, 0, 3)
	FamilyFixture.ensure_candidates(vs, 0, 3)
	var winner := vs.enfeoff(0, r1)
	var r2 := _enfeoffable_region(vs, 0, 3)
	FamilyFixture.ensure_candidates(vs, 0)
	var sibling := vs.enfeoff(0, r2)
	_check(winner > 0 and sibling > 0 and winner != sibling, "应成功分封两个藩王")
	vs.start_civil_war(winner)
	# 同样把旧宗主压缩到只剩首都，以覆盖反向兼并时首笔单城事务
	# 会提前提升藩王、令 live 宗藩查询失效的历史回归。
	var overlord_capital_id := vs.nations[0].capital_city_id
	var overlord_collapse_operations: Array[Dictionary] = []
	for overlord_city in vs.cities_of(0):
		if overlord_city.id == overlord_capital_id:
			continue
		overlord_collapse_operations.append({
			"city_id": overlord_city.id,
			"controller_id": winner,
			"legal_owner_id": winner,
			"sponsor_id": -1,
			"reset_political_target": true,
			"stock_policy": (
				GameState.TerritoryStockDisposition.MOVE_TO_NEW_POOL
			),
			"reason": "civil_capture_last_overlord_capital_fixture",
		})
	var overlord_collapsed := vs.apply_territory_transaction(
		overlord_collapse_operations
	)
	var overlord_capital := vs.cities[overlord_capital_id]
	overlord_capital.food_storage = 100
	vs.refresh_derived()
	_check(
		bool(overlord_collapsed.get("ok", false))
			and vs.cities_of(0).size() == 1
			and overlord_capital.owner_nation == 0
			and overlord_capital.has_warehouse
			and vs.overlord_of(winner) == 0
			and vs.is_in_civil_war(winner)
			and vs.overlord_of(sibling) == 0,
		"藩王胜回归夹具须保留旧宗主最后一座首都与兄弟藩王"
	)
	var winner_food_before := vs.nations[winner].granary_food
	var vs_capture_revision_before := vs.ownership_revision
	var vs_sim := Simulation.new()
	vs_sim.setup(vs)
	var vassal_captor: Army = null
	for candidate in vs.armies:
		if candidate.owner_nation == winner and candidate.size > 0:
			vassal_captor = candidate
			break
	if vassal_captor == null:
		var winner_capital := vs.nations[winner].capital_city_id
		vassal_captor = vs.create_army(
			winner,
			winner_capital,
			GameState.INITIAL_HEAVY_ARMY_SIZE,
			GameState.INITIAL_HEAVY_ARMY_SIZE
		)
	_check(vassal_captor != null, "藩王胜回归须找到反叛方攻城军")
	if vassal_captor != null:
		vassal_captor.location_city = overlord_capital_id
		vassal_captor.move_from = overlord_capital_id
		vassal_captor.move_to = -1
		vassal_captor.move_progress = 0.0
		vassal_captor.on_edge = false
		vassal_captor.state = Army.State.IDLE
		vassal_captor.battle_id = -1
		vassal_captor.path.clear()
		vassal_captor.occupation_claimant_nation = winner
		vs_sim._capture_city(vassal_captor, overlord_capital, -1)
	_check(
		not vs.nations[0].alive
			and vs.cities_of(0).is_empty()
			and not vs.is_vassal(winner)          # 胜者升为新顶点
			and vs.overlord_of(sibling) == winner  # 兄弟藩王转投胜者
			and vs.is_allied(winner, sibling)
			and not vs.is_in_civil_war(sibling)
			and overlord_capital.owner_nation == winner
			and not overlord_capital.has_warehouse
			and overlord_capital.food_storage == 0
			and vs.nations[winner].granary_food == (
				winner_food_before
				+ int(floor(
					100.0 * GameState.TERRITORY_CAPTURE_SPOILS_RATE
				))
			)
			and vs.ownership_revision == vs_capture_revision_before + 1
			and vs.suzerainty_structure_valid()
			and vs.territory_structure_valid()
			and vs._battle_group_structure_valid(),
		(
			"藩王真实攻破宗主最后首都：单次事务继承体系、兄弟改投，"
			+ "首都库存仅获30%且胜者成为主权顶点"
		)
	)
	vs_sim.free()


# ------------------------------------------------------------------ 32i2. 资源容量

func _test_resource_capacity_limits() -> void:
	print("[32i2] 资源容量：按配置储备周期计算，宗主递归计入藩属城市")
	var gs := preload("res://tests/support/grid_world.gd").new()
	gs.generate_grid_world(41000)
	var own_food_output := 0
	var own_manpower_output := 0
	for city in gs.land_cities_of(0):
		own_food_output += city.food_per_half_year
		own_manpower_output += city.manpower_per_month
	var own_food_capacity := (
		own_food_output * GameState.FOOD_CAPACITY_HALF_YEARS
	)
	var own_manpower_capacity := (
		own_manpower_output * GameState.INITIAL_MANPOWER_RESERVE_MONTHS
	)
	_check(
		gs.food_storage_capacity(0) == own_food_capacity
			and gs.manpower_pool_capacity(0) == own_manpower_capacity
			and gs.nations[0].manpower_pool == own_manpower_capacity,
		"独立国粮食与人力容量须按当前配置的储备周期计算"
	)
	var warehouse := gs.warehouse_cities_of(0)[0]
	warehouse.food_storage = own_food_capacity - 10
	gs.refresh_derived()
	_check(
		gs.deposit_food(0, 100)
			and warehouse.food_storage == own_food_capacity,
		"粮食入库必须在配置容量处截断"
	)
	gs.nations[0].manpower_pool = own_manpower_capacity - 10
	_check(
		gs.add_manpower(0, 100) == 10
			and gs.nations[0].manpower_pool == own_manpower_capacity,
		"人力增加必须在配置容量处截断"
	)
	warehouse.food_storage = own_food_capacity + 100
	gs.nations[0].manpower_pool = own_manpower_capacity + 100
	gs.refresh_derived()
	gs.clamp_resource_capacities()
	_check(
		warehouse.food_storage == own_food_capacity
			and gs.nations[0].manpower_pool == own_manpower_capacity,
		"月结算边界必须清除领土或宗藩变化留下的超额库存"
	)

	var region := _enfeoffable_region(gs, 0, 8)
	FamilyFixture.ensure_candidates(gs, 0)
	var subject := gs.enfeoff(0, region)
	var child_region := _enfeoffable_region(gs, subject)
	FamilyFixture.ensure_candidates(gs, subject)
	var child := gs.enfeoff(subject, child_region)
	_check(subject >= 0 and child >= 0, "资源容量测试须建立两级藩属")
	var root_food_output := 0
	var root_manpower_output := 0
	var subject_manpower_output := 0
	for member_id in gs.food_pool_members(0):
		for city in gs.land_cities_of(member_id):
			root_food_output += city.food_per_half_year
			root_manpower_output += city.manpower_per_month
	for member_id in gs.food_pool_members(subject):
		for city in gs.land_cities_of(member_id):
			subject_manpower_output += city.manpower_per_month
	_check(
		gs.food_storage_capacity(0)
			== root_food_output * GameState.FOOD_CAPACITY_HALF_YEARS
			and gs.food_storage_capacity(child)
				== root_food_output * GameState.FOOD_CAPACITY_HALF_YEARS
			and gs.manpower_pool_capacity(0)
				== root_manpower_output
					* GameState.INITIAL_MANPOWER_RESERVE_MONTHS
			and gs.manpower_pool_capacity(subject)
				== subject_manpower_output
					* GameState.INITIAL_MANPOWER_RESERVE_MONTHS,
		"宗主容量须递归包含全部藩属城市，藩王人力容量只包含自己的子树"
	)


# ------------------------------------------------------------------ 32i3. 共享粮仓 + 补给中继节点 + 内战切分

func _test_shared_granary_and_relay_supply() -> void:
	print("[32i2] 共享粮仓：分封守恒归根池、藩王首都零库存中继降损耗、内战切分守恒+火星兵")
	# --- 1. 分封：粮食不划走、全归宗主根池；藩王首都为零库存中继节点 ---
	var gs := preload("res://tests/support/grid_world.gd").new()
	gs.generate_grid_world(41001)
	for a in range(gs.nations.size()):
		for b in range(a + 1, gs.nations.size()):
			gs.set_diplomatic_relation(a, b, GameState.DiplomaticRelation.NEUTRAL)
	gs.refresh_derived()
	var pre_food := gs.nations[0].granary_food
	var region := _enfeoffable_region(gs, 0, 3)
	FamilyFixture.ensure_candidates(gs, 0)
	var subject := gs.enfeoff(0, region)
	gs.refresh_derived()
	# 本段只验证宗藩共享粮池聚合；贸易已不再产生粮食外部流量。
	for pool_nation in gs.nations:
		pool_nation.trade_policy = RulerProfile.POLICY_ISOLATION
	var sub_capital := gs.nations[subject].capital_city_id
	_check(
		subject > 0
			and not gs.cities[sub_capital].has_warehouse
			and gs.cities[sub_capital].food_storage == 0
			and gs.nations[subject].granary_food == 0
			and gs.nations[0].granary_food == pre_food
			and gs.food_pool_holder(subject) == 0,
		"分封后粮食全留宗主根池（%d==%d）、藩王首都零库存中继" % [gs.nations[0].granary_food, pre_food]
	)
	gs.nations[0].food_demand_ema = 0.0
	gs.nations[subject].food_demand_ema = 0.0
	var pool_expected_production := 0.0
	var pool_expected_demand := 0.0
	var pool_garrisons := Simulation.build_garrison_index(
		gs
	)
	for member_id in gs.food_pool_members(0):
		var member: Nation = gs.nations[member_id]
		for army in gs.armies:
			if army.owner_nation == member_id and army.size > 0:
				pool_expected_demand += TradeNetwork._projected_army_monthly_food_demand(army, member, RulerProfile.food_consumption_multiplier(member))
		for center_id in gs.administrative_center_city_ids:
			var center: City = gs.cities[center_id]
			if center.owner_nation == member_id:
				pool_expected_demand += Simulation.city_garrison_cost_report(gs, member_id, center_id, center.garrison_manpower, gs.capital_hop_distances(member_id)).food_demand
		for city in gs.cities_of(member_id):
			pool_expected_production += (
				float(Simulation.city_food_output(
					gs,
					city,
					pool_garrisons
				)) / 6.0
			)
	var pool_report := DiplomacyAI.war_food_report(
		gs,
		0
	)
	_check(
		int(pool_report["pool_holder"]) == 0
			and pool_report["pool_members"]
				== gs.food_pool_members(0)
			and is_equal_approx(
				float(pool_report[
					"monthly_food_production"
				]),
				pool_expected_production
			)
			and is_equal_approx(
				float(pool_report[
					"current_monthly_demand"
				]),
				pool_expected_demand
			),
		"宗藩战争粮食报告必须按共享粮池聚合全部成员的生产、需求与库存"
	)

	# --- 2. 削藩内战：反叛方按领土粮食产能占比切分共享库存（守恒）、并刷火星兵 ---
	var cw := preload("res://tests/support/grid_world.gd").new()
	cw.generate_grid_world(41002)
	for a in range(cw.nations.size()):
		for b in range(a + 1, cw.nations.size()):
			cw.set_diplomatic_relation(a, b, GameState.DiplomaticRelation.NEUTRAL)
	cw.refresh_derived()
	var cw_region := _enfeoffable_region(cw, 0, 3)
	FamilyFixture.ensure_candidates(cw, 0)
	var rebel := cw.enfeoff(0, cw_region)
	cw.refresh_derived()
	var pool_food_before := cw.nations[0].granary_food + cw.nations[rebel].granary_food
	var rebel_armies_before := 0
	for army in cw.armies:
		if army.owner_nation == rebel and army.size > 0:
			rebel_armies_before += 1
	var rebel_land := cw.land_cities_of(rebel).size()
	var started := cw.start_civil_war(rebel)
	cw.refresh_derived()
	# 切分守恒：内战后宗主根池 + 反叛方新池 = 内战前共享池总量。
	var pool_food_after := cw.nations[0].granary_food + cw.nations[rebel].granary_food
	_check(
		started
			and pool_food_after == pool_food_before
			and cw.nations[rebel].granary_food > 0
			and cw.cities[cw.nations[rebel].capital_city_id].has_warehouse
			and cw.food_pool_holder(rebel) == rebel,
		"内战切分共享库存必须守恒（前%d==后%d）且反叛方自成一池" % [pool_food_before, pool_food_after]
	)
	# 火星兵：反叛方首都凭空动员 ceil(0.1 × 陆城数) 个满编主战军团。
	var expected_uprising := int(ceil(0.1 * float(rebel_land)))
	var rebel_main_armies := 0
	for army in cw.armies:
		if (
			army.owner_nation == rebel
			and army.size == GameState.INITIAL_HEAVY_ARMY_SIZE
			and army.location_city == cw.nations[rebel].capital_city_id
		):
			rebel_main_armies += 1
	_check(
		rebel_main_armies >= expected_uprising
			and expected_uprising >= 1
			and cw._battle_group_structure_valid()
			and cw.suzerainty_structure_valid(),
		"内战起兵须刷 ceil(0.1×%d)=%d 个满编主战火星兵（实测≥%d）且结构不变量成立"
			% [rebel_land, expected_uprising, rebel_main_armies]
	)


# ------------------------------------------------------------------ 32i3. 藩王就近治理产出加成

func _test_vassal_governance_output_bonus() -> void:
	print("[32i3] 藩王加成：藩王疆域城市钱粮产出×1.5、owner 派生自动生效、经济结算与AI估值同源")
	var gs := preload("res://tests/support/grid_world.gd").new()
	gs.generate_grid_world(41010)
	for a in range(gs.nations.size()):
		for b in range(a + 1, gs.nations.size()):
			gs.set_diplomatic_relation(a, b, GameState.DiplomaticRelation.NEUTRAL)
	# 构造宗主 0 与藩王，藩王 id 明确；随后在同一城上翻转 owner，隔离 garrison/war 等混淆项，
	# 纯粹检验「owner 是否藩王」这一维度对产出真源的 1.5× 影响。
	var region := _enfeoffable_region(gs, 0, 3)
	FamilyFixture.ensure_candidates(gs, 0)
	var subject := gs.enfeoff(0, region)
	_check(subject > 0 and gs.is_vassal(subject) and not gs.is_vassal(0), "分封应建立藩王且宗主非藩王")
	# 本用例只隔离宗藩治理倍率；新藩王正常会获得独立随机君主，
	# 若不显式中性化便会把治理倍率与君主产出倍率混在一起。
	_set_neutral_ruler(gs.nations[0])
	_set_neutral_ruler(gs.nations[subject])

	# 在同一座藩王城市上临时移除宗藩记录，隔离治理倍率，不破坏州治与属府同方控制。
	var probe: City = null
	for city in gs.land_cities_of(subject):
		if city.gold_per_month > 0 and city.food_per_half_year > 0:
			probe = city
			break
	_check(probe != null, "需要一座有正钱粮产出的藩王城作为探针")
	probe.war_disruption_until_day = 0
	for army in gs.armies:
		if not army.on_edge and army.location_city == probe.id:
			army.size = 0
	var subject_record: Dictionary = gs.suzerainty[subject].duplicate(true)
	gs.suzerainty.erase(subject)
	var independent_gold := Simulation.city_gold_output(gs, probe)
	var independent_food := Simulation.city_food_output(gs, probe)
	_check(
		is_equal_approx(Simulation.city_governance_output_multiplier(gs, probe), 1.0)
			and independent_gold > 0
			and independent_food > 0,
		"独立国城市不应用藩王治理加成"
	)

	gs.suzerainty[subject] = subject_record
	var vassal_gold := Simulation.city_gold_output(gs, probe)
	var vassal_food := Simulation.city_food_output(gs, probe)
	_check(
		is_equal_approx(
			Simulation.city_governance_output_multiplier(gs, probe),
			Simulation.VASSAL_GOVERNANCE_OUTPUT_MULTIPLIER
		)
			and vassal_gold == int(floor(float(independent_gold) * 1.5))
			and vassal_food == int(floor(float(independent_food) * 1.5)),
		"藩王城钱粮产出须为 1.5×（gold %d→%d、food %d→%d）"
			% [independent_gold, vassal_gold, independent_food, vassal_food]
	)


# ------------------------------------------------------------------ 32i4. 宗藩断联不等于占领

func _test_suzerainty_disconnection_requires_capture() -> void:
	print("[32i4] 宗藩飞地：断联不等于占领，实际攻占后议和才确认法理")

	# --- 子场景 A：合法连通的藩王领土不得被误清理（无假阳性）---
	# 链 0-1-2-3-4：宗主 0 首都=城0、直辖 城0/城1；藩王 1 领 城2/城3/城4，经 城1-城2 连回宗主。
	# 此时藩王领土经宗主城1 与体系首都连通（体系视为整体），不是飞地 → 每日清理必须不动它。
	var sa := preload("res://tests/support/grid_world.gd").new()
	sa.generate_grid_world(51001)
	sa.armies.clear()
	sa.battles.clear()
	for city in sa.cities:
		city.owner_nation = 3
		city.is_capital = false
		city.has_warehouse = false
		city.food_storage = 0
		sa.recognized_city_owners[city.id] = 3
	for c in [0, 1]:
		sa.cities[c].owner_nation = 0
		sa.recognized_city_owners[c] = 0
	for c in [2, 3, 4, 11]:
		sa.cities[c].owner_nation = 1
		sa.recognized_city_owners[c] = 1
	for road in [[0, 1], [1, 2], [2, 3], [3, 4]]:
		var e := sa.edge_of(int(road[0]), int(road[1]))
		if e != null:
			e.max_manpower = Edge.STANDARD_MANPOWER
	sa.nations[0].capital_city_id = 0
	sa.cities[0].is_capital = true
	sa.cities[0].has_warehouse = true
	sa.nations[1].capital_city_id = 2
	sa.cities[2].is_capital = true
	for a in range(sa.nations.size()):
		for b in range(a + 1, sa.nations.size()):
			sa.set_diplomatic_relation(a, b, GameState.DiplomaticRelation.NEUTRAL)
	sa.set_diplomatic_relation(0, 1, GameState.DiplomaticRelation.ALLIED)
	sa.suzerainty[1] = {
		"overlord_id": 0, "tribute_rate": 0.25,
		"created_day": 0, "last_centralization_day": -1, "civil_war": false,
	}
	sa.refresh_derived()
	_check(
		sa.cities[2].owner_nation == 1
			and sa.cities[3].owner_nation == 1
			and sa.cities[4].owner_nation == 1
			and sa.suzerainty_structure_valid(),
		"无假阳性：经宗主连通的藩王领土不得被误清理（2=%d 3=%d 4=%d）"
			% [sa.cities[2].owner_nation, sa.cities[3].owner_nation, sa.cities[4].owner_nation]
	)

	# --- 子场景 B：被敌方体系包围也不能自动易手；实际攻占才产生临时占领。---
	# 链 0-1-2-3-4，体系 0→1 的藩王领城4所在完整州；城2/3属敌体系。
	var sb := preload("res://tests/support/grid_world.gd").new()
	sb.generate_grid_world(51002)
	sb.armies.clear()
	sb.battles.clear()
	for city in sb.cities:
		city.owner_nation = 3
		city.is_capital = false
		city.has_warehouse = false
		city.food_storage = 0
		sb.recognized_city_owners[city.id] = 3
	for c in [0, 1]:
		sb.cities[c].owner_nation = 0
		sb.recognized_city_owners[c] = 0
	for c in [4, 5, 6, 13]:
		sb.cities[c].owner_nation = 1
		sb.recognized_city_owners[c] = 1
	sb.cities[63].owner_nation = 2
	sb.recognized_city_owners[63] = 2
	for road in [[0, 1], [1, 2], [2, 3], [3, 4]]:
		var e := sb.edge_of(int(road[0]), int(road[1]))
		if e != null:
			e.max_manpower = Edge.STANDARD_MANPOWER
	sb.nations[0].capital_city_id = 0
	sb.cities[0].is_capital = true
	sb.cities[0].has_warehouse = true
	sb.nations[1].capital_city_id = 5
	sb.cities[5].is_capital = true
	_set_single_warehouse(sb, 0, 0, 0)
	_set_warehouses(sb, 1, [] as Array[int], [] as Array[int], 5)
	sb.cities[5].is_capital = true
	_set_single_warehouse(sb, 2, 63, 0)
	# 国3在本夹具中没有实控城市，必须显式清掉生成期留下的首都/粮仓索引。
	# 国3仍持有大多数背景城市，作为国2的和平藩属保留首都但不设独立粮仓。
	_set_warehouses(sb, 3, [] as Array[int], [] as Array[int], 62)
	sb.cities[62].is_capital = true
	for a in range(sb.nations.size()):
		for b in range(a + 1, sb.nations.size()):
			sb.set_diplomatic_relation(a, b, GameState.DiplomaticRelation.NEUTRAL)
	sb.set_diplomatic_relation(0, 1, GameState.DiplomaticRelation.ALLIED)
	sb.suzerainty[1] = {
		"overlord_id": 0, "tribute_rate": 0.25,
		"created_day": 0, "last_centralization_day": -1, "civil_war": false,
	}
	sb.set_diplomatic_relation(2, 3, GameState.DiplomaticRelation.ALLIED)
	sb.suzerainty[3] = {
		"overlord_id": 2, "tribute_rate": 0.25,
		"created_day": 0, "last_centralization_day": -1, "civil_war": false,
	}
	for attacker in [0, 1]:
		for defender in [2, 3]:
			sb.set_diplomatic_relation(
				attacker, defender, GameState.DiplomaticRelation.WAR
			)
	var sb_garrison := _make_army(12990, 1, 5000, 10, 10)
	sb_garrison.max_size = GameState.INITIAL_HEAVY_ARMY_SIZE
	sb_garrison.location_city = 4
	sb_garrison.move_from = 4
	sb_garrison.state = Army.State.IDLE
	sb.armies.append(sb_garrison)
	sb.refresh_derived()
	_check(
		sb.cities[5].owner_nation == 1
			and sb.cities[4].owner_nation == 1
			and sb_garrison.size == 5000,
		(
			"战争飞地内仍有本体系守军时不得因道路断联直接吞并或删除驻军"
			+ "（5=%d 4=%d 守军=%d）"
		) % [
			sb.cities[5].owner_nation,
			sb.cities[4].owner_nation,
			sb_garrison.size,
		]
	)
	# 和平时地理断联本身不能代替割地协议。
	for attacker in [0, 1]:
		for defender in [2, 3]:
			sb.set_diplomatic_relation(
				attacker, defender, GameState.DiplomaticRelation.NEUTRAL
			)
	sb_garrison.size = 0
	_check(
		sb.cities[5].owner_nation == 1
			and sb.cities[4].owner_nation == 1
			and sb.recognized_owner_of(5) == 1
			and sb.recognized_owner_of(4) == 1,
		"和平时断联藩王飞地不得无协议自动割给相邻国家"
	)
	# 恢复战争后，即使没有守军，断联本身也不能产生敌方实控。
	for attacker in [0, 1]:
		for defender in [2, 3]:
			sb.set_diplomatic_relation(
				attacker, defender, GameState.DiplomaticRelation.WAR
			)
	_check(
		sb.cities[5].owner_nation == 1
			and sb.cities[4].owner_nation == 1
			and sb.recognized_owner_of(5) == 1
			and sb.recognized_owner_of(4) == 1
			and sb.cities[5].occupation_sponsor_nation == -1
			and sb.cities[4].occupation_sponsor_nation == -1
			and sb.suzerainty_structure_valid(),
		(
			"战争与道路断联不能替代真实攻城，飞地州必须继续由原国实控"
			+ "（5=%d 4=%d）"
		)
			% [sb.cities[5].owner_nation, sb.cities[4].owner_nation]
	)
	# 显式模拟城4被敌方宗主实际攻下；只有这一步才能形成临时占领。
	var sb_capture_result: Dictionary = sb.transfer_city_control(4, 2, 2)
	_check(
		bool(sb_capture_result.get("changed", false))
			and sb.cities[5].owner_nation == 1
			and sb.recognized_owner_of(5) == 1
			and sb.cities[5].occupation_sponsor_nation == -1
			and sb.cities[4].owner_nation == 2
			and sb.recognized_owner_of(4) == 1
			and sb.cities[4].occupation_sponsor_nation == 2
			and sb.territory_structure_valid(),
		"只有显式 transfer_city_control 才能把断联城4变成敌方临时占领"
	)
	var sb_recognized := sb.recognize_coalition_occupied_territory(
		[0, 1] as Array[int],
		[2, 3] as Array[int]
	)
	_check(
		sb_recognized == ([4] as Array[int])
			and sb.cities[5].owner_nation == 1
			and sb.recognized_owner_of(5) == 1
			and sb.cities[5].occupation_sponsor_nation == -1
			and sb.cities[4].owner_nation == 2
			and sb.recognized_owner_of(4) == 2
			and sb.cities[4].occupation_sponsor_nation == -1
			and sb.territory_structure_valid(),
		"只有实际攻占形成的临时占领，才可在集团议和后确认为法理领土"
	)


# ------------------------------------------------------------------ 32i4b. 对外领土主权接收者

func _test_external_territory_sovereignty() -> void:
	print("[32i4b] 对外领土：藩王与盟友出发地决定战果，法理收复仍归原藩王")
	var gs := preload("res://tests/support/grid_world.gd").new()
	gs.generate_grid_world(51003)
	gs.armies.clear()
	gs.battles.clear()
	for a in range(gs.nations.size()):
		for b in range(a + 1, gs.nations.size()):
			gs.set_diplomatic_relation(
				a, b, GameState.DiplomaticRelation.NEUTRAL
			)
	# 两个独立宗藩体系：0→1 与 2→3。
	for pair in [[0, 1], [2, 3]]:
		var root := int(pair[0])
		var subject := int(pair[1])
		gs.suzerainty[subject] = {
			"overlord_id": root,
			"tribute_rate": GameState.DEFAULT_TRIBUTE_RATE,
			"created_day": 0,
			"last_centralization_day": -1,
			"civil_war": false,
		}
		gs.set_diplomatic_relation(
			root, subject, GameState.DiplomaticRelation.ALLIED
		)
		# 手工挂接宗藩时同步模拟 enfeoff() 的共享粮仓语义：藩王首都
		# 保留首都身份，但不再拥有独立粮仓或库存。
		for warehouse_id in gs.nations[subject].warehouse_city_ids:
			gs.cities[warehouse_id].has_warehouse = false
			gs.cities[warehouse_id].food_storage = 0
		gs.nations[subject].warehouse_city_ids.clear()
	for attacker in [0, 1]:
		for defender in [2, 3]:
			gs.set_diplomatic_relation(
				attacker, defender, GameState.DiplomaticRelation.WAR
			)
	gs.refresh_derived()
	var subject_origin: City = null
	var subject_target: City = null
	for border_edge in gs.edges:
		var border_a := gs.cities[border_edge.city_a]
		var border_b := gs.cities[border_edge.city_b]
		if border_a.owner_nation == 1 and border_b.owner_nation == 3:
			subject_origin = border_a
			subject_target = border_b
			border_edge.max_manpower = Edge.STANDARD_MANPOWER
			break
		if border_b.owner_nation == 1 and border_a.owner_nation == 3:
			subject_origin = border_b
			subject_target = border_a
			border_edge.max_manpower = Edge.STANDARD_MANPOWER
			break
	var second_target: City = null
	for city in gs.land_cities_of(3):
		if city != subject_target and not city.is_capital and not city.has_warehouse:
			second_target = city
			break
	_check(
		subject_origin != null and subject_target != null and second_target != null,
		"跨宗藩领土测试必须找到藩王到敌方藩王的真实边界及第二座普通城"
	)
	var sim := Simulation.new()
	sim.setup(gs)
	# A 宗主军从自己的藩王领土出发攻下 B 藩王城市：实控归提供
	# 进攻出发地的 A 藩王，B 藩王法理暂时保留，sponsor 仍是实际交战军。
	var subject_army := _make_army(12991, 0, 5000, 10, 10)
	subject_army.location_city = subject_origin.id
	subject_army.move_from = subject_origin.id
	subject_army.state = Army.State.MOVING
	subject_army.path = [subject_target.id] as Array[int]
	gs.armies.append(subject_army)
	sim._begin_next_leg(subject_army)
	var frozen_subject_claimant := subject_army.occupation_claimant_nation
	sim._release_edge(subject_army)
	subject_army.location_city = subject_target.id
	subject_army.move_from = subject_target.id
	sim._capture_city(subject_army, subject_target)
	_check(
		frozen_subject_claimant == 1
			and subject_army.occupation_claimant_nation == -1
			and subject_target.owner_nation == 1
			and gs.recognized_owner_of(subject_target.id) == 3
			and subject_target.occupation_sponsor_nation == 0,
		(
			"宗主军从藩王领土进攻时实控必须归该藩王，"
			+ "sponsor 保留宗主且不能把控制权上收"
		)
	)
	var recognized := gs.recognize_coalition_occupied_territory(
		[0, 1] as Array[int],
		[2, 3] as Array[int]
	)
	_check(
		recognized.has(subject_target.id)
			and subject_target.owner_nation == 1
			and gs.recognized_owner_of(subject_target.id) == 1
			and subject_target.occupation_sponsor_nation == -1,
		"集团议和确认战果时，外国藩王旧地必须成为实际占领藩王的法理领土"
	)

	# 集团和平：claimant 1 控制并持有库存的粮仓确认给自身时，作为
	# 和平藩王仍共享宗主 0 的粮池，库存必须完整进入根粮仓。
	var coalition_warehouse: City = null
	for candidate in gs.land_cities_of(2):
		if not candidate.is_capital and not candidate.has_warehouse:
			coalition_warehouse = candidate
			break
	_check(
		coalition_warehouse != null,
		"集团和平粮仓上收回归必须找到一座普通敌方城市"
	)
	if coalition_warehouse != null:
		var coalition_recipient_warehouse := gs.warehouse_cities_of(0)[0]
		var coalition_food_before := coalition_recipient_warehouse.food_storage
		var coalition_captured_food := 137
		coalition_warehouse.owner_nation = 1
		coalition_warehouse.occupation_sponsor_nation = 1
		coalition_warehouse.has_warehouse = true
		coalition_warehouse.food_storage = coalition_captured_food
		gs.nations[1].warehouse_city_ids.append(coalition_warehouse.id)
		var coalition_warehouse_recognized := (
			gs.recognize_coalition_occupied_territory(
				[0, 1] as Array[int],
				[2, 3] as Array[int]
			)
		)
		_check(
			coalition_warehouse_recognized.has(
				coalition_warehouse.id
			)
				and coalition_warehouse.owner_nation == 1
				and gs.recognized_owner_of(coalition_warehouse.id) == 1
				and coalition_warehouse.occupation_sponsor_nation == -1
				and not coalition_warehouse.has_warehouse
				and coalition_warehouse.food_storage == 0
				and not gs.nations[1].warehouse_city_ids.has(
					coalition_warehouse.id
				)
				and coalition_recipient_warehouse.food_storage
					== coalition_food_before + coalition_captured_food
				and gs.territory_structure_valid(),
			"集团和平确认藩王 claimant 粮仓时必须完整回流共享粮池并清理原城粮仓状态"
		)

	# 宗主替本体系藩王收复其法理旧地时，法理优先，仍归原藩王。
	gs.recognized_city_owners[second_target.id] = 1
	var root_army := _make_army(12992, 0, 5000, 10, 10)
	root_army.location_city = second_target.id
	root_army.move_from = second_target.id
	gs.armies.append(root_army)
	sim._capture_city(root_army, second_target)
	_check(
		second_target.owner_nation == 1
			and gs.recognized_owner_of(second_target.id) == 1
			and second_target.occupation_sponsor_nation == -1,
		"宗主或同体系盟军收复藩王法理领土时必须归还藩王，不能上收宗主"
	)
	_check(gs.suzerainty_structure_valid(), "跨体系领土结算后宗藩结构必须保持合法")
	gs.refresh_derived()
	_check(
		gs.territory_structure_valid(),
		"跨体系领土结算后实控/法理/首都/粮仓结构必须保持合法"
	)
	sim.free()

	# 宗主0/藩王1/敌2：藩王攻城时战果实控与 sponsor 都归藩王。
	# 藩王随后灭亡时，正常的死亡宗藩继承再把其法理交给宗主。
	var departed_state := preload("res://tests/support/grid_world.gd").new()
	departed_state.generate_grid_world(51005)
	departed_state.armies.clear()
	departed_state.battles.clear()
	for departed_a in range(departed_state.nations.size()):
		for departed_b in range(
			departed_a + 1, departed_state.nations.size()
		):
			departed_state.set_diplomatic_relation(
				departed_a, departed_b,
				GameState.DiplomaticRelation.NEUTRAL
			)
	departed_state.suzerainty[1] = {
		"overlord_id": 0,
		"tribute_rate": GameState.DEFAULT_TRIBUTE_RATE,
		"created_day": 0,
		"last_centralization_day": -1,
		"civil_war": false,
	}
	departed_state.set_diplomatic_relation(
		0, 1, GameState.DiplomaticRelation.ALLIED
	)
	departed_state.set_diplomatic_relation(
		0, 2, GameState.DiplomaticRelation.WAR
	)
	departed_state.set_diplomatic_relation(
		1, 2, GameState.DiplomaticRelation.WAR
	)
	# 手工宗藩与 enfeoff 保持相同共享粮池语义。
	for departed_warehouse_id in (
		departed_state.nations[1].warehouse_city_ids.duplicate()
	):
		departed_state.cities[departed_warehouse_id].has_warehouse = false
		departed_state.cities[departed_warehouse_id].food_storage = 0
	departed_state.nations[1].warehouse_city_ids.clear()
	departed_state.refresh_derived()
	var departed_target: City = null
	for candidate in departed_state.land_cities_of(2):
		if not candidate.is_capital and not candidate.has_warehouse:
			departed_target = candidate
			break
	_check(departed_target != null, "死亡藩王 sponsor 回归必须找到敌方普通城市")
	if departed_target != null:
		var departed_sim := Simulation.new()
		departed_sim.setup(departed_state)
		var departed_army := _make_army(12993, 1, 5000, 10, 10)
		departed_army.location_city = departed_target.id
		departed_army.move_from = departed_target.id
		departed_state.armies.append(departed_army)
		departed_sim._capture_city(departed_army, departed_target)
		_check(
			departed_target.owner_nation == 1
				and departed_state.recognized_owner_of(departed_target.id) == 2
				and departed_target.occupation_sponsor_nation == 1,
			"藩王军攻下敌城后必须形成 owner=1 sponsor=1 legal=2"
		)
		var subject_operations: Array[Dictionary] = []
		for subject_city in departed_state.cities_of(1):
			subject_operations.append({
				"city_id": subject_city.id,
				"controller_id": 0,
				"legal_owner_id": 0,
				"sponsor_id": -1,
				"reset_political_target": true,
				"reason": "departed_vassal_fixture",
				"stock_policy": (
					GameState.TerritoryStockDisposition.MOVE_TO_NEW_POOL
				),
			})
		var subject_removed: Dictionary = (
			departed_state.apply_territory_transaction(subject_operations)
		)
		departed_state.suzerainty.erase(1)
		departed_state.set_diplomatic_relation(
			1, 2, GameState.DiplomaticRelation.NEUTRAL
		)
		departed_state.refresh_derived()
		var departed_peace := departed_sim._make_coalition_peace(0, 2)
		_check(
			bool(subject_removed.get("ok", false))
				and bool(subject_removed.get("changed", false))
				and departed_state.cities_of(1).is_empty()
				and not departed_state.nations[1].alive
				and not departed_state.is_enemy(1, 2)
				and bool(departed_peace.get("changed", false))
				and departed_target.owner_nation
					== departed_state.recognized_owner_of(departed_target.id)
				and departed_target.occupation_sponsor_nation == -1
				and departed_state.territory_structure_valid(),
			(
				"藩王无城并退出 1-2 战争后，0-2 集团议和仍必须按宗主 "
				+ "sponsor 将其攻占城永久确认给0"
			)
		)
		departed_sim.free()


# ------------------------------------------------------------------ 32i5. 藩王 MAIN 封国内线指挥

func _test_vassal_local_main_command() -> void:
	print("[32i5] 藩王军制：分封不赐军、复用普通扩军与战役AI、高凝聚力时外交归宗主")
	var gs := preload("res://tests/support/grid_world.gd").new()
	gs.generate_grid_world(52001)
	for a in range(gs.nations.size()):
		for b in range(a + 1, gs.nations.size()):
			gs.set_diplomatic_relation(a, b, GameState.DiplomaticRelation.NEUTRAL)
	var region := _enfeoffable_region(gs, 0, 3)
	FamilyFixture.ensure_candidates(gs, 0)
	var subject := gs.enfeoff(0, region)
	_check(subject > 0, "分封应成功建立藩王")

	# 分封当下不赠送正规军；MAIN 留待藩王后续自费组建。
	var army_n := 0
	for army in gs.armies:
		if army.owner_nation == subject and army.size > 0:
			army_n += 1
	_check(
		army_n == 0 and gs.nations[subject].battle_groups.is_empty(),
		"分封不赠送野战军（军队=%d、战团=%d）"
			% [army_n, gs.nations[subject].battle_groups.size()]
	)

	# 藩王可用自身资源组建 MAIN 战团。
	var sim := Simulation.new()
	sim.setup(gs)
	gs.uses_heightmap = true
	gs.nations[subject].treasury_gold = 100000
	gs.nations[subject].manpower_pool = 100000
	var cap := gs.nations[subject].capital_city_id
	gs.deposit_food(0, 100000)
	var initial_view := AiWorldView.build(gs, subject)
	var initial_snapshot := StrategicMapSnapshot.build(
		initial_view
	)
	var initial_threat := ThreatField.build(initial_view)
	var initial_plan := CityDefensePlan.build(
		initial_view,
		initial_snapshot,
		initial_threat
	)
	var autonomous_recruited := (
		sim._ai_manage_force_structure(
			initial_view,
			initial_snapshot,
			initial_threat,
			initial_plan
		)
	)
	var vassal_group: BattleGroup = (
		gs.nations[subject].battle_groups[0]
		if not gs.nations[
			subject
		].battle_groups.is_empty()
		else null
	)
	var autonomous_main: Army = null
	if vassal_group != null:
		var autonomous_members := (
			gs.battle_group_members(
				subject,
				vassal_group.id
			)
		)
		if not autonomous_members.is_empty():
			autonomous_main = autonomous_members[0]
	_check(
		autonomous_recruited
			and autonomous_main != null
			and autonomous_main.is_main_battle_role()
			and autonomous_main.max_size
				== GameState.INITIAL_HEAVY_ARMY_SIZE,
		"资源充足时藩王 AI 应自主创建第一支 MAIN 战团"
	)
	if vassal_group == null or autonomous_main == null:
		sim.free()
		return
	var vassal_main := autonomous_main
	_check(
		vassal_main != null
			and vassal_main.owner_nation == subject
			and vassal_main.is_main_battle_role()
			and gs.battle_group_members(subject, vassal_group.id).size() == 1,
		"藩王应能以本国资源组建自有单主战军 MAIN 战团"
	)
	if vassal_main == null:
		sim.free()
		return

	# 对照：宗主 0 征 MAIN 应成功（宗主可建主战力）。
	gs.nations[0].treasury_gold = 100000
	gs.nations[0].manpower_pool = 100000
	var overlord_cap := gs.nations[0].capital_city_id
	var overlord_group := gs.create_battle_group(0)
	var overlord_main := sim._create_army_for_nation(
		0, overlord_cap, GameState.INITIAL_HEAVY_ARMY_SIZE, "宗主征MAIN", true, overlord_group.id
	)
	_check(
		overlord_main != null and overlord_main.is_main_battle_role(),
		"宗主必须能征召 MAIN 主战军团（对照）"
	)


	# 制造一座法理失地，验证小藩王仍使用普通军制与普通攻势资格。
	var relief_city := -1
	for neighbor in gs.neighbors(cap):
		if gs.cities[neighbor].owner_nation == subject:
			relief_city = neighbor
			break
	_check(relief_city >= 0, "藩王战役测试需要第二座封地城市")
	var enemy_id := 1
	gs.set_diplomatic_relation(
		subject,
		enemy_id,
		GameState.DiplomaticRelation.WAR
	)
	gs.cities[relief_city].owner_nation = enemy_id
	gs.recognized_city_owners[relief_city] = subject
	gs.ownership_revision += 1
	gs.deposit_food(0, 100000)
	var reclaim_view := AiWorldView.build(gs, subject)
	var reclaim_snapshot := StrategicMapSnapshot.build(
		reclaim_view
	)
	var reclaim_threat := ThreatField.build(reclaim_view)
	var reclaim_plan := CityDefensePlan.build(
		reclaim_view,
		reclaim_snapshot,
		reclaim_threat
	)
	var wartime_assessment := sim._build_force_structure_assessment(
		reclaim_view,
		{},
		{}
	)
	_check(
		not wartime_assessment.small_nation_survival,
		"和平宗藩参加盟主共同战争后应走普通军制，不得被四城小国模式压成一支轻型 MAIN"
	)
	var foreign_enemy_city := -1
	for enemy_city in gs.land_cities_of(enemy_id):
		if gs.recognized_owner_of(enemy_city.id) != subject:
			foreign_enemy_city = enemy_city.id
			break
	_check(foreign_enemy_city >= 0, "藩王普通军事 AI 测试需要非本藩法理的敌城")
	_check(
		foreign_enemy_city >= 0
			and reclaim_plan.can_join_offensive(
				vassal_main,
				foreign_enemy_city
			),
		"共同战争中的藩王 MAIN 应与普通国家一样可攻击非本藩法理敌城"
	)

	# 攻势外交门控：藩王与敌国交战也不主动宣战（进攻性外交由宗主代理）。
	var war_state := preload("res://tests/support/grid_world.gd").new()
	war_state.generate_grid_world(52002)
	for a in range(war_state.nations.size()):
		for b in range(a + 1, war_state.nations.size()):
			war_state.set_diplomatic_relation(a, b, GameState.DiplomaticRelation.NEUTRAL)
	var war_region := _enfeoffable_region(war_state, 0, 3)
	FamilyFixture.ensure_candidates(war_state, 0)
	var war_vassal := war_state.enfeoff(0, war_region)
	var war_actions: Array[Dictionary] = []
	DiplomacyAI._collect_war_actions(war_state, war_actions, {}, {})
	var vassal_declares := false
	for action in war_actions:
		if int(action.get("a", -1)) == war_vassal or int(action.get("nation_id", -1)) == war_vassal:
			vassal_declares = true
	_check(not vassal_declares, "藩王不得出现在主动宣战/战备动作的发起方")
	sim.free()


# ------------------------------------------------------------------ 32i6. 敌城滞留军队每日驱离

func _test_stranded_hostile_army_eviction() -> void:
	print("[32i6] 敌城滞留驱离：定居在无通行权敌城的己方军队须每日兜底撤离，杜绝 IDLE 死锁")
	var gs := preload("res://tests/support/grid_world.gd").new()
	gs.generate_grid_world(53001)
	gs.armies.clear()
	gs.battles.clear()
	# 全图归敌国 1；国 0 只留首都城0，与敌城1 有正容量道路（撤退有路可走）。
	for city in gs.cities:
		city.owner_nation = 1
		city.is_capital = false
		city.has_warehouse = false
		gs.recognized_city_owners[city.id] = 1
	gs.cities[0].owner_nation = 0
	gs.recognized_city_owners[0] = 0
	gs.nations[0].capital_city_id = 0
	gs.cities[0].is_capital = true
	gs.cities[0].has_warehouse = true
	gs.nations[1].capital_city_id = 63
	gs.cities[63].is_capital = true
	for road in [[0, 1], [1, 2]]:
		var e := gs.edge_of(int(road[0]), int(road[1]))
		if e != null:
			e.max_manpower = Edge.STANDARD_MANPOWER
	for a in range(gs.nations.size()):
		for b in range(a + 1, gs.nations.size()):
			gs.set_diplomatic_relation(a, b, GameState.DiplomaticRelation.NEUTRAL)
	gs.set_diplomatic_relation(0, 1, GameState.DiplomaticRelation.WAR)
	gs.refresh_derived()
	# 人为制造滞留：国 0 的一支主战军 IDLE 定居在敌城1（无通行权）。
	var stranded := _make_army(9301, 0, GameState.INITIAL_HEAVY_ARMY_SIZE, 10)
	stranded.location_city = 1
	stranded.move_from = 1
	stranded.move_to = -1
	stranded.on_edge = false
	stranded.state = Army.State.IDLE
	gs.armies.append(stranded)
	var sim := Simulation.new()
	sim.setup(gs)
	_check(
		stranded.current_city_node() == 1
			and not gs.has_military_access(0, 1),
		"前置：滞留军应定居敌城1 且国0 对国1 无通行权"
	)
	# 直接触发兜底清理：滞留军须被撤离（不再定居敌城1）。
	sim._evict_stranded_hostile_armies()
	_check(
		stranded.state == Army.State.RETREATING
			or stranded.current_city_node() != 1
			or stranded.size <= 0,
		"敌城滞留军队须被驱离（state=%d node=%d size=%d）"
			% [stranded.state, stranded.current_city_node(), stranded.size]
	)
	sim.free()


# ------------------------------------------------------------------ 32j. 分封战争加成 + 藩王首都失陷不投降

func _test_vassal_wartime_support_and_capital() -> void:
	print("[32j] 分封战争加成：前线藩王自主参战、后方藩王提贡赋、藩王首都失陷不投降割地")
	var gs := preload("res://tests/support/grid_world.gd").new()
	gs.generate_grid_world(32095)
	for a in range(gs.nations.size()):
		for b in range(a + 1, gs.nations.size()):
			gs.set_diplomatic_relation(a, b, GameState.DiplomaticRelation.NEUTRAL)
	# 国家角色：0=宗主，1=前线藩王，2=后方藩王，3=敌国。
	# 城市（基于 grid 真实边）：城0=宗主首都；城1=前线藩王首都(城1↔城2 有边,接壤敌国)；
	# 城2=敌国；城9=后方藩王首都(城9 邻 城1/城10/城17,均非敌国,不接壤)。
	var overlord := 0
	var front_vassal := 1
	var rear_vassal := 2
	var enemy := 3
	# 全图先归宗主，再逐一指派测试相关城市，确保接壤关系完全可控。
	for city in gs.cities:
		city.owner_nation = overlord
		city.is_capital = false
		city.has_warehouse = false
		gs.recognized_city_owners[city.id] = overlord
	var overlord_capital := 0
	var front_city := 1
	var enemy_city := 2
	var rear_city := 9
	gs.cities[front_city].owner_nation = front_vassal
	gs.recognized_city_owners[front_city] = front_vassal
	gs.cities[enemy_city].owner_nation = enemy
	gs.recognized_city_owners[enemy_city] = enemy
	gs.cities[rear_city].owner_nation = rear_vassal
	gs.recognized_city_owners[rear_city] = rear_vassal
	gs.nations[overlord].capital_city_id = overlord_capital
	gs.cities[overlord_capital].is_capital = true
	gs.cities[front_city].is_capital = true
	gs.cities[rear_city].is_capital = true
	gs.nations[front_vassal].capital_city_id = front_city
	gs.nations[rear_vassal].capital_city_id = rear_city
	# 宗藩记录：两藩王挂到宗主 0，默认贡赋率；宗主↔藩王 ALLIED。
	for sub in [front_vassal, rear_vassal]:
		gs.set_diplomatic_relation(overlord, sub, GameState.DiplomaticRelation.ALLIED)
		gs.suzerainty[sub] = {
			"overlord_id": overlord,
			"tribute_rate": 0.25,
			"created_day": 0,
			"last_centralization_day": -1,
			"civil_war": false,
		}
	# 对外共同体化：宗主与两藩王都与敌国处于战争（体系对外统一敌对）。
	gs.set_diplomatic_relation(overlord, enemy, GameState.DiplomaticRelation.WAR)
	gs.set_diplomatic_relation(front_vassal, enemy, GameState.DiplomaticRelation.WAR)
	gs.set_diplomatic_relation(rear_vassal, enemy, GameState.DiplomaticRelation.WAR)
	gs.refresh_derived()

	# 接壤判定：前线藩王接壤敌国，后方藩王不接壤。
	_check(
		gs.vassal_borders_system_enemy(front_vassal)
			and not gs.vassal_borders_system_enemy(rear_vassal),
		"接壤判定：前线藩王须接壤敌国、后方藩王须不接壤（front=%s rear=%s）"
			% [
				str(gs.vassal_borders_system_enemy(front_vassal)),
				str(gs.vassal_borders_system_enemy(rear_vassal)),
			]
	)

	# 给前线藩王一支静止在本土的主战军团，验证战时仍归藩王自主指挥。
	# 复用网格生成时已有的军队并迁到封地首都，避免额外改变本测试的军队数量。
	var main_army: Army = null
	for army in gs.armies:
		if army.owner_nation == front_vassal and army.size > 0:
			main_army = army
			break
	_check(main_army != null, "前线藩王须有可改造为 MAIN 的既有军队")
	main_army.battle_group_id = -1
	main_army.location_city = front_city
	main_army.move_from = front_city
	main_army.move_to = -1
	main_army.on_edge = false
	main_army.state = Army.State.IDLE
	main_army.max_size = GameState.INITIAL_HEAVY_ARMY_SIZE
	main_army.size = GameState.INITIAL_HEAVY_ARMY_SIZE
	var fg := gs.create_battle_group(front_vassal)
	gs.assign_army_to_battle_group(main_army, fg.id)
	var main_army_id := main_army.id
	_check(
		main_army.owner_nation == front_vassal
			and gs._battle_group_structure_valid(),
		"前线藩王的 MAIN 战团必须保留本国所有权并自主参战（army=%d owner=%d）"
			% [main_army_id, main_army.owner_nation]
	)

	# 战时贡赋：结算后后方藩王按提升率上缴、前线藩王不被强制加税。
	var sim := Simulation.new()
	sim.setup(gs)
	for n in gs.nations:
		n.treasury_gold = 1000
	var gold_income: Array[int] = []
	gold_income.resize(gs.nations.size())
	gold_income.fill(0)
	gold_income[rear_vassal] = 100
	gold_income[front_vassal] = 100
	sim._resolve_tribute(gold_income)
	# 后方藩王按 max(0.25, 0.60)=0.60 上缴 100×0.6=60；前线藩王按记录率 0.25 上缴 25。
	_check(
		gs.nations[rear_vassal].treasury_gold == 1000 - 60
			and gs.nations[front_vassal].treasury_gold == 1000 - 25,
		"战时后方藩王按提升率上缴、前线藩王按原率（后方余%d 前线余%d）"
			% [gs.nations[rear_vassal].treasury_gold, gs.nations[front_vassal].treasury_gold]
	)
	sim._resolve_economy()
	_check(
		main_army.owner_nation == front_vassal
			and main_army.battle_group_id == fg.id,
		"战时经济结算不得抽调前线藩王 MAIN（owner=%d group=%d）"
			% [main_army.owner_nation, main_army.battle_group_id]
	)
	sim.free()

	# 藩王首都失陷不触发投降割地：敌国占领前线藩王首都，只丢该城，不整国投降。
	var cap_state := preload("res://tests/support/grid_world.gd").new()
	cap_state.generate_grid_world(32096)
	for a in range(cap_state.nations.size()):
		for b in range(a + 1, cap_state.nations.size()):
			cap_state.set_diplomatic_relation(a, b, GameState.DiplomaticRelation.NEUTRAL)
	var cap_region := _enfeoffable_region(cap_state, 0, 3)
	FamilyFixture.ensure_candidates(cap_state, 0)
	var cap_subject := cap_state.enfeoff(0, cap_region)
	_check(cap_subject > 0, "分封应成功建立藩王（首都失陷用例）")
	var cap_sim := Simulation.new()
	cap_sim.setup(cap_state)
	var vassal_capital := cap_state.nations[cap_subject].capital_city_id
	var vassal_city_count_before := cap_state.land_cities_of(cap_subject).size()
	var history_before := cap_state.diplomatic_history.size()
	# 敌国 1 与藩王开战并直接占领藩王首都。
	cap_state.set_diplomatic_relation(1, cap_subject, GameState.DiplomaticRelation.WAR)
	var invader := _make_army(9500, 1, 5000, 10)
	invader.location_city = vassal_capital
	invader.move_from = vassal_capital
	cap_state.armies.append(invader)
	cap_sim._capture_city(invader, cap_state.cities[vassal_capital], 1)
	var relocated_vassal_capital := (
		cap_state.nations[cap_subject].capital_city_id
	)
	_check(
		cap_state.cities[vassal_capital].owner_nation == 1
			and cap_state.diplomatic_history.size() == history_before
			and cap_state.land_cities_of(cap_subject).size()
				== vassal_city_count_before - 1
			and cap_state.suzerainty_structure_valid(),
		"藩王首都失陷只丢该城、不触发投降割地、不写投降历史、宗藩不变量成立"
	)
	_check(
		relocated_vassal_capital >= 0
			and relocated_vassal_capital != vassal_capital
			and cap_state.cities[relocated_vassal_capital].owner_nation
				== cap_subject
			and cap_state.cities[relocated_vassal_capital].is_capital
			and not cap_state.cities[relocated_vassal_capital].has_warehouse
			and cap_state.nations[cap_subject].warehouse_city_ids.is_empty()
			and not cap_state.cities[vassal_capital].is_capital,
		"藩王首都失陷后必须立即迁都，且新首都仍是共享粮仓零库存中继"
	)
	_check(
		cap_state.territory_structure_valid(),
		"藩王首都失陷事务结束后领土结构不变量必须成立"
	)
	cap_sim.free()

	# 藩王全境失守不能触发整个宗藩体系集团议和。藩王只退出自己的
	# 战争关系，宗主继续对外作战，最终议和权仍在宗主。
	var eliminated_state := preload("res://tests/support/grid_world.gd").new()
	eliminated_state.generate_grid_world(32097)
	for a in range(eliminated_state.nations.size()):
		for b in range(a + 1, eliminated_state.nations.size()):
			eliminated_state.set_diplomatic_relation(
				a, b, GameState.DiplomaticRelation.NEUTRAL
			)
	var eliminated_region := _enfeoffable_region(
		eliminated_state, 0, 3
	)
	FamilyFixture.ensure_candidates(eliminated_state, 0)
	var eliminated_subject := eliminated_state.enfeoff(
		0, eliminated_region
	)
	eliminated_state.set_diplomatic_relation(
		0, 1, GameState.DiplomaticRelation.WAR
	)
	eliminated_state.set_diplomatic_relation(
		eliminated_subject, 1, GameState.DiplomaticRelation.WAR
	)
	for lost_city in eliminated_state.cities_of(eliminated_subject):
		lost_city.owner_nation = 1
		lost_city.occupation_sponsor_nation = 1
	eliminated_state.refresh_derived()
	var subject_field_army := _make_army(9501, eliminated_subject, 5000, 10)
	var subject_enemy_army := _make_army(9502, 1, 5000, 10)
	var root_field_army := _make_army(9503, 0, 5000, 10)
	var root_enemy_army := _make_army(9504, 1, 5000, 10)
	var subject_battle := eliminated_state.new_battle(Battle.Kind.FIELD)
	subject_battle.side_a.append(subject_field_army)
	subject_battle.side_b.append(subject_enemy_army)
	var root_battle := eliminated_state.new_battle(Battle.Kind.FIELD)
	root_battle.side_a.append(root_field_army)
	root_battle.side_b.append(root_enemy_army)
	for battle_setup in [
		[subject_field_army, subject_battle.id],
		[subject_enemy_army, subject_battle.id],
		[root_field_army, root_battle.id],
		[root_enemy_army, root_battle.id],
	]:
		var field_army: Army = battle_setup[0]
		field_army.state = Army.State.FIGHTING
		field_army.battle_id = int(battle_setup[1])
		eliminated_state.armies.append(field_army)
	# 保留宗藩记录直到无城结算识别其身份。
	var eliminated_sim := Simulation.new()
	eliminated_sim.setup(eliminated_state)
	var eliminated_history_before := eliminated_state.diplomatic_history.size()
	eliminated_sim._resolve_eliminated_nation_capitulations()
	_check(
		eliminated_state.is_enemy(0, 1)
			and not eliminated_state.is_enemy(eliminated_subject, 1)
			and subject_battle.finished
			and not root_battle.finished
			and subject_field_army.battle_id == -1
			and root_field_army.battle_id == root_battle.id
			and eliminated_state.diplomatic_history.size()
				== eliminated_history_before,
		(
			"藩王全境失守只结束自身战争与战斗，不得终止宗主对外战争："
			+ "root_war=%s subject_war=%s subject_finished=%s root_finished=%s "
			+ "subject_bid=%d root_bid=%d history=%d/%d"
		) % [
			str(eliminated_state.is_enemy(0, 1)),
			str(eliminated_state.is_enemy(eliminated_subject, 1)),
			str(subject_battle.finished),
			str(root_battle.finished),
			subject_field_army.battle_id,
			root_field_army.battle_id,
			eliminated_state.diplomatic_history.size(),
			eliminated_history_before,
		]
	)
	eliminated_state.prune_dead_suzerainty()
	var inherited_legal_claims := true
	for lost_city in eliminated_state.cities:
		if lost_city.owner_nation == 1 and lost_city.occupation_sponsor_nation == 1:
			inherited_legal_claims = (
				inherited_legal_claims
				and eliminated_state.recognized_owner_of(lost_city.id) == 0
			)
	_check(
		not eliminated_state.is_vassal(eliminated_subject)
			and inherited_legal_claims
			and eliminated_state.suzerainty_structure_valid(),
		"灭亡藩王退出战争后，封地法理须回归宗主并清理宗藩记录"
	)
	eliminated_sim.free()


# ------------------------------------------------------------------ 34. 资源核心与粮食战争动员

func _test_sustainable_force_capacity() -> void:
	print("[34a] 可持续军力：和平按国家资源容量扩军，且不读取州战役需求")
	var gs := preload("res://tests/support/grid_world.gd").new()
	gs.generate_grid_world(34000)
	gs.uses_heightmap = true
	for nation in gs.nations:
		nation.trade_policy = RulerProfile.POLICY_ISOLATION
	for army in gs.armies.duplicate():
		if army.owner_nation == 0:
			gs.armies.erase(army)
	for city in gs.cities_of(0):
		city.gold_per_month = 1000
		city.food_per_half_year = 10000
	gs.nations[0].treasury_gold = 1000000
	gs.nations[0].manpower_pool = 1000000
	gs.deposit_food(0, 1000000)
	var base_report := DiplomacyAI.force_capacity_report(
		gs, 0, DiplomacyAI.FoodPosture.PEACE, {}
	)
	var base_target_troops := (
		int(base_report["supportable_armies"])
		* GameState.INITIAL_HEAVY_ARMY_SIZE
	)
	var base_target_food := DiplomacyAI.war_food_report(
		gs,
		0,
		base_target_troops,
		DiplomacyAI.FoodPosture.OFFENSIVE_WAR,
		{}
	)
	_check(
		int(base_target_food["emergency_food_reserve"])
			== int(ceil(
				float(base_target_food["target_monthly_demand"])
					* float(DiplomacyAI.EMERGENCY_FOOD_MONTHS)
			)),
		"目标军力粮食报告必须按目标需求预留六个月口粮：food=%s"
			% [str(base_target_food)]
	)
	var shared := preload("res://tests/support/grid_world.gd").new()
	shared.generate_grid_world(34002)
	var shared_region := _enfeoffable_region(shared, 0, 3)
	FamilyFixture.ensure_candidates(shared, 0)
	var shared_subject := shared.enfeoff(0, shared_region)
	if shared_subject >= 0:
		var subject_army := Army.new()
		subject_army.id = 340020
		subject_army.owner_nation = shared_subject
		subject_army.size = GameState.INITIAL_HEAVY_ARMY_SIZE
		subject_army.max_size = GameState.INITIAL_HEAVY_ARMY_SIZE
		subject_army.location_city = shared.nations[shared_subject].capital_city_id
		shared.armies.append(subject_army)
		var shared_food := DiplomacyAI.war_food_report(
			shared,
			0,
			GameState.INITIAL_HEAVY_ARMY_SIZE,
			DiplomacyAI.FoodPosture.OFFENSIVE_WAR,
			{}
		)
		_check(
			float(shared_food["target_monthly_demand"])
				> float(shared_food["food_per_troop_month"])
					* GameState.INITIAL_HEAVY_ARMY_SIZE
			and int(shared_food["emergency_food_reserve"])
				== int(ceil(
					float(shared_food["target_monthly_demand"])
						* DiplomacyAI.EMERGENCY_FOOD_MONTHS
				)),
			"共享粮池容量必须把藩王既有军粮计入目标需求与六个月储备：%s"
				% [str(shared_food)]
		)
	else:
		_check(false, "共享粮池容量夹具必须成功分封完整州")
	var original_preparation_center := (
		gs.nations[0].war_preparation_objective_center_city
	)
	gs.nations[0].war_preparation_objective_center_city = (
		gs.administrative_center_city_ids[0]
	)
	var capacity_front := gs.create_campaign_front(
		-1, [0] as Array[int], 0,
		CoalitionCampaignFront.Mode.OFFENSE,
		gs.administrative_center_city_ids[-1]
	)
	var targeted_report := DiplomacyAI.force_capacity_report(
		gs, 0, DiplomacyAI.FoodPosture.PEACE, {}
	)
	gs.nations[0].war_preparation_objective_center_city = (
		original_preparation_center
	)
	gs.release_campaign_front(capacity_front.front_id)
	_check(
		int(base_report["additional_armies"]) >= 3
		and int(base_report["additional_armies"])
			== int(targeted_report["additional_armies"]),
		"和平容量必须允许富国扩军，且不随目标州R/V或战役目标变化"
	)
	var sim := Simulation.new()
	sim.setup(gs)
	var before_count := gs.active_army_count(0)
	var expected_recruits := int(base_report["additional_armies"])
	var view := AiWorldView.build(gs, 0)
	var recruited := sim._ai_manage_force_structure(
		view,
		StrategicMapSnapshot.build(view),
		ThreatField.build(view)
	)
	_check(
		recruited
		and gs.active_army_count(0) - before_count
			== expected_recruits
			and gs.nations[0].ai_last_force_reason.contains(
				"可持续军力容量扩军"
			),
		"富裕和平国家每次军制评估应一次补到可持续容量：delta=%d expected=%d reason=%s report=%s"
			% [
				gs.active_army_count(0) - before_count,
				expected_recruits,
				gs.nations[0].ai_last_force_reason,
				str(base_report),
			]
	)
	var post_recruit_report := DiplomacyAI.force_capacity_report(
		gs, 0, DiplomacyAI.FoodPosture.PEACE, {}
	)
	var post_recruit_food := sim._food_security_report(0, [], {})
	_check(
		int(post_recruit_report["current_armies"])
			== int(base_report["sustainable_armies"])
		and int(post_recruit_report["supportable_armies"])
			>= int(post_recruit_report["current_armies"])
		and int(post_recruit_report["additional_armies"]) == 0
		and not bool(post_recruit_food["needs_demobilization"]),
		"一次征满后容量不得反转或立即触发缩编：before=%s after=%s food=%s"
			% [
				str(base_report),
				str(post_recruit_report),
				str(post_recruit_food),
			]
	)
	var stable_count := gs.active_army_count(0)
	gs.day += Simulation.FORCE_STRUCTURE_REVIEW_INTERVAL_DAYS
	var next_view := AiWorldView.build(gs, 0)
	sim._ai_manage_force_structure(
		next_view,
		StrategicMapSnapshot.build(next_view),
		ThreatField.build(next_view)
	)
	_check(
		gs.active_army_count(0) == stable_count,
		"下一次半年军制评估不得因同一容量口径扩军或裁军：%d -> %d"
			% [stable_count, gs.active_army_count(0)]
	)
	for army in gs.armies.duplicate():
		if army.owner_nation == 0:
			gs.armies.erase(army)
	gs.nations[0].manpower_pool = (
		ReinforcementRules.PEACETIME_MANPOWER_RESERVE
		+ GameState.INITIAL_HEAVY_ARMY_SIZE
	)
	var manpower_report := DiplomacyAI.force_capacity_report(
		gs, 0, DiplomacyAI.FoodPosture.PEACE, {}
	)
	_check(
		int(manpower_report["additional_armies"]) == 1
		and int(manpower_report["manpower_limit"]) == 1,
		"和平容量必须在保留人力储备后只征得起的完整军团"
	)
	gs.nations[0].manpower_pool = 1000000
	gs.nations[0].treasury_gold = 0
	var creation_report := DiplomacyAI.force_capacity_report(
		gs, 0, DiplomacyAI.FoodPosture.PEACE, {}
	)
	_check(
		int(creation_report["additional_armies"]) >= 1
		and not creation_report.has("gold_creation_limit"),
		"零现金和平扩军仍受粮食和人力资格约束"
	)
	gs.nations[0].treasury_gold = 1000000
	for city in gs.cities_of(0):
		city.food_per_half_year = 0
		city.food_storage = 0
	var food_report := DiplomacyAI.force_capacity_report(
		gs, 0, DiplomacyAI.FoodPosture.PEACE, {}
	)
	_check(
		int(food_report["additional_armies"]) == 0
		and int(food_report["food_limit"]) == 0,
		"和平国家不得依赖持续消耗粮仓维持新增常备军"
	)
	for city in gs.cities_of(0):
		city.food_per_half_year = 9000
	for warehouse in gs.warehouse_cities_of(0):
		warehouse.food_storage = 50000
	var recovery_report := DiplomacyAI.force_capacity_report(
		gs, 0, DiplomacyAI.FoodPosture.PEACE, {}
	)
	var recovery_target := int(
		recovery_report["sustainable_armies"]
	) * GameState.INITIAL_HEAVY_ARMY_SIZE
	var recovery_food_plan := DiplomacyAI.war_food_report(
		gs,
		0,
		recovery_target,
		DiplomacyAI.FoodPosture.PEACE,
		{}
	)
	_check(
		int(recovery_report["additional_armies"]) > 0
		and bool(recovery_food_plan["target_sustainable"]),
		"和平容量的最终军数必须同时承担提高后的三年粮仓恢复目标：report=%s food=%s"
			% [str(recovery_report), str(recovery_food_plan)]
	)
	sim.free()


func _test_invalid_loyalty_snapshot_does_not_corrupt_city() -> void:
	print("[34b] 忠诚月结：灭亡国家残留节点不写入无效政治目标")
	var gs := preload("res://tests/support/grid_world.gd").new()
	gs.generate_grid_world(34001)
	var city := gs.cities_of(0)[0]
	var target_before := city.loyalty_target_nation
	gs.nations[0].alive = false
	RebellionSystem.resolve_month(gs)
	_check(
		city.loyalty_target_nation == target_before
		and city.loyalty_target_nation >= 0,
		"无效月度忠诚快照不得把残留城市或码头的政治目标改为-1"
	)

func _test_resource_hubs_and_food_mobilization() -> void:
	print("[34] 资源核心：AI价值识别；富粮国家宣战时有限爆兵")
	_check(
		Simulation._force_structure_review_due(0, 0)
			and Simulation._force_structure_review_due(0, 180)
			and Simulation._force_structure_review_due(7, 7)
			and Simulation._force_structure_review_due(7, 187)
			and not Simulation._force_structure_review_due(0, 179)
			and not Simulation._force_structure_review_due(7, 8),
		"军制评估必须按国家错峰，每180天触发一次"
	)
	var gs := preload("res://tests/support/grid_world.gd").new()
	gs.generate_grid_world(34001)
	# 本用例直接对比本国产粮动员能力；贸易不再自动购买粮食或人力。
	for nation in gs.nations:
		nation.trade_policy = RulerProfile.POLICY_ISOLATION
	for nation_a in range(gs.nations.size()):
		for nation_b in range(nation_a + 1, gs.nations.size()):
			gs.set_diplomatic_relation(
				nation_a,
				nation_b,
				GameState.DiplomaticRelation.NEUTRAL
			)
	gs.day = DiplomacyAI.MIN_NEUTRAL_DAYS
	for city in gs.cities_of(0):
		city.food_per_half_year = 120
	for city in gs.cities_of(1):
		city.food_per_half_year = 0
	for army in gs.armies:
		if army.owner_nation == 0:
			army.size = 333
		elif army.owner_nation == 1:
			army.size = 1333
	gs.nations[0].manpower_pool = (
		DiplomacyAI.MIN_MANPOWER_RESERVE
		+ DiplomacyAI.MAX_MOBILIZATION_ARMIES
			* GameState.INITIAL_HEAVY_ARMY_SIZE
	)
	gs.nations[1].manpower_pool = 30000
	for warehouse in gs.warehouse_cities_of(0):
		warehouse.food_storage = 5000
	for warehouse in gs.warehouse_cities_of(1):
		warehouse.food_storage = 100
	var rich_capacity := DiplomacyAI.mobilization_capacity(gs, 0)
	var defensive_capacity := DiplomacyAI.mobilization_capacity(
		gs,
		0,
		DiplomacyAI.FoodPosture.DEFENSIVE_WAR
	)
	var poor_capacity := DiplomacyAI.mobilization_capacity(gs, 1)
	var rich_gold_before_cash_test := (
		gs.nations[0].treasury_gold
	)
	var cash_report := DiplomacyAI.resource_report(gs, 0)
	var half_year_reserve := (
		int(cash_report["gold_reserve_baseline_income"])
		* Simulation.WAR_GOLD_RESERVE_MONTHS
	)
	gs.nations[0].treasury_gold = 0
	var below_reserve_war_capacity := (
		DiplomacyAI.mobilization_capacity(
			gs,
			0,
			DiplomacyAI.FoodPosture.OFFENSIVE_WAR
		)
	)
	gs.nations[0].treasury_gold = (
		half_year_reserve
	)
	var exact_reserve_war_capacity := (
		DiplomacyAI.mobilization_capacity(
			gs,
			0,
			DiplomacyAI.FoodPosture.OFFENSIVE_WAR
		)
	)
	gs.nations[0].treasury_gold = 0
	var zero_cash_guarded_capacity := (
		DiplomacyAI.mobilization_capacity(
			gs,
			0,
			DiplomacyAI.FoodPosture.GUARDED
		)
	)
	gs.nations[0].treasury_gold = rich_gold_before_cash_test
	var rich_target_troops := DiplomacyAI._troop_count(gs, 0) \
		+ rich_capacity * GameState.INITIAL_HEAVY_ARMY_SIZE
	var rich_food_plan := DiplomacyAI.war_food_report(
		gs,
		0,
		rich_target_troops,
		DiplomacyAI.FoodPosture.OFFENSIVE_WAR
	)
	var stock_before_runway_test := gs.warehouse_cities_of(0)[0].food_storage
	gs.warehouse_cities_of(0)[0].food_storage = 500
	var low_stock_plan := DiplomacyAI.war_food_report(
		gs,
		0,
		rich_target_troops,
		DiplomacyAI.FoodPosture.OFFENSIVE_WAR
	)
	gs.warehouse_cities_of(0)[0].food_storage = stock_before_runway_test
	_check(
		rich_capacity > 0
		and rich_capacity <= DiplomacyAI.MAX_MOBILIZATION_ARMIES
		and defensive_capacity >= rich_capacity
		and poor_capacity == 0,
		"富粮国应可在闭合容量内动员，防御动员不少于进攻，贫粮大国不得爆兵：rich=%d defensive=%d poor=%d"
			% [rich_capacity, defensive_capacity, poor_capacity]
	)
	_check(
		exact_reserve_war_capacity == below_reserve_war_capacity
			and zero_cash_guarded_capacity <= exact_reserve_war_capacity,
		"国库变化不得改变粮食支持容量，粮食储备偏好仍生效"
	)
	_check(
		bool(rich_food_plan["target_sustainable"])
		and int(rich_food_plan["forecast"]["food_deficit"]) == 0
		and float(rich_food_plan["target_runway_years"])
			>= float(low_stock_plan["target_runway_years"])
		and float(rich_food_plan["full_strength_annual_demand"])
			> float(rich_food_plan["current_annual_demand"])
		and float(rich_food_plan["target_annual_demand"])
			> float(rich_food_plan["current_annual_demand"]),
		"战争粮食报告应量化现有编制满员与扩军目标年耗，库存越多可支撑战争越久"
	)
	_check(
		DiplomacyAI.war_desire(gs, 0, 1) >= DiplomacyAI.WAR_DECLARE_SCORE,
		"粮食动员潜力应使富粮小国具备向贫粮大国宣战的决策能力"
	)

	var resource_target: City = null
	for city in gs.cities_of(1):
		for neighbor in gs.neighbors(city.id):
			if (
				gs.cities[neighbor].owner_nation == 0
				and gs.edge_of(city.id, neighbor).max_manpower > 0
			):
				resource_target = city
				break
		if resource_target != null:
			break
	_check(resource_target != null, "测试地图应存在国0接壤的国1城市")
	if resource_target != null:
		for city in gs.cities_of(1):
			city.is_food_hub = false
			city.is_manpower_hub = false
		resource_target.is_food_hub = true
		resource_target.is_manpower_hub = true
		resource_target.food_per_half_year = 1000
		resource_target.manpower_per_month = 100000
		var selected := DiplomacyAI.select_war_objective(gs, 0, 1)
		_check(
			int(selected.get("city_id", -1))
				== gs.administrative_center_of(resource_target.id)
			and str(selected.get("reason", "")).contains("粮食核心")
			and str(selected.get("reason", "")).contains("人口核心"),
			"高产粮食/人口城市所属州应成为优先目标：target=%d center=%d selected=%s"
				% [resource_target.id, gs.administrative_center_of(resource_target.id), str(selected)]
		)
		resource_target.is_food_hub = false
		resource_target.is_manpower_hub = false
		resource_target.food_per_half_year = 0
		resource_target.manpower_per_month = 10
		var mobilization_center := gs.administrative_center_of(
			resource_target.id
		)
		gs.cities[mobilization_center].garrison_manpower = (
			GameState.ZHOU_GARRISON_CAPACITY
		)

	for army in gs.armies.duplicate():
		if army.owner_nation == 0:
			gs.armies.erase(army)
	var troops_before := 0
	for army in gs.armies:
		if army.owner_nation == 0:
			troops_before += army.size
	var sim := Simulation.new()
	sim.setup(gs)
	var declared := sim._execute_diplomatic_action({
		"kind": DiplomacyAI.Action.DECLARE_WAR,
		"a": 0,
		"b": 1,
		"objective_city": resource_target.id if resource_target != null else -1,
		"objective_reason": "资源核心测试",
		"mobilization_armies": rich_capacity,
		"reason": "富粮动员测试",
	})
	_check(
		declared
		and gs.nations[0].war_mobilization_target_troops
			== troops_before
				+ rich_capacity * GameState.INITIAL_HEAVY_ARMY_SIZE
		and gs.nations[1].war_mobilization_target_troops > 0
		and gs.nations[1].war_mobilization_target_troops
			< gs.nations[0].war_mobilization_target_troops,
		"宣战双方应按各自粮食条件设置不同目标兵力"
	)
	var army_count_before := gs.armies.size()
	gs.uses_heightmap = true
	var wartime_capacity_report := DiplomacyAI.force_capacity_report(
		gs, 0, DiplomacyAI.FoodPosture.OFFENSIVE_WAR, {}
	)
	var expected_wartime_recruits := int(
		wartime_capacity_report["additional_armies"]
	)
	var mobilized := sim._ai_manage_force_structure(
		AiWorldView.build(gs, 0),
		StrategicMapSnapshot.build(AiWorldView.build(gs, 0)),
		ThreatField.build(AiWorldView.build(gs, 0))
	)
	_check(
		mobilized
			and gs.armies.size()
				== army_count_before
					+ expected_wartime_recruits
			and gs.nations[0].ai_last_force_reason.contains(
				"可持续军力容量扩军"
			),
		"半年军制评估必须在库存门禁内一次补到战时容量：delta=%d expected=%d reason=%s"
			% [
				gs.armies.size() - army_count_before,
				expected_wartime_recruits,
				gs.nations[0].ai_last_force_reason,
			]
	)
	sim._execute_diplomatic_action({
		"kind": DiplomacyAI.Action.MAKE_PEACE,
		"a": 0,
		"b": 1,
		"reason": "动员清理测试",
	})
	_check(
		gs.nations[0].war_mobilization_target_troops == 0
		and gs.nations[0].war_mobilization_until_day == -1,
			"结束最后一场战争后必须清除动员目标"
	)
	sim.free()


func _test_small_nation_survival_and_emergency_recruitment() -> void:
	print("[34b] 小国生存：最后城市集中守备、负收益应急征兵与库存硬边界")
	var gs := preload("res://tests/support/grid_world.gd").new()
	gs.generate_grid_world(34002)
	gs.uses_heightmap = true
	gs.armies.clear()
	gs.battles.clear()
	for nation_a in range(gs.nations.size()):
		for nation_b in range(nation_a + 1, gs.nations.size()):
			gs.set_diplomatic_relation(
				nation_a,
				nation_b,
				GameState.DiplomaticRelation.NEUTRAL
			)
	var last_city_id := gs.nations[0].capital_city_id
	for city in gs.cities:
		city.owner_nation = 1
		city.has_warehouse = false
		city.is_capital = false
		if city.id == last_city_id:
			city.owner_nation = 0
			city.has_warehouse = true
			city.is_capital = true
			city.food_per_half_year = 0
			city.food_storage = 100000
	gs.set_diplomatic_relation(
		0,
		1,
		GameState.DiplomaticRelation.WAR
	)
	var guard := gs.create_army(
		0,
		last_city_id,
		GameState.INITIAL_HEAVY_ARMY_SIZE,
		GameState.INITIAL_HEAVY_ARMY_SIZE
	)
	var enemy_city_id := gs.neighbors(last_city_id)[0]
	var besieger := gs.create_army(
		1,
		enemy_city_id,
		GameState.INITIAL_HEAVY_ARMY_SIZE,
		GameState.INITIAL_HEAVY_ARMY_SIZE
	)
	var sim := Simulation.new()
	sim.setup(gs)
	var siege := gs.new_battle(Battle.Kind.SIEGE)
	siege.city = gs.cities[last_city_id]
	siege.edge = gs.edge_of(last_city_id, enemy_city_id)
	siege.side_b_defends_city = true
	siege.side_a.append(besieger)
	siege.side_b.append(guard)
	besieger.state = Army.State.FIGHTING
	besieger.battle_id = siege.id
	guard.state = Army.State.FIGHTING
	guard.battle_id = siege.id
	var siege_view := AiWorldView.build(gs, 0)
	var creation_cost := 0
	gs.nations[0].manpower_pool = (
		GameState.INITIAL_HEAVY_ARMY_SIZE
	)
	gs.nations[0].treasury_gold = creation_cost
	var food_report := sim._food_security_report(
		0,
		siege_view.friendly_armies
	)
	var mobilized := sim._ai_manage_force_structure(
		siege_view,
		StrategicMapSnapshot.build(siege_view),
		ThreatField.build(siege_view)
	)
	var emergency_army: Army = null
	for army in gs.armies:
		if army.owner_nation == 0 and army != guard:
			emergency_army = army
			break
	_check(
		not mobilized
			and emergency_army == null
			and gs.active_army_count(0) == 1
			and float(food_report["monthly_surplus"]) < 0.0
			and float(food_report["runway_years"])
				>= Simulation.EMERGENCY_RECRUITMENT_MIN_RUNWAY_YEARS
			and gs.nations[0].treasury_gold == creation_cost
			and gs.nations[0].manpower_pool
				== GameState.INITIAL_HEAVY_ARMY_SIZE,
		"最后城市已有主战军时不得再生成额外主战军"
	)
	_check(
		siege.has_army(guard)
			and guard.battle_id == siege.id,
		"已有主战守军必须继续留在围城守军侧"
	)
	# 小国只保留“无军时补一军”的生存下限；已有军队后按同一资源容量扩军。
	siege.finished = true
	gs.battles.erase(siege)
	guard.state = Army.State.IDLE
	guard.battle_id = -1
	besieger.state = Army.State.IDLE
	besieger.battle_id = -1
	gs.cities[last_city_id].food_per_half_year = 100000
	gs.cities[last_city_id].gold_per_month = 1000
	gs.cities[last_city_id].food_storage = 100000
	gs.nations[0].manpower_pool = 100000
	gs.nations[0].treasury_gold = 100000
	var small_capacity_report := DiplomacyAI.force_capacity_report(
		gs, 0, DiplomacyAI.FoodPosture.DEFENSIVE_WAR, {}
	)
	var stable_view := AiWorldView.build(gs, 0)
	var small_nation_grew_again := sim._ai_manage_force_structure(
		stable_view,
		StrategicMapSnapshot.build(stable_view),
		ThreatField.build(stable_view)
	)
	var standard_army_count := 0
	for small_army in gs.armies:
		if small_army.owner_nation != 0 or small_army.size <= 0:
			continue
		if small_army.max_size == GameState.INITIAL_HEAVY_ARMY_SIZE:
			standard_army_count += 1
	_check(
		small_nation_grew_again
			and gs.active_army_count(0) == 3
			and standard_army_count == 3
			and guard.battle_group_id >= 0
			and gs.battle_group_members(0, guard.battle_group_id).size() == 1,
		"一城小国已有生存军后应按资源容量扩至军队槽位上限：count=%d standard=%d reason=%s report=%s"
			% [
				gs.active_army_count(0), standard_army_count,
				gs.nations[0].ai_last_force_reason,
				str(small_capacity_report),
			]
	)
	for army in gs.armies.duplicate():
		if army.owner_nation == 0 and army != guard:
			gs.armies.erase(army)
	gs.cities[last_city_id].food_per_half_year = 0
	gs.cities[last_city_id].food_storage = 0
	gs.nations[0].manpower_pool = (
		GameState.INITIAL_HEAVY_ARMY_SIZE
	)
	gs.nations[0].treasury_gold = creation_cost
	var empty_stock_manpower_before := gs.nations[0].manpower_pool
	var empty_stock_view := AiWorldView.build(gs, 0)
	var _empty_stock_changed := (
		sim._ai_manage_force_structure(
			empty_stock_view,
			StrategicMapSnapshot.build(empty_stock_view),
			ThreatField.build(empty_stock_view)
		)
	)
	_check(
		gs.active_army_count(0) == 1
			and gs.nations[0].treasury_gold == creation_cost
			and gs.nations[0].manpower_pool
				>= empty_stock_manpower_before,
		"负收益征兵不等于透支：粮库为0时必须拒绝建军且不得预扣金钱或人力"
	)
	sim.free()


## [35] 阶段1 战斗公平性与守恒：胜负与 A/B 位置无关、伤亡整数守恒、平局、士气影响战力、拆分不改总量。
func _test_combat_fairness_and_conservation() -> void:
	print("[35] 战斗公平：A/B 无偏置 + 伤亡守恒 + 平局 + 士气战力 + 拆分等价")

	# (a) A/B 位置无偏置：同一对不对称阵容，交换 side_a/side_b 与固定种子后，胜方应随之镜像交换。
	#     强者(3000)对弱者(1000)：强者所在侧必胜，与它站 A 还是 B 无关。
	var seed_list := [1, 7, 42, 123, 999]
	var ab_consistent := true
	for s in seed_list:
		var rng1 := RandomNumberGenerator.new(); rng1.seed = s
		var strong_a := _make_field_battle([_make_army(0, 0, 3000, 10)], [_make_army(1, 1, 1000, 10)], 0.0, 4)
		_run_battle(strong_a, rng1)
		var rng2 := RandomNumberGenerator.new(); rng2.seed = s
		var strong_b := _make_field_battle([_make_army(0, 0, 1000, 10)], [_make_army(1, 1, 3000, 10)], 0.0, 4)
		_run_battle(strong_b, rng2)
		# 强者在 A 时 winner==1，强者在 B 时 winner==2；否则说明有位置偏置。
		if strong_a.winner_side != 1 or strong_b.winner_side != 2:
			ab_consistent = false
	_check(ab_consistent, "强弱对决胜负必须随位置镜像交换，不得有 A/B 偏置")

	# (b) decide_winner 纯函数对称性：交换输入，输出必须 1↔2 对称，平局(0)不变。
	_check(Combat.decide_winner(true, false, false, false, 0.0, 0.0) == 2, "仅 A 被歼→B 胜")
	_check(Combat.decide_winner(false, true, false, false, 0.0, 0.0) == 1, "仅 B 被歼→A 胜")
	_check(Combat.decide_winner(false, false, true, false, 5.0, 3.0) == 2, "仅 A 溃→B 胜")
	_check(Combat.decide_winner(false, false, false, true, 3.0, 5.0) == 1, "仅 B 溃→A 胜")
	_check(Combat.decide_winner(true, true, false, false, 5.0, 3.0) == 1, "同时歼灭→残力高者(A)胜")
	_check(Combat.decide_winner(true, true, false, false, 3.0, 5.0) == 2, "同时歼灭→残力高者(B)胜")
	_check(Combat.decide_winner(true, true, false, false, 4.0, 4.0) == 0, "同时歼灭且残力相等→平局")
	_check(Combat.decide_winner(false, false, true, true, 4.0, 4.0) == 0, "同时溃败且残力相等→平局")

	# (c) 完全对称战斗：同质双方（同 size/atk/def/morale）应打成平局(0)，绝不默认 A 胜。
	var sym_ties := 0
	for s in seed_list:
		var rng := RandomNumberGenerator.new(); rng.seed = s
		var b := _make_field_battle([_make_army(0, 0, 1000, 10)], [_make_army(1, 1, 1000, 10)], 0.0, 4)
		_run_battle(b, rng)
		if b.winner_side == 0:
			sym_ties += 1
	_check(sym_ties == seed_list.size(), "完全对称战斗应全部判平局，实为 %d/%d" % [sym_ties, seed_list.size()])

	# (d) 伤亡整数守恒（最大余数法）：sum == min(round(loss), Σsize)，每支 0<=c<=size。
	var sizes: Array[int] = [1000, 3000, 500, 2500]
	var pool := 7000
	var cas := Combat.distribute_casualties(sizes, 1234.0)
	var sum_cas := 0
	var bounded := true
	for i in range(sizes.size()):
		sum_cas += cas[i]
		if cas[i] < 0 or cas[i] > sizes[i]:
			bounded = false
	_check(sum_cas == 1234, "伤亡守恒：Σ应=1234，实为 %d" % sum_cas)
	_check(bounded, "每支伤亡必须在 [0, size] 内")
	# 溢出夹住：loss 超过总兵力 → 全歼，Σ==pool。
	var cas_all := Combat.distribute_casualties(sizes, 99999.0)
	var sum_all := 0
	for c in cas_all:
		sum_all += c
	_check(sum_all == pool, "损失超总兵力应全歼 Σ==%d，实为 %d" % [pool, sum_all])

	# (e) 拆分不改变总伤亡（防套利 item12）：1×10000 与 10×1000 承受同一 loss，总伤相等。
	var loss_target := 3456.0
	var single_sum := 0
	for c in Combat.distribute_casualties([10000], loss_target):
		single_sum += c
	var split_sizes: Array[int] = []
	for _i in range(10):
		split_sizes.append(1000)
	var split_sum := 0
	for c in Combat.distribute_casualties(split_sizes, loss_target):
		split_sum += c
	_check(single_sum == split_sum, "拆分伤亡总量应一致：单支%d vs 10支%d" % [single_sum, split_sum])

	# (f) 士气影响战力：combat_efficiency 单调、满士气=1.0、下界=MIN_COMBAT_EFFICIENCY。
	_check(_approx(Combat.combat_efficiency(1.0), 1.0), "满士气效率应=1.0")
	_check(_approx(Combat.combat_efficiency(0.0), Combat.MIN_COMBAT_EFFICIENCY), "零士气效率应=下界")
	_check(Combat.combat_efficiency(0.5) > Combat.combat_efficiency(0.2), "效率随士气单调递增")
	# 同兵力同装备，满士气攻方一回合杀伤应 ≥ 疲劳攻方（士气折算攻击力，而非第二血条）。
	var full_att := _make_army(0, 0, 2000, 10)             # morale 默认 1.0
	var tired_att := _make_army(0, 0, 2000, 10); tired_att.morale = 0.3
	var loss_full := _one_round_side_b_loss([full_att], [_make_army(2, 1, 3000, 10)], 90)
	var loss_tired := _one_round_side_b_loss([tired_att], [_make_army(2, 1, 3000, 10)], 90)
	_check(loss_full > loss_tired, "满士气攻方杀伤(%d)应高于疲劳攻方(%d)（士气折算战力）" % [loss_full, loss_tired])
	var mixed_strong := _make_army(3, 0, 1000, 20, 10)
	mixed_strong.morale = 0.25
	var mixed_steady := _make_army(4, 0, 2000, 8, 10)
	mixed_steady.morale = 0.75
	var mixed_side: Array[Army] = [
		mixed_strong,
		mixed_steady,
	]
	var mixed_expected_attack := (
		float(mixed_strong.size)
			* float(mixed_strong.attack)
			* Combat.combat_efficiency(
					mixed_strong.combat_morale()
				)
		+ float(mixed_steady.size)
			* float(mixed_steady.attack)
			* Combat.combat_efficiency(mixed_steady.morale)
	)
	var mixed_frontline := Combat.frontline_allocation(
		mixed_side,
		100000
	)
	var mixed_actual_attack := Combat._frontline_attack(
		mixed_frontline,
		Combat._side_combat_efficiency(mixed_side)
	)
	_check(
		_approx(
			mixed_actual_attack,
			mixed_expected_attack,
			0.000001
		),
		"无限正面混编军的侧级组织效率必须严格还原逐军火力求和"
	)
	# 君主倍率改变的是有效士气量纲。侵蚀回写必须除以君主倍率，
	# 否则 ruler>1 的军队会被多扣、ruler<1 的军队会被少扣。
	var high_ruler_morale := _make_army(5, 0, 1000, 10, 10)
	var low_ruler_morale := _make_army(6, 0, 1000, 10, 10)
	high_ruler_morale.morale = 0.8
	low_ruler_morale.morale = 0.8
	high_ruler_morale.ruler_morale_multiplier = 1.25
	low_ruler_morale.ruler_morale_multiplier = 0.5
	var ruler_morale_side: Array[Army] = [
		high_ruler_morale,
		low_ruler_morale,
	]
	var ruler_morale_frontline: Array[Dictionary] = [
		{
			"army": high_ruler_morale,
			"committed": high_ruler_morale.size,
			"size_before": high_ruler_morale.size,
		},
		{
			"army": low_ruler_morale,
			"committed": low_ruler_morale.size,
			"size_before": low_ruler_morale.size,
		},
	]
	var high_effective_before := high_ruler_morale.combat_morale()
	var low_effective_before := low_ruler_morale.combat_morale()
	var ruler_mass_before := (
		float(high_ruler_morale.size) * high_effective_before
		+ float(low_ruler_morale.size) * low_effective_before
	)
	Combat._erode_frontline_morale(
		ruler_morale_side,
		ruler_morale_frontline,
		0,
		ruler_mass_before / 2000.0
	)
	var ruler_mass_after := (
		float(high_ruler_morale.size)
			* high_ruler_morale.combat_morale()
		+ float(low_ruler_morale.size)
			* low_ruler_morale.combat_morale()
	)
	_check(
		_approx(
			ruler_mass_after,
			ruler_mass_before
				- 2000.0 * Combat.MORALE_BASE_DECAY,
			0.000001
		),
		"不同君主倍率的前线侵蚀后，有效士气质量必须精确达到目标"
	)
	_check(
		_approx(
			high_effective_before
				- high_ruler_morale.combat_morale(),
			Combat.MORALE_BASE_DECAY,
			0.000001
		)
		and _approx(
			low_effective_before
				- low_ruler_morale.combat_morale(),
			Combat.MORALE_BASE_DECAY,
			0.000001
		),
		"君主士气倍率不得放大或缩小每兵有效士气侵蚀"
	)

	# (g) 正面宽度/预备队（item 5）：窄路(frontage=5000)上大军(20000)无法全数展开。
	_check(Combat.frontage_engaged_ratio(20000, 5000) == 0.25, "2万兵挤5千正面→参战比例应=0.25")
	_check(Combat.frontage_engaged_ratio(3000, 5000) == 1.0, "兵力小于正面→全员参战")
	# 拆分不增加总正面（item12）：1×20000 与 20×1000 在同一窄路，一回合对守军总杀伤应一致。
	var single_army := _make_field_battle([_make_army(0, 0, 20000, 10)], [_make_army(99, 1, 20000, 10)], 0.0, 4)
	single_army.edge.max_manpower = 5000
	var split_list: Array = []
	for k in range(20):
		split_list.append(_make_army(k, 0, 1000, 10))
	var split_army := _make_field_battle(split_list, [_make_army(99, 1, 20000, 10)], 0.0, 4)
	split_army.edge.max_manpower = 5000
	var rng_s1 := RandomNumberGenerator.new(); rng_s1.seed = 3
	var rng_s2 := RandomNumberGenerator.new(); rng_s2.seed = 3
	var sb1 := single_army.side_size(single_army.side_b)
	var sb2 := split_army.side_size(split_army.side_b)
	CombatFixture.resolve_round(single_army)
	CombatFixture.resolve_round(split_army)
	var single_dmg := sb1 - single_army.side_size(single_army.side_b)
	var split_dmg := sb2 - split_army.side_size(split_army.side_b)
	_check(absi(single_dmg - split_dmg) <= 2, "窄路拆分总杀伤应一致：单支%d vs 拆分%d" % [single_dmg, split_dmg])
	# 完整多回合受限正面不变量：1×10000 与 2×5000 对同一敌军时，
	# 行政编组粒度不得改变逐轮火力、伤亡、全军组织度、胜负或时长。
	var constrained_whole := _make_field_battle(
		[_make_army(10, 0, 10000, 10, 10)],
		[_make_army(20, 1, 10000, 10, 10)],
		0.0,
		4
	)
	var constrained_split := _make_field_battle(
		[
			_make_army(11, 0, 5000, 10, 10),
			_make_army(12, 0, 5000, 10, 10),
		],
		[_make_army(21, 1, 10000, 10, 10)],
		0.0,
		4
	)
	constrained_whole.edge.max_manpower = 5000
	constrained_split.edge.max_manpower = 5000
	var constrained_rng_whole := RandomNumberGenerator.new()
	var constrained_rng_split := RandomNumberGenerator.new()
	constrained_rng_whole.seed = 860001
	constrained_rng_split.seed = 860001
	var constrained_start_a := constrained_whole.side_size(
		constrained_whole.side_a
	)
	var constrained_start_b := constrained_whole.side_size(
		constrained_whole.side_b
	)
	var constrained_trace_equal := true
	var constrained_rounds := 0
	Combat.battle_log_enabled = true
	while (
		not constrained_whole.finished
		and not constrained_split.finished
		and constrained_rounds < 1000
	):
		Combat.clear_battle_log()
		CombatFixture.resolve_round(constrained_whole)
		var whole_record: Dictionary = (
			Combat.battle_log[-1].duplicate(true)
		)
		Combat.clear_battle_log()
		CombatFixture.resolve_round(constrained_split)
		var split_record: Dictionary = (
			Combat.battle_log[-1].duplicate(true)
		)
		constrained_trace_equal = (
			constrained_trace_equal
			and int(whole_record["casualties_a"])
				== int(split_record["casualties_a"])
			and int(whole_record["casualties_b"])
				== int(split_record["casualties_b"])
			and _approx(
				float(whole_record["effective_attack_a"]),
				float(split_record["effective_attack_a"]),
				0.000001
			)
			and _approx(
				float(whole_record["effective_attack_b"]),
				float(split_record["effective_attack_b"]),
				0.000001
			)
			and _approx(
				_battle_force_morale(
					constrained_whole.side_a,
					constrained_whole.routed_a
				),
				_battle_force_morale(
					constrained_split.side_a,
					constrained_split.routed_a
				),
				0.000000001
			)
			and _approx(
				_battle_force_morale(
					constrained_whole.side_b,
					constrained_whole.routed_b
				),
				_battle_force_morale(
					constrained_split.side_b,
					constrained_split.routed_b
				),
				0.000000001
			)
		)
		constrained_rounds += 1
	Combat.battle_log_enabled = false
	Combat.clear_battle_log()
	var constrained_loss_whole := [
		constrained_start_a
			- constrained_whole.side_size(
				constrained_whole.side_a
			)
			- constrained_whole.side_size(
				constrained_whole.routed_a
			),
		constrained_start_b
			- constrained_whole.side_size(
				constrained_whole.side_b
			)
			- constrained_whole.side_size(
				constrained_whole.routed_b
			),
	]
	var constrained_loss_split := [
		constrained_start_a
			- constrained_split.side_size(
				constrained_split.side_a
			)
			- constrained_split.side_size(
				constrained_split.routed_a
			),
		constrained_start_b
			- constrained_split.side_size(
				constrained_split.side_b
			)
			- constrained_split.side_size(
				constrained_split.routed_b
			),
	]
	_check(
		constrained_trace_equal
			and constrained_whole.finished
			and constrained_split.finished
			and constrained_whole.winner_side
				== constrained_split.winner_side
			and constrained_whole.round_no
				== constrained_split.round_no
			and constrained_loss_whole
				== constrained_loss_split,
		(
			"5000正面完整战斗拆分不变量失败："
			+ "winner=%d/%d rounds=%d/%d loss=%s/%s"
		) % [
			constrained_whole.winner_side,
			constrained_split.winner_side,
			constrained_whole.round_no,
			constrained_split.round_no,
			str(constrained_loss_whole),
			str(constrained_loss_split),
		]
	)
	# 窄路一回合杀伤应显著低于宽路：大军被正面卡住，只有前线部队出力。
	var wide := _make_field_battle([_make_army(0, 0, 20000, 10)], [_make_army(2, 1, 20000, 10)], 0.0, 4)
	wide.edge.max_manpower = 100000        # 宽路：全员展开
	var narrow := _make_field_battle([_make_army(0, 0, 20000, 10)], [_make_army(2, 1, 20000, 10)], 0.0, 4)
	narrow.edge.max_manpower = 5000        # 窄路：仅 5000 展开
	var rng_w := RandomNumberGenerator.new(); rng_w.seed = 7
	var rng_n := RandomNumberGenerator.new(); rng_n.seed = 7
	var wide_before := wide.side_size(wide.side_b)
	var narrow_before := narrow.side_size(narrow.side_b)
	CombatFixture.resolve_round(wide)
	CombatFixture.resolve_round(narrow)
	var wide_loss := wide_before - wide.side_size(wide.side_b)
	var narrow_loss := narrow_before - narrow.side_size(narrow.side_b)
	_check(narrow_loss < wide_loss, "窄路杀伤(%d)应显著低于宽路(%d)（预备队不出力）" % [narrow_loss, wide_loss])
	# 预备队不受伤亡：窄路一回合伤亡不得超过前线参战兵力 5000。
	_check(narrow_loss <= 5000, "窄路单回合伤亡(%d)不得超过前线正面 5000（预备队不受伤）" % narrow_loss)

	# (h) 军队 id 不改变战斗结果（item 16 对称性）：完全相同的阵容，仅把 id 整体错开，
	#     多回合解算结果必须逐位一致——战斗数学不得依赖 id。
	var rng_id1 := RandomNumberGenerator.new(); rng_id1.seed = 55
	var low_ids := _make_field_battle([_make_army(0, 0, 4000, 11, 9)], [_make_army(1, 1, 3800, 10, 10)], 0.2, 4)
	var l1 := _run_battle(low_ids, rng_id1)
	var rng_id2 := RandomNumberGenerator.new(); rng_id2.seed = 55
	var high_ids := _make_field_battle([_make_army(500, 0, 4000, 11, 9)], [_make_army(501, 1, 3800, 10, 10)], 0.2, 4)
	var l2 := _run_battle(high_ids, rng_id2)
	_check(
		low_ids.winner_side == high_ids.winner_side
		and low_ids.side_size(low_ids.side_a) == high_ids.side_size(high_ids.side_a)
		and low_ids.side_size(low_ids.side_b) == high_ids.side_size(high_ids.side_b)
		and l1 == l2,
		"军队 id 整体偏移不得改变战斗结果（胜负/存活/回合数逐位一致）"
	)

	# (i) 一侧内部创建/加入顺序不改变战斗结果（item 16 + 本轮镜像修复的核心不变量）：
	#     同一多重集 {3000,1000,2000} 以正序与逆序装入 side_a，对同一 side_b 打同种子多回合，
	#     结果必须逐位一致。浮点求和不满足结合律，靠 resolve_round 内的物理键规范排序消除顺序依赖。
	var rng_o1 := RandomNumberGenerator.new(); rng_o1.seed = 88
	var fwd := _make_field_battle(
		[_make_army(0, 0, 3000, 10, 10), _make_army(1, 0, 1000, 10, 10), _make_army(2, 0, 2000, 10, 10)],
		[_make_army(9, 1, 6100, 10, 10)], 0.1, 4
	)
	var of1 := _run_battle(fwd, rng_o1)
	var rng_o2 := RandomNumberGenerator.new(); rng_o2.seed = 88
	var rev := _make_field_battle(
		[_make_army(0, 0, 2000, 10, 10), _make_army(1, 0, 1000, 10, 10), _make_army(2, 0, 3000, 10, 10)],
		[_make_army(9, 1, 6100, 10, 10)], 0.1, 4
	)
	var of2 := _run_battle(rev, rng_o2)
	_check(
		fwd.winner_side == rev.winner_side
		and fwd.side_size(fwd.side_a) == rev.side_size(rev.side_a)
		and fwd.side_size(fwd.side_b) == rev.side_size(rev.side_b)
		and of1 == of2,
		"同一多重集不同装入顺序，战斗结果必须逐位一致（浮点求和顺序无关）"
	)

	# Fixed equal dice preserve deterministic symmetry; independent dice allow reversals.
	var symmetric := true
	for roll in range(11):
		var ma := _make_army(0, 0, 5000, 10, 10)
		var mb := _make_army(1, 1, 5000, 10, 10)
		var mbat := _make_field_battle([ma], [mb], 0.3, 4)
		mbat.field_dice = PackedInt32Array([roll, roll, roll, roll])
		Combat.resolve_round(mbat)
		if ma.size != mb.size or not is_equal_approx(ma.morale, mb.morale):
			symmetric = false
	_check(symmetric, "固定同骰双方单回合仍严格对称")
	var adv_wins := 0
	for seed in range(200):
		var adv := _make_field_battle([_make_army(0, 0, 2100, 10, 10)], [_make_army(1, 1, 2000, 10, 10)], 0.1, 4)
		adv.ensure_opening_dice(1000 + seed, true)
		_run_battle(adv, RandomNumberGenerator.new())
		if adv.winner_side == 1:
			adv_wins += 1
	_check(adv_wins > 0 and adv_wins < 200, "独立固定四骰允许弱方翻盘且不固定偏向某侧")


## [36] item15 结构化战斗日志：默认关闭零记录、启用后字段完整可读、且不改变战斗结果（镜像安全）。
func _test_structured_battle_log() -> void:
	print("[36] 结构化战斗日志：可关闭 + 字段完整 + 不影响战斗数值")

	# (a) 默认关闭：跑一场战斗不产生任何日志。
	Combat.clear_battle_log()
	Combat.battle_log_enabled = false
	var rng0 := RandomNumberGenerator.new(); rng0.seed = 7
	var quiet := _make_field_battle([_make_army(0, 0, 2000, 10)], [_make_army(1, 1, 2000, 10)], 0.2, 4)
	_run_battle(quiet, rng0)
	_check(Combat.battle_log.is_empty(), "日志默认关闭时不得产生任何记录，实为 %d 条" % Combat.battle_log.size())

	# (b) 启用后：每回合一条记录，字段齐全（对照方案书 item15 字段清单），末条 winner 与战斗一致。
	Combat.clear_battle_log()
	Combat.battle_log_enabled = true
	var rng1 := RandomNumberGenerator.new(); rng1.seed = 7
	var logged := _make_field_battle([_make_army(0, 0, 3000, 12)], [_make_army(1, 1, 2000, 10)], 0.3, 4)
	logged.id = 77
	var rounds := _run_battle(logged, rng1)
	_check(Combat.battle_log.size() == rounds,
		"启用日志后记录条数应等于回合数 %d，实为 %d" % [rounds, Combat.battle_log.size()])
	var required_keys := [
		"battle_id", "day", "round_no", "kind", "participants_a", "participants_b",
		"frontline_strength_a", "reserve_strength_a", "effective_attack_a", "effective_defense_a",
		"opening_dice", "performance_modifier_a", "frontage_a", "terrain_modifier_a", "supply_modifier_a",
		"casualties_a", "morale_before_a", "morale_after_a", "reinforcements_arrived_a",
		"rout_reason", "winner_or_draw",
	]
	var first: Dictionary = Combat.battle_log[0]
	var keys_ok := true
	for k in required_keys:
		if not first.has(k):
			keys_ok = false
	_check(keys_ok, "日志记录应包含 item15 规定的全部字段，缺失键；实有 %s" % str(first.keys()))
	_check(int(first["battle_id"]) == 77, "日志应携带 battle_id，实为 %s" % str(first["battle_id"]))
	var last: Dictionary = Combat.battle_log[Combat.battle_log.size() - 1]
	_check(int(last["winner_or_draw"]) == logged.winner_side and String(last["rout_reason"]) != "none",
		"末条日志 winner/rout_reason 应与战斗结束态一致：winner=%s reason=%s" % [
			str(last["winner_or_draw"]), str(last["rout_reason"])])
	# morale_after 应随回合单调不增（士气侵蚀），且首回合 morale_before≈1.0。
	_check(_approx(float(first["morale_before_a"]), 1.0),
		"满编新军首回合 morale_before 应≈1.0，实为 %.4f" % float(first["morale_before_a"]))
	_check(
		first["participants_a"] is Array
			and not (first["participants_a"] as Array).is_empty()
			and first["battle_context"] is Dictionary,
		"日志应携带可独立回放的参战军快照与战场上下文"
	)

	# (c) JSONL 落盘/加载/回放：每条记录可独立重建，篡改结果必须被检测。
	var log_path := "user://combat_log_roundtrip_test.jsonl"
	var saved := CombatLog.save_jsonl(
		Combat.battle_log,
		log_path
	)
	var loaded := CombatLog.load_jsonl(log_path)
	_check(
		bool(saved.get("ok", false))
			and bool(loaded.get("ok", false))
			and (loaded["records"] as Array).size()
				== Combat.battle_log.size(),
		"结构化日志 JSONL 应可完整落盘并加载：save=%s load=%s"
			% [str(saved), str(loaded)]
	)
	if bool(loaded.get("ok", false)):
		var replayed := CombatLog.replay_records(
			loaded["records"] as Array[Dictionary]
		)
		_check(
			bool(replayed.get("ok", false)),
			"加载后的战斗日志应逐回合确定性重放：%s"
				% str(replayed)
		)
		var tampered: Array[Dictionary] = (
			loaded["records"] as Array[Dictionary]
		).duplicate(true)
		if not tampered.is_empty():
			var after_a: Array = tampered[0][
				"participants_after_a"
			]
			if not after_a.is_empty():
				after_a[0]["size"] = int(
					after_a[0]["size"]
				) + 1
				var rejected := CombatLog.replay_records(
					tampered
				)
				_check(
					not bool(rejected.get("ok", true)),
					"回放器必须拒绝被篡改的战斗结果"
				)
				var entropy_tampered: Array[Dictionary] = (
					loaded["records"] as Array[Dictionary]
				).duplicate(true)
				entropy_tampered[0]["opening_dice"][0] = 11
				var entropy_rejected := CombatLog.replay_records(
					entropy_tampered
				)
				_check(
					not bool(entropy_rejected.get("ok", true)),
				"回放器必须拒绝越界开场骰"
				)
				var key_tampered: Array[Dictionary] = (
					loaded["records"] as Array[Dictionary]
				).duplicate(true)
				var key_context: Dictionary = key_tampered[0][
					"battle_context"
				]
				key_context["field_dice"][0] = (int(key_context["field_dice"][0]) + 1) % 11
				var key_rejected := CombatLog.replay_records(
					key_tampered
				)
				_check(
					not bool(key_rejected.get("ok", true)),
				"回放器必须拒绝与记录不一致的开场骰"
				)
	DirAccess.remove_absolute(
		ProjectSettings.globalize_path(log_path)
	)

	# (d) 镜像安全：开/关日志跑同种子同阵容，战斗结果逐位一致（日志只读、不改数值）。
	Combat.battle_log_enabled = false
	var rng_off := RandomNumberGenerator.new(); rng_off.seed = 12345
	var b_off := _make_field_battle([_make_army(0, 0, 2500, 11)], [_make_army(1, 1, 2300, 10)], 0.25, 4)
	_run_battle(b_off, rng_off)
	var off_a := b_off.side_size(b_off.side_a)
	var off_b := b_off.side_size(b_off.side_b)
	Combat.clear_battle_log()
	Combat.battle_log_enabled = true
	var rng_on := RandomNumberGenerator.new(); rng_on.seed = 12345
	var b_on := _make_field_battle([_make_army(0, 0, 2500, 11)], [_make_army(1, 1, 2300, 10)], 0.25, 4)
	_run_battle(b_on, rng_on)
	_check(b_on.side_size(b_on.side_a) == off_a and b_on.side_size(b_on.side_b) == off_b
		and b_on.winner_side == b_off.winner_side,
		"开启日志不得改变战斗结果：off=(%d,%d,w%d) on=(%d,%d,w%d)" % [
			off_a, off_b, b_off.winner_side,
			b_on.side_size(b_on.side_a), b_on.side_size(b_on.side_b), b_on.winner_side])

	# 收尾：恢复默认关闭态，避免污染其他测试。
	Combat.battle_log_enabled = false
	Combat.clear_battle_log()


## [36b] 首都防御加成：城市作为首都时城防加成翻倍（真源 + 实战 + AI 估值三处一致）。
func _test_equivariant_ordering() -> void:
	print("[37] 镜像等变排序：城市镜像 + 军队 ID 置换不变")
	var gs := preload("res://tests/support/grid_world.gd").new()
	gs.generate_grid_world(12345)
	var city_order_ok := true
	for row_a in range(preload("res://tests/support/grid_world.gd").GRID / 2):
		for col_a in range(preload("res://tests/support/grid_world.gd").GRID / 2):
			var a := row_a * preload("res://tests/support/grid_world.gd").GRID + col_a
			var mirror_a := (
				row_a * preload("res://tests/support/grid_world.gd").GRID
				+ preload("res://tests/support/grid_world.gd").GRID - 1 - col_a
			)
			for row_b in range(preload("res://tests/support/grid_world.gd").GRID / 2):
				for col_b in range(preload("res://tests/support/grid_world.gd").GRID / 2):
					var b := row_b * preload("res://tests/support/grid_world.gd").GRID + col_b
					var mirror_b := (
						row_b * preload("res://tests/support/grid_world.gd").GRID
						+ preload("res://tests/support/grid_world.gd").GRID - 1 - col_b
					)
					if (
						EquivariantOrder.city_id_less(
							gs, 0, a, b
						)
						!= EquivariantOrder.city_id_less(
							gs, 1, mirror_a, mirror_b
						)
					):
						city_order_ok = false
	_check(
		city_order_ok,
		"势力局部城市物理序应在水平镜像国家间严格等变"
	)

	var army_a := _make_army(1, 0, 1000, 10, 10)
	army_a.location_city = 0
	army_a.move_from = 0
	var army_b := _make_army(999, 0, 1000, 10, 10)
	army_b.location_city = 8
	army_b.move_from = 8
	var before := EquivariantOrder.army_less(
		gs, 0, army_a, army_b
	)
	army_a.id = 999999
	army_b.id = -100
	var after := EquivariantOrder.army_less(
		gs, 0, army_a, army_b
	)
	_check(
		before == after,
		"交换军队 ID 不得改变决策物理顺序"
	)

	# 首都与领土质心均落在中轴时，没有可等变的固定左右朝向；镜像城市
	# 必须落入同一轨道键，而不是隐式固定为“向右”。
	for city in gs.cities:
		city.owner_nation = 3
	gs.nations[0].capital_city_id = 0
	gs.cities[0].owner_nation = 0
	gs.cities[0].map_position = Vector2(0.5, 0.5)
	for city_id in [1, 2]:
		gs.cities[city_id].owner_nation = 0
		gs.cities[city_id].map_position = Vector2(
			0.4 if city_id == 1 else 0.6,
			0.25
		)
		gs.cities[city_id].terrain_height = 0.5
		gs.cities[city_id].terrain_relief = 0.5
	EquivariantOrder._city_rank_cache.clear()
	_check(
		is_zero_approx(
			EquivariantOrder._nation_forward_sign(gs, 0)
		)
			and EquivariantOrder.city_key(gs, 0, 1)
				== EquivariantOrder.city_key(gs, 0, 2)
			and not EquivariantOrder.city_id_less(
				gs, 0, 1, 2
			)
			and not EquivariantOrder.city_id_less(
				gs, 0, 2, 1
			),
		"中轴自映射势力必须使用 abs(x-0.5) 轨道，不能任意选择全局方向"
	)


## [38] 审查闭环：跨回合援军、真实预备队、单军溃退、有效围城、日补给。
func _test_remaining_combat_risk_closures() -> void:
	print("[38] 残余机制闭环：跨日援军 + 显式预备队 + 单军溃退 + 有效围城 + 日补给")

	# 两批援军跨两个回合抵达，每批仅按当时兵力与士气合并。
	var tired := _make_army(10000, 0, 1000, 0, 10)
	tired.morale = 0.30
	var enemy := _make_army(10001, 1, 20000, 0, 10)
	var reinforcement_battle := _make_field_battle(
		[tired],
		[enemy],
		0.0,
		4
	)
	reinforcement_battle.edge.max_manpower = 30000
	for batch in range(2):
		var old_size := reinforcement_battle.side_size(reinforcement_battle.side_a)
		var old_morale := tired.morale
		var fresh := _make_army(
			10002 + batch,
			0,
			5000,
			0,
			10
		)
		reinforcement_battle.side_a.append(fresh)
		reinforcement_battle.reinforce_fresh_a.append(fresh)
		var merged := (old_morale * float(old_size) + fresh.morale * float(fresh.size)) / float(old_size + fresh.size)
		CombatFixture.resolve_round(reinforcement_battle)
		_check(tired.morale < merged and _approx(tired.morale, fresh.morale), "跨回合援军只共享加权士气，不额外提振")

	# (b) 5000 正面只能投入第一军；完整预备队首轮不伤亡、不掉战斗士气。
	var frontline := _make_army(10010, 0, 5000, 10, 10)
	var reserve := _make_army(10011, 0, 4000, 10, 10)
	var opponent := _make_army(10012, 1, 5000, 10, 10)
	var frontage_battle := _make_field_battle(
		[frontline, reserve],
		[opponent],
		0.0,
		4
	)
	frontage_battle.edge.max_manpower = 5000
	CombatFixture.resolve_round(frontage_battle)
	_check(
		reserve.size == 4000 and reserve.morale < 1.0 and _approx(reserve.morale, frontline.morale),
		"完整预备队保持兵力但共享组织度损耗，实为 size=%d morale=%.4f"
			% [reserve.size, reserve.morale]
	)
	_check(
		frontline.size < 5000 and frontline.morale < 1.0,
		"前线軍承担伤亡，全军承担士气侵蚀"
	)
	frontline.size = 0
	var reserve_before := reserve.size
	CombatFixture.resolve_round(frontage_battle)
	_check(
		reserve.size < reserve_before and reserve.morale < 1.0,
		"前线退出后，预备队应在下一轮补入并开始承受战斗损耗"
	)

	# (c) 单军跌破 ARMY_ROUT_THRESHOLD 后立即离开战斗侧，健康预备队继续作战。
	var near_rout := _make_army(10020, 0, 5000, 10, 10)
	near_rout.morale = Combat.ARMY_ROUT_THRESHOLD + 0.001
	var healthy := _make_army(10021, 0, 4000, 10, 10)
	var rout_enemy := _make_army(10022, 1, 5000, 10, 10)
	var rout_battle := _make_field_battle(
		[near_rout, healthy],
		[rout_enemy],
		0.0,
		4
	)
	rout_battle.edge.max_manpower = 5000
	CombatFixture.resolve_round(rout_battle)
	_check(
		rout_battle.routed_a.is_empty()
			and rout_battle.side_a.has(near_rout)
			and rout_battle.side_a.has(healthy)
			and _approx(near_rout.morale, healthy.morale)
			and not rout_battle.finished,
		"低士气军应与健康军共享组织度，不得独立溃退"
	)
	var promotion_state := preload("res://tests/support/grid_world.gd").new()
	promotion_state.generate_grid_world(38042)
	promotion_state.armies.clear()
	var broken_challenger := _make_army(
		10023,
		0,
		1000,
		10,
		10
	)
	broken_challenger.morale = (
		Combat.ARMY_ROUT_THRESHOLD - 0.001
	)
	broken_challenger.location_city = (
		promotion_state.cities_of(0)[0].id
	)
	broken_challenger.move_from = broken_challenger.location_city
	promotion_state.armies.append(broken_challenger)
	var promotion_battle := Battle.new()
	promotion_battle.kind = Battle.Kind.SIEGE
	promotion_battle.city = promotion_state.cities_of(1)[0]
	promotion_battle.side_b.append(broken_challenger)
	var promotion_sim := Simulation.new()
	promotion_sim.setup(promotion_state)
	promotion_sim._promote_challengers(promotion_battle)
	_check(
		promotion_battle.finished
			and promotion_battle.side_a.is_empty(),
		"低于单军阈值的挑战者不得绕过战斗回合接管围城"
	)
	var healthy_challenger := _make_army(
		10024,
		0,
		1000,
		10,
		10
	)
	var takeover_battle := Battle.new()
	takeover_battle.kind = Battle.Kind.SIEGE
	takeover_battle.city = promotion_state.cities_of(1)[0]
	takeover_battle.side_b.append(healthy_challenger)
	takeover_battle.reinforce_fresh_b.append(
		healthy_challenger
	)
	takeover_battle.frontline_priority_b[
		healthy_challenger
	] = 2
	promotion_sim._promote_challengers(takeover_battle)
	_check(
		takeover_battle.side_a.has(healthy_challenger)
			and takeover_battle.reinforce_fresh_a.has(
				healthy_challenger
			)
			and takeover_battle.field_dice.is_empty()
			and takeover_battle.assault_dice.is_empty()
			and takeover_battle.side_b.is_empty()
			and takeover_battle.reinforce_fresh_b.is_empty(),
		"挑战者接管围城时应迁移新援状态并清空旧 side_b 身份"
	)
	promotion_sim.free()

	# (d) 围城只计算城墙正面内、受组织度和当日补给修正的有效兵力。
	var siege_full := _make_army(10030, 0, 10000, 10, 10)
	var siege_tired := _make_army(10031, 0, 10000, 10, 10)
	siege_tired.morale = 0.50
	var siege_unsupplied := _make_army(10032, 0, 10000, 10, 10)
	siege_unsupplied.supply_ratio = 0.50
	var full_strength := Combat.effective_siege_strength([siege_full])
	var tired_strength := Combat.effective_siege_strength([siege_tired])
	var unsupplied_strength := Combat.effective_siege_strength([
		siege_unsupplied
	])
	_check(
		full_strength == 10000
			and tired_strength < full_strength
			and unsupplied_strength < full_strength,
		"低士气/部分缺粮必须降低有效围城兵力：full=%d tired=%d supply=%d"
			% [full_strength, tired_strength, unsupplied_strength]
	)
	var siege_mass_a := _make_army(10033, 0, 10000, 10, 10)
	var siege_mass_b := _make_army(10034, 0, 10000, 10, 10)
	_check(
		Combat.effective_siege_strength([
			siege_mass_a,
			siege_mass_b,
		]) == Combat.SIEGE_FRONTAGE,
		"超额围城兵力应受城墙正面 %d 限制"
			% Combat.SIEGE_FRONTAGE
	)

	# (e) 军粮按存续编制结算：30天总耗保持月口径，战损不释放维护费。
	var supply_state := preload("res://tests/support/grid_world.gd").new()
	supply_state.generate_grid_world(38038)
	var supply_sim := Simulation.new()
	supply_sim.setup(supply_state)
	supply_state.armies.clear()
	var supply_city := supply_state.cities_of(0)[0]
	_set_single_warehouse(
		supply_state,
		0,
		supply_city.id,
		100
	)
	var supplied_army := _make_army(10040, 0, 12000, 10, 10)
	supplied_army.location_city = supply_city.id
	supplied_army.move_from = supply_city.id
	supply_state.armies.append(supplied_army)
	for day in range(1, 31):
		supply_state.day = day
		supply_sim._resolve_supply()
	_check(
		supply_city.food_storage == 62,
		"12000残兵的15000人编制30天应消耗38粮，不得按日ceil放大，实余 %d"
			% supply_city.food_storage
	)
	supplied_army.size = 24000
	supply_city.food_storage = 1
	supply_state.day = 31
	supply_sim._resolve_supply()
	_check(
		_approx(supplied_army.supply_ratio, 0.5)
			and supplied_army.starving,
		"同月兵力翻倍且仅余 1 粮时，当日 2 粮需求应立即得到 0.5 满足率，实为 %.3f"
			% supplied_army.supply_ratio
	)
	supply_sim.free()

	# (f) 同日增援资格必须按冻结战线批量判定；后方第一军加入不能把战线
	# 推回并让更远的第二军级联加入。
	var join_state := preload("res://tests/support/grid_world.gd").new()
	join_state.generate_grid_world(38039)
	join_state.armies.clear()
	join_state.battles.clear()
	var join_edge := join_state.edges[0]
	join_state.set_diplomatic_relation(
		0,
		1,
		GameState.DiplomaticRelation.WAR
	)
	var core_a := _place_army_on_edge(
		join_state, 10050, 0,
		join_edge.city_a, join_edge.city_b, 0.40
	)
	var core_b := _place_army_on_edge(
		join_state, 10051, 1,
		join_edge.city_b, join_edge.city_a, 0.40
	)
	var near_b := _place_army_on_edge(
		join_state, 10052, 1,
		join_edge.city_b, join_edge.city_a, 0.30
	)
	var far_b := _place_army_on_edge(
		join_state, 10053, 1,
		join_edge.city_b, join_edge.city_a, 0.20
	)
	var existing := join_state.new_battle(Battle.Kind.FIELD)
	existing.edge = join_edge
	existing.contact_dist_a = 0.40 * float(join_edge.distance)
	existing.contact_dist_b = 0.60 * float(join_edge.distance)
	existing.side_a.append(core_a)
	existing.side_b.append(core_b)
	for core in [core_a, core_b]:
		core.state = Army.State.FIGHTING
		core.battle_id = existing.id
	var join_sim := Simulation.new()
	join_sim.setup(join_state)
	join_sim._detect_encounters()
	_check(
		existing.side_b.has(near_b)
			and not existing.side_b.has(far_b)
			and far_b.battle_id == -1
			and _approx(
				existing.contact_dist_b,
				0.60 * float(join_edge.distance)
			),
		"同日增援应冻结资格且后军不得把反向战线推回"
	)
	join_sim.free()

	var initial_join_state := preload("res://tests/support/grid_world.gd").new()
	initial_join_state.generate_grid_world(38041)
	initial_join_state.armies.clear()
	initial_join_state.battles.clear()
	var initial_edge := initial_join_state.edges[0]
	initial_join_state.set_diplomatic_relation(
		0,
		1,
		GameState.DiplomaticRelation.WAR
	)
	_place_army_on_edge(
		initial_join_state, 10054, 0,
		initial_edge.city_a, initial_edge.city_b, 0.45
	)
	_place_army_on_edge(
		initial_join_state, 10055, 1,
		initial_edge.city_b, initial_edge.city_a, 0.45
	)
	var initial_near := _place_army_on_edge(
		initial_join_state, 10056, 1,
		initial_edge.city_b, initial_edge.city_a, 0.35
	)
	var initial_far := _place_army_on_edge(
		initial_join_state, 10057, 1,
		initial_edge.city_b, initial_edge.city_a, 0.25
	)
	var initial_join_sim := Simulation.new()
	initial_join_sim.setup(initial_join_state)
	initial_join_sim._detect_encounters()
	var initial_nation_one_side: Array[Army] = []
	if initial_join_state.battles.size() == 1:
		var initial_battle := initial_join_state.battles[0]
		initial_nation_one_side = (
			initial_battle.side_a
			if (
				not initial_battle.side_a.is_empty()
				and initial_battle.side_a[0].owner_nation == 1
			)
			else initial_battle.side_b
		)
	_check(
		initial_join_state.battles.size() == 1
			and initial_nation_one_side.has(initial_near)
			and not initial_nation_one_side.has(initial_far),
		"新战斗首日也应冻结增援资格，禁止逐支加入形成级联"
	)
	initial_join_sim.free()

func _make_atomic_coalition_peace_fixture(seed: int) -> Dictionary:
	var gs := preload("res://tests/support/grid_world.gd").new()
	gs.generate_grid_world(seed)
	gs.armies.clear()
	gs.battles.clear()
	for nation_a in range(gs.nations.size()):
		for nation_b in range(nation_a + 1, gs.nations.size()):
			gs.set_diplomatic_relation(
				nation_a, nation_b,
				GameState.DiplomaticRelation.NEUTRAL
			)
	gs.set_diplomatic_relation(0, 1, GameState.DiplomaticRelation.WAR)
	var occupied_city: City = null
	for center_value in gs.administrative_center_city_ids:
		var candidate := gs.cities[int(center_value)]
		if (
			candidate.owner_nation == 1
			and not candidate.is_capital
			and not candidate.has_warehouse
		):
			occupied_city = candidate
			break
	assert(occupied_city != null)
	occupied_city.owner_nation = 0
	occupied_city.occupation_sponsor_nation = 0
	gs.ownership_revision += 1
	gs.set_war_objective(0, 1, occupied_city.id, "原子和平回滚目标")
	gs.nations[0].war_mobilization_target_troops = 34567
	gs.nations[0].war_mobilization_until_day = gs.day + 90
	gs.nations[0].war_mobilization_reason = "原子和平回滚动员"
	var attacker := _make_army(320250, 0, 5000, 10, 10)
	var defender := _make_army(320251, 1, 5000, 10, 10)
	attacker.location_city = occupied_city.id
	attacker.move_from = occupied_city.id
	defender.location_city = occupied_city.id
	defender.move_from = occupied_city.id
	gs.armies.append(attacker)
	gs.armies.append(defender)
	var battle := gs.new_battle(Battle.Kind.FIELD)
	battle.side_a.append(attacker)
	battle.side_b.append(defender)
	attacker.state = Army.State.FIGHTING
	attacker.battle_id = battle.id
	defender.state = Army.State.FIGHTING
	defender.battle_id = battle.id
	var sim := Simulation.new()
	sim.setup(gs)
	# setup 的财政同步是夹具初始化的一部分；测试指纹从计划完成后才冻结。
	return {
		"state": gs,
		"simulation": sim,
		"occupied_city_id": occupied_city.id,
	}


func _coalition_peace_fingerprint(
	gs: GameState,
	sim: Simulation
) -> Dictionary:
	var result := _territory_fingerprint(gs)
	result["war_objectives"] = gs.war_objectives.duplicate(true)
	result["war_relation_ids"] = gs.war_relation_ids.duplicate(true)
	result["rebellions"] = gs.rebellions.duplicate(true)
	result["diplomatic_history"] = gs.diplomatic_history.duplicate(true)
	result["ai_last_decision_day"] = sim._ai_last_decision_day
	var mobilization_rows: Array[Dictionary] = []
	for nation in gs.nations:
		mobilization_rows.append({
			"id": nation.id,
			"last_court_expense_due": nation.last_court_expense_due,
			"last_court_expense_paid": nation.last_court_expense_paid,
			"last_court_expense_rate": nation.last_court_expense_rate,
			"war_mobilization_target_troops": (
				nation.war_mobilization_target_troops
			),
			"war_mobilization_until_day": nation.war_mobilization_until_day,
			"war_mobilization_reason": nation.war_mobilization_reason,
			"war_preparation_target_nation": (
				nation.war_preparation_target_nation
			),
			"campaign_objective_center": (
				gs.campaign_objective_center(nation.id)
			),
		})
	result["mobilization"] = mobilization_rows
	var army_runtime_rows: Array[Dictionary] = []
	for army in gs.armies:
		army_runtime_rows.append({
			"id": army.id,
			"owner": army.owner_nation,
			"size": army.size,
			"state": army.state,
			"battle_id": army.battle_id,
			"path": army.path.duplicate(),
			"location_city": army.location_city,
			"move_from": army.move_from,
			"move_to": army.move_to,
			"move_progress": army.move_progress,
			"on_edge": army.on_edge,
			"diplomatic_repatriation": army.diplomatic_repatriation,
			"forced_retreat": army.forced_retreat,
			"ai_action": army.ai_action,
			"ai_target_city": army.ai_target_city,
			"ai_order_until_day": army.ai_order_until_day,
			"ai_order_reason": army.ai_order_reason,
			"campaign_war_id": army.campaign_war_id,
		})
	result["army_runtime"] = army_runtime_rows
	var battle_rows: Array[Dictionary] = []
	for battle in gs.battles:
		var side_a_ids: Array[int] = []
		var side_b_ids: Array[int] = []
		for army in battle.side_a:
			side_a_ids.append(army.id)
		for army in battle.side_b:
			side_b_ids.append(army.id)
		battle_rows.append({
			"id": battle.id,
			"kind": battle.kind,
			"finished": battle.finished,
			"winner_side": battle.winner_side,
			"round_no": battle.round_no,
			"side_b_defends_city": battle.side_b_defends_city,
			"contact_dist_a": battle.contact_dist_a,
			"contact_dist_b": battle.contact_dist_b,
			"side_a": side_a_ids,
			"side_b": side_b_ids,
			"city_id": battle.city.id if battle.city != null else -1,
			"edge_key": (
				GameState.edge_key(battle.edge.city_a, battle.edge.city_b)
				if battle.edge != null
				else -1
			),
		})
	result["battles"] = battle_rows
	return result


func _transfer_all_owned_cities_for_fixture(
	gs: GameState,
	former_owner: int,
	recipient: int,
	reason: String
) -> Dictionary:
	var operations: Array[Dictionary] = []
	for city in gs.cities:
		if city.owner_nation != former_owner:
			continue
		operations.append({
			"city_id": city.id,
			"controller_id": recipient,
			"legal_owner_id": recipient,
			"sponsor_id": -1,
			"reset_political_target": true,
			"stock_policy": (
				GameState.TerritoryStockDisposition.MOVE_TO_NEW_POOL
			),
			"reason": reason,
		})
	return gs.apply_territory_transaction(operations)


func _territory_fingerprint(gs: GameState) -> Dictionary:
	var city_rows: Array[Dictionary] = []
	for city in gs.cities:
		city_rows.append({
			"id": city.id,
			"owner": city.owner_nation,
			"legal": gs.recognized_owner_of(city.id),
			"sponsor": city.occupation_sponsor_nation,
			"capital": city.is_capital,
			"warehouse": city.has_warehouse,
			"food": city.food_storage,
		})
	var nation_rows: Array[Dictionary] = []
	for nation in gs.nations:
		nation_rows.append({
			"id": nation.id,
			"alive": nation.alive,
			"capital_city_id": nation.capital_city_id,
			"warehouse_city_ids": nation.warehouse_city_ids.duplicate(),
			"granary_food": nation.granary_food,
			"manpower_pool": nation.manpower_pool,
			"treasury_gold": nation.treasury_gold,
			"last_rebellion_day": nation.last_rebellion_day,
		})
	var army_rows: Array[Dictionary] = []
	for army in gs.armies:
		army_rows.append({
			"id": army.id,
			"owner": army.owner_nation,
			"size": army.size,
			"battle_group_id": army.battle_group_id,
			"campaign_war_id": army.campaign_war_id,
			"occupation_claimant": army.occupation_claimant_nation,
			"state": army.state,
			"battle_id": army.battle_id,
		})
	return {
		"cities": city_rows,
		"nations": nation_rows,
		"armies": army_rows,
		"suzerainty": gs.suzerainty.duplicate(true),
		"diplomatic_relations": gs.diplomatic_relations.duplicate(true),
		"diplomatic_since_day": gs.diplomatic_since_day.duplicate(true),
		"truce_until_day": gs.truce_until_day.duplicate(true),
		"war_relation_ids": gs.war_relation_ids.duplicate(true),
		"campaign_pairs": NativeSnapshotBuilder.build(gs)["campaign_pairs"],
		"next_war_id": gs.next_war_id,
		"ownership_revision": gs.ownership_revision,
		"diplomacy_revision": gs.diplomacy_revision,
	}


func _make_edge(danger: float, distance: int) -> Edge:
	var e := Edge.new()
	e.city_a = 0
	e.city_b = 1
	e.distance = distance
	e.danger = danger
	e.max_manpower = 45000
	return e


func _set_warehouses(
	gs: GameState,
	nation_id: int,
	city_ids: Array[int],
	stocks: Array[int],
	capital_id: int = -1
) -> void:
	var nation := gs.nations[nation_id]
	for old_id in nation.warehouse_city_ids:
		var old_city := gs.cities[old_id]
		old_city.is_capital = false
		old_city.has_warehouse = false
		old_city.food_storage = 0
	nation.warehouse_city_ids = city_ids.duplicate()
	nation.capital_city_id = capital_id if capital_id != -1 else (
		city_ids[0] if not city_ids.is_empty() else -1
	)
	for i in range(city_ids.size()):
		var city := gs.cities[city_ids[i]]
		city.has_warehouse = true
		city.is_capital = city.id == nation.capital_city_id
		city.food_storage = stocks[i]


func _set_single_warehouse(gs: GameState, nation_id: int, city_id: int, stock: int) -> void:
	_set_warehouses(
		gs,
		nation_id,
		[city_id] as Array[int],
		[stock] as Array[int],
		city_id
	)


func _ensure_civil_war_fixture_contact(gs: GameState, root: int, subject: int) -> void:
	# These fixtures test mobilization and annexation, while isolated outcomes have
	# their own tests. Supply an explicit military road if donated fiefs are enclaves.
	if subject < 0 or root < 0:
		return
	if MilitaryReachability.contact(gs, [root], [subject], [root, subject]) \
		or MilitaryReachability.contact(gs, [subject], [root], [root, subject]):
		return
	var origin := gs.nations[root].capital_city_id
	var destination := gs.nations[subject].capital_city_id
	gs._add_edge(origin, destination)
	var route := gs.edge_of(origin, destination)
	route.kind = Edge.Kind.LAND
	route.max_manpower = 100000
	gs.road_network_revision += 1


func _enfeoffable_region(
	gs: GameState,
	nation_id: int,
	minimum_city_count: int = 1
) -> Array[int]:
	var result: Array[int] = []
	var seen: Dictionary = {}
	var capital_id := gs.nations[nation_id].capital_city_id
	var centers: Array[int] = []
	for center_value in gs.administrative_center_city_ids:
		centers.append(int(center_value))
	centers.sort()
	for center_id in centers:
		if center_id == capital_id or gs.cities[center_id].owner_nation != nation_id:
			continue
		var members := gs.normalize_enfeoff_region(
			nation_id,
			[center_id] as Array[int]
		)
		if members.is_empty():
			continue
		for city_id in members:
			if not seen.has(city_id):
				seen[city_id] = true
				result.append(city_id)
		if result.size() >= minimum_city_count:
			break
	if result.is_empty():
		for center_id in centers:
			if center_id == capital_id:
				continue
			var donor_region := gs.administrative_members(center_id)
			if donor_region.is_empty() or donor_region.has(capital_id):
				continue
			var donor_owner := gs.cities[center_id].owner_nation
			if (
				donor_owner == nation_id
				or (
					donor_owner >= 0
					and gs.suzerainty_root(donor_owner)
						== gs.suzerainty_root(nation_id)
				)
			):
				continue
			var operations: Array[Dictionary] = []
			for city_id in donor_region:
				operations.append({
					"city_id": city_id,
					"controller_id": nation_id,
					"legal_owner_id": nation_id,
					"sponsor_id": -1,
					"reset_political_target": true,
					"stock_policy": GameState.TerritoryStockDisposition.RETURN_TO_OLD_POOL,
					"reason": "test_enfeoffable_region",
				})
			var transfer := gs.apply_territory_transaction(operations)
			if bool(transfer.get("ok", false)):
				result = donor_region
				for _closure_pass in range(gs.administrative_region_count + 1):
					var closure := gs.enfeoff_region_closure(nation_id, result)
					var complete: Dictionary = {}
					for city_id in closure:
						var closure_center := gs.administrative_center_of(city_id)
						for member_id in gs.administrative_members(closure_center):
							complete[member_id] = true
					var complete_ids: Array[int] = []
					complete_ids.assign(complete.keys())
					complete_ids.sort()
					var completion_operations: Array[Dictionary] = []
					for member_id in complete_ids:
						if (
							gs.cities[member_id].owner_nation == nation_id
							and gs.recognized_owner_of(member_id) == nation_id
						):
							continue
						completion_operations.append({
							"city_id": member_id,
							"controller_id": nation_id,
							"legal_owner_id": nation_id,
							"sponsor_id": -1,
							"reset_political_target": true,
							"stock_policy": GameState.TerritoryStockDisposition.RETURN_TO_OLD_POOL,
							"reason": "test_enfeoffable_closure",
						})
					if not completion_operations.is_empty():
						var completion := gs.apply_territory_transaction(
							completion_operations
						)
						if not bool(completion.get("ok", false)):
							result.clear()
							break
					result = gs.normalize_enfeoff_region(nation_id, complete_ids)
					if not result.is_empty():
						break
				if not result.is_empty():
					break
	result.sort()
	if result.size() >= gs.land_cities_of(nation_id).size():
		return [] as Array[int]
	return result


func _make_army(aid: int, nation: int, size: int, atk: int, def_v: int = 10) -> Army:
	var a := Army.new()
	a.id = aid
	a.owner_nation = nation
	a.size = size
	a.attack = atk
	a.defense = def_v
	return a


## 构造一场野战：side_a / side_b 各军在边中点相遇（contact = L/2）。
func _make_field_battle(side_a: Array, side_b: Array, danger: float, distance: int) -> Battle:
	var b := Battle.new()
	b.id = 0
	b.kind = Battle.Kind.FIELD
	b.edge = _make_edge(danger, distance)
	b.contact_dist_a = distance / 2.0
	b.contact_dist_b = distance / 2.0
	# 通用机制单测隔离战术运气，专门的 item 8 统计测试负责验证独立随机。
	for a in side_a:
		b.side_a.append(a)
	for a in side_b:
		b.side_b.append(a)
	return b


## 跑完一场战斗（回合直到结束），返回回合数。带硬上限防死循环。
func _run_battle(battle: Battle, rng: RandomNumberGenerator) -> int:
	var guard := 0
	while not battle.finished and guard < 1000:
		CombatFixture.resolve_round(battle)
		guard += 1
	return guard


func _battle_force_morale(
	active: Array[Army],
	routed: Array[Army]
) -> float:
	var morale_mass := 0.0
	var manpower := 0
	for army in active + routed:
		if army.size <= 0:
			continue
		morale_mass += float(army.size) * army.morale
		manpower += army.size
	return (
		morale_mass / float(manpower)
		if manpower > 0
		else 0.0
	)


func _place_army_on_edge(gs, id: int, nation: int, from_city: int, to_city: int, progress: float) -> Army:
	var a := _make_army(id, nation, 1000, 10)
	a.state = Army.State.MOVING
	a.move_from = from_city
	a.move_to = to_city
	a.move_progress = progress
	a.on_edge = true
	gs.armies.append(a)
	return a
