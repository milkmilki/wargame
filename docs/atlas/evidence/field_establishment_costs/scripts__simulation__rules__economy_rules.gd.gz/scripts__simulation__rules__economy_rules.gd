class_name EconomyRules
extends RefCounted
## Pure monthly fiscal aggregation. Simulation supplies policy callbacks so
## this module does not own campaign, ruler, or cache lifecycle state.


static func monthly_gold_flows_from_trade(
	state: GameState,
	trade: Dictionary,
	effective_upkeep: Callable,
	garrison_upkeep: Callable,
	city_output: Callable,
	tribute_rate: Callable,
	city_outputs: PackedInt32Array = PackedInt32Array(),
	garrison_upkeep_values: Array[int] = []
) -> Array[Dictionary]:
	var upkeep_by_nation := _upkeep_by_nation(
		state,
		effective_upkeep,
		garrison_upkeep,
		garrison_upkeep_values
	)
	var result := _empty_reports(state, trade, upkeep_by_nation)
	_add_city_income(state, result, city_output, city_outputs)
	_add_tribute_flows(state, result, tribute_rate)
	_finalize_balances(state, result)
	return result


static func _upkeep_by_nation(
	state: GameState,
	effective_upkeep: Callable,
	garrison_upkeep: Callable,
	garrison_upkeep_values: Array[int] = []
) -> Dictionary:
	var field: Array[int] = []
	var garrison: Array[int] = []
	field.resize(state.nations.size())
	garrison.resize(state.nations.size())
	field.fill(0)
	garrison.fill(0)
	for army in state.armies:
		if (
			army.size <= 0
			or army.owner_nation < 0
			or army.owner_nation >= field.size()
		):
			continue
		field[state.financial_nation_of(army.owner_nation)] += GameState.army_monthly_upkeep(army.maintenance_manpower())
	for nation in state.nations:
		field[nation.id] = int(effective_upkeep.call(
			state, nation.id, field[nation.id]
		))
		garrison[nation.id] = (
			garrison_upkeep_values[nation.id]
			if nation.id >= 0 and nation.id < garrison_upkeep_values.size()
			else int(garrison_upkeep.call(state, nation.id))
		)
	return {"field": field, "garrison": garrison}


static func _empty_reports(
	state: GameState,
	trade: Dictionary,
	upkeep_by_nation: Dictionary
) -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	for nation in state.nations:
		var food_trade_income := trade_array_value(
			trade, "nation_food_sale_income", nation.id
		)
		# 采购相关字段为兼容旧快照保留；当前贸易结算固定返回 0。
		var food_trade_expense := trade_array_value(
			trade, "nation_food_cost", nation.id
		)
		var manpower_trade_expense := trade_array_value(
			trade, "nation_manpower_cost", nation.id
		)
		var trade_gross_income := trade_array_value(
			trade, "nation_trade_gold", nation.id
		)
		var trade_tax_income := maxi(
			trade_gross_income - food_trade_income, 0
		)
		var trade_net_income := (
			trade_tax_income
			+ food_trade_income
			- food_trade_expense
			- manpower_trade_expense
		)
		var field_upkeep := int(
			(upkeep_by_nation["field"] as Array)[nation.id]
		)
		var garrison_upkeep := int(
			(upkeep_by_nation["garrison"] as Array)[nation.id]
		)
		result.append({
			"nation_id": nation.id,
			"city_income": 0,
			"trade_tax_income": trade_tax_income,
			"food_trade_income": food_trade_income,
			"food_trade_expense": food_trade_expense,
			"manpower_trade_expense": manpower_trade_expense,
			"trade_net_income": trade_net_income,
			"tribute_received": 0,
			"tribute_paid": 0,
			"net_income": 0,
			"field_army_upkeep": field_upkeep,
			"garrison_upkeep": garrison_upkeep,
			"military_upkeep": field_upkeep + garrison_upkeep,
			"balance": 0,
		})
	return result


static func _add_city_income(
	state: GameState,
	result: Array[Dictionary],
	city_output: Callable,
	city_outputs: PackedInt32Array = PackedInt32Array()
) -> void:
	for city in state.cities:
		if city.owner_nation < 0 or city.owner_nation >= result.size():
			continue
		var owner := state.financial_nation_of(city.owner_nation)
		result[owner]["city_income"] = (
			int(result[owner]["city_income"])
			+ (
				city_outputs[city.id]
				if city.id >= 0 and city.id < city_outputs.size()
				else int(city_output.call(state, city))
			)
		)


static func _add_tribute_flows(
	state: GameState,
	result: Array[Dictionary],
	tribute_rate: Callable
) -> void:
	for subject_value in state.suzerainty:
		var subject_id := int(subject_value)
		var overlord_id := state.overlord_of(subject_id)
		if (
			subject_id < 0
			or subject_id >= result.size()
			or overlord_id < 0
			or overlord_id >= result.size()
		):
			continue
		var tribute := int(floor(
			float(result[subject_id]["city_income"])
			* float(tribute_rate.call(state, subject_id))
		))
		result[subject_id]["tribute_paid"] = (
			int(result[subject_id]["tribute_paid"]) + tribute
		)
		result[overlord_id]["tribute_received"] = (
			int(result[overlord_id]["tribute_received"]) + tribute
		)


static func _finalize_balances(state: GameState, result: Array[Dictionary]) -> void:
	for nation_id in range(result.size()):
		var report: Dictionary = result[nation_id]
		var net_income := (
			int(report["city_income"])
			+ int(report["trade_net_income"])
			+ int(report["tribute_received"])
			- int(report["tribute_paid"])
		)
		report["net_income"] = net_income
		var base_rate := RulerProfile.court_expense_rate(state.nations[nation_id])
		var royal := RoyalTitles.report(state, nation_id)
		var basis_points := int(round(base_rate * 10000.0)) + int(royal.basis_points)
		var rate := float(basis_points) / 10000.0
		var due := int(int(maxi(net_income, 0)) * basis_points / 10000)
		report["court_base_expense_rate"] = base_rate
		report["royal_expense_basis_points"] = royal.basis_points
		report["royal_title_counts"] = royal.counts.duplicate()
		report["court_expense_rate"] = rate
		report["court_expense_due"] = due
		report["court_expense_paid"] = mini(due, maxi(state.nations[nation_id].treasury_gold + net_income, 0))
		report["income_after_court"] = net_income - due
		report["balance"] = net_income - due - int(report["military_upkeep"])


static func trade_array_value(
	trade_snapshot: Dictionary,
	key: String,
	index: int
) -> int:
	var values: Variant = trade_snapshot.get(key, [])
	if not (values is Array) or index < 0 or index >= values.size():
		return 0
	return int(values[index])
