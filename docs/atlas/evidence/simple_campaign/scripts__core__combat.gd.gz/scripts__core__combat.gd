class_name Combat
extends RefCounted
## 战斗解算（全静态）。EU4 式多回合：每 tick 打一个回合（固定发挥→伤亡→士气侵蚀），
## 士气先于兵力崩溃，故败方通常带残兵撤退。支持 N v M（火力按兵力聚合、伤亡按比例摊分）。
##
## 只读取 Battle 开场四骰，计算伤亡/士气与 size 扣减，并在一方崩溃时置 battle.finished。
## 不负责 armies 增删 / passing_count / 占领 / 撤退落位——那些由 Simulation 处理。

const DEF_REF: float = 10.0                ## 防御减伤参考：减伤系数 = DEF_REF/(DEF_REF+eff_def)
const K_ROUND: float = 120.0               ## 单回合伤害除数（越大每回合伤亡越小，战斗越久）

# ---- 开场四骰由 Battle 保存，解算不消费随机数 ----

# ---- 正面宽度 / 预备队（item 5：道路/地形/战斗类型决定同时参战兵力上限）----
## 一侧「正面宽度」= 同一时刻能投入前线交战的最大兵力。超出部分进入预备队：
## 预备队不贡献攻击、不受伤亡、不占用正面；前线部队损失后由预备队按序补入（下一回合自动重选）。
## 道路野战：正面 = 道路容量 edge.max_manpower（窄路限制大军展开）。
## 城下野战：真实守军出战时使用 SIEGE_FIELD_FRONTAGE，不再受进城道路限制。
## 纯攻城：正面 = 城墙可展开兵力 SIEGE_FRONTAGE（城墙周长有限，无法全军压城）。
## 无边信息兜底用 FRONTAGE_FALLBACK。拆分不增加总正面（基于总兵力的前 N 名，与军队数量无关，item 12）。
const FRONTAGE_FALLBACK: int = 15000
const SIEGE_FIELD_FRONTAGE: int = 50000
const SIEGE_FRONTAGE: int = 15000
const SIEGE_TWO_DIRECTION_ATTACK_MULT: float = 1.20
const SIEGE_THREE_DIRECTION_ATTACK_MULT: float = 1.30

# ---- 士气 ----
const MORALE_START: float = 1.0
const MORALE_FLOOR: float = 0.0            ## 士气跌破此值该军崩溃（Army.morale 下界）
const MORALE_CASUALTY_K: float = 1.2       ## 伤亡比例对士气的侵蚀系数
const MORALE_BASE_DECAY: float = 0.01      ## 每回合基础士气衰减（保证战斗必然收敛结束）
const MORALE_STARVE_DECAY: float = 0.10    ## 断粮方每回合额外士气衰减——粮草特色
const MORALE_RECOVERY_DAYS: int = 60       ## 满军费、满补给时从零士气恢复至上限的天数

# ---- 士气→战斗效率（item 2：士气是组织度而非第二血条）----
## 有效战斗力 = 名义战斗力 × combat_efficiency(morale)。
## efficiency = MIN + (1-MIN)*morale：满士气(1.0)→1.0（保持既有满士气标定不变），
## 零士气→MIN（仍能自卫但火力大幅下降，不再贡献完整伤害）。
const MIN_COMBAT_EFFICIENCY: float = 0.2
## 整侧溃败阈值（兵力加权派生士气）。不为 0：士气极低的一方在兵力归零前合理溃败。
const SIDE_ROUT_THRESHOLD: float = 0.15
## 单支军队溃退阈值：士气 <= 此值的军队视为已失去组织、退出前线（不再计入有效战力）。
const ARMY_ROUT_THRESHOLD: float = 0.05
const COMBAT_RULES_VERSION: int = 6

# ---- 边地形：danger 是唯一真源 ----
const ATTACK_DANGER_K: float = 0.50        ## 攻击惩罚固定系数
const DEFENSE_DANGER_K: float = 0.40       ## 初始防御惩罚系数
const HOLDING_TAU_DAYS: float = 30.0       ## 驻防适应时间常数
const HOLDING_ATTACK_MULTIPLIER: float = 0.50
const CITY_GARRISON_ATTACK_MULTIPLIER: float = 0.10
const HOLDING_DEFENSE_MULTIPLIER: float = 1.50
## 关隘（chokepoint）连续曲线（item 9：去数值断崖）。danger≥ONSET 进入"隘口带"：攻击倍率
## 从 ONSET 处的常规线性值连续、单调地降到 danger=1.0 时的地板 FLOOR，不再在阈值处硬跳变。
## 由此「地形参数小幅变化只产生小幅结果变化」（无 0.001 跨阈战力减半），同时极端地形仍强力压制进攻。
const CHOKEPOINT_DANGER_ONSET: float = 0.85  ## 隘口带起点：danger≥此值攻击惩罚加速下探（连续，非跳变）
const CHOKEPOINT_ATTACK_FLOOR: float = 0.25  ## danger=1.0 时的攻击倍率地板（隘口最极端处）

const SIEGE_STARVE_DEF_MULT: float = 0.3     ## 粮尽守军城防加成衰减系数（战力大幅下降）
# ---- 结构化战斗日志（item 15：调试与回放）----
## 默认关闭（零开销，满足"日志可关闭"）；启用后每个 resolve_round 末尾向 battle_log 追加
## 一条纯数据记录（无自然语言逻辑判断，满足"测试环境可读取"+"能定位战斗结果为何产生"）。
## 全静态：调用方（Simulation/测试）负责开关与清空。镜像安全——只读快照、不改任何战斗数值。
static var battle_log_enabled: bool = false
static var battle_log: Array[Dictionary] = []


static func holding_attack_multiplier(is_holding: bool) -> float:
	return HOLDING_ATTACK_MULTIPLIER if is_holding else 1.0


static func holding_defense_multiplier(is_holding: bool) -> float:
	return HOLDING_DEFENSE_MULTIPLIER if is_holding else 1.0


static func clear_battle_log() -> void:
	battle_log.clear()


## danger 对攻击力的固定惩罚，不随驻防时间变化。item 9：全程连续、单调、无阈值跳变。
##  danger∈[0, ONSET)：常规线性 1 - ATTACK_DANGER_K·danger（moderate 地形标定不变，danger=0.5→0.75）。
##  danger∈[ONSET, 1]：隘口带——从 ONSET 处的常规线性值连续下探到 danger=1 的地板 FLOOR。
## 两段在 danger=ONSET 处取值相同（C0 连续），故不存在「浮点跨阈战力减半」。
static func attack_multiplier(danger: float) -> float:
	var normalized := clampf(danger, 0.0, 1.0)
	var linear := 1.0 - ATTACK_DANGER_K * normalized
	if normalized < CHOKEPOINT_DANGER_ONSET:
		return clampf(linear, 0.0, 1.0)
	# 隘口带内按 [ONSET,1] 归一化的进度 t，从 ONSET 处线性值插值到地板 FLOOR（连续、单调递减）。
	var onset_value := 1.0 - ATTACK_DANGER_K * CHOKEPOINT_DANGER_ONSET
	var t := (normalized - CHOKEPOINT_DANGER_ONSET) / maxf(1.0 - CHOKEPOINT_DANGER_ONSET, 1e-6)
	return clampf(lerpf(onset_value, CHOKEPOINT_ATTACK_FLOOR, t), 0.0, 1.0)


## 防御方对地形的适应：惩罚随连续驻防天数指数衰减并无限趋近 0，但永不产生正加成。
static func defense_multiplier(danger: float, holding_days: float) -> float:
	var d := clampf(danger, 0.0, 1.0)
	var days := maxf(holding_days, 0.0)
	return clampf(1.0 - DEFENSE_DANGER_K * d * exp(-days / HOLDING_TAU_DAYS), 0.0, 1.0)


## 地形对守方的净利好系数（派生纯函数，唯一真源）：= 防御适应倍率 / 敌方跨边进攻倍率。
## danger 越高、连续驻防越久越利于据守（>1）；danger=0 时两倍率均为 1，退化为 1.0（平地无影响）。
## 供 AI 撤退判定（据守价值）与防区边选取（优先据守险要边）共用，保证认知与实战解算同源。
static func terrain_hold_bias(danger: float, holding_days: float) -> float:
	return (
		defense_multiplier(danger, holding_days)
		/ maxf(attack_multiplier(danger), 0.01)
	)


static func siege_attack_direction_count(
	battle: Battle
) -> int:
	if (
		battle == null
		or battle.kind != Battle.Kind.SIEGE
		or battle.city == null
	):
		return 1
	var origins := {}
	for army in battle.side_a:
		if (
			army.size <= 0
			or army.move_to != battle.city.id
			or army.move_from < 0
			or army.move_from == battle.city.id
		):
			continue
		origins[army.move_from] = true
	return maxi(origins.size(), 1)


static func siege_attack_damage_multiplier(
	battle: Battle
) -> float:
	if battle != null and battle.uses_field_combat_rules():
		return 1.0
	var directions := siege_attack_direction_count(battle)
	if directions >= 3:
		return SIEGE_THREE_DIRECTION_ATTACK_MULT
	if directions == 2:
		return SIEGE_TWO_DIRECTION_ATTACK_MULT
	return 1.0


## 解算一场战斗的一个回合，就地修改 battle 与其中军队的 size / 士气。
## 结束（一方崩溃或被歼灭）时置 battle.finished=true 与 winner_side(1/2)。
static func resolve_round(battle: Battle, day: int = -1) -> void:
	var field_rules := battle.uses_field_combat_rules()
	battle.routed_a.clear()
	battle.routed_b.clear()
	battle.prune_dead()
	if not field_rules:
		_extract_routed_armies(battle.side_a, battle.routed_a)
		_extract_routed_armies(battle.side_b, battle.routed_b)
	var size_a := battle.side_size(battle.side_a)
	var size_b := battle.side_size(battle.side_b)
	# 任一方已无可战军队：对称裁决。低于单军阈值的部队已移入 routed，
	# Simulation 会立即从真实战场位置启动撤退。
	if size_a <= 0 or size_b <= 0:
		battle.finished = true
		battle.winner_side = decide_winner(
			size_a <= 0 and battle.routed_a.is_empty(),
			size_b <= 0 and battle.routed_b.is_empty(),
			size_a <= 0 and not battle.routed_a.is_empty(),
			size_b <= 0 and not battle.routed_b.is_empty(),
			0.0,
			0.0
		)
		return

	if not Battle.valid_dice(battle.opening_dice()):
		push_error("Combat requires initialized opening dice")
		return
	battle.round_no += 1
	var log_reinforced_a := battle.reinforce_fresh_a.size() if battle_log_enabled else 0
	var log_reinforced_b := battle.reinforce_fresh_b.size() if battle_log_enabled else 0

	# 规范化两侧内部顺序（镜像等变的关键）：一切战斗数学（火力/防御/士气聚合、伤亡摊分）
	# 都按数组顺序做浮点求和，而浮点加法不满足结合律——同一军队多重集若插入顺序不同，
	# 求和会差 ~1 ULP，经除法与取整放大成 1 兵差、再经士气侵蚀累积破坏镜像。
	# 按纯物理键（兵力/攻/防/士气，全降序）规范排序后，聚合与摊分仅依赖物理多重集、
	# 与加入历史无关：镜像成对的两侧因物理量相同而得到逐位一致的求和。全物理键、无 id 依赖。
	_canonicalize_side(
		battle.side_a,
		battle.frontline_priority_a
	)
	_canonicalize_side(
		battle.side_b,
		battle.frontline_priority_b
	)

	var shared_a := battle.shared_morale_summary(battle.side_a) if field_rules else {}
	var shared_b := battle.shared_morale_summary(battle.side_b) if field_rules else {}
	var log_participants_before_a: Array[Dictionary] = []
	var log_participants_before_b: Array[Dictionary] = []
	var log_battle_context: Dictionary = {}
	if battle_log_enabled:
		log_participants_before_a = _side_log_snapshot(battle.side_a + battle.routed_a)
		log_participants_before_b = _side_log_snapshot(battle.side_b + battle.routed_b)
		log_battle_context = _battle_log_context(battle)
	if field_rules:
		battle.write_shared_morale(battle.side_a, float(shared_a.ratio))
		battle.write_shared_morale(battle.side_b, float(shared_b.ratio))
	battle.reinforce_fresh_a.clear()
	battle.reinforce_fresh_b.clear()
	# morale_before 的语义是「增援结算完成、伤亡发生前」。
	var log_morale_before_a := battle.side_morale(battle.side_a) if battle_log_enabled else 0.0
	var log_morale_before_b := battle.side_morale(battle.side_b) if battle_log_enabled else 0.0
	var morale_before_a := float(shared_a.effective) if field_rules else battle.side_morale(battle.side_a)
	var morale_before_b := float(shared_b.effective) if field_rules else battle.side_morale(battle.side_b)
	var combat_efficiency_a := combat_efficiency(morale_before_a) if field_rules else _side_combat_efficiency(
		battle.side_a
	)
	var combat_efficiency_b := combat_efficiency(morale_before_b) if field_rules else _side_combat_efficiency(
		battle.side_b
	)

	var danger := battle.edge.danger if battle.edge != null else 0.0
	var attack_pen_a := 1.0
	var attack_pen_b := 1.0
	var defense_pen_a := 1.0
	var defense_pen_b := 1.0
	if field_rules:
		var terrain_attack_penalty := attack_multiplier(danger)
		attack_pen_a = terrain_attack_penalty
		attack_pen_b = terrain_attack_penalty
		defense_pen_a = defense_multiplier(
			danger,
			battle.holding_days if battle.holding_side == 1 else 0.0
		)
		defense_pen_b = defense_multiplier(
			danger,
			battle.holding_days if battle.holding_side == 2 else 0.0
		)
		if battle.holding_side == 1:
			attack_pen_a *= holding_attack_multiplier(true)
			defense_pen_a *= holding_defense_multiplier(true)
		elif battle.holding_side == 2:
			attack_pen_b *= holding_attack_multiplier(true)
			defense_pen_b *= holding_defense_multiplier(true)

	# 城市守军通过临时 Army 自身的倍率参与攻防；普通驻城野战军不再获得工事加成。
	var garrison_b := 0

	# 正面宽度（item 5）：每轮按规范物理序明确投入各军的前线兵力。
	# Reserves avoid casualties, but share field morale with the fighting side.
	var dice := battle.opening_dice()
	var performance_a := Battle.dice_multiplier(dice[0])
	var performance_b := Battle.dice_multiplier(dice[1])
	var frontage := combat_frontage(battle)
	var frontage_a := int(frontage * (10 + dice[2]) / 10)
	var frontage_b := int(frontage * (10 + dice[3]) / 10)
	var frontline_a := frontline_allocation(
		battle.side_a,
		frontage_a,
		battle.frontline_priority_a,
		field_rules
	)
	var frontline_b := frontline_allocation(
		battle.side_b,
		frontage_b,
		battle.frontline_priority_b,
		field_rules
	)
	var frontline_size_a := _frontline_size(frontline_a)
	var frontline_size_b := _frontline_size(frontline_b)

	# 火力只由本轮明确投入的前线兵力贡献。
	var fire_a := (
		_frontline_attack(frontline_a, combat_efficiency_a)
		* attack_pen_a
		* performance_a
		* siege_attack_damage_multiplier(battle)
	)
	var fire_b := (
		_frontline_attack(frontline_b, combat_efficiency_b)
		* attack_pen_b
		* performance_b
	)

	# 只有前线承受攻击，因此防御也按前线兵力加权；守方再叠加城防。
	var def_a := _frontline_avg_defense(frontline_a) * defense_pen_a * performance_a
	var def_b := (_frontline_avg_defense(frontline_b) * defense_pen_b + garrison_b) * performance_b

	# 本回合伤亡：受对方火力，被己方有效防御减伤（守恒与上限交由 distribute_casualties）
	var loss_a := fire_b / K_ROUND * (DEF_REF / (DEF_REF + def_a))
	var loss_b := fire_a / K_ROUND * (DEF_REF / (DEF_REF + def_b))
	loss_a = minf(loss_a, float(frontline_size_a))
	loss_b = minf(loss_b, float(frontline_size_b))

	# 伤亡只在前线兵力池中按最大余数法守恒分配；完整预备队保持原兵力。
	var actual_a := _apply_frontline_losses(frontline_a, loss_a)
	var actual_b := _apply_frontline_losses(frontline_b, loss_b)

	# Field losses erode one shared ratio; garrison assault keeps local erosion.
	if field_rules:
		shared_a = _erode_shared_morale(battle, battle.side_a, frontline_a, actual_a, float(shared_a.ratio))
		shared_b = _erode_shared_morale(battle, battle.side_b, frontline_b, actual_b, float(shared_b.ratio))
	else:
		_erode_frontline_morale(
			battle.side_a, frontline_a, actual_a, morale_before_a
		)
		_erode_frontline_morale(
			battle.side_b, frontline_b, actual_b, morale_before_b
		)
		_extract_routed_armies(battle.side_a, battle.routed_a)
		_extract_routed_armies(battle.side_b, battle.routed_b)

	# 结束判定：全灭、全体单军溃退，或剩余侧平均士气崩溃。
	var active_size_a := battle.side_size(battle.side_a)
	var active_size_b := battle.side_size(battle.side_b)
	var dead_a := (
		active_size_a <= 0
		and _side_size(battle.routed_a) <= 0
	)
	var dead_b := (
		active_size_b <= 0
		and _side_size(battle.routed_b) <= 0
	)
	# 当回合刚退出的低士气军仍属于本侧战果的一部分。若侧级平均只看
	# active，拆分方可通过把低值容器移入 routed 来抬高平均士气并多打一轮。
	var mor_a := float(shared_a.effective) if field_rules else _combined_side_morale(
		battle.side_a,
		battle.routed_a
	)
	var mor_b := float(shared_b.effective) if field_rules else _combined_side_morale(
		battle.side_b,
		battle.routed_b
	)
	var broke_a := (
		(active_size_a <= 0 and not battle.routed_a.is_empty())
		or (active_size_a > 0 and mor_a <= SIDE_ROUT_THRESHOLD)
	)
	var broke_b := (
		(active_size_b <= 0 and not battle.routed_b.is_empty())
		or (active_size_b > 0 and mor_b <= SIDE_ROUT_THRESHOLD)
	)
	if dead_a or dead_b or broke_a or broke_b:
		battle.finished = true
		# 对称指标裁决（item 1）：与 a/b 位置、军队 id、遍历顺序无关；完全对称判平局。
		battle.winner_side = decide_winner(
			dead_a, dead_b, broke_a, broke_b,
			float(active_size_a) * combat_efficiency(mor_a) if field_rules else _combined_side_residual(
				battle.side_a,
				battle.routed_a
			),
			float(active_size_b) * combat_efficiency(mor_b) if field_rules else _combined_side_residual(
				battle.side_b,
				battle.routed_b
			)
		)

	# item 15：结构化战斗日志（纯数据快照，可关闭、测试可读、不参与任何逻辑判断）。
	if battle_log_enabled:
		var rout_reason := "none"
		if battle.finished:
			if dead_a or dead_b:
				rout_reason = "annihilation"
			elif broke_a or broke_b:
				rout_reason = "morale_rout"
			else:
				rout_reason = "empty_side"
		battle_log.append({
			"combat_rules_version": COMBAT_RULES_VERSION,
			"battle_id": battle.id,
				"day": day,
			"round_no": battle.round_no,
			"kind": battle.kind,
				"participants_a": log_participants_before_a,
				"participants_b": log_participants_before_b,
				"participant_count_a": log_participants_before_a.size(),
				"participant_count_b": log_participants_before_b.size(),
				"participants_after_a": _side_log_snapshot(battle.side_a),
				"participants_after_b": _side_log_snapshot(battle.side_b),
				"battle_context": log_battle_context,
			"frontline_strength_a": frontline_size_a,
			"frontline_strength_b": frontline_size_b,
			"reserve_strength_a": size_a - frontline_size_a,
			"reserve_strength_b": size_b - frontline_size_b,
			"frontline_a": _frontline_log_snapshot(frontline_a),
			"frontline_b": _frontline_log_snapshot(frontline_b),
			"routed_a": _side_log_snapshot(battle.routed_a),
			"routed_b": _side_log_snapshot(battle.routed_b),
			"effective_attack_a": fire_a,
			"effective_attack_b": fire_b,
			"effective_defense_a": def_a,
			"effective_defense_b": def_b,
			"opening_dice": Array(dice),
			"performance_modifier_a": performance_a,
			"performance_modifier_b": performance_b,
			"expansion_modifier_a": Battle.dice_multiplier(dice[2]),
			"expansion_modifier_b": Battle.dice_multiplier(dice[3]),
			"base_frontage": frontage,
			"frontage_a": frontage_a,
			"frontage_b": frontage_b,
			"terrain_modifier_a": attack_pen_a,
			"terrain_modifier_b": attack_pen_b,
			"supply_modifier_a": _frontline_supply_ratio(frontline_a),
			"supply_modifier_b": _frontline_supply_ratio(frontline_b),
			"casualties_a": actual_a,
			"casualties_b": actual_b,
			"morale_before_a": log_morale_before_a,
			"morale_before_b": log_morale_before_b,
			"morale_after_a": battle.side_morale(battle.side_a),
			"morale_after_b": battle.side_morale(battle.side_b),
			"reinforcements_arrived_a": log_reinforced_a,
			"reinforcements_arrived_b": log_reinforced_b,
			"shared_ratio_after_a": float(shared_a.get("ratio", 0.0)),
			"shared_ratio_after_b": float(shared_b.get("ratio", 0.0)),
			"rout_reason": rout_reason,
			"winner_or_draw": battle.winner_side,
				"finished": battle.finished,
		})


## 日志用前线人数加权补给率；真实攻防逐军读取，不使用此平均值解算。
static func _frontline_supply_ratio(frontline: Array[Dictionary]) -> float:
	var total := _frontline_size(frontline)
	if total <= 0:
		return 0.0
	var supplied := 0.0
	for entry in frontline:
		var army: Army = entry["army"]
		supplied += float(entry["committed"]) * clampf(army.supply_ratio, 0.0, 1.0)
	return supplied / float(total)


static func _side_log_snapshot(side: Array[Army]) -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	for army in side:
		result.append({
			"id": army.id,
			"owner_nation": army.owner_nation,
			"campaign_war_id": army.campaign_war_id,
			"campaign_front_id": army.campaign_front_id,
			"size": army.size,
			"max_size": army.max_size,
			"attack": army.attack,
			"ruler_attack_multiplier": army.ruler_attack_multiplier,
			"ruler_defense_multiplier": army.ruler_defense_multiplier,
			"ruler_morale_multiplier": army.ruler_morale_multiplier,
			"funding_multiplier": army.funding_multiplier,
			"max_morale": army.max_morale,
			"defense": army.defense,
			"morale": army.morale,
			"starving": army.starving,
			"supply_ratio": army.supply_ratio,
			"is_city_garrison": army.is_city_garrison,
			"city_garrison_combat_multiplier":
				army.city_garrison_combat_multiplier,
			"city_garrison_defense_bonus":
				army.city_garrison_defense_bonus,
		})
	return result


static func _frontline_log_snapshot(
	frontline: Array[Dictionary]
) -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	for entry in frontline:
		var army: Army = entry["army"]
		result.append({
			"army_id": army.id,
			"committed": int(entry["committed"]),
			"reserve": (
				int(entry["size_before"])
				- int(entry["committed"])
			),
			"casualties": int(entry.get("casualties", 0)),
		})
	return result


static func _battle_log_context(battle: Battle) -> Dictionary:
	var context := {
		"uses_field_combat_rules": battle.uses_field_combat_rules(),
		"holding_side": battle.holding_side,
		"holding_days": battle.holding_days,
		"side_b_defends_city": battle.side_b_defends_city,
		"contact_dist_a": battle.contact_dist_a,
		"contact_dist_b": battle.contact_dist_b,
		"field_dice": Array(battle.field_dice),
		"assault_dice": Array(battle.assault_dice),
		"field_sequence": battle.field_sequence,
		"assault_sequence": battle.assault_sequence,
		"shared_ratio_before_a": float(battle.shared_morale_summary(battle.side_a).ratio) if battle.uses_field_combat_rules() else 0.0,
		"shared_ratio_before_b": float(battle.shared_morale_summary(battle.side_b).ratio) if battle.uses_field_combat_rules() else 0.0,
		"shared_ratio_without_arrivals_a": _morale_ratio_without_arrivals(battle, battle.side_a, battle.reinforce_fresh_a),
		"shared_ratio_without_arrivals_b": _morale_ratio_without_arrivals(battle, battle.side_b, battle.reinforce_fresh_b),
		"frontline_priority_a": _priority_log_snapshot(
			battle.frontline_priority_a
		),
		"frontline_priority_b": _priority_log_snapshot(
			battle.frontline_priority_b
		),
		"edge": {},
		"city": {},
	}
	if battle.edge != null:
		context["edge"] = {
			"distance": battle.edge.distance,
			"danger": battle.edge.danger,
			"max_manpower": battle.edge.max_manpower,
			"kind": battle.edge.kind,
			"travel_time_multiplier":
				battle.edge.travel_time_multiplier,
			"supply_loss_multiplier":
				battle.edge.supply_loss_multiplier,
			"allows_holding": battle.edge.allows_holding,
		}
	if battle.city != null:
		context["city"] = {
			"food_storage": battle.city.food_storage,
			"garrison_manpower": battle.city.garrison_manpower,
		}
	return context


static func _morale_ratio_without_arrivals(battle: Battle, side: Array[Army], arrivals: Array[Army]) -> float:
	if not battle.uses_field_combat_rules():
		return 0.0
	var pending := {}
	for army in arrivals:
		pending[army] = true
	var existing: Array[Army] = []
	for army in side:
		if not pending.has(army):
			existing.append(army)
	return float(battle.shared_morale_summary(existing).ratio)


static func _priority_log_snapshot(priority: Dictionary) -> Dictionary:
	var result := {}
	for army in priority:
		result[str((army as Army).id)] = int(priority[army])
	return result


## 战斗胜负裁决（item 1，纯函数，无 RNG）。返回 1=side_a 胜 / 2=side_b 胜 / 0=平局。
## 判定顺序：① 兵力歼灭优先（仅一方全歼→另一方胜）；② 士气溃败（仅一方崩→另一方胜）；
## ③ 双方同时失败 → 按对称「剩余续战能力」residual 裁决，完全相等则平局。
## 关键性质：交换 (a,b) 输入 → 输出对称交换（1↔2，0 不变），故不存在「默认 A 方获胜」偏置；
## residual 是兵力×效率之和，与军队 id / 创建顺序 / 遍历顺序无关。
static func decide_winner(
	dead_a: bool, dead_b: bool,
	broke_a: bool, broke_b: bool,
	residual_a: float, residual_b: float
) -> int:
	if dead_a and not dead_b:
		return 2
	if dead_b and not dead_a:
		return 1
	if dead_a and dead_b:
		return _break_tie(residual_a, residual_b)
	if broke_a and not broke_b:
		return 2
	if broke_b and not broke_a:
		return 1
	return _break_tie(residual_a, residual_b)


## 对称 tie-break：续战能力高者胜，完全相等判平局（0）。
static func _break_tie(residual_a: float, residual_b: float) -> int:
	if is_equal_approx(residual_a, residual_b):
		return 0
	if residual_a > residual_b:
		return 1
	if residual_b > residual_a:
		return 2
	return 0


## 规范化一侧内部顺序：按纯物理键降序（size, attack, defense, morale）就地排序。
## 目的是让后续所有浮点求和（火力/防御/士气/伤亡摊分）只依赖军队物理多重集、与加入历史无关，
## 从而在镜像下逐位一致。四键全等的两军物理上可互换，其残余相对顺序不影响任何求和结果。
static func _canonicalize_side(
	side: Array[Army],
	priority: Dictionary = {}
) -> void:
	var physical_less := func(a: Army, b: Army) -> bool:
		if a.size != b.size:
			return a.size > b.size
		var attack_a := a.combat_attack()
		var attack_b := b.combat_attack()
		if not is_equal_approx(attack_a, attack_b):
			return attack_a > attack_b
		var defense_a := a.combat_defense()
		var defense_b := b.combat_defense()
		if not is_equal_approx(defense_a, defense_b):
			return defense_a > defense_b
		if not is_equal_approx(a.morale, b.morale):
			return a.morale > b.morale
		return int(priority.get(a, 1 << 30)) < int(
			priority.get(b, 1 << 30)
		)
	# Most rounds keep the previous physical order; avoid sorting it again.
	for index in range(1, side.size()):
		if physical_less.call(side[index], side[index - 1]):
			side.sort_custom(physical_less)
			return


## 为本轮明确选择前线兵力。返回项为 {army, committed, size_before}；
## 未出现在结果中的军队是完整预备队。最后一支军队可只投入部分兵力。
static func frontline_allocation(
	side: Array[Army],
	frontage: int,
	priority: Dictionary = {},
	collective_morale: bool = false
) -> Array[Dictionary]:
	var ordered: Array[Army] = side.duplicate()
	_canonicalize_side(ordered, priority)
	var remaining := frontage
	if remaining <= 0:
		remaining = _side_size(ordered)
	var result: Array[Dictionary] = []
	for army in ordered:
		if (
			remaining <= 0
			or army.size <= 0
			or (not collective_morale and army.combat_morale() <= ARMY_ROUT_THRESHOLD)
		):
			continue
		var committed := mini(army.size, remaining)
		if committed <= 0:
			continue
		result.append({
			"army": army,
			"committed": committed,
			"size_before": army.size,
		})
		remaining -= committed
	return result


static func _frontline_size(frontline: Array[Dictionary]) -> int:
	var total := 0
	for entry in frontline:
		total += int(entry["committed"])
	return total


static func _frontline_attack(
	frontline: Array[Dictionary],
	side_efficiency: float
) -> float:
	var total := 0.0
	for entry in frontline:
		var army: Army = entry["army"]
		total += (
			float(entry["committed"])
			* army.combat_attack()
			* _city_garrison_attack_multiplier(army)
			* side_efficiency
		)
	return total


static func _side_combat_efficiency(side: Array[Army]) -> float:
	var nominal_attack := 0.0
	var effective_attack := 0.0
	for army in side:
		if army.size <= 0:
			continue
		var army_nominal := (
			float(army.size)
			* army.combat_attack()
			* _city_garrison_attack_multiplier(army)
		)
		nominal_attack += army_nominal
		effective_attack += (
			army_nominal
				* combat_efficiency(army.combat_morale())
		)
	return (
		effective_attack / nominal_attack
		if nominal_attack > 0.0
		else 0.0
	)


static func _frontline_avg_defense(
	frontline: Array[Dictionary]
) -> float:
	var total := _frontline_size(frontline)
	if total <= 0:
		return 0.0
	var weighted := 0.0
	for entry in frontline:
		var army: Army = entry["army"]
		weighted += (
			float(entry["committed"]) * army.combat_defense()
				* _city_garrison_defense_multiplier(army)
		)
	return weighted / float(total)


static func _city_garrison_base_stat_multiplier(army: Army) -> float:
	if army == null or not army.is_city_garrison:
		return 1.0
	return maxf(army.city_garrison_combat_multiplier, 0.0)


static func _city_garrison_attack_multiplier(army: Army) -> float:
	return (
		_city_garrison_base_stat_multiplier(army)
		* (CITY_GARRISON_ATTACK_MULTIPLIER if army != null and army.is_city_garrison else 1.0)
	)


static func _city_garrison_defense_multiplier(army: Army) -> float:
	return (
		_city_garrison_base_stat_multiplier(army)
		* (
			maxf(army.city_garrison_defense_bonus, 0.0)
			if army != null and army.is_city_garrison
			else 1.0
		)
	)


static func _apply_frontline_losses(
	frontline: Array[Dictionary],
	total_loss: float
) -> int:
	if frontline.is_empty() or total_loss <= 0.0:
		return 0
	var committed: Array[int] = []
	for entry in frontline:
		committed.append(int(entry["committed"]))
	var casualties := distribute_casualties(committed, total_loss)
	var applied := 0
	for index in range(frontline.size()):
		var army: Army = frontline[index]["army"]
		army.size -= casualties[index]
		frontline[index]["casualties"] = casualties[index]
		applied += casualties[index]
	return applied


static func _erode_shared_morale(
	battle: Battle,
	side: Array[Army],
	frontline: Array[Dictionary],
	casualties: int,
	ratio_before: float
) -> Dictionary:
	var summary := battle.shared_morale_summary(side)
	var committed := _frontline_size(frontline)
	var frontline_survivors := 0
	var starving_survivors := 0
	for entry in frontline:
		var army: Army = entry.army
		var survivors := maxi(int(entry.committed) - int(entry.get("casualties", 0)), 0)
		frontline_survivors += survivors
		if army.starving:
			starving_survivors += survivors
	var loss := 0.0
	if committed > 0:
		loss = float(frontline_survivors) * (float(casualties) / float(committed) * MORALE_CASUALTY_K + MORALE_BASE_DECAY)
		loss += float(starving_survivors) * MORALE_STARVE_DECAY
	var capacity := float(summary.capacity)
	var ratio := clampf(ratio_before - loss / capacity, 0.0, 1.0) if capacity > 0.0 else 0.0
	summary.ratio = ratio
	summary.effective = ratio * capacity / float(summary.size) if int(summary.size) > 0 else 0.0
	battle.write_shared_morale(side, ratio)
	return summary


static func _erode_frontline_morale(
	side: Array[Army],
	frontline: Array[Dictionary],
	actual_casualties: int,
	morale_before: float
) -> void:
	var normal_side: Array[Army] = []
	var normal_frontline: Array[Dictionary] = []
	var normal_casualties := 0
	for army in side:
		if not army.is_city_garrison:
			normal_side.append(army)
	for entry in frontline:
		var entry_army: Army = entry["army"]
		if entry_army.is_city_garrison:
			continue
		normal_frontline.append(entry)
		normal_casualties += int(entry.get("casualties", 0))
	if normal_side.size() != side.size():
		if normal_frontline.is_empty():
			return
		_erode_frontline_morale(
			normal_side,
			normal_frontline,
			normal_casualties,
			Battle.new().side_morale(normal_side)
		)
		return
	var committed_total := _frontline_size(frontline)
	if committed_total <= 0:
		return
	var base_erode := (
		float(actual_casualties)
			/ float(committed_total)
			* MORALE_CASUALTY_K
		+ MORALE_BASE_DECAY
	)
	var frontline_survivors_total := 0
	var starving_survivors := 0
	for entry in frontline:
		var army: Army = entry["army"]
		if army.size <= 0:
			continue
		var frontline_survivors := maxi(
			int(entry["committed"])
				- int(entry.get("casualties", 0)),
			0
		)
		frontline_survivors_total += frontline_survivors
		if army.starving:
			starving_survivors += frontline_survivors
	var surviving_size := _side_size(side)
	if surviving_size <= 0:
		return
	# 士气是组织度密度，size×morale 是可守恒的组织度质量。伤亡先按本侧
	# 战前平均密度移除，随后只扣除幸存前线的战斗侵蚀；这个目标不依赖
	# 行政军队如何拆分。具体损耗仍只回写到本轮前线，完整预备队保持不变。
	var target_mass := (
		float(surviving_size) * morale_before
		- float(frontline_survivors_total) * base_erode
		- float(starving_survivors) * MORALE_STARVE_DECAY
	)
	target_mass = clampf(
		target_mass,
		0.0,
		_side_max_morale_mass(side)
	)
	_adjust_frontline_morale_mass(
		side,
		frontline,
		target_mass
	)


static func _adjust_frontline_morale_mass(
	side: Array[Army],
	frontline: Array[Dictionary],
	target_mass: float
) -> void:
	var current_mass := _side_morale_mass(side)
	var remaining := current_mass - target_mass
	if absf(remaining) <= 0.000000001:
		return
	var adjustable: Array[Dictionary] = []
	for entry in frontline:
		var army: Army = entry["army"]
		if army.size <= 0:
			continue
		var frontline_survivors := maxi(
			int(entry["committed"])
				- int(entry.get("casualties", 0)),
			0
		)
		if frontline_survivors > 0:
			adjustable.append({
				"army": army,
				"weight": frontline_survivors,
			})
	while (
		not adjustable.is_empty()
		and absf(remaining) > 0.000000001
	):
		var total_weight := 0
		for candidate in adjustable:
			total_weight += int(candidate["weight"])
		if total_weight <= 0:
			break
		var next_adjustable: Array[Dictionary] = []
		var changed := 0.0
		for candidate in adjustable:
			var army: Army = candidate["army"]
			var requested_mass := (
				remaining
				* float(candidate["weight"])
				/ float(total_weight)
			)
			var old_morale := army.morale
			# requested_mass 与 _side_morale_mass 都以 combat_morale 为量纲；
			# 回写持久 morale 及统计 applied_mass 时必须使用完全相同的倍率。
			var morale_multiplier := maxf(
				army.ruler_morale_multiplier, 0.1
			)
			army.morale = clampf(
				army.morale
					- requested_mass
						/ (
							float(maxi(army.size, 1))
							* morale_multiplier
						),
				MORALE_FLOOR,
				army.max_morale
			)
			var applied_mass := (
				(old_morale - army.morale)
				* float(army.size)
				* morale_multiplier
			)
			changed += applied_mass
			if (
				remaining > 0.0
				and army.morale > MORALE_FLOOR
			) or (
				remaining < 0.0
				and army.morale < army.max_morale
			):
				next_adjustable.append(candidate)
		remaining -= changed
		if absf(changed) <= 0.000000001:
			break
		adjustable = next_adjustable


static func _side_morale_mass(side: Array[Army]) -> float:
	var total := 0.0
	for army in side:
		if army.size > 0:
			total += float(army.size) * army.combat_morale()
	return total


static func _side_max_morale_mass(side: Array[Army]) -> float:
	var total := 0.0
	for army in side:
		if army.size > 0:
			total += float(army.size) * army.combat_max_morale()
	return total


static func _extract_routed_armies(
	side: Array[Army],
	routed: Array[Army]
) -> void:
	for index in range(side.size() - 1, -1, -1):
		var army := side[index]
		if (
			army.size > 0
			and not army.is_city_garrison
			and army.combat_morale() <= ARMY_ROUT_THRESHOLD
		):
			routed.push_front(army)
			side.remove_at(index)


static func _side_size(side: Array[Army]) -> int:
	var total := 0
	for army in side:
		if army.size > 0:
			total += army.size
	return total


## 一侧「剩余续战能力」= Σ 存活军队 size × combat_efficiency(morale)。对称、与顺序无关。
static func _side_residual(side: Array[Army]) -> float:
	var total := 0.0
	for a in side:
		if a.size > 0:
			total += (
				float(a.size)
				* combat_efficiency(a.combat_morale())
				* sqrt(
					_city_garrison_attack_multiplier(a)
					* _city_garrison_defense_multiplier(a)
				)
			)
	return total


static func _combined_side_morale(
	active: Array[Army],
	routed: Array[Army]
) -> float:
	var morale_mass := _side_morale_mass(active)
	var total_size := _side_size(active)
	for army in routed:
		if army.size > 0:
			morale_mass += (
				float(army.size) * army.combat_morale()
			)
			total_size += army.size
	return (
		morale_mass / float(total_size)
		if total_size > 0
		else 0.0
	)


static func _combined_side_residual(
	active: Array[Army],
	routed: Array[Army]
) -> float:
	return _side_residual(active) + _side_residual(routed)


static func _side_attack(side: Array[Army]) -> float:
	var total := 0.0
	for a in side:
		if a.size > 0:
			total += (
				float(a.size)
				* a.combat_attack()
				* combat_efficiency(a.combat_morale())
			)
	return total


## 本场战斗单侧「正面宽度」容量（item 5，纯函数）。道路野战取道路容量，
## 城下真实军队野战固定 50000，纯攻城取城墙容量。
## 双方共享同一正面（同一条战线/同一段城墙）。返回值 <=0 时视为无限制（回退 FRONTAGE_FALLBACK）。
static func combat_frontage(battle: Battle) -> int:
	if battle.kind == Battle.Kind.SIEGE:
		return (
			SIEGE_FIELD_FRONTAGE
			if battle.uses_field_combat_rules()
			else SIEGE_FRONTAGE
		)
	if battle.edge != null and battle.edge.max_manpower > 0:
		return battle.edge.max_manpower
	return FRONTAGE_FALLBACK


## 开场展开骰扩大本侧宽度，不改变道路行军容量。
static func side_combat_frontage(battle: Battle, side: int) -> int:
	var dice := battle.opening_dice()
	assert(Battle.valid_dice(dice))
	return int(combat_frontage(battle) * (10 + dice[2 if side == 1 else 3]) / 10)


## 兼容查询：返回聚合参战比例，实际解算使用显式前线。
static func frontage_engaged_ratio(side_total: int, frontage: int) -> float:
	if side_total <= 0:
		return 0.0
	if frontage <= 0 or frontage >= side_total:
		return 1.0
	return float(frontage) / float(side_total)


## 士气→战斗效率（item 2，纯函数）。efficiency = MIN + (1-MIN)*morale：
## 满士气(1.0)→1.0（保持既有满士气标定不变，故满编满士气战斗数值与重构前一致）；
## 零士气→MIN_COMBAT_EFFICIENCY（仍能自卫但火力大幅下降，不再贡献完整伤害）。
## 单调线性、无阈值台阶，士气因此是「组织度/战斗意志」而非第二条生命值。
static func combat_efficiency(morale: float) -> float:
	return MIN_COMBAT_EFFICIENCY + (1.0 - MIN_COMBAT_EFFICIENCY) * clampf(morale, 0.0, 1.0)


static func _side_avg_defense(side: Array[Army], side_size: int) -> float:
	if side_size <= 0:
		return 0.0
	var wsum := 0.0
	for a in side:
		if a.size > 0:
			wsum += float(a.size) * float(a.defense)
	return wsum / float(side_size)


## 对一侧每支存活军队侵蚀士气。基础侵蚀同侧共担；断粮军队额外掉 MORALE_STARVE_DECAY。
## 直接写入 Army.morale（真源），clamp 到 [MORALE_FLOOR, Army.max_morale]。
static func _erode_side_morale(side: Array[Army], base_erode: float) -> void:
	for a in side:
		if a.size <= 0:
			continue
		var e := base_erode
		if a.starving:
			e += MORALE_STARVE_DECAY
		a.morale = clampf(a.morale - e, MORALE_FLOOR, a.max_morale)


## 将本回合总伤亡守恒地摊分到本侧各军并就地扣减 size（item 3）。返回实际扣减的总伤亡（整数）。
## 委托 distribute_casualties 保证：sum == min(round(total_loss), 总存活兵力)，每支 0<=伤亡<=size。
static func _apply_losses(side: Array[Army], total_loss: float) -> int:
	if total_loss <= 0.0:
		return 0
	var alive: Array[Army] = []
	var sizes: Array[int] = []
	for a in side:
		if a.size > 0:
			alive.append(a)
			sizes.append(a.size)
	if alive.is_empty():
		return 0
	var casualties := distribute_casualties(sizes, total_loss)
	var applied := 0
	for i in range(alive.size()):
		alive[i].size -= casualties[i]
		applied += casualties[i]
	return applied


## 伤亡整数守恒分配（item 3，纯函数，无 RNG）。用「最大余数法」：
##  1) 目标总伤亡 T = min(round(total_loss), Σsizes)（不能超过总存活兵力）；
##  2) 各军精确份额 = T × size/Σsizes，先发整数部分（且不超过各自 size）；
##  3) 剩余名额按 (小数余数, -size, index) 降序补发一人，跳过已达 size 上限者；
##  4) 循环补发直至 T 发完或所有军队均达 size 上限。
## 保证：sum(result) == min(round(total_loss), Σsizes)，且对每支 0<=result[i]<=sizes[i]。
## 与「军队对象数量」无关：拆分 sizes 不改变总伤亡（防拆分套利 item 12）。
static func distribute_casualties(sizes: Array[int], total_loss: float) -> Array[int]:
	var n := sizes.size()
	var result: Array[int] = []
	result.resize(n)
	result.fill(0)
	var pool := 0
	for s in sizes:
		pool += maxi(s, 0)
	if n == 0 or pool <= 0 or total_loss <= 0.0:
		return result
	var target := mini(int(round(total_loss)), pool)
	if target <= 0:
		return result
	# 步骤 2：整数部分 + 记录小数余数
	var remainders: Array[float] = []
	remainders.resize(n)
	var assigned := 0
	for i in range(n):
		var exact := total_loss * float(sizes[i]) / float(pool)
		var whole := mini(int(floor(exact)), sizes[i])
		result[i] = whole
		assigned += whole
		remainders[i] = exact - float(floor(exact))
	# 步骤 3-4：剩余名额按余数降序补发（cap 溢出跳过），确定性 tie-break。
	var leftover := target - assigned
	# 候选按 (余数降序, size 降序, index 升序) 排序——纯物理量，无军队 id 依赖。
	var order: Array[int] = []
	for i in range(n):
		order.append(i)
	order.sort_custom(func(x: int, y: int) -> bool:
		if not is_equal_approx(remainders[x], remainders[y]):
			return remainders[x] > remainders[y]
		if sizes[x] != sizes[y]:
			return sizes[x] > sizes[y]
		return x < y
	)
	while leftover > 0:
		var progressed := false
		for i in order:
			if leftover <= 0:
				break
			if result[i] < sizes[i]:
				result[i] += 1
				leftover -= 1
				progressed = true
		if not progressed:
			break   # 所有军队均达 size 上限（target 已被 pool 夹住，理论不会走到）
	return result
