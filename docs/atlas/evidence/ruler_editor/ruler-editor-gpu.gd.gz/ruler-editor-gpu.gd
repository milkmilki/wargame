extends SceneTree
var failures:=0
func check(ok: bool,message: String):
	if not ok:failures+=1;printerr("RULER_EDITOR_GPU_FAIL ",message)
func _initialize():call_deferred("run")
func editor_for(view):
	for cached in view.info_panel.section_cache.values():
		if cached.has("editor"):return cached.editor
	return null
func key(popup,keycode):
	var event:=InputEventKey.new();event.keycode=keycode;event.pressed=true;popup.window_input.emit(event)
func capture(view,name):
	await process_frame;await process_frame;RenderingServer.force_draw(true)
	root.get_texture().get_image().save_png("res://.dbg/ruler-editor-"+name+".png")
func run():
	root.size=Vector2i(1280,720)
	var view=load("res://atlas_military.tscn").instantiate();root.add_child(view)
	var deadline:=Time.get_ticks_msec()+180000
	while not view.view_ready or view.generating:
		if Time.get_ticks_msec()>deadline:check(false,"startup timeout");quit(1);return
		await process_frame
	view.simulation.paused=true;view.simulation.set_process(false)
	check(await view.await_render_ready(30000),"real world render ready")
	view.show_information("nation",0)
	var editor=editor_for(view);check(editor!=null,"nation inspector has dropdowns")
	var original_rng: int=view.state.rng.state
	var original_person: int=view.state.nations[0].ruler_person_id
	var builds: int=view.info_panel.build_count
	print("RULER_EDITOR_DIAGNOSTIC ",JSON.stringify({"editable":editor.editable,"blocked":not view.ruler_edit_available(),"selected":editor.archetype.selected,"connections_id":editor.archetype.get_popup().get_signal_connection_list("id_pressed").size(),"connections_index":editor.archetype.get_popup().get_signal_connection_list("index_pressed").size()}))
	await process_frame;await process_frame
	view.info_panel.scroll.ensure_control_visible(editor)
	await capture(view,"wide")
	var popup: PopupMenu=editor.archetype.get_popup();editor.archetype.show_popup();await process_frame
	await capture(view,"types")
	# Native PopupMenu uses index_pressed, not id_pressed, for OptionButton.
	# Synthetic viewport key injection did not activate this native window.
	popup.index_pressed.emit(editor.archetype.get_item_index(RulerProfile.MERCHANT));popup.hide();await process_frame
	print("RULER_EDITOR_DIAGNOSTIC_AFTER type=",view.state.nations[0].ruler_archetype," selection=",editor.archetype.selected)
	check(view.state.nations[0].ruler_archetype==RulerProfile.MERCHANT,"native menu signal changes actual ruler")
	editor.traits[0].get_popup().index_pressed.emit(1+RulerProfile.TRAIT_IDS.find(RulerProfile.TRAIT_DILIGENT))
	check(view.state.nations[0].ruler_traits.has(RulerProfile.TRAIT_DILIGENT),"native trait popup changes actual trait")
	check(view.info_panel.build_count==builds,"editing preserves inspector widgets")
	var template=preload("res://scripts/atlas/military_template.gd")
	var definition: Dictionary=template.encode(view.state)
	var restored:=GameState.new();restored.generate_from_atlas(template.decode(definition))
	check(restored.nations[0].ruler_archetype==RulerProfile.MERCHANT and restored.nations[0].ruler_traits==view.state.nations[0].ruler_traits,"map template preserves edited type and traits")
	check(view.state.rng.state==original_rng and view.state.nations[0].ruler_person_id==original_person,"editing and template saving preserve live identity and random stream")
	root.size=Vector2i(900,600);await process_frame;view.info_panel.scroll.ensure_control_visible(editor)
	await capture(view,"compact")
	check(editor.archetype.get_global_rect().end.x<=view.info_panel.get_global_rect().end.x,"dropdown fits compact inspector")
	print("RULER_EDITOR_GPU ",JSON.stringify({"pid":OS.get_process_id(),"seed":view.state.world_seed,"mask":view.data.options.settlement_mask,"renderer":RenderingServer.get_current_rendering_method(),"failures":failures,"fixture":"live masked Eurasia; native menu signals for type/trait edits, template roundtrip; no simulation days advanced; not physical keyboard/mouse validation"}))
	root.remove_child(view);view.queue_free();await process_frame;quit(1 if failures else 0)
