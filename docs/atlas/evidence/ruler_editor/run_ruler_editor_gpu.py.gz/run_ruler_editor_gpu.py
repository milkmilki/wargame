from pathlib import Path
import subprocess
r=Path(__file__).resolve().parents[1]
with (r/'.dbg/ruler-editor-gpu.stdout.txt').open('w',encoding='utf-8') as out,(r/'.dbg/ruler-editor-gpu.stderr.txt').open('w',encoding='utf-8') as err:
    p=subprocess.Popen(['D:/ProjectICreate/Godot_v4.7.1-stable_win64.exe','--path',str(r),'--script','res://.dbg/ruler-editor-gpu.gd'],stdout=out,stderr=err)
    print('RULER_EDITOR_GPU_PID',p.pid,flush=True); code=p.wait(timeout=240)
print('exit',code)
print((r/'.dbg/ruler-editor-gpu.stdout.txt').read_text(encoding='utf-8')[-1800:])
print((r/'.dbg/ruler-editor-gpu.stderr.txt').read_text(encoding='utf-8')[-1800:])
raise SystemExit(code)
