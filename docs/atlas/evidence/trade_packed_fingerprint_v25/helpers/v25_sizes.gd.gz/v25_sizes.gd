extends SceneTree
func _initialize(): call_deferred("run")
func run():
	var sim: Simulation = preload("res://.dbg/state_codec.gd").new().restore("res://.dbg/daily-v9/frozen-day180.bin")
	var before := preload("res://tests/support/trade_fingerprint_reference.gd").fingerprint(sim.state)
	var after := TradeNetwork.structure_fingerprint(sim.state)
	var output := {"pid":OS.get_process_id(),"before_bytes":before.size(),"after_bytes":after.size(),"cities":sim.state.cities.size(),"edges":sim.state.edges.size()}
	FileAccess.open("res://.dbg/trade-fingerprint-v25/sizes.json",FileAccess.WRITE).store_string(JSON.stringify(output))
	print("V25_FINGERPRINT_SIZE ",JSON.stringify(output));sim.free();quit()
