extends SceneTree
func _initialize(): call_deferred("run")
func run():
	var sim: Simulation = preload("res://.dbg/state_codec.gd").new().restore("res://.dbg/daily-v9/frozen-day180.bin","res://.dbg/v25_probe_sim.gd")
	var reference: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://docs/atlas/evidence/forecast_selected_rows_v24/daily/after-28592.json"))
	var rows := []
	for day in range(35):
		sim.segments.clear(); sim._advance_day(false)
		var h:=HashingContext.new(); h.start(HashingContext.HASH_SHA256); h.update(var_to_bytes(NativeSnapshotBuilder.build(sim.state)))
		var sha:=h.finish().hex_encode(); assert(sha==reference.rows[day].sha256)
		rows.append({"day":sim.state.day,"segments":sim.segments.duplicate(true),"sha256":sha})
		if day%5==0: await process_frame
	FileAccess.open("res://.dbg/campaign-query-v25/probe.json",FileAccess.WRITE).store_string(JSON.stringify({"pid":OS.get_process_id(),"rows":rows},"  "))
	print("V25_PROBE_COMPLETE ",OS.get_process_id()); sim.free(); quit()
