from pathlib import Path
import subprocess
path='scripts/core/trade_network.gd';base=subprocess.check_output(['git','show','HEAD:'+path]).decode().replace('\r\n','\n')
old=Path('.dbg/trade-fingerprint-v25/trade_network-before.gd.txt').read_text(encoding='utf-8-sig');new=Path('.dbg/trade-fingerprint-v25/trade_network-after.gd.txt').read_text(encoding='utf-8-sig')
def method(s):start=s.index('static func _structure_fingerprint_locked(');return s[start:s.index('\n\nstatic func domestic_ideal_graph_fingerprint_exact',start)]
a=method(old);b=method(new)
old_city=a[a.index('\tvar non_trade_gold_outputs'):a.index('\tfor nation in state.nations:')]
new_city=b[b.index('\tvar non_trade_gold_outputs'):b.index('\tfor nation in state.nations:')]
old_edge=a[a.index('\tfor edge in state.edges:'):a.index('\treturn var_to_bytes(fields)')]
new_edge=b[b.index('\tvar edge_records :='):b.index('\treturn var_to_bytes(fields)')]
old_city=old_city.replace('city.is_dock, city.node_kind,','city.is_dock,');old_edge=old_edge.replace('edge.distance, edge.precise_distance, edge.control_city_id,','edge.distance,');start=base.index('static func structure_fingerprint(');end=base.index('\n\nstatic func domestic_ideal_graph_fingerprint_exact',start);method_base=base[start:end];assert method_base.count(old_city)==1 and method_base.count(old_edge)==1;method_base=method_base.replace(old_city,new_city,1).replace(old_edge,new_edge,1).replace('trade_structure_v5','trade_structure_v6_packed_records');base=base[:start]+method_base+base[end:]
blob=subprocess.check_output(['git','hash-object','-w','--path='+path,'--stdin'],input=base.encode()).decode().strip();subprocess.run(['git','update-index','--cacheinfo','100644,'+blob+','+path],check=True)
path='run_tests.py';s=subprocess.check_output(['git','show','HEAD:'+path]).decode().replace('\r\n','\n');needle='"forecast_selected_rows",';assert s.count(needle)==1;s=s.replace(needle,needle+' "trade_packed_fingerprint",',1)
blob=subprocess.check_output(['git','hash-object','-w','--path='+path,'--stdin'],input=s.encode()).decode().strip();subprocess.run(['git','update-index','--cacheinfo','100644,'+blob+','+path],check=True)
w=Path(path).read_text(encoding='utf-8');assert w.count(needle)==1;Path(path).write_text(w.replace(needle,needle+' "trade_packed_fingerprint",',1),encoding='utf-8')
subprocess.run(['git','add','tests/trade_packed_fingerprint.gd','tests/support/trade_fingerprint_reference.gd'],check=True)
print('STAGED v25 only')
