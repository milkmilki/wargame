from pathlib import Path
import gzip,hashlib,json,shutil,statistics,subprocess
src=Path('.dbg/trade-fingerprint-v25');dest=Path('docs/atlas/evidence/trade_packed_fingerprint_v25');dest.mkdir(parents=True,exist_ok=True)
pairs=json.loads((src/'daily/paired-summary.json').read_text());assert len(pairs)==5;assert all(a['sha256']==b['sha256'] for p in pairs for a,b in zip(p['before']['rows'],p['after']['rows']))
working=json.loads(Path('.dbg/regression/summary-selected.json').read_text(encoding='utf-8-sig'));assert len(working['results'])==18 and all(r['ok'] for r in working['results'])
stage=Path('.dbg/v25-staged-verify/.dbg/regression');staged=json.loads((stage/'summary-selected.json').read_text(encoding='utf-8-sig'));assert len(staged['results'])==10 and all(r['ok'] for r in staged['results'])
target=dest/'daily';target.mkdir(exist_ok=True)
for p in (src/'daily').iterdir():
 if p.name=='paired-summary.json':continue
 if p.suffix=='.json':(target/p.name).write_text(json.dumps(json.loads(p.read_text()),separators=(',',':'))+'\n',encoding='utf-8')
 elif p.name.endswith('.gd.txt'):(target/(p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
 else:shutil.copyfile(p,target/p.name)
for report,folder,label in [(working,Path('.dbg/regression'),'working'),(staged,stage,'staged')]:
 target=dest/label;target.mkdir(exist_ok=True);(target/'summary.json').write_text(json.dumps(report,separators=(',',':'))+'\n')
 for r in report['results']:shutil.copyfile(folder/(r['test']+'.log'),target/(r['test']+'.log.txt'))
for p in src.iterdir():
 if p.is_file() and p.name in ['runtime-summary.json','runtime-before.stdout.txt','runtime-before.stderr.txt','runtime-after.stdout.txt','runtime-after.stderr.txt','staged-import.stdout.txt','staged-import.stderr.txt','red.log.txt','sizes.json','sizes.stdout.txt','sizes.stderr.txt']:
  if p.suffix=='.json':(dest/p.name).write_text(json.dumps(json.loads(p.read_text()),separators=(',',':'))+'\n')
  elif p.name=='staged-import.stdout.txt':(dest/(p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
  else:shutil.copyfile(p,dest/p.name)
probe=Path('.dbg/campaign-query-v25/probe.json');(dest/'diagnostic.json.gz').write_bytes(gzip.compress(probe.read_bytes(),mtime=0));reference=json.loads(probe.read_text());assert all(a['sha256']==b['sha256'] for a,b in zip(reference['rows'],pairs[0]['before']['rows']))
helpers=dest/'helpers';helpers.mkdir(exist_ok=True)
for name in ['v25_probe.py','v25_probe_sim.gd','v25_probe.gd','v25_fingerprint_compare.py','v25_fingerprint_daily.gd','v25_runtime_compare.py','v25_runtime.gd','v25_sizes.py','v25_sizes.gd','state_codec.gd','v17_daily.gd','prepare_v25.py','stage_v25.py','record_v25.py']:
 (helpers/(name+'.gz')).write_bytes(gzip.compress((Path('.dbg')/name).read_bytes(),mtime=0))
metrics={}
for k in ['mean_ms','p95_ms','peak_ms']:
 a=statistics.median(p['before'][k] for p in pairs);b=statistics.median(p['after'][k] for p in pairs);metrics[k]={'before':a,'after':b,'reduction_percent':(a-b)/a*100}
for k in ['ai_snapshot_forecast_structure_fingerprint','ai_snapshot_forecast_structure_stage','ai_snapshot_forecast_gold_flows','monthly_diplomacy','monthly_reinforcements','ai','supply']:
 metrics[k]={v:statistics.median(statistics.mean(r['profile'].get(k,0) for r in p[v]['rows'])/1000 for p in pairs) for v in ['before','after']}
sample=json.loads((src/'daily/after-33004.json').read_text());sources=dest/'sources';sources.mkdir(exist_ok=True);archives={}
for path,sha in sample['source_hashes'].items():
 raw=Path(path).read_bytes();assert hashlib.sha256(raw).hexdigest()==sha,path
 name=path.replace('/','__')+'.gz';(sources/name).write_bytes(gzip.compress(raw,mtime=0));archives[name]={'original_path':path,'sha256':sha}
raw=(src/'trade_network-before.gd.txt').read_bytes();name='trade_network-before.gd.gz';(sources/name).write_bytes(gzip.compress(raw,mtime=0));archives[name]={'original_path':'scripts/core/trade_network.gd','sha256':hashlib.sha256(raw).hexdigest(),'variant':'before'}
runtime=json.loads((src/'runtime-summary.json').read_text());assert len(runtime['after']['rows'])==35 and all(a['sha256']==b['sha256'] for a,b in zip(runtime['before']['rows'],runtime['after']['rows']))
summary={'date':'2026-10-11','base_commit':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'godot':'4.7.1.stable.official.a13da4feb','scope':'headless computation, not GUI frame rate','configuration':{'seed':1,'nations':40,'nodes':1192,'edges':1308,'initial_armies':234,'trade':True,'rulers':True,'mask':{'south':20,'north':55,'west':-15,'east':145}},'days':[181,215],'frozen_file':'.dbg/daily-v9/frozen-day180.bin','frozen_sha256':hashlib.sha256(Path('.dbg/daily-v9/frozen-day180.bin').read_bytes()).hexdigest(),'initial_native_sha256':sample['initial_sha256'],'metrics':metrics,'fingerprint_sizes':json.loads((src/'sizes.json').read_text()),'equal_daily_states':175,'process_pairs':[{v:{k:val for k,val in p[v].items() if k!='rows'} for v in ['before','after']} for p in pairs],'runtime':{'days':35,'equal_daily_states':35,'before_pid':runtime['before']['pid'],'after_pid':runtime['after']['pid'],'workers':4,'note':'Inherited cumulative runtime peaks are not new main-thread performance evidence.'},'tests':{'new_checks':596,'working_passed':18,'staged_passed':10,'core_checks':505},'source_archives':archives,'limitations':['One seed, 35-day window and one monthly boundary; no long-run or GUI claim.','All five paired means decreased; one paired peak increased. Other-stage variance contributes to the total.','Working baseline already contains node-kind, precise-distance and control-city dependencies; staged commit also includes these three fields.','Other pending annual trade and UI features are excluded from the staged commit.']}
(dest/'summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n',encoding='utf-8');(dest/'.gitattributes').write_text('*.gz binary\n',encoding='utf-8')
print('V25 validated evidence saved')
