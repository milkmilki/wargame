from pathlib import Path
import subprocess
out=Path('.dbg/trade-fingerprint-v25')
with (out/'sizes.stdout.txt').open('wb') as o,(out/'sizes.stderr.txt').open('wb') as e:
 p=subprocess.Popen(['D:/ProjectICreate/Godot_v4.7.1-stable_win64.exe','--headless','--path',str(Path.cwd()),'--script','res://.dbg/v25_sizes.gd'],stdout=o,stderr=e,creationflags=subprocess.CREATE_NO_WINDOW);print('SIZE_START',p.pid,flush=True);c=p.wait(timeout=120)
 assert c==0 and not (out/'sizes.stderr.txt').read_text().strip();print((out/'sizes.stdout.txt').read_text())
