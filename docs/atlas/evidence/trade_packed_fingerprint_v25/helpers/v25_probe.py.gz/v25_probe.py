from pathlib import Path
import subprocess
out=Path('.dbg/campaign-query-v25');out.mkdir(exist_ok=True)
s=Path('.dbg/v19_probe_sim.gd').read_text(encoding='utf-8-sig');Path('.dbg/v25_probe_sim.gd').write_text(s,encoding='utf-8')
s=Path('.dbg/v19_probe.gd').read_text(encoding='utf-8-sig').replace('v19_probe_sim','v25_probe_sim').replace('docs/atlas/evidence/resource_capacity_batch_v18/after-12956.json','docs/atlas/evidence/forecast_selected_rows_v24/daily/after-28592.json').replace('.dbg/v19-probe.json','.dbg/campaign-query-v25/probe.json').replace('V19_PROBE_COMPLETE','V25_PROBE_COMPLETE')
Path('.dbg/v25_probe.gd').write_text(s,encoding='utf-8')
with (out/'probe.stdout.txt').open('wb') as o,(out/'probe.stderr.txt').open('wb') as e:
 p=subprocess.Popen(['D:/ProjectICreate/Godot_v4.7.1-stable_win64.exe','--headless','--path',str(Path.cwd()),'--script','res://.dbg/v25_probe.gd'],stdout=o,stderr=e,creationflags=subprocess.CREATE_NO_WINDOW);print('PROBE_START',p.pid,flush=True);c=p.wait(timeout=180)
print('PROBE_EXIT',c);print((out/'probe.stderr.txt').read_text())
