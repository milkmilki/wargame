from pathlib import Path
p=Path('scripts/core/trade_network.gd');s=p.read_text(encoding='utf-8-sig');start=s.index('static func _structure_fingerprint_locked(');end=s.index('\n\nstatic func domestic_ideal_graph_fingerprint_exact',start);old=s[start:end];new=old.replace('trade_structure_v5','trade_structure_v6_packed_records')
pos=new.index('\tfor city in state.cities:');new=new[:pos]+'''	var city_records := PackedInt64Array(); city_records.resize(state.cities.size()*14)
	var city_positions := PackedVector2Array(); city_positions.resize(state.cities.size())
	var city_index := 0
'''+new[pos:]
a=new.index('\t\tfields.append([\n\t\t\t"city"');b=new.index('\n\tfor nation in state.nations:',a)
new=new[:a]+'''		var offset := city_index * 14
		city_records[offset] = city.id
		city_records[offset+1] = city.owner_nation
		city_records[offset+2] = int(city.is_dock)
		city_records[offset+3] = city.node_kind
		city_records[offset+4] = city.gold_per_month
		city_records[offset+5] = city.food_per_half_year
		city_records[offset+6] = non_trade_gold_output
		city_records[offset+7] = int(city.is_capital)
		city_records[offset+8] = int(city.has_warehouse)
		city_records[offset+9] = int(city.is_port_market)
		city_records[offset+10] = int(city.is_crossroads)
		city_records[offset+11] = int(city.is_food_hub)
		city_records[offset+12] = region_id
		city_records[offset+13] = int(city.get_meta("initial_owner_city", -1))
		city_positions[city_index] = city.map_position
		city_index += 1
	fields.append(["cities_packed",city_records,city_positions])
'''+new[b:]
a=new.index('\tfor edge in state.edges:');b=new.index('\n\treturn var_to_bytes(fields)',a)
new=new[:a]+'''	var edge_records := PackedInt64Array(); edge_records.resize(state.edges.size()*7)
	var edge_values := PackedFloat64Array(); edge_values.resize(state.edges.size()*4)
	var edge_index := 0
	for edge in state.edges:
		var offset := edge_index * 7
		edge_records[offset] = edge.city_a
		edge_records[offset+1] = edge.city_b
		edge_records[offset+2] = edge.kind
		edge_records[offset+3] = edge.max_manpower
		edge_records[offset+4] = edge.base_max_manpower
		edge_records[offset+5] = edge.distance
		edge_records[offset+6] = edge.control_city_id
		var value_offset := edge_index * 4
		edge_values[value_offset] = edge.precise_distance
		edge_values[value_offset+1] = edge.travel_time_multiplier
		edge_values[value_offset+2] = edge.danger
		edge_values[value_offset+3] = edge.supply_loss_multiplier
		edge_index += 1
	fields.append(["edges_packed",edge_records,edge_values])'''+new[b:]
s=s[:start]+new+s[end:];p.write_text(s,encoding='utf-8');Path('.dbg/trade-fingerprint-v25/trade_network-after.gd.txt').write_bytes(p.read_bytes())
