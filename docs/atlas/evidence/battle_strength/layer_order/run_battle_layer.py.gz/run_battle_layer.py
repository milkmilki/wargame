from pathlib import Path
import subprocess,sys
r=Path(__file__).resolve().parents[1]
prefix=r/'.dbg'/('battle-layer-'+sys.argv[1])
command=['D:/ProjectICreate/Godot_v4.7.1-stable_win64.exe','--path',str(r),'--script','res://.dbg/battle-strength-layer-gpu.gd']
with prefix.with_suffix('.stdout.txt').open('w',encoding='utf-8') as out, prefix.with_suffix('.stderr.txt').open('w',encoding='utf-8') as err:
    p=subprocess.Popen(command,stdout=out,stderr=err)
    print('BATTLE_LAYER_PID',p.pid,flush=True); code=p.wait(timeout=180)
print('exit',code,flush=True)
print(prefix.with_suffix('.stdout.txt').read_text(encoding='utf-8')[-2400:])
print(prefix.with_suffix('.stderr.txt').read_text(encoding='utf-8')[-1200:])
raise SystemExit(code)
