extends SceneTree
var failures:=0
func check(ok: bool,message: String):
	if not ok: failures+=1;printerr("BATTLE_BAR_GPU_FAIL ",message)
func _initialize():call_deferred("run")
func troop(size: int,owner: int,city: int,guard: bool=false) -> Army:
	var army:=Army.new();army.size=size;army.max_size=30000;army.owner_nation=owner;army.location_city=city;army.is_city_garrison=guard
	return army
func run():
	root.size=Vector2i(1280,720)
	var view=load("res://atlas_military.tscn").instantiate();root.add_child(view)
	var deadline=Time.get_ticks_msec()+120000
	while not view.view_ready or view.generating:
		if Time.get_ticks_msec()>deadline:printerr("BATTLE_BAR_GPU_FAIL startup timeout");quit(1);return
		await process_frame
	view.simulation.set_process(false);view.simulation.paused=true
	check(await view.await_render_ready(15000),"initial render")
	var target:=Vector2((112.+180.)/360.,(90.-34.)/180.)
	var city: City;var distance:=INF
	for candidate in view.state.land_cities():
		var d: float=candidate.map_position.distance_squared_to(target)
		if d<distance:distance=d;city=candidate
	var battle:=Battle.new();battle.id=987654;battle.kind=Battle.Kind.SIEGE;battle.city=city;battle.side_b_defends_city=false
	city.garrison_manpower=1500;battle.side_b=[];battle.side_a=[troop(20000,(city.owner_nation+1)%view.state.nations.size(),city.id)]
	view.state.battles.append(battle)
	var point:=city.map_position*Vector2(2048,1024)
	var samples:=[]
	for entry in [{"zoom":1.,"shift":0.,"name":"1x"},{"zoom":4.,"shift":0.,"name":"4x"},{"zoom":8.,"shift":0.,"name":"8x"},{"zoom":4.,"shift":2048.,"name":"wrap"}]:
		view.zoom=entry.zoom;view.map_root.scale=Vector2.ONE*entry.zoom;view.map_root.position=Vector2(640,360)-(point+Vector2(entry.shift,0))*entry.zoom;view.schedule_symbols()
		# Force the actual front renderer through the bar and its caption.
		var paths: Array=[]
		for height in [-27.,-43.]:
			paths.append({"path":PackedVector2Array([point+Vector2(-140.,height)/entry.zoom,point+Vector2(140.,height)/entry.zoom]),"closed":false,"defender":0})
		view.front_layer.fronts=paths;view.front_layer.classification_count+=1
		view.front_layer.mesh_key.clear();view.front_layer.persistent_version=-1
		view.front_layer.visible=true;view.front_layer.queue_redraw()
		check(await view.await_render_ready(15000),"render "+entry.name)
		for i in range(5):await process_frame
		RenderingServer.force_draw(true)
		var picture=root.get_texture().get_image();picture.save_png("res://.dbg/battle-strength-layer-"+entry.name+".png")
		picture.get_region(Rect2i(490,296,300,120)).save_png("res://.dbg/battle-strength-layer-"+entry.name+"-detail.png")
		var colors: Array=[]
		for x in [538,550,700]:colors.append(picture.get_pixel(x,333).to_html(false))
		samples.append({"view":entry.name,"colors":colors})
		check(colors==["984843","6654b5","6654b5"],"pure city garrison/attacker segments, constant screen position "+entry.name)
		var redraws: int=view.overlay.marker_redraw_count
		for i in range(5):await process_frame
		check(view.overlay.marker_redraw_count==redraws,"stationary battle retains canvas commands "+entry.name)
	print("BATTLE_BAR_GPU ",JSON.stringify({"pid":OS.get_process_id(),"seed":view.state.world_seed,"mask":view.data.options.settlement_mask,"renderer":RenderingServer.get_current_rendering_method(),"samples":samples,"failures":failures,"fixture":"actual front renderer forced through bar and caption; display-only pure siege: city garrison 1500, side_b empty, side_b_defends_city false, attacker 20000; no simulation advancement"}))
	root.remove_child(view);view.queue_free();await process_frame;quit(1 if failures else 0)
