extends "res://scripts/simulation/simulation.gd"
var observed_orders: Array = []
func _record_ai_order(army: Army, candidate: ActionCandidate) -> void:
	observed_orders.append({"day":state.day,"army":army.id,"kind":candidate.kind,"reason":candidate.reason,"from":army.location_city,"target":candidate.target_city})
	super._record_ai_order(army,candidate)
const BeforeUtility = preload("res://.dbg/precontact-retreat/utility-before.gd")
func _decide_ai_army(
	nation_id: int,
	nation: Nation,
	army: Army,
	view: AiWorldView,
	snapshot: StrategicMapSnapshot,
	threat: ThreatField,
	coordinator: ArmyCoordinator,
	minimum_participant_ratio: float,
	defense_plan: CityDefensePlan,
	mobilization_claims: Dictionary = {}
) -> void:
	_set_runtime_profile_stage(&"ai_army_campaign")
	if (
		army.size <= 0
		or mobilization_claims.has(army.id)
		or _ai_planned_armies.has(army.id)
		or state.campaign_assignment_center(army.id) >= 0
		or army.campaign_war_id >= 0
	):
		return
	# 新建或扩编会使国家攻势需求与分配失效；本日先保持原地，下一次
	# 国家级规划完成后再行动，避免在计划重建前由普通 Utility AI 单独冲城。
	if (
		army.is_main_battle_role()
		and army.ai_action == ActionCandidate.Kind.CREATE_ARMY
		and army.ai_order_created_day == state.day
	):
		return
	_set_runtime_profile_stage(&"ai_army_choose")
	var choose_started := (
		Time.get_ticks_usec() if runtime_stage_profiling_enabled else 0
	)
	var candidate := BeforeUtility.choose(
		view,
		snapshot,
		threat,
		coordinator,
		army,
		minimum_participant_ratio,
		defense_plan
	)
	_record_runtime_span(&"ai_army_choose", choose_started)
	if candidate.kind == ActionCandidate.Kind.NONE:
		return
	_set_runtime_profile_stage(&"ai_army_execute")
	var execute_started := (
		Time.get_ticks_usec() if runtime_stage_profiling_enabled else 0
	)
	var executed := _execute_ai_candidate(army, candidate)
	_record_runtime_span(&"ai_army_execute", execute_started)
	if executed:
		if candidate.kind == ActionCandidate.Kind.HOLD:
			coordinator.reserve_edge(
				candidate.target_edge_a,
				candidate.target_edge_b,
				army
			)
		elif candidate.target_city != -1:
			coordinator.reserve(candidate.target_city, army)

