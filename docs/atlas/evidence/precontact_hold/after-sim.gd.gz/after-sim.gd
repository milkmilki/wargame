extends "res://scripts/simulation/simulation.gd"
var observed_orders: Array = []
func _record_ai_order(army: Army, candidate: ActionCandidate) -> void:
	observed_orders.append({"day":state.day,"army":army.id,"kind":candidate.kind,"reason":candidate.reason,"from":army.location_city,"target":candidate.target_city})
	super._record_ai_order(army,candidate)
