from pathlib import Path
import subprocess, json, hashlib, sys, time
r=Path(__file__).resolve().parents[2]; d=Path(__file__).resolve().parent
exe='D:/ProjectICreate/Godot_v4.7.1-stable_win64.exe'
def run(label, opts):
    command=[exe,'--headless','--path',str(r),'--script','res://.dbg/precontact-retreat/probe.gd','--']+['--'+k+'='+str(v) for k,v in opts.items()]
    with (d/(label+'.log')).open('w',encoding='utf-8') as f:
        p=subprocess.Popen(command,stdout=f,stderr=subprocess.STDOUT)
        print(label,'PID',p.pid,flush=True); code=p.wait()
    log=(d/(label+'.log')).read_text(encoding='utf-8')
    if code or 'SCRIPT ERROR' in log or 'ERROR:' in log: raise RuntimeError(label+': '+log[-3000:])
    print(label,'complete',flush=True)
common={'output':str(d/'warmup.json'),'simulation':'res://.dbg/precontact-retreat/before-sim.gd'}
if sys.argv[1]=='warmup':
    run('warmup',dict(common,fresh='true',payload=str(r/'.dbg/atlas-military-eurasia-mask.bin'),days=180,freeze=str(d/'day180.bin')))
else:
    for i in range(5):
        for variant in (['before','after'] if i%2==0 else ['after','before']):
            label=f'{variant}-{i}'
            run(label,dict(common,simulation=f'res://.dbg/precontact-retreat/{variant}-sim.gd',days=60,codec='res://.dbg/precontact-retreat/codec.gd',snapshot=str(d/'day180.bin'),output=str(d/(label+'.json'))))
