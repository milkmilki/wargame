from pathlib import Path
import subprocess,json,gzip,hashlib,statistics
r=Path(__file__).resolve().parents[2]; d=Path(__file__).resolve().parent
command=['D:/ProjectICreate/Godot_v4.7.1-stable_win64.exe','--headless','--path',str(r),'--script','res://tests/army_precontact_hold.gd','--','--utility=res://.dbg/precontact-retreat/utility-before.gd']
with (d/'red.log').open('w',encoding='utf-8') as f:
    p=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT)
assert p.returncode==1
assert 'checks=10 failures=6' in (d/'red.log').read_text(encoding='utf-8')
subprocess.run(['D:/PythonICreate/Python311/python.exe',str(d/'summarize.py')],check=True)
e=r/'docs/atlas/evidence/precontact_hold'; v=json.loads((e/'summary.json').read_text(encoding='utf-8'))
v.update(base_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),godot='4.7.1.stable.official.a13da4feb',date='2026-10-11',red_checks=10,red_failures=6,green_checks=10,green_failures=0,
    method='Five independent processes per variant, alternating order. One day180 snapshot generated from the pre-change UtilityAI and current full-establishment maintenance policy; trade/rulers and dynamic diplomacy enabled. Identical order logging/profiling wrappers; before overrides only _decide_ai_army to call archived UtilityAI. Timings exclude snapshot decode, output and invariant audit.',
    movement_definition='Accepted ATTACK/REINFORCE/RETREAT orders; excludes HOLD and formation creation. Moving samples exclude forced RETREATING state.',
    snapshot_stored_in='.dbg/precontact-retreat/day180.bin (ignored); regenerate with archived run_bench.py warmup',
    limitations=['Single seed and 60-day war window, not a 30-year audit or GUI benchmark.','Removing withdrawals changes subsequent attack orders and battle history; this is not an equivalence optimization.','Whole-AI and total-compute differences below 1% are within run variability, not evidence of overall speedup.'])
v['timing_ranges']={variant:{k:[min(p[variant][k] for p in v['pairs']),max(p[variant][k] for p in v['pairs'])] for k in ['daily_compute_ms','daily_ai_ms','daily_utility_choose_ms']} for variant in ('before','after')}
v['repeated_behavior_equal']={variant:len({json.dumps({k:p[variant][k] for k in ['mean_moving','peak_moving','movement_orders','order_kinds','precontact_retreat_orders']},sort_keys=True) for p in v['pairs']})==1 for variant in ('before','after')}
v['helper_hashes']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in d.glob('*.gd')}
v['test_results']={name:(r/'.dbg/regression'/f'{name}.log').read_text(encoding='utf-8').strip().splitlines()[-1] for name in ['army_precontact_hold','test_suite','campaign_center_defeat_regroup','war_count_and_conqueror','campaign_camp_counteroffensive','atlas_reserve_stations','atlas_access_and_repatriation','project_compile','atlas_territory_transactions','atlas_battle_strength']}
(e/'summary.json').write_text(json.dumps(v,indent=2,ensure_ascii=False),encoding='utf-8')
rows=json.loads((d/'after-0.json').read_text(encoding='utf-8'))['rows']
means={k:statistics.mean(x['profile'].get(k,0)/1000 for x in rows) for k in rows[0]['profile']}
print('Top AI profile means (nested timers must not be summed):', sorted([(k,round(a,3)) for k,a in means.items() if k.startswith('ai')],key=lambda x:-x[1])[:14])
print('Timing ranges:',v['timing_ranges'],'Repeated behavior:',v['repeated_behavior_equal'])
