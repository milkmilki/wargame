from pathlib import Path
import json, statistics, collections, hashlib, gzip, shutil
d=Path(__file__).resolve().parent; r=d.parents[1]
def metrics(p):
    v=json.loads(p.read_text(encoding='utf-8')); rows=v['rows']; orders=v['orders']
    counts=collections.Counter(o['kind'] for o in orders)
    retreat=[o for o in orders if o['kind']==5 and (o['reason'].startswith('局部战力比') or o['reason'].startswith('驻防边敌军优势'))]
    return {'pid':v['pid'],'seed':v['seed'],'mask':v['mask'],'trade':v['trade'],'rulers':v['rulers'],
      'initial':v['initial'],'final':rows[-1], 'errors':v['errors'],
      'daily_compute_ms':statistics.mean(x['compute_us']/1000 for x in rows),
      'daily_ai_ms':statistics.mean(x['profile'].get('ai',0)/1000 for x in rows),
      'daily_army_decisions_ms':statistics.mean(x['profile'].get('ai_army_decisions',0)/1000 for x in rows),
      'daily_utility_choose_ms':v['spans'].get('ai_army_choose',0)/1000/len(rows),
      'mean_moving':statistics.mean(x['moving'] for x in rows),
      'peak_moving':max(x['moving'] for x in rows),'order_kinds':dict(counts),
      'movement_orders':sum(counts[k] for k in (4,2,5)), 'precontact_retreat_orders':len(retreat),
      'precontact_retreat_examples':retreat[:8]}
result={'scope':'headless compute; excludes restore, sampling and audit; not GUI FPS',
    'days':[181,240], 'pairs':[], 'source_hashes':{}, 'snapshot_sha256':hashlib.sha256((d/'day180.bin').read_bytes()).hexdigest()}
for i in range(5):
    result['pairs'].append({v:metrics(d/f'{v}-{i}.json') for v in ('before','after')})
keys=['daily_compute_ms','daily_ai_ms','daily_army_decisions_ms','daily_utility_choose_ms','mean_moving','movement_orders','precontact_retreat_orders']
result['median_of_process_means']={v:{k:statistics.median(x[v][k] for x in result['pairs']) for k in keys} for v in ('before','after')}
for f in ['scripts/ai/utility_ai.gd','scripts/simulation/simulation.gd','tests/army_precontact_hold.gd']:
    result['source_hashes'][f]=hashlib.sha256((r/f).read_bytes()).hexdigest()
e=r/'docs/atlas/evidence/precontact_hold'; e.mkdir(parents=True,exist_ok=True)
(e/'summary.json').write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding='utf-8')
for p in list(d.glob('*.gd'))+list(d.glob('*.py'))+list(d.glob('*.json'))+list(d.glob('*.log')):
    with gzip.open(e/(p.name+'.gz'),'wb') as out: out.write(p.read_bytes())
for name in ['army_precontact_hold','test_suite','campaign_center_defeat_regroup','war_count_and_conqueror','campaign_camp_counteroffensive','atlas_reserve_stations','atlas_access_and_repatriation','project_compile','atlas_territory_transactions','atlas_battle_strength']:
    p=r/'.dbg/regression'/f'{name}.log'
    with gzip.open(e/(p.name+'.gz'),'wb') as out: out.write(p.read_bytes())
print(json.dumps(result['median_of_process_means'],indent=2))
