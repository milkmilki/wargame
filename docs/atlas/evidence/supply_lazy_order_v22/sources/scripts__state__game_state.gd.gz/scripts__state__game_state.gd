class_name GameState
extends RefCounted
## 单一数据源（SSoT）：持有全部 cities / edges / nations / armies，
## 并负责确定性世界生成。所有可变游戏状态都归此对象所有。

const TerritoryTransaction = preload("res://scripts/state/territory_transaction.gd")

const NATION_COUNT: int = 4
const CITY_MANPOWER_PER_MONTH_MIN: int = 500
const CITY_MANPOWER_PER_MONTH_MAX: int = 1000
const RESOURCE_CAPACITY_YEARS: int = 3
const FOOD_CAPACITY_HALF_YEARS: int = RESOURCE_CAPACITY_YEARS * 2
const INITIAL_MANPOWER_RESERVE_MONTHS: int = (RESOURCE_CAPACITY_YEARS+2) * 12
const INITIAL_HEAVY_ARMY_SIZE: int = 15000
const ARMY_COUNT_LIMIT_PER_CITY: int = 3
const ZHOU_GARRISON_CAPACITY: int = 15000
const ZHOU_GARRISON_MONTHLY_REINFORCEMENT: int = 1500
const SMALL_NATION_SURVIVAL_MAX_CITIES: int = 4
const SMALL_NATION_MOBILE_RESERVE_ARMIES: int = 1
const DEFAULT_TRUCE_DAYS: int = 180
const WAR_GOLD_TROOPS_PER_UNIT: int = 1400
const CITY_FOOD_PER_HALF_YEAR_MIN: int = 400
const CITY_FOOD_PER_HALF_YEAR_MAX: int = 600
const TERRAIN_CITY_GOLD_PER_MONTH_MIN: int = 1
const TERRAIN_CITY_GOLD_PER_MONTH_MAX: int = 5
const TERRAIN_CITY_GOLD_TARGET_AVERAGE: int = 7
const TERRAIN_CITY_GOLD_OUTPUT_MIN: int = 1
const TERRAIN_CITY_GOLD_OUTPUT_MAX: int = 15
const TERRAIN_CITY_FOOD_PER_HALF_YEAR_MIN: int = 145
const TERRAIN_CITY_FOOD_PER_HALF_YEAR_MAX: int = 195
const PLAIN_CITY_SHARE: float = 0.35
const PORT_MARKET_OUTPUT_MULTIPLIER: float = 3.0
const CROSSROADS_GOLD_MULTIPLIER: float = 1.5
const PLAIN_GOLD_MULTIPLIER: float = 1.5
const PLAIN_FOOD_MULTIPLIER: float = 1.5
const DEVELOPMENT_PROPAGATION_RATE: float = 0.5
const TERRAIN_HEIGHT_OUTPUT_MIN_MULTIPLIER: float = 0.2
const TERRAIN_HEIGHT_OUTPUT_SIGMOID_MIDPOINT: float = 0.5
const TERRAIN_HEIGHT_OUTPUT_SIGMOID_STEEPNESS: float = 10.0
const CROSSROADS_MIN_ROADS: int = 6
const INITIAL_CITY_FOOD_STOCK_MIN: int = 500
const INITIAL_CITY_FOOD_STOCK_MAX: int = 600
const FOOD_HUB_MIN_OUTPUT: int = 1600
const MANPOWER_HUB_MIN_OUTPUT: int = 800


enum DiplomaticRelation {
	NEUTRAL,
	WAR,
	ALLIED,
}

## 城市实控变化时，原城内库存的结算策略。所有运行期领土业务都必须显式
## 选择一种去向；事务会在提交前确认对应的最终粮池确实可以入账。
enum TerritoryStockDisposition {
	RETURN_TO_OLD_POOL,
	MOVE_TO_NEW_POOL,
	CAPTURE_SPOILS,
	DESTROY,
}

const TERRITORY_CAPTURE_SPOILS_RATE: float = 0.30

## 分封默认贡赋率。
const DEFAULT_TRIBUTE_RATE: float = 0.25
const VASSAL_DISSOLUTION_COHESION_THRESHOLD: float = 0.35
const VASSAL_SYSTEM_DISSOLUTION_DAYS: int = 360
const VASSAL_COLOR_HUE_OFFSET_DEGREES: float = 5.0
const VASSAL_COLOR_SATURATION_OFFSET: float = 0.10
const VASSAL_COLOR_VALUE_OFFSET: float = 0.05
const VASSAL_COLOR_SUBJECT_HUE_VARIANCE_DEGREES: float = 4.0
const ADJACENT_SOVEREIGN_MIN_HUE_DEGREES: float = 15.0
const NATION_COLOR_HUE_MIN: float = 0.0
const NATION_COLOR_HUE_MAX: float = 1.0
## Macaron palette contract: low saturation and high value keep national fills
## soft and readable on the parchment/terrain base without becoming neon.
const NATION_COLOR_SATURATION_MIN: float = 0.28
const NATION_COLOR_SATURATION_MAX: float = 0.42
const NATION_COLOR_VALUE_MIN: float = 0.70
const NATION_COLOR_VALUE_MAX: float = 0.80
## Fixed HSV palette: coral, powder blue, mint and cream orange.
const NATION_PALETTE_HUES := [
	0.000,
	0.610,
	0.350,
	0.140,
]
const NATION_PALETTE_SATURATIONS := [0.38, 0.32, 0.30, 0.36]
const NATION_PALETTE_VALUES := [0.84, 0.86, 0.82, 0.90]


static func army_monthly_upkeep(troops: int) -> int:
	if troops <= 0:
		return 0
	return int(ceil(
		float(troops) / float(WAR_GOLD_TROOPS_PER_UNIT)
	))


## Shared HSV contract for every faction-owned visual. Hue and alpha survive;
## saturation/value stay inside the requested non-neon palette rectangle.
static func normalize_nation_color(color: Color) -> Color:
	return Color.from_hsv(
		clampf(color.h, NATION_COLOR_HUE_MIN, NATION_COLOR_HUE_MAX),
		clampf(
			color.s,
			NATION_COLOR_SATURATION_MIN,
			NATION_COLOR_SATURATION_MAX
		),
		clampf(
			color.v,
			NATION_COLOR_VALUE_MIN,
			NATION_COLOR_VALUE_MAX
		),
		color.a
	)


func nation_monthly_military_upkeep(nation_id: int) -> int:
	var total := 0
	for army in armies:
		if financial_nation_of(army.owner_nation) == nation_id and army.size > 0:
			total += army_monthly_upkeep(army.size)
	return total

var cities: Array[City] = []
var edges: Array[Edge] = []
var nations: Array[Nation] = []
var armies: Array[Army] = []
var battles: Array[Battle] = []            ## 进行中的多回合战斗
## front_id -> CoalitionCampaignFront。州战线属于战争集团连通分量，不属于国家。
var campaign_fronts: Dictionary = {}
var next_campaign_front_id: int = 0
var campaign_pairs: Dictionary = {} # pair_id -> CoalitionCampaignPair
var next_campaign_pair_id: int = 0
var _campaign_pair_revision: Array[int] = []
## Atlas alliance topology is immutable between exact relation/identity changes.
## Both alive-only variants share their own complete, read-only graph.
var _alliance_component_cache: Dictionary = {}
var _alliance_component_mutex := Mutex.new()
## 王族谱共享真源；Nation 仅保存 tree/person id，避免独立后复制谱系。
var family_trees: Dictionary = {}
var succession_conflicts: Dictionary = {} # original nation -> SuccessionConflict
var succession_events: Array[Dictionary] = []
var next_family_tree_id: int = 0
var next_family_person_id: int = 0
var family_revision: int = 0

## 邻接表：city_id -> Array[int]（相邻 city_id）
var adjacency: Dictionary = {}
## 边查找：规范化无碰撞 int64 key -> Edge
var edge_lookup: Dictionary = {}

var day: int = 0                            ## 时间真源（1 tick = 1 天）
var month: int = 0                          ## 派生显示量：day / DAYS_PER_MONTH（每 tick 由 Simulation 刷新）
var rng: RandomNumberGenerator = RandomNumberGenerator.new()
var world_seed: int = 12345                 ## 命名/君主等独立确定性域的稳定种子
## 正式世界/地图模板启用确定性君主；兼容网格夹具保持中性，且其运行时
## 新建藩王/叛军沿用同一模式。不能借 uses_heightmap 判断，因为旧测试会单独切换它。
var _random_ruler_profiles_enabled: bool = true


func random_ruler_profiles_enabled() -> bool:
	return _random_ruler_profiles_enabled
var _next_army_id: int = 0
var _next_battle_id: int = 0
var next_war_id: int = 0
var ownership_revision: int = 0             ## 城市易主版本号，供战略地图缓存失效
var diplomacy_revision: int = 0             ## 外交关系版本号，供 AI 战略缓存失效
var garrison_revision: int = 0              ## 州治守军变化版本号，供战役缓存失效
var road_network_revision: int = 0          ## 运行时道路通行性/容量重算版本号
## 规范化国家对 key -> DiplomaticRelation / 关系生效日 / 停战截止日。
var diplomatic_relations: Dictionary = {}
var diplomatic_since_day: Dictionary = {}
var truce_until_day: Dictionary = {}
var diplomatic_history: Array[Dictionary] = []
## 只在战争或政治事务最终结束时追加的冻结历史记录。
var chronicle_events: Array[Dictionary] = []
## war_id -> 结算期间的参与者、名称快照与实际战斗损失。
var war_chronicle_contexts: Dictionary = {}
var chronicle_pending_war_ids: Array[int] = []
## 规范化交战国家对 -> 稳定战争 ID。外交目标只是开战目标，不承担战争身份。
var war_relation_ids: Dictionary = {}
## 规范化国家对 key -> {attacker, defender, city_id, reason, started_day, scope}。
var war_objectives: Dictionary = {}
## 宗藩关系有向真源（SSoT）：subject_id -> {
##     overlord_id, tribute_rate, created_day,
##     last_centralization_day, civil_war
## }。不对称，故不塞进对称的 diplomatic_relations。
## 不变量：一个藩王至多一个宗主；宗主链无环；非内战宗藩对为 ALLIED，
## 削藩内战宗藩对为 WAR。
var suzerainty: Dictionary = {}
var vassal_conflicts: Dictionary = {}
var last_vassal_conflict_result: Dictionary = {}
## 宗藩根 id -> 本轮连续低于私人战争阈值的首日。
var suzerainty_low_cohesion_since_day: Dictionary = {}
var _suzerainty_cohesion_revision: int = -1
var _suzerainty_cohesion_by_root: Dictionary = {}
var uses_heightmap: bool = false
var map_aspect_ratio: float = 1.0
var generation_metadata: Dictionary = {}
var map_models: Dictionary = {}
var atlas_layout: Dictionary = {}
var trade_enabled: bool = true
## Runtime-only Atlas trade geometry and fiscal cache; never part of map templates.
var atlas_trade_cache: Dictionary = {}
var atlas_trade_centers: Dictionary = {}
var atlas_trade_mutex := Mutex.new()

func generate_from_atlas(payload: Dictionary) -> void:
	load("res://scripts/atlas/military_import.gd").install(self,payload)

func atlas_edge_access(edge: Edge,nation_id: int,goal: int = -1,logistics: bool = false,exit_city: int = -1) -> bool:
	if edge.control_city_id<0 or edge.control_city_id>=cities.size(): return false
	var control := cities[edge.control_city_id]
	if not logistics and edge.control_city_id==exit_city: return true
	if edge.control_city_id==goal and is_enemy(nation_id,control.owner_nation): return true
	return has_logistics_access(nation_id,control.owner_nation) if logistics else has_military_access(nation_id,control.owner_nation)
var last_generation_error: String = ""
## 每个有效栅格像素保存所属 city_id；-1 表示地图轮廓外。
var province_map_size: Vector2i = Vector2i.ZERO
var province_ids: PackedInt32Array = PackedInt32Array()

func province_city_at(position: Vector2) -> int:
	if not position.is_finite() or position.x < 0 or position.y < 0 or position.x >= 1 or position.y >= 1:
		return -1
	if province_map_size.x <= 0 or province_map_size.y <= 0 or province_ids.size() != province_map_size.x * province_map_size.y:
		return -1
	var cell := Vector2i(position * Vector2(province_map_size))
	return province_ids[cell.y * province_map_size.x + cell.x]
## Static transport-graph analysis. Region IDs are assigned by deterministic
## Leiden; node betweenness and key cities use the same passable graph,
## including docks and their landing, river and sea connections.
var region_ids: PackedInt32Array = PackedInt32Array()
var region_count: int = 0
var region_colors: PackedColorArray = PackedColorArray()
var node_betweenness: PackedFloat32Array = PackedFloat32Array()
var region_key_city_ids: PackedInt32Array = PackedInt32Array()
var region_analysis_revision: int = 0
var regional_strategy_revision: int = 0
var _regional_strategy_geometry: Dictionary = {}
var _regional_strategy_control: Dictionary = {}
## Land-only administrative regions. Docks and inactive cities remain -1 and
## never bridge two land components. These values are derived from roads.
var administrative_region_ids: PackedInt32Array = PackedInt32Array()
var administrative_center_by_city: PackedInt32Array = PackedInt32Array()
var administrative_hop_distances: PackedInt32Array = PackedInt32Array()
var administrative_center_city_ids: PackedInt32Array = PackedInt32Array()
var administrative_region_count: int = 0
var administrative_region_colors: PackedColorArray = PackedColorArray()
var administrative_region_revision: int = 0
var _garrisons_initialized: bool = false
## Political borders are land-city contacts, not arbitrary transport edges.
## A river dock creates one local crossing between its banks; river/sea links
## between docks remain transport-only and never extend this topology.
var _territorial_border_cache_revision: Array[int] = []
var _territorial_border_pairs: Array[Vector2i] = []
var _territorial_border_adjacency: Array = []
var _local_crossing_banks_by_dock: Dictionary = {}
var _territorial_border_cache_mutex := Mutex.new()
## 省份栅格的静态拓扑缓存。领土变化只重新聚合宗藩根，不重复扫描贴图。
var _province_neighbor_pairs: Array[Vector2i] = []
var _province_neighbor_pairs_ready: bool = false
## 版本化自然特征记录。河流点严格按源头到下游排列；程序化水文、导入
## 地图和当前省界生成器都必须输出同一契约。通行真源仍是 Edge。
var river_features: Array[Dictionary] = []
## Runtime river traffic is empty in Atlas; environmental hydrology lives in atlas_layout.data.
var river_paths: Array[PackedVector2Array] = []
## 法理归属用于区分“本国底色”和“占领国斜线”；和平协议会确认实际控制区。
var recognized_city_owners: PackedInt32Array = PackedInt32Array()
## 地方叛乱真源：rebel_nation_id -> {parent_id,started_day,core_city_ids,
## recognized,active,reason}。削藩内战继续使用 suzerainty.civil_war。
var rebellions: Dictionary = {}
## 当月派生贸易路线；静态道路仍由 edges 持有。
var trade_routes: Array[Dictionary] = []
var trade_revision: int = 0
var naming_revision: int = 0

## 结束态
var winner: int = -1                        ## -1 表示未结束

# ------------------------------------------------------------------ 生成

func generate_from_map_definition(definition: Dictionary) -> void:
	var validation_error := MapDefinition.validate(definition)
	if not validation_error.is_empty():
		last_generation_error = validation_error
		return
	generate_from_atlas(load("res://scripts/atlas/military_template.gd").decode(definition))


func apply_city_editor_changes(
	city_id: int,
	changes: Dictionary
) -> Dictionary:
	if city_id < 0 or city_id >= cities.size():
		return {"ok": false, "error": "城市不存在。"}
	var city := cities[city_id]
	if not atlas_layout.is_empty() and city.is_traffic:
		return {"ok": false, "error": "交通节点不是可编辑的治所。"}
	# 先完成所有可能失败的校验；尤其不能在领土事务被拒绝前移动地图坐标。
	var new_position := Vector2(
		clampf(float(changes.get("map_x", city.map_position.x)), 0.0, 1.0),
		clampf(float(changes.get("map_y", city.map_position.y)), 0.0, 1.0)
	)
	var position_changed := new_position != city.map_position
	if not atlas_layout.is_empty() and position_changed:
		return {"ok": false, "error": "Atlas 治所位置属于固定州府布局，请通过独立场景重新生成。"}
	var previous_owner := city.owner_nation
	var owner := clampi(int(changes.get("owner_nation", previous_owner)), 0, nations.size() - 1)
	var owner_changed := owner != previous_owner
	if (
		owner_changed
		and not city.is_dock
		and land_cities_of(previous_owner).size() <= 1
	):
		return {"ok": false, "error": "不能转移一个国家的最后一座陆地城市。"}
	# 先解析全部字段，避免任一无效值在领土或坐标已提交后才触发转换错误。
	var manpower_per_month := maxi(int(changes.get(
		"manpower_per_month", city.manpower_per_month
	)), 0)
	var gold_per_month := maxi(int(changes.get(
		"gold_per_month", city.gold_per_month
	)), 0)
	var food_per_half_year := maxi(int(changes.get(
		"food_per_half_year", city.food_per_half_year
	)), 0)
	var food_storage := maxi(int(changes.get(
		"food_storage", city.food_storage
	)), 0)
	var terrain_height := clampf(float(changes.get(
		"terrain_height", city.terrain_height
	)), 0.0, 1.0)
	var terrain_relief := clampf(float(changes.get(
		"terrain_relief", city.terrain_relief
	)), 0.0, 1.0)
	var terrain_output_multiplier := clampf(float(changes.get(
		"terrain_output_multiplier", city.terrain_output_multiplier
	)), 0.0, 4.0)
	var development_gold_multiplier := clampf(float(changes.get(
		"development_gold_multiplier", city.development_gold_multiplier
	)), 0.0, 10.0)
	var development_food_multiplier := clampf(float(changes.get(
		"development_food_multiplier", city.development_food_multiplier
	)), 0.0, 10.0)
	if owner_changed:
		var territory_result := transfer_city_sovereignty(
			city_id, owner, "city_editor_transfer",
			TerritoryStockDisposition.MOVE_TO_NEW_POOL
		)
		if not bool(territory_result.get("ok", false)):
			return {
				"ok": false,
				"error": str(territory_result.get(
					"error", "领土转移失败。"
				)),
			}
	city.map_position = new_position
	city.manpower_per_month = manpower_per_month
	city.gold_per_month = gold_per_month
	city.food_per_half_year = food_per_half_year
	city.food_storage = food_storage
	city.terrain_height = terrain_height
	RegionalStrategy.invalidate_geometry(self)
	city.terrain_relief = terrain_relief
	city.terrain_output_multiplier = terrain_output_multiplier
	city.development_gold_multiplier = development_gold_multiplier
	city.development_food_multiplier = development_food_multiplier
	city.is_food_hub = bool(changes.get("is_food_hub", city.is_food_hub))
	city.is_manpower_hub = bool(changes.get("is_manpower_hub", city.is_manpower_hub))
	city.is_plain_city = bool(changes.get("is_plain_city", city.is_plain_city))
	city.is_port_market = bool(changes.get("is_port_market", city.is_port_market))
	city.is_crossroads = bool(changes.get("is_crossroads", city.is_crossroads))
	return {"ok": true, "city_id": city_id}


func apply_edge_editor_changes(
	city_a: int,
	city_b: int,
	changes: Dictionary
) -> Dictionary:
	var edge := edge_of(city_a, city_b)
	if edge == null:
		return {"ok": false, "error": "道路不存在。"}
	if not atlas_layout.is_empty():
		if int(changes.get("kind",edge.kind))!=Edge.Kind.LAND: return {"ok":false,"error":"Atlas 本轮只允许陆路，不能重新启用河运或海运。"}
		for army in armies:
			if army.on_edge or not army.path.is_empty() or army.battle_id>=0 or army.campaign_front_id>=0: return {"ok":false,"error":"存在行军、战斗或战线绑定，不能编辑Atlas交通。"}
		for battle in battles:
			if not battle.finished: return {"ok":false,"error":"战斗期间不能编辑Atlas交通。"}
	var was_region_link := _edge_participates_in_region_graph(edge)
	var previous_kind := edge.kind
	edge.kind = clampi(int(changes.get("kind", edge.kind)), Edge.Kind.LAND, Edge.Kind.SEA)
	if previous_kind == Edge.Kind.RIVER and edge.kind != Edge.Kind.RIVER:
		edge.river_navigation.clear()
		edge.river_reaches.clear()
	var requested_capacity := int(changes.get("max_manpower", edge.max_manpower))
	edge.distance = maxi(int(changes.get("distance", edge.distance)), 1)
	edge.danger = clampf(float(changes.get("danger", edge.danger)), 0.0, 1.0)
	edge.travel_time_multiplier = maxf(float(changes.get("travel_time_multiplier", edge.travel_time_multiplier)), 0.01)
	edge.supply_loss_multiplier = maxf(float(changes.get("supply_loss_multiplier", edge.supply_loss_multiplier)), 0.0)
	edge.allows_holding = bool(changes.get("allows_holding", edge.allows_holding))
	edge.max_height_difference = clampf(float(changes.get("max_height_difference", edge.max_height_difference)), 0.0, 1.0)
	edge.land_ratio = clampf(float(changes.get("land_ratio", edge.land_ratio)), 0.0, 1.0)
	if edge.kind == Edge.Kind.RIVER:
		edge.max_manpower = (
			Edge.WATER_MANPOWER
			if edge.river_is_navigable()
			else 0
		)
	elif edge.kind == Edge.Kind.SEA:
		edge.max_manpower = Edge.WATER_MANPOWER
	else:
		edge.max_manpower = Edge.quantize_land_capacity(requested_capacity)
	edge.base_max_manpower = edge.max_manpower
	edge.is_backbone = bool(changes.get("is_backbone", edge.is_backbone))
	edge.is_terrain_connector = (
		edge.kind == Edge.Kind.LAND
		and bool(changes.get(
			"is_terrain_connector", edge.is_terrain_connector
		))
	)
	if edge.kind in [Edge.Kind.RIVER, Edge.Kind.SEA]:
		edge.allows_holding = false
	road_network_revision += 1
	if was_region_link != _edge_participates_in_region_graph(edge):
		rebuild_region_analysis()
	rebuild_administrative_regions()
	return {"ok": true, "city_a": edge.city_a, "city_b": edge.city_b}


func _reset_world(world_seed: int) -> void:
	atlas_layout.clear(); trade_enabled = true
	self.world_seed = world_seed
	rng.seed = world_seed
	cities.clear()
	edges.clear()
	nations.clear()
	family_trees.clear()
	remove_meta("royal_census")
	remove_meta("royal_reconcile_revision")
	succession_conflicts.clear()
	succession_events.clear()
	next_family_tree_id = 0
	next_family_person_id = 0
	family_revision = 0
	armies.clear()
	battles.clear()
	campaign_fronts.clear()
	campaign_pairs.clear()
	next_campaign_pair_id = 0
	_campaign_pair_revision.clear()
	_alliance_component_cache.clear()
	adjacency.clear()
	edge_lookup.clear()
	day = 0
	month = 0
	winner = -1
	_next_army_id = 0
	next_war_id = 0
	next_campaign_front_id = 0
	ownership_revision = 0
	diplomacy_revision = 0
	garrison_revision = 0
	road_network_revision = 0
	diplomatic_relations.clear()
	diplomatic_since_day.clear()
	truce_until_day.clear()
	diplomatic_history.clear()
	chronicle_events.clear()
	war_chronicle_contexts.clear()
	chronicle_pending_war_ids.clear()
	war_relation_ids.clear()
	war_objectives.clear()
	suzerainty.clear()
	vassal_conflicts.clear()
	last_vassal_conflict_result.clear()
	suzerainty_low_cohesion_since_day.clear()
	_suzerainty_cohesion_revision = -1
	_suzerainty_cohesion_by_root.clear()
	generation_metadata = {}
	map_models = {}
	last_generation_error = ""
	province_map_size = Vector2i.ZERO
	province_ids = PackedInt32Array()
	region_ids = PackedInt32Array()
	region_count = 0
	region_colors = PackedColorArray()
	node_betweenness = PackedFloat32Array()
	region_key_city_ids = PackedInt32Array()
	region_analysis_revision = 0
	regional_strategy_revision = 0
	_regional_strategy_geometry.clear()
	_regional_strategy_control.clear()
	administrative_region_ids = PackedInt32Array()
	administrative_center_by_city = PackedInt32Array()
	administrative_hop_distances = PackedInt32Array()
	administrative_center_city_ids = PackedInt32Array()
	administrative_region_count = 0
	administrative_region_colors = PackedColorArray()
	administrative_region_revision = 0
	_garrisons_initialized = false
	_territorial_border_cache_revision.clear()
	_territorial_border_pairs.clear()
	_territorial_border_adjacency.clear()
	_local_crossing_banks_by_dock.clear()
	_province_neighbor_pairs.clear()
	_province_neighbor_pairs_ready = false
	river_features.clear()
	river_paths.clear()
	recognized_city_owners = PackedInt32Array()
	rebellions.clear()
	trade_routes.clear()
	atlas_trade_cache.clear()
	atlas_trade_centers = {}
	trade_revision = 0
	naming_revision = 0
	_random_ruler_profiles_enabled = true


func _generate_nations(
	initial_relation: int,
	nation_count: int = NATION_COUNT,
	initialize_rulers: bool = true
) -> void:
	_random_ruler_profiles_enabled = initialize_rulers
	for i in range(nation_count):
		var n := Nation.new()
		n.id = i
		n.color = normalize_nation_color(
			Color.from_hsv(
				float(NATION_PALETTE_HUES[i]),
				float(NATION_PALETTE_SATURATIONS[i]),
				float(NATION_PALETTE_VALUES[i])
			)
			if nation_count == NATION_COUNT
			else Color.from_hsv(
				lerpf(
					NATION_COLOR_HUE_MIN,
					NATION_COLOR_HUE_MAX,
					fposmod(float(i) * 0.61803398875, 1.0)
				),
				0.30 + float(i % 4) * 0.025,
				0.78 + float(i % 5) * 0.025
			)
		)
		n.treasury_gold = 10000
		n.political_system = 0
		n.alive = true
		if initialize_rulers:
			RulerProfile.initialize_nation(n, world_seed, i)
		else:
			n.ruler_archetype = RulerProfile.BALANCED
			n.ruler_traits.clear()
			n.trade_policy = RulerProfile.POLICY_BALANCED
		nations.append(n)
	for nation_a in range(nations.size()):
		for nation_b in range(nation_a + 1, nations.size()):
			var key := _diplomacy_key(nation_a, nation_b)
			diplomatic_relations[key] = initial_relation
			diplomatic_since_day[key] = day
			if initial_relation == DiplomaticRelation.WAR:
				war_relation_ids[key] = next_war_id
				next_war_id += 1


func _initialize_recognized_city_owners() -> void:
	recognized_city_owners.resize(cities.size())
	for city in cities:
		recognized_city_owners[city.id] = city.owner_nation


func _initialize_manpower_pools() -> void:
	for nation in nations:
		nation.manpower_pool = 0
	for city in cities:
		if city.owner_nation < 0 or city.owner_nation >= nations.size():
			continue
		nations[city.owner_nation].manpower_pool += (
			city.manpower_per_month * INITIAL_MANPOWER_RESERVE_MONTHS
		)


static func terrain_height_output_multiplier(
	normalized_height: float
) -> float:
	var height := clampf(normalized_height, 0.0, 1.0)
	var sigmoid_at_low := 1.0 / (
		1.0 + exp(
			TERRAIN_HEIGHT_OUTPUT_SIGMOID_STEEPNESS
				* (0.0 - TERRAIN_HEIGHT_OUTPUT_SIGMOID_MIDPOINT)
		)
	)
	var sigmoid_at_high := 1.0 / (
		1.0 + exp(
			TERRAIN_HEIGHT_OUTPUT_SIGMOID_STEEPNESS
				* (1.0 - TERRAIN_HEIGHT_OUTPUT_SIGMOID_MIDPOINT)
		)
	)
	var sigmoid_at_height := 1.0 / (
		1.0 + exp(
			TERRAIN_HEIGHT_OUTPUT_SIGMOID_STEEPNESS
				* (
					height
					- TERRAIN_HEIGHT_OUTPUT_SIGMOID_MIDPOINT
				)
		)
	)
	var normalized_sigmoid := (
		(sigmoid_at_height - sigmoid_at_high)
		/ (sigmoid_at_low - sigmoid_at_high)
	)
	return (
		TERRAIN_HEIGHT_OUTPUT_MIN_MULTIPLIER
		+ (
			1.0
			- TERRAIN_HEIGHT_OUTPUT_MIN_MULTIPLIER
		) * normalized_sigmoid
	)


func _initialize_capitals_and_warehouses() -> void:
	var initial_food: Array[int] = []
	initial_food.resize(nations.size())
	initial_food.fill(0)
	for city in cities:
		if city.owner_nation >= 0 and city.owner_nation < nations.size():
			initial_food[city.owner_nation] += city.food_storage
		city.food_storage = 0
		city.is_capital = false
		city.capital_since_day = -1
		city.has_warehouse = false
	for nation in nations:
		var owned := land_cities_of(nation.id)
		var owned_zhou: Array[City] = []
		for city in owned:
			if is_zhou_city(city.id):
				owned_zhou.append(city)
		var candidates := owned_zhou if not owned_zhou.is_empty() else owned
		var centroid := Vector2.ZERO
		for city in owned:
			centroid += city.map_position
		centroid /= float(maxi(owned.size(), 1))
		var capital_id := candidates[0].id
		var best_distance := INF
		for city in candidates:
			var distance := city.map_position.distance_squared_to(centroid)
			if distance < best_distance or (
					is_equal_approx(distance, best_distance)
					and EquivariantOrder.city_id_less(
						self,
						nation.id,
						city.id,
						capital_id
					)
			):
				best_distance = distance
				capital_id = city.id
		nation.capital_city_id = capital_id
		nation.warehouse_city_ids = [capital_id] as Array[int]
		var capital := cities[capital_id]
		capital.is_capital = true
		capital.capital_since_day = day
		capital.has_warehouse = true
		capital.food_storage = initial_food[nation.id]


func _initialize_city_loyalty(reset_values: bool = true) -> void:
	for city in cities:
		var recognized := recognized_owner_of(city.id)
		if reset_values or city.loyalty_target_nation < 0:
			city.loyalty_target_nation = (
				recognized if recognized >= 0 else city.owner_nation
			)
		if reset_values:
			city.loyalty = RebellionSystem.LOYALTY_DEFAULT
			city.loyalty_trend = 0.0
			city.unrest = 100.0 - city.loyalty
			city.rebellion_progress = 0
			city.rebellion_cooldown_until_day = -1
			city.last_loyalty_reason = "initial"


## 首都道路跳数的公共真源；忠诚、分封和未来行政范围共用。
func capital_hop_distances(nation_id: int) -> Dictionary:
	return RebellionSystem.capital_hops(self, nation_id)


## 四象限等分：每国 4x4=16 城
func rebuild_region_analysis(
	resolution: float = RegionGraphAnalysis.DEFAULT_RESOLUTION
) -> Dictionary:
	var started := Time.get_ticks_usec()
	var active := PackedInt32Array()
	for city in cities:
		if not city.is_traffic: active.append(city.id)
	var links: Array[Vector2i] = []
	if not atlas_layout.is_empty():
		for a in atlas_layout.settlement_adjacency:
			for b in atlas_layout.settlement_adjacency[a]:
				if a<b: links.append(Vector2i(a,b))
	else:
		for edge in edges:
			if _edge_participates_in_region_graph(edge): links.append(Vector2i(edge.city_a, edge.city_b))
	var analysis := RegionGraphAnalysis.analyze(
		cities.size(), active, links, resolution
	)
	region_ids = analysis["region_ids"]
	region_count = int(analysis["region_count"])
	node_betweenness = analysis["betweenness"]
	region_key_city_ids = analysis["key_city_ids"]
	region_colors.resize(region_count)
	for region_id in range(region_count):
		region_colors[region_id] = region_color(region_id)
	region_analysis_revision += 1
	RegionalStrategy.invalidate_geometry(self)
	return {
		"region_count": region_count,
		"key_city_count": region_key_city_ids.size(),
		"node_count": active.size(),
		"edge_count": links.size(),
		"elapsed_usec": Time.get_ticks_usec() - started,
		"revision": region_analysis_revision,
	}


func rebuild_administrative_regions() -> Dictionary:
	if not atlas_layout.is_empty():
		var h: Dictionary = atlas_layout.hierarchy
		administrative_region_count = h.state_parents.size()
		administrative_region_ids.resize(cities.size()); administrative_region_ids.fill(-1)
		administrative_center_by_city.resize(cities.size()); administrative_center_by_city.fill(-1)
		administrative_hop_distances.resize(cities.size()); administrative_hop_distances.fill(-1)
		administrative_center_city_ids.clear()
		for state in range(h.members.size()):
			administrative_center_city_ids.append(state)
			for city_id in h.members[state]:
				administrative_region_ids[city_id] = state; administrative_center_by_city[city_id] = state
				administrative_hop_distances[city_id] = 0 if city_id==state else 1
		administrative_region_colors.resize(administrative_region_count)
		for id in range(administrative_region_count): administrative_region_colors[id] = region_color(id)
		administrative_region_revision += 1
		return {"region_count":administrative_region_count,"center_count":administrative_region_count,"revision":administrative_region_revision,"fixed":true}
	var started := Time.get_ticks_usec()
	var previous_centers := {}
	if _garrisons_initialized:
		for center_value in administrative_center_city_ids:
			previous_centers[int(center_value)] = true
	var active := PackedInt32Array()
	var positions := PackedVector2Array()
	positions.resize(cities.size())
	for city in cities:
		positions[city.id] = city.map_position
		city.administrative_rebellion_progress = 0
		if city.politically_active and not city.is_dock:
			active.append(city.id)
	var links: Array[Vector2i] = []
	var attachment_links: Array[Vector2i] = []
	for edge in edges:
		if (
			edge == null
			or edge.max_manpower <= 0
			or edge.city_a < 0
			or edge.city_b < 0
			or edge.city_a >= cities.size()
			or edge.city_b >= cities.size()
			or not cities[edge.city_a].politically_active
			or not cities[edge.city_b].politically_active
		):
			continue
		if edge.kind == Edge.Kind.LAND:
			# 州界只按陆路划分，码头保持独立交通节点，不进州域。
			if cities[edge.city_a].is_dock or cities[edge.city_b].is_dock:
				continue
			links.append(Vector2i(edge.city_a, edge.city_b))
		else:
			# 抢滩、水路与海路只用于把没有陆路连接的孤城并入邻州，不参与
			# 州界划分本身。两端都必须是州域城市：码头在初始国家分配里是
			# 独立节点，穿过码头的归属路径不保证同属一国，会让并入的孤城
			# 变成只能穿过外国码头的飞地。
			if cities[edge.city_a].is_dock or cities[edge.city_b].is_dock:
				continue
			attachment_links.append(Vector2i(edge.city_a, edge.city_b))
	var analysis := AdministrativeRegionAnalysis.analyze(
		cities.size(), active, links, positions, attachment_links
	)
	administrative_region_ids = analysis["region_ids"]
	administrative_region_count = int(analysis["region_count"])
	administrative_center_city_ids = analysis["center_city_ids"]
	administrative_center_by_city = analysis["center_by_city"]
	administrative_hop_distances = analysis["hop_distances"]
	administrative_region_colors.resize(administrative_region_count)
	for region_id in range(administrative_region_count):
		administrative_region_colors[region_id] = region_color(region_id)
	administrative_region_revision += 1
	RegionalStrategy.invalidate_geometry(self)
	if _garrisons_initialized:
		_reconcile_garrisons_after_administrative_rebuild(previous_centers)
	war_objectives.clear()
	clear_campaign_fronts()
	for nation in nations:
		nation.war_preparation_objective_center_city = -1
	return {
		"region_count": administrative_region_count,
		"center_count": administrative_center_city_ids.size(),
		"node_count": active.size(),
		"edge_count": links.size(),
		"elapsed_usec": Time.get_ticks_usec() - started,
		"revision": administrative_region_revision,
	}


func administrative_center_of(city_id: int) -> int:
	if city_id < 0 or city_id >= administrative_center_by_city.size():
		return -1
	return administrative_center_by_city[city_id]


func is_zhou_city(city_id: int) -> bool:
	return city_id >= 0 and administrative_center_of(city_id) == city_id


func is_fu_city(city_id: int) -> bool:
	var center := administrative_center_of(city_id)
	return center >= 0 and center != city_id


func administrative_members(center_city_id: int) -> Array[int]:
	var result: Array[int] = []
	if not is_zhou_city(center_city_id):
		return result
	for city_id in range(administrative_center_by_city.size()):
		if administrative_center_by_city[city_id] == center_city_id:
			result.append(city_id)
	return result


func administrative_controller(center_city_id: int) -> int:
	if not is_zhou_city(center_city_id):
		return -1
	return cities[center_city_id].owner_nation


func city_garrison_capacity(city_id: int) -> int:
	if (
		city_id < 0
		or city_id >= cities.size()
		or cities[city_id].is_dock
		or not cities[city_id].politically_active
	):
		return 0
	return ZHOU_GARRISON_CAPACITY if is_zhou_city(city_id) else 0


## Batch queries pass their already resolved bloc; direct queries resolve it here.
func administrative_campaign_control_share(
	attacker_id: int,
	center_city_id: int,
	attacker_bloc: Array[int] = []
) -> float:
	if not is_zhou_city(center_city_id):
		return 0.0
	var fu_count := 0
	var controlled_fu_count := 0
	if attacker_bloc.is_empty():
		attacker_bloc = alliance_bloc(attacker_id)
	if attacker_bloc.is_empty() and attacker_id >= 0:
		attacker_bloc.append(attacker_id)
	for city_id in administrative_members(center_city_id):
		if city_id == center_city_id:
			continue
		fu_count += 1
		if attacker_bloc.has(cities[city_id].owner_nation):
			controlled_fu_count += 1
	if fu_count <= 0:
		return 0.0
	return float(controlled_fu_count) / float(fu_count)


func city_garrison_defense_bonus(
	attacker_id: int,
	center_city_id: int,
	attacker_bloc: Array[int] = []
) -> float:
	if not is_zhou_city(center_city_id):
		return 1.0
	if not atlas_layout.is_empty() and administrative_members(center_city_id).size()==1: return 1.0
	var control_share := administrative_campaign_control_share(
		attacker_id, center_city_id, attacker_bloc
	)
	return 3.0 - 2.0 * clampf(control_share, 0.0, 1.0)


func campaign_siege_requirement(
	attacker_id: int,
	center_city_id: int,
	attacker_bloc: Array[int] = []
) -> int:
	if not is_zhou_city(center_city_id):
		return 0
	var garrison := maxi(cities[center_city_id].garrison_manpower, 0)
	return ceili(
		float(garrison)
			* city_garrison_defense_bonus(attacker_id, center_city_id, attacker_bloc)
	)


## R stays raw manpower. Apply ruler policy only to the siege demand.
func campaign_required_manpower(attacker_id: int, raw_requirement: int) -> int:
	var multiplier := (
		RulerProfile.campaign_requirement_multiplier(nations[attacker_id])
		if attacker_id >= 0 and attacker_id < nations.size() else 1.0
	)
	return ceili(float(maxi(raw_requirement, 0)) * multiplier)


func campaign_attack_requirement(
	attacker_id: int,
	center_city_id: int,
	include_field_threat: bool = true
) -> int:
	var siege := campaign_required_manpower(attacker_id,
		campaign_siege_requirement(attacker_id, center_city_id))
	return maxi(siege, campaign_minimum_launch_requirement(attacker_id, center_city_id)) if include_field_threat else siege


## Strict integer threshold: C > 0.9V, or C > 0.45V for a conqueror.
## Empty fields still require a real, available army.
func campaign_field_minimum_manpower(nation_id: int, enemy_manpower: int) -> int:
	var conqueror := (nation_id >= 0 and nation_id < nations.size()
		and nations[nation_id].ruler_archetype == RulerProfile.CONQUEROR)
	return maxi(enemy_manpower, 0) * (9 if conqueror else 18) / 20 + 1


func campaign_offense_manpower(nation_id: int, raw_siege: int, enemy_manpower: int) -> int:
	return maxi(45000, maxi(campaign_required_manpower(nation_id, raw_siege),
		campaign_field_minimum_manpower(nation_id, enemy_manpower)))


func campaign_prewar_target_manpower(nation_id: int, raw_siege: int, enemy_manpower: int) -> int:
	return maxi(45000, maxi(campaign_required_manpower(nation_id, raw_siege),
		2 * maxi(enemy_manpower, 0)))


## Action eligibility excludes virtual garrison R and allocation floors.
func campaign_minimum_launch_requirement(
	attacker_id: int,
	center_city_id: int
) -> int:
	return campaign_field_minimum_manpower(attacker_id,
		campaign_reinforcement_threat(attacker_id, center_city_id))


## Preview V before relations become hostile. Only effective real armies of the
## target's defensive alliance bloc physically touching the objective state
## count; neutral third parties and the attacker's own bloc are excluded.
func campaign_prewar_reinforcement_threat(
	attacker_id: int,
	target_nation_id: int,
	center_city_id: int,
	defender_bloc: Array[int] = [],
	attacker_bloc: Array[int] = []
) -> int:
	if (
		not is_zhou_city(center_city_id)
		or target_nation_id < 0
		or target_nation_id >= nations.size()
	):
		return 0
	# Batch callers supply current blocs; direct callers keep the original query.
	if defender_bloc.is_empty(): defender_bloc=alliance_bloc(target_nation_id)
	if attacker_bloc.is_empty(): attacker_bloc=alliance_bloc(attacker_id)
	var result := 0
	for army in armies:
		if (
			not army_effective_for_field_campaign(army)
			or army.is_city_garrison
			or not defender_bloc.has(army.owner_nation)
			or attacker_bloc.has(army.owner_nation)
		):
			continue
		var touches_region := false
		if army.on_edge:
			touches_region = (
				administrative_center_of(army.move_from) == center_city_id
				or administrative_center_of(army.move_to) == center_city_id
			)
		elif army.location_city >= 0:
			touches_region = (
				administrative_center_of(army.location_city) == center_city_id
			)
		if touches_region:
			result += army.size
	return result


func campaign_prewar_launch_requirement(
	attacker_id: int,
	target_nation_id: int,
	center_city_id: int
) -> int:
	if not is_zhou_city(center_city_id):
		return 0
	return campaign_prewar_target_manpower(attacker_id,
		campaign_siege_requirement(attacker_id, center_city_id),
		campaign_prewar_reinforcement_threat(attacker_id, target_nation_id, center_city_id))


## Dynamic V for a state campaign. Only effective real enemy field armies
## physically in the state or on an edge touching it are counted. The virtual
## center garrison belongs to R and is deliberately excluded here.
func campaign_reinforcement_threat(
	attacker_id: int,
	center_city_id: int
) -> int:
	if not is_zhou_city(center_city_id):
		return 0
	var regional_manpower := 0
	for army in armies:
		if (
			not army_effective_for_field_campaign(army)
			or army.is_city_garrison
			or not is_enemy(attacker_id, army.owner_nation)
		):
			continue
		var in_region := false
		if army.on_edge:
			in_region = (
				administrative_center_of(army.move_from) == center_city_id
				or administrative_center_of(army.move_to) == center_city_id
			)
		elif army.location_city >= 0:
			in_region = (
				administrative_center_of(army.location_city) == center_city_id
			)
		if in_region:
			regional_manpower += army.size
	return regional_manpower


func create_campaign_front(
	war_id: int,
	participant_nation_ids: Array[int],
	anchor_nation_id: int,
	mode: int,
	center_city_id: int
) -> CoalitionCampaignFront:
	var front := CoalitionCampaignFront.new()
	front.front_id = next_campaign_front_id
	next_campaign_front_id += 1
	front.war_id = war_id
	front.participant_nation_ids = participant_nation_ids.duplicate()
	front.participant_nation_ids.sort()
	front.anchor_nation_id = anchor_nation_id
	front.mode = mode
	front.center_city_id = center_city_id
	campaign_fronts[front.front_id] = front
	return front


func register_campaign_front(
	front: CoalitionCampaignFront,
	participant_nation_ids: Array[int],
	anchor_nation_id: int
) -> CoalitionCampaignFront:
	if front == null:
		return null
	if front.front_id < 0:
		front.front_id = next_campaign_front_id
		next_campaign_front_id += 1
	else:
		next_campaign_front_id = maxi(
			next_campaign_front_id, front.front_id + 1
		)
	front.participant_nation_ids = participant_nation_ids.duplicate()
	front.participant_nation_ids.sort()
	front.anchor_nation_id = anchor_nation_id
	campaign_fronts[front.front_id] = front
	for army_id_value in front.army_assignments:
		for army in armies:
			if army.id == int(army_id_value):
				army.campaign_front_id = front.front_id
				army.campaign_war_id = front.war_id
				break
	return front


func campaign_front(front_id: int) -> CoalitionCampaignFront:
	return campaign_fronts.get(front_id) as CoalitionCampaignFront


func campaign_front_for(
	nation_id: int,
	center_city_id: int,
	mode: int = -1,
	war_id: int = -1
) -> CoalitionCampaignFront:
	for front_value in campaign_fronts.values():
		var front := front_value as CoalitionCampaignFront
		if (
			front != null
			and not front.retiring
			and front.center_city_id == center_city_id
			and front.participant_nation_ids.has(nation_id)
			and (mode < 0 or front.mode == mode)
			and (war_id < 0 or front.war_id == war_id)
		):
			return front
	return null


func campaign_fronts_for_nation(
	nation_id: int,
	war_id: int = -1,
	mode: int = -1
) -> Array[CoalitionCampaignFront]:
	var result: Array[CoalitionCampaignFront] = []
	for front_value in campaign_fronts.values():
		var front := front_value as CoalitionCampaignFront
		if (
			front != null
			and not front.retiring
			and front.participant_nation_ids.has(nation_id)
			and (war_id < 0 or front.war_id == war_id)
			and (mode < 0 or front.mode == mode)
		):
			result.append(front)
	result.sort_custom(func(a: CoalitionCampaignFront, b: CoalitionCampaignFront) -> bool:
		if a.mode != b.mode:
			return a.mode == CoalitionCampaignFront.Mode.DEFENSE
		return EquivariantOrder.mirror_orbit_city_less(
			self, a.center_city_id, b.center_city_id
		)
	)
	return result


func campaign_objective_center(nation_id: int) -> int:
	var fronts := campaign_fronts_for_nation(nation_id)
	return fronts[0].center_city_id if not fronts.is_empty() else -1


func release_campaign_front(front_id: int) -> void:
	var front := campaign_front(front_id)
	if front == null:
		return
	for army in armies:
		if army.campaign_front_id != front_id:
			continue
		army.campaign_front_id = -1
		if army.state not in [Army.State.FIGHTING, Army.State.RETREATING]:
			army.path.clear()
			army.ai_target_city = -1
			army.ai_order_until_day = day
	campaign_fronts.erase(front_id)


func clear_campaign_fronts() -> void:
	for front_id_value in campaign_fronts.keys().duplicate():
		release_campaign_front(int(front_id_value))
	campaign_fronts.clear()
	campaign_pairs.clear()
	_campaign_pair_revision.clear()


func record_campaign_offensive_failure(war_id: int, members: Array[int], until_day: int, opponents: Array[int] = []) -> void:
	if war_id < 0 or until_day <= day:
		return
	sync_campaign_pairs(coalition_campaign_components())
	for pair_value in campaign_pairs.values():
		var pair := pair_value as CoalitionCampaignPair
		if pair.war_id != war_id:
			continue
		for nation_id in members:
			if not pair.includes(nation_id) or (not opponents.is_empty() and not _campaign_members_overlap(pair.opponents_for(nation_id), opponents)):
				continue
			pair.cooldown_until_by_nation[nation_id] = maxi(int(pair.cooldown_until_by_nation.get(nation_id, -1)), until_day)


func campaign_offensive_cooldown_until(war_id: int, members: Array[int], opponents: Array[int] = []) -> int:
	var result := -1
	for pair_value in campaign_pairs.values():
		var pair := pair_value as CoalitionCampaignPair
		if pair.war_id != war_id:
			continue
		for nation_id in members:
			if pair.includes(nation_id) and (opponents.is_empty() or _campaign_members_overlap(pair.opponents_for(nation_id), opponents)):
				result = maxi(result, int(pair.cooldown_until_by_nation.get(nation_id, -1)))
	return result


func prune_campaign_offensive_cooldowns() -> void:
	for pair_value in campaign_pairs.values():
		var pair := pair_value as CoalitionCampaignPair
		for nation_id in pair.cooldown_until_by_nation.keys():
			if int(pair.cooldown_until_by_nation[nation_id]) <= day or not pair.includes(nation_id) or not nations[nation_id].alive:
				pair.cooldown_until_by_nation.erase(nation_id)


static func _campaign_members_overlap(a: Array[int], b: Array[int]) -> bool:
	for nation_id in a:
		if b.has(nation_id):
			return true
	return false


func campaign_pairs_for_nation(nation_id: int, war_id: int = -1) -> Array[CoalitionCampaignPair]:
	var result: Array[CoalitionCampaignPair] = []
	for value in campaign_pairs.values():
		var pair := value as CoalitionCampaignPair
		if pair.includes(nation_id) and (war_id < 0 or pair.war_id == war_id):
			result.append(pair)
	result.sort_custom(func(a: CoalitionCampaignPair, b: CoalitionCampaignPair) -> bool: return a.pair_id < b.pair_id)
	return result


func find_campaign_pair(war_id: int, nation_id: int, opponent_id: int) -> CoalitionCampaignPair:
	for pair in campaign_pairs_for_nation(nation_id, war_id):
		if pair.opponents_for(nation_id).has(opponent_id):
			return pair
	return null


func sync_campaign_pairs(components: Array[Dictionary]) -> void:
	var revision: Array[int] = [diplomacy_revision, ownership_revision, road_network_revision, administrative_region_revision]
	if revision == _campaign_pair_revision:
		return
	_campaign_pair_revision = revision
	var by_member := {}
	for component in components:
		for nation_id in component["members"]:
			by_member[Vector2i(int(component["war_id"]), int(nation_id))] = component
	var old_by_key := {}
	for value in campaign_pairs.values():
		var pair := value as CoalitionCampaignPair
		old_by_key["%d:%s:%s" % [pair.war_id, str(pair.side_a_nation_ids), str(pair.side_b_nation_ids)]] = pair
	var new_by_key := {}
	var relation_keys: Array = war_relation_ids.keys()
	relation_keys.sort()
	for relation_key in relation_keys:
		var parts := str(relation_key).split(":")
		var war_id := int(war_relation_ids[relation_key])
		var a: Dictionary = by_member.get(Vector2i(war_id, int(parts[0])), {})
		var b: Dictionary = by_member.get(Vector2i(war_id, int(parts[1])), {})
		if a.is_empty() or b.is_empty() or a["key"] == b["key"] or not is_enemy(int(parts[0]), int(parts[1])):
			continue
		var members_a: Array[int] = a["members"]
		var members_b: Array[int] = b["members"]
		if members_a[0] > members_b[0]:
			var swap := members_a
			members_a = members_b
			members_b = swap
		var key := "%d:%s:%s" % [war_id, str(members_a), str(members_b)]
		if new_by_key.has(key):
			continue
		var pair: CoalitionCampaignPair = old_by_key.get(key)
		if pair == null:
			pair = CoalitionCampaignPair.new()
			pair.pair_id = next_campaign_pair_id
			next_campaign_pair_id += 1
			pair.war_id = war_id
			pair.side_a_nation_ids = members_a.duplicate()
			pair.side_b_nation_ids = members_b.duplicate()
		new_by_key[key] = pair
	var replacements := {}
	for pair_value in new_by_key.values():
		var pair := pair_value as CoalitionCampaignPair
		replacements[pair.pair_id] = pair
	# Only topology changes migrate metadata; ordinary ownership changes reuse pairs.
	for old_value in campaign_pairs.values():
		var old := old_value as CoalitionCampaignPair
		if replacements.has(old.pair_id):
			continue
		for pair_value in replacements.values():
			var pair := pair_value as CoalitionCampaignPair
			if pair.war_id != old.war_id:
				continue
			var aligned := _campaign_members_overlap(pair.side_a_nation_ids, old.side_a_nation_ids) and _campaign_members_overlap(pair.side_b_nation_ids, old.side_b_nation_ids)
			var reversed := _campaign_members_overlap(pair.side_a_nation_ids, old.side_b_nation_ids) and _campaign_members_overlap(pair.side_b_nation_ids, old.side_a_nation_ids)
			if not aligned and not reversed:
				continue
			for nation_id in old.cooldown_until_by_nation:
				if pair.includes(nation_id):
					pair.cooldown_until_by_nation[nation_id] = maxi(int(pair.cooldown_until_by_nation.get(nation_id, -1)), int(old.cooldown_until_by_nation[nation_id]))
			for slot in old.battlefields:
				var front := campaign_front(int(slot["offense_front_id"]))
				var actor := front.anchor_nation_id if front != null else int(slot["preferred_nation_id"])
				var center := int(slot["center_city_id"])
				var opponent := cities[center].owner_nation if center >= 0 and center < cities.size() else -1
				if not pair.includes(actor):
					continue
				if not pair.opponents_for(actor).has(opponent):
					if front != null and opponent >= 0 and is_enemy(actor, opponent):
						continue
					var recognized := recognized_owner_of(center) if center >= 0 else -1
					if front != null and old.opponents_for(actor).has(recognized) and not pair.opponents_for(actor).has(recognized):
						continue
					var old_opponents := old.opponents_for(actor)
					if not _campaign_members_overlap(pair.opponents_for(actor), old_opponents):
						continue
					# Pending rights follow one surviving opposing component, not every child.
					var first := -1
					for member_id in old_opponents:
						if nations[member_id].alive and by_member.has(Vector2i(old.war_id, member_id)):
							first = member_id
							break
					if not pair.opponents_for(actor).has(first):
						continue
				if not pair.battlefields.has(slot):
					pair.battlefields.append(slot)
				if front != null:
					front.campaign_pair_id = pair.pair_id
	campaign_pairs = replacements
	prune_campaign_offensive_cooldowns()


func campaign_assignment_center(army_id: int) -> int:
	for army in armies:
		if army.id == army_id:
			var front := campaign_front(army.campaign_front_id)
			return front.center_city_id if front != null else -1
	return -1


func campaign_assignment_war(army_id: int) -> int:
	for army in armies:
		if army.id == army_id:
			return army.campaign_war_id
	return -1


## 集团战争池与共享战线的唯一聚合报告。participant_nation_id 只用于定位
## 其所在连通分量；报告同时给出集团总量和该国投入量。
func coalition_campaign_allocation(
	war_id: int,
	participant_nation_id: int
) -> Dictionary:
	var result := {
		"component_members": [] as Array[int],
		"war_pool_total": 0,
		"war_pool_effective": 0,
		"reserve_effective": 0,
		"allocatable_effective": 0,
		"nation_pool_total": 0,
		"nation_pool_effective": 0,
		"duplicate_assignments": 0,
		"offensive_cooldown_until_day": -1,
		"pairs": [] as Array[Dictionary],
		"fronts": {},
	}
	if (
		participant_nation_id < 0
		or participant_nation_id >= nations.size()
		or war_id < 0
	):
		return result
	var matching_fronts := campaign_fronts_for_nation(
		participant_nation_id, war_id
	)
	var members: Array[int] = [participant_nation_id]
	if not matching_fronts.is_empty():
		members = matching_fronts[0].participant_nation_ids.duplicate()
	else:
		for component in coalition_campaign_components(war_id):
			var component_members: Array[int] = component["members"]
			if component_members.has(participant_nation_id):
				members = component_members.duplicate()
				break
	result["component_members"] = members
	result["offensive_cooldown_until_day"] = campaign_offensive_cooldown_until(war_id, members)
	for pair in campaign_pairs_for_nation(participant_nation_id, war_id):
		(result["pairs"] as Array).append({"pair_id": pair.pair_id,
			"opponent_members": pair.opponents_for(participant_nation_id).duplicate(),
			"offensive_cooldown_until_day": pair.cooldown_until(members),
			"battlefields": pair.battlefields.duplicate(true)})
	var front_reports: Dictionary = result["fronts"]
	var assignment_counts := {}
	for front in matching_fronts:
		front_reports[front.front_id] = {
				"campaign_pair_id": front.campaign_pair_id,
				"battlefield_slot": front.battlefield_slot,
				"selection_reason": front.selection_reason,
				"center_id": front.center_city_id,
				"mode": front.mode,
				"assigned_total": 0,
				"assigned_effective": 0,
				"actual_effective": 0,
				"reported_effective": front.reported_effective_manpower,
				"allocation_requirement": front.reported_requirement,
				"report_locked": front.combat_report_locked,
				"report_day": front.combat_report_day,
				"arrived_effective": 0,
				"rally_city_id": campaign_receiving_city(front),
				"rally_idle_arrived": 0,
			}
		for army_id_value in front.army_assignments:
			var army_id := int(army_id_value)
			assignment_counts[army_id] = int(
				assignment_counts.get(army_id, 0)
			) + 1
			if int(assignment_counts[army_id]) == 2:
				result["duplicate_assignments"] = (
					int(result["duplicate_assignments"]) + 1
				)
	for army in armies:
		if not members.has(army.owner_nation) or army.size <= 0:
			continue
		var effective := army_effective_for_field_campaign(army)
		var assigned_front := campaign_front(army.campaign_front_id)
		if army.campaign_war_id == war_id:
			result["war_pool_total"] = int(result["war_pool_total"]) + army.size
			if army.owner_nation == participant_nation_id:
				result["nation_pool_total"] = int(result["nation_pool_total"]) + army.size
			if effective:
				result["war_pool_effective"] = (
					int(result["war_pool_effective"]) + army.size
				)
				if army.owner_nation == participant_nation_id:
					result["nation_pool_effective"] = (
						int(result["nation_pool_effective"]) + army.size
					)
				if (
					army.defensive_deployment_until_day <= day
					and (
						assigned_front == null
						or assigned_front.mode
							== CoalitionCampaignFront.Mode.OFFENSE
					)
				):
					result["allocatable_effective"] = (
						int(result["allocatable_effective"]) + army.size
					)
		if assigned_front != null and front_reports.has(assigned_front.front_id):
			var front: Dictionary = front_reports[assigned_front.front_id]
			front["assigned_total"] = int(front["assigned_total"]) + army.size
			if effective:
				front["assigned_effective"] = (
					int(front["assigned_effective"]) + army.size
				)
				front["actual_effective"] = int(front["assigned_effective"])
				if army.state == Army.State.IDLE and army.is_at_city_node(int(front["rally_city_id"])):
					front["rally_idle_arrived"] = int(front["rally_idle_arrived"]) + army.size
				if (
					not army.on_edge
					and army.location_city >= 0
					and administrative_center_of(army.location_city)
						== assigned_front.center_city_id
				):
					front["arrived_effective"] = (
						int(front["arrived_effective"]) + army.size
					)
		elif (
			army.campaign_war_id == -1
			and assigned_front == null
			and effective
			and army.state == Army.State.IDLE
			and army.defensive_deployment_until_day <= day
		):
			result["reserve_effective"] = (
				int(result["reserve_effective"]) + army.size
			)
			result["allocatable_effective"] = (
				int(result["allocatable_effective"]) + army.size
			)
	return result


func campaign_enemy_ids(nation_id: int, war_id: int) -> Array[int]:
	var flags := {}
	for other in nations:
		if other.id == nation_id or not other.alive:
			continue
		if (
			war_id_between(nation_id, other.id) == war_id
			and is_enemy(nation_id, other.id)
		):
			flags[other.id] = true
	var result: Array[int] = []
	for enemy_value in flags:
		result.append(int(enemy_value))
	result.sort()
	return result


## 活跃战争的阵营领土连通分量。联盟闭包决定同侧，真实领土边界决定能否共享
## 州战线；码头河运链不会在这里扩张接壤。
func coalition_campaign_components(
	requested_war_id: int = -1
) -> Array[Dictionary]:
	var participants_by_war := {}
	for relation_key_value in war_relation_ids:
		var internal := false
		for conflict_value in succession_conflicts.values():
			if int(war_relation_ids[relation_key_value]) == (conflict_value as SuccessionConflict).war_id:
				internal = true
		if internal:
			continue
		var war_id := int(war_relation_ids[relation_key_value])
		if requested_war_id >= 0 and war_id != requested_war_id:
			continue
		var parts := str(relation_key_value).split(":")
		if parts.size() != 2:
			continue
		if not participants_by_war.has(war_id):
			participants_by_war[war_id] = {}
		var flags: Dictionary = participants_by_war[war_id]
		flags[int(parts[0])] = true
		flags[int(parts[1])] = true
	var nation_neighbors := {}
	for contact in territorial_border_pairs():
		var owner_a := cities[contact.x].owner_nation
		var owner_b := cities[contact.y].owner_nation
		if owner_a < 0 or owner_b < 0 or owner_a == owner_b:
			continue
		if not nation_neighbors.has(owner_a):
			nation_neighbors[owner_a] = {}
		if not nation_neighbors.has(owner_b):
			nation_neighbors[owner_b] = {}
		(nation_neighbors[owner_a] as Dictionary)[owner_b] = true
		(nation_neighbors[owner_b] as Dictionary)[owner_a] = true
	var result: Array[Dictionary] = []
	var war_ids: Array = participants_by_war.keys()
	war_ids.sort()
	var alliance_blocs := {}
	for war_value in war_ids:
		var war_id := int(war_value)
		var participant_flags: Dictionary = participants_by_war[war_id]
		var side_groups := {}
		var participant_ids: Array[int] = []
		for nation_value in participant_flags:
			var nation_id := int(nation_value)
			if nation_id < 0 or nation_id >= nations.size() or not nations[nation_id].alive:
				continue
			participant_ids.append(nation_id)
			if not alliance_blocs.has(nation_id):
				var bloc := alliance_bloc(nation_id)
				for member_id in bloc:
					alliance_blocs[int(member_id)] = bloc
			var bloc: Array[int] = (alliance_blocs.get(nation_id, [] as Array[int]) as Array[int]).duplicate()
			var faction: Dictionary = vassal_conflicts.get(war_id, {})
			if bool(faction.get("active", false)):
				bloc.assign(faction.central if faction.central.has(nation_id) else faction.rebels)
			var side_key := nation_id
			for bloc_value in bloc:
				var bloc_id := int(bloc_value)
				if participant_flags.has(bloc_id):
					side_key = mini(side_key, bloc_id)
			if not side_groups.has(side_key):
				side_groups[side_key] = [] as Array[int]
			(side_groups[side_key] as Array[int]).append(nation_id)
		participant_ids.sort()
		for side_members_value in side_groups.values():
			var side_members: Array[int] = side_members_value
			side_members.sort()
			var remaining := {}
			for member_id in side_members:
				remaining[member_id] = true
			while not remaining.is_empty():
				var seeds: Array = remaining.keys()
				seeds.sort()
				var queue: Array[int] = [int(seeds[0])]
				var members: Array[int] = []
				remaining.erase(queue[0])
				while not queue.is_empty():
					var current := int(queue.pop_front())
					members.append(current)
					var neighbors: Dictionary = nation_neighbors.get(current, {})
					for neighbor_value in neighbors:
						var neighbor := int(neighbor_value)
						if remaining.has(neighbor) and side_members.has(neighbor):
							remaining.erase(neighbor)
							queue.append(neighbor)
				members.sort()
				var enemy_flags := {}
				for member_id in members:
					for candidate_id in participant_ids:
						if (
							war_id_between(member_id, candidate_id) == war_id
							and is_enemy(member_id, candidate_id)
						):
							enemy_flags[candidate_id] = true
				var enemy_ids: Array[int] = []
				for enemy_value in enemy_flags:
					enemy_ids.append(int(enemy_value))
				enemy_ids.sort()
				result.append({
					"war_id": war_id,
					"members": members,
					"enemy_ids": enemy_ids,
					"key": "%d:%s" % [war_id, str(members)],
				})
	result.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
		if int(a["war_id"]) != int(b["war_id"]):
			return int(a["war_id"]) < int(b["war_id"])
		return str(a["key"]) < str(b["key"])
	)
	return result


func army_effective_for_field_campaign(army: Army) -> bool:
	return (
		army != null
		and army.size > 0
		and army.is_main_battle_role()
		and army.state not in [Army.State.RETREATING, Army.State.RECOVERING]
		and not army.starving
		and army.supply_ratio > 0.0
	)


func campaign_committed_manpower(
	attacker_id: int,
	center_city_id: int
) -> int:
	var front := campaign_front_for(
		attacker_id, center_city_id, CoalitionCampaignFront.Mode.OFFENSE
	)
	if front == null:
		return 0
	var result := 0
	for army in armies:
		if (
			army.campaign_front_id == front.front_id
			and army_effective_for_field_campaign(army)
		):
			result += army.size
	return result


func army_committed_to_administrative_campaign(
	army: Army,
	center_city_id: int
) -> bool:
	if (
		army == null
		or army.owner_nation < 0
		or army.owner_nation >= nations.size()
	):
		return false
	var plan := campaign_front(army.campaign_front_id)
	if (
		plan == null
		or plan.center_city_id != center_city_id
		or not plan.army_assignments.has(army.id)
	):
		return false
	return army.campaign_war_id == plan.war_id


func campaign_defensive_committed_manpower(
	defender_id: int,
	center_city_id: int
) -> int:
	if not is_zhou_city(center_city_id):
		return 0
	var front := campaign_front_for(
		defender_id, center_city_id, CoalitionCampaignFront.Mode.DEFENSE
	)
	if front == null:
		return 0
	var result := 0
	for army in armies:
		if (
			army.campaign_front_id != front.front_id
			or not army_effective_for_field_campaign(army)
		):
			continue
		result += army.size
	return result


## Field force required for a defender to sortie against the committed enemy
## force in a state.  Garrison manpower is deliberately kept separate: it
## anchors the center but does not count as a mobile field army.
func campaign_defense_activity_index() -> Dictionary:
	var forces := {}
	var camps := {}
	var defense_armies := {}
	var battles_by_center := {}
	var rear_fronts := {}
	for front_value in campaign_fronts.values():
		var front := front_value as CoalitionCampaignFront
		if campaign_has_rear_camp(front):
			rear_fronts[front.front_id] = front
	for army in armies:
		var defense_centers := {}
		if army.location_city >= 0:
			defense_centers[administrative_center_of(army.location_city)] = true
		if army.on_edge:
			defense_centers[administrative_center_of(army.move_from)] = true
			defense_centers[administrative_center_of(army.move_to)] = true
		if army.ai_target_city >= 0:
			defense_centers[administrative_center_of(army.ai_target_city)] = true
		for center_id in defense_centers:
			if not defense_armies.has(center_id):
				defense_armies[center_id] = []
			(defense_armies[center_id] as Array).append(army)
		if army.size <= 0:
			continue
		var effective := not army.is_city_garrison and army_effective_for_field_campaign(army)
		var front := rear_fronts.get(army.campaign_front_id) as CoalitionCampaignFront
		if front != null and front.army_assignments.has(army.id):
			var at_camp := army.is_at_city_node(front.camp_city_id)
			var returning := (
				int(front.army_assignments[army.id]) == front.camp_city_id
				and _campaign_has_live_route(army, front.camp_city_id)
			)
			if at_camp or returning:
				if not camps.has(front.center_city_id):
					camps[front.center_city_id] = []
				(camps[front.center_city_id] as Array).append({
					"army_id": army.id, "owner": army.owner_nation,
					"war_id": front.war_id, "city_id": front.camp_city_id,
					"size": army.size if effective else 0,
				})
		if not effective:
			continue
		var centers := {}
		if army.location_city >= 0:
			centers[administrative_center_of(army.location_city)] = true
		if army.on_edge:
			centers[administrative_center_of(army.move_from)] = true
			centers[administrative_center_of(army.move_to)] = true
		var incoming_center := (
			administrative_center_of(army.ai_target_city)
			if _campaign_has_live_attack_route(army) else -1
		)
		if incoming_center >= 0 and not centers.has(incoming_center):
			centers[incoming_center] = false
		for center_id in centers:
			if int(center_id) < 0:
				continue
			if not forces.has(center_id):
				forces[center_id] = []
			(forces[center_id] as Array).append({
				"army_id": army.id, "owner": army.owner_nation, "size": army.size,
				"present": bool(centers[center_id]),
			})
	var sieges := {}
	for battle in battles:
		if battle.finished:
			continue
		var battle_centers := {}
		if battle.city != null:
			battle_centers[administrative_center_of(battle.city.id)] = true
		elif battle.edge != null:
			battle_centers[administrative_center_of(battle.edge.city_a)] = true
			battle_centers[administrative_center_of(battle.edge.city_b)] = true
		for center_id in battle_centers:
			if not battles_by_center.has(center_id):
				battles_by_center[center_id] = []
			(battles_by_center[center_id] as Array).append(battle)
		if battle.kind != Battle.Kind.SIEGE or battle.city == null:
			continue
		var center_id := administrative_center_of(battle.city.id)
		if not sieges.has(center_id):
			sieges[center_id] = []
		(sieges[center_id] as Array).append(battle.siege_attacker_nation)
	var fu_by_center := {}
	for city in cities:
		if not city.politically_active or city.is_dock or not is_fu_city(city.id):
			continue
		var center_id := administrative_center_of(city.id)
		if not fu_by_center.has(center_id):
			fu_by_center[center_id] = [] as Array[int]
		(fu_by_center[center_id] as Array[int]).append(city.id)
	# Index only genuine hostile activity once, rather than filtering every
	# owned state again for each war component.
	var defense_candidates := {}
	for buckets in [forces, camps]:
		for center_id in buckets:
			for force in buckets[center_id]:
				_index_defense_candidate(defense_candidates, int(center_id), int(force["owner"]))
	for center_id in sieges:
		for owner in sieges[center_id]:
			_index_defense_candidate(defense_candidates, int(center_id), int(owner))
	for center_id in fu_by_center:
		for city_id in fu_by_center[center_id]:
			_index_defense_candidate(defense_candidates, int(center_id), cities[city_id].owner_nation)
	return {"forces": forces, "camps": camps, "sieges": sieges, "fu_by_center": fu_by_center,
		"defense_armies": defense_armies,
		"battles_by_center": battles_by_center, "defense_candidates": defense_candidates}


func _index_defense_candidate(result: Dictionary, center_id: int, enemy_owner: int) -> void:
	if not is_zhou_city(center_id):
		return
	var owner := cities[center_id].owner_nation
	if not is_enemy(owner, enemy_owner):
		return
	var key := "%d:%d" % [war_id_between(owner, enemy_owner), owner]
	if not result.has(key):
		result[key] = {}
	(result[key] as Dictionary)[center_id] = true


## Inspect an issued route, not a stale target or a new UI-time path search.
func _campaign_has_live_attack_route(army: Army) -> bool:
	if army.ai_action != ActionCandidate.Kind.ATTACK or army.ai_target_city < 0:
		return false
	if army.state not in [Army.State.MOVING, Army.State.FIGHTING]:
		return false
	return _campaign_has_live_route(army, army.ai_target_city)


func _campaign_has_live_route(army: Army, target_city: int) -> bool:
	if army.state not in [Army.State.MOVING, Army.State.FIGHTING, Army.State.RETREATING]:
		return false
	var route: Array[int] = []
	if army.on_edge:
		route.append(army.move_to)
	route.append_array(army.path)
	if route.is_empty() or route[-1] != target_city:
		return false
	var previous := army.move_from if army.on_edge else army.location_city
	for city_id in route:
		var edge := edge_of(previous, city_id)
		if edge == null or edge.max_manpower <= 0:
			return false
		if city_id != target_city and not has_military_access(
			army.owner_nation, cities[city_id].owner_nation
		):
			if not cities[city_id].is_dock:
				return false
			var docks := Pathfinding._local_crossing_transit_docks(self, army.owner_nation, target_city)
			if not docks.has(city_id):
				return false
		previous = city_id
	return true


func campaign_defense_context(
	nation_id: int, center_id: int, war_id: int,
	activity_index: Dictionary = {}
) -> Dictionary:
	var result := {"active": false, "invaded": false, "incoming": false,
		"besieged": false, "enemy_fu_ids": [] as Array[int], "enemy_camp_ids": [] as Array[int],
		"enemy_manpower": 0, "requirement": 0}
	if not is_zhou_city(center_id):
		return result
	var index := campaign_defense_activity_index() if activity_index.is_empty() else activity_index
	var counted_armies := {}
	for force in (index["forces"] as Dictionary).get(center_id, []):
		var owner := int(force["owner"])
		if not is_enemy(nation_id, owner) or (war_id >= 0 and war_id_between(nation_id, owner) != war_id):
			continue
		if bool(force["present"]) and not counted_armies.has(int(force.get("army_id", -1))):
			result["enemy_manpower"] = int(result["enemy_manpower"]) + int(force["size"])
			counted_armies[int(force.get("army_id", -1))] = true
		result["invaded" if bool(force["present"]) else "incoming"] = true
	for camp in (index.get("camps", {}) as Dictionary).get(center_id, []):
		var owner := int(camp["owner"])
		if not is_enemy(nation_id, owner) or (war_id >= 0 and int(camp["war_id"]) != war_id) or war_id_between(nation_id, owner) != int(camp["war_id"]):
			continue
		if not (result["enemy_camp_ids"] as Array[int]).has(int(camp["city_id"])):
			(result["enemy_camp_ids"] as Array[int]).append(int(camp["city_id"]))
		if not counted_armies.has(int(camp["army_id"])):
			result["enemy_manpower"] = int(result["enemy_manpower"]) + int(camp["size"])
			counted_armies[int(camp["army_id"])] = true
	for owner in (index["sieges"] as Dictionary).get(center_id, []):
		if is_enemy(nation_id, int(owner)) and (war_id < 0 or war_id_between(nation_id, int(owner)) == war_id):
			result["besieged"] = true
	for city_id in (index["fu_by_center"] as Dictionary).get(center_id, []):
		var owner := cities[city_id].owner_nation
		if is_fu_city(city_id) and is_enemy(nation_id, owner) and (war_id < 0 or war_id_between(nation_id, owner) == war_id):
			(result["enemy_fu_ids"] as Array[int]).append(city_id)
	result["active"] = bool(result["invaded"]) or bool(result["incoming"]) or bool(result["besieged"]) or not (result["enemy_fu_ids"] as Array).is_empty() or not (result["enemy_camp_ids"] as Array).is_empty()
	result["requirement"] = campaign_field_minimum_manpower(nation_id, int(result["enemy_manpower"])) if int(result["enemy_manpower"]) > 0 else 0
	if bool(result["active"]) and int(result["requirement"]) == 0:
		result["requirement"] = INITIAL_HEAVY_ARMY_SIZE
	return result


func campaign_field_requirement(defender_id: int, center_city_id: int) -> int:
	return int(campaign_defense_context(defender_id, center_city_id, -1)["requirement"])


func campaign_has_forward_camp(front: CoalitionCampaignFront) -> bool:
	return (
		front != null and front.mode == CoalitionCampaignFront.Mode.OFFENSE
		and front.camp_city_id >= 0 and front.camp_city_id < cities.size()
		and administrative_center_of(front.camp_city_id) == front.center_city_id
		and has_military_access(front.anchor_nation_id, cities[front.camp_city_id].owner_nation)
	)


func campaign_has_rear_camp(front: CoalitionCampaignFront) -> bool:
	return (
		front != null and not front.retiring
		and front.mode == CoalitionCampaignFront.Mode.OFFENSE
		and front.camp_city_id >= 0 and front.camp_city_id < cities.size()
		and front.camp_city_id == front.staging_city_id
		and front.center_city_id >= 0 and front.center_city_id < cities.size()
		and not has_military_access(front.anchor_nation_id, cities[front.center_city_id].owner_nation)
		and administrative_center_of(front.camp_city_id) != front.center_city_id
		and has_military_access(front.anchor_nation_id, cities[front.camp_city_id].owner_nation)
	)


func campaign_receiving_city(front: CoalitionCampaignFront) -> int:
	if front.mode == CoalitionCampaignFront.Mode.DEFENSE:
		return front.center_city_id
	if front.camp_city_id >= 0:
		return front.camp_city_id
	if front.phase == CoalitionCampaignFront.Phase.BREAK_IN and not front.tactical_target_city_ids.is_empty():
		return int(front.tactical_target_city_ids[0])
	return front.staging_city_id if front.staging_city_id >= 0 else front.center_city_id


func enemy_army_present_in_administrative_region(
	defender_id: int,
	center_city_id: int
) -> bool:
	if not is_zhou_city(center_city_id):
		return false
	for army in armies:
		if (
			army == null
			or army.size <= 0
			or not is_enemy(defender_id, army.owner_nation)
		):
			continue
		if (
			army.location_city >= 0
			and administrative_center_of(army.location_city) == center_city_id
		):
			return true
		if (
			army.on_edge
			and (
				(
					army.move_from >= 0
					and administrative_center_of(army.move_from)
						== center_city_id
				)
				or (
					army.move_to >= 0
					and administrative_center_of(army.move_to)
						== center_city_id
				)
			)
		):
			return true
	return false


func reinforce_city_garrisons_monthly() -> int:
	var total := 0
	# 每个州治只需判断一次。逐中心调用 city_under_siege 会在多战线时
	# 退化成 O(州治×战斗)，先按战斗建立集合再做 O(1) 查询。
	var besieged := besieged_city_ids()
	for center_value in administrative_center_city_ids:
		var center_id := int(center_value)
		var city := cities[center_id]
		if besieged.has(center_id):
			continue
		var owner_id := city.owner_nation
		if owner_id < 0 or owner_id >= nations.size():
			continue
		var missing := city_garrison_capacity(center_id) - city.garrison_manpower
		var support_ratio := clampf(city.garrison_supply_ratio, 0.0, 1.0)
		var reinforcement_limit := int(floor(
			float(ZHOU_GARRISON_MONTHLY_REINFORCEMENT) * support_ratio
		))
		var added := mini(
			maxi(missing, 0),
			mini(
				reinforcement_limit,
				maxi(nations[owner_id].manpower_pool, 0)
			)
		)
		if added <= 0:
			continue
		city.garrison_manpower += added
		nations[owner_id].manpower_pool -= added
		total += added
	if total > 0:
		garrison_revision += 1
	return total


func fill_city_garrison_from_owner_pool(city_id: int) -> int:
	if city_garrison_capacity(city_id) <= 0:
		return 0
	var city := cities[city_id]
	var owner_id := city.owner_nation
	if owner_id < 0 or owner_id >= nations.size():
		return 0
	var added := mini(
		city_garrison_capacity(city_id) - city.garrison_manpower,
		maxi(nations[owner_id].manpower_pool, 0)
	)
	if added <= 0:
		return 0
	city.garrison_manpower += added
	city.garrison_supply_ratio = 1.0
	nations[owner_id].manpower_pool -= added
	garrison_revision += 1
	return added


func _initialize_city_garrisons_free() -> void:
	var changed := false
	for city in cities:
		var desired := city_garrison_capacity(city.id)
		if city.garrison_manpower != desired:
			city.garrison_manpower = desired
			changed = true
	_garrisons_initialized = true
	if changed:
		garrison_revision += 1


func _reconcile_garrisons_after_administrative_rebuild(
	previous_centers: Dictionary
) -> void:
	var changed := false
	var current_centers := {}
	for center_value in administrative_center_city_ids:
		current_centers[int(center_value)] = true
	for old_center_value in previous_centers.keys():
		var old_center := int(old_center_value)
		if current_centers.has(old_center) or old_center < 0 or old_center >= cities.size():
			continue
		var old_city := cities[old_center]
		var owner_id := old_city.owner_nation
		if owner_id >= 0 and owner_id < nations.size():
			nations[owner_id].manpower_pool += maxi(old_city.garrison_manpower, 0)
		if old_city.garrison_manpower != 0:
			old_city.garrison_manpower = 0
			changed = true
	for new_center_value in current_centers.keys():
		var new_center := int(new_center_value)
		if previous_centers.has(new_center):
			continue
		var before := cities[new_center].garrison_manpower
		fill_city_garrison_from_owner_pool(new_center)
		changed = changed or cities[new_center].garrison_manpower != before
	if changed:
		garrison_revision += 1


func city_administrative_output_enabled(city_id: int) -> bool:
	if city_id < 0 or city_id >= cities.size():
		return false
	var city := cities[city_id]
	if not city.politically_active:
		return false
	if city.is_dock or is_zhou_city(city_id):
		return city.owner_nation >= 0
	var center := administrative_center_of(city_id)
	return (
		center >= 0
		and center < cities.size()
		and city.owner_nation >= 0
		and financial_nation_of(cities[center].owner_nation) == financial_nation_of(city.owner_nation)
	)


func _edge_participates_in_region_graph(edge: Edge) -> bool:
	return (
		edge != null
		and edge.max_manpower > 0
		and edge.city_a >= 0
		and edge.city_b >= 0
		and edge.city_a < cities.size()
		and edge.city_b < cities.size()
	)


static func region_color(region_id: int) -> Color:
	if region_id < 0:
		return Color.TRANSPARENT
	var hue := fposmod(0.08 + float(region_id) * 0.61803398875, 1.0)
	var saturation := 0.50 + 0.07 * float(region_id % 3)
	var value := 0.68 + 0.07 * float(floori(float(region_id) / 3.0) % 2)
	return Color.from_hsv(hue, saturation, value, 1.0)


func road_network_rebuild_block_reason() -> String:
	if edges.is_empty():
		return "当前世界没有可调校的道路。"
	return ""


func _generate_armies() -> void:
	for nation in nations:
		var owned_land := land_cities_of(nation.id)
		if owned_land.is_empty():
			continue
		var group := create_battle_group(nation.id)
		var army := create_army(
			nation.id,
			nation.capital_city_id,
			INITIAL_HEAVY_ARMY_SIZE,
			INITIAL_HEAVY_ARMY_SIZE
		)
		if group == null or army == null:
			if group != null:
				nation.battle_groups.erase(group)
			continue
		_initialize_army_attributes(army)
		assign_army_to_battle_group(army, group.id)


func _battle_group_structure_valid() -> bool:
	# Validate the same membership rules in one pass. Transaction checks and
	# daily audits must not scan every army once for every registered group.
	var registered := {}
	for nation_index in range(nations.size()):
		for group in nations[nation_index].battle_groups:
			if group.id >= 0:
				registered[Vector2i(nation_index, group.id)] = true
	var counts := {}
	for army in armies:
		if army.size <= 0:
			continue
		var key := Vector2i(army.owner_nation, army.battle_group_id)
		if army.max_size != INITIAL_HEAVY_ARMY_SIZE or not registered.has(key):
			return false
		counts[key] = int(counts.get(key, 0)) + 1
	for nation in nations:
		for group in nation.battle_groups:
			if int(counts.get(Vector2i(nation.id, group.id), 0)) > BattleGroup.MAX_ARMIES:
				return false
	return true


func _initialize_army_attributes(army: Army) -> void:
	assert(army != null, "初始军队生成不得突破国家军队上限")
	army.speed_factor = rng.randf_range(0.3, 0.9)
	army.attack = rng.randi_range(8, 15)
	army.defense = rng.randi_range(8, 15)


func create_battle_group(nation_id: int) -> BattleGroup:
	if nation_id < 0 or nation_id >= nations.size():
		return null
	var nation := nations[nation_id]
	var group := BattleGroup.new()
	group.id = nation.next_battle_group_id
	nation.next_battle_group_id += 1
	group.owner_nation = nation_id
	group.created_day = day
	nation.battle_groups.append(group)
	return group


func battle_group_by_id(
	nation_id: int,
	group_id: int
) -> BattleGroup:
	if nation_id < 0 or nation_id >= nations.size() or group_id < 0:
		return null
	for group in nations[nation_id].battle_groups:
		if group.id == group_id:
			return group
	return null


func battle_group_members(
	nation_id: int,
	group_id: int,
	alive_only: bool = true
) -> Array[Army]:
	var result: Array[Army] = []
	if battle_group_by_id(nation_id, group_id) == null:
		return result
	for army in armies:
		if (
			army.owner_nation == nation_id
			and army.battle_group_id == group_id
			and (not alive_only or army.size > 0)
		):
			result.append(army)
	return result


func assign_army_to_battle_group(
	army: Army,
	group_id: int
) -> bool:
	if (
		army == null
		or army.size <= 0
		or army.max_size != INITIAL_HEAVY_ARMY_SIZE
		or battle_group_by_id(
			army.owner_nation,
			group_id
		) == null
	):
		return false
	var army_count := 0
	for member in battle_group_members(army.owner_nation, group_id):
		if member == army:
			continue
		army_count += 1
	if army_count >= BattleGroup.MAX_ARMIES:
		return false
	army.battle_group_id = group_id
	return true


## 把一支 15000 人主战军放入独立指挥单位，不合并实体或共享兵力池。
func assign_main_army_to_independent_command(army: Army) -> Army:
	if (
		army == null
		or army.size <= 0
		or army.max_size != INITIAL_HEAVY_ARMY_SIZE
		or army.owner_nation < 0
		or army.owner_nation >= nations.size()
	):
		return null
	var nation := nations[army.owner_nation]
	for group in nation.battle_groups:
		if battle_group_members(nation.id, group.id).is_empty():
			return army if assign_army_to_battle_group(army, group.id) else null
	var created_group := create_battle_group(nation.id)
	if created_group == null:
		return null
	if assign_army_to_battle_group(army, created_group.id):
		return army
	nation.battle_groups.erase(created_group)
	return null


func create_army(
	nation_id: int,
	city_id: int,
	size: int,
	max_size: int = Army.DEFAULT_MAX_SIZE
) -> Army:
	if (
		nation_id < 0 or nation_id >= nations.size()
		or is_succession_identity(nation_id)
		or city_id < 0 or city_id >= cities.size()
		or cities[city_id].owner_nation != nation_id
		or size <= 0
		or max_size != INITIAL_HEAVY_ARMY_SIZE
		or active_army_count(nation_id)
			>= max_army_count(nation_id)
	):
		return null
	var army := Army.new()
	army.id = _next_army_id
	_next_army_id += 1
	army.owner_nation = nation_id
	army.funding_multiplier = Army.funding_from_payment(nations[nation_id].military_payment_ratio)
	army.ruler_attack_multiplier = RulerProfile.attack_multiplier(nations[nation_id])
	army.ruler_defense_multiplier = RulerProfile.defense_multiplier(nations[nation_id])
	army.ruler_morale_multiplier = RulerProfile.morale_multiplier(nations[nation_id])
	army.max_size = max_size
	army.size = mini(size, max_size)
	army.max_morale = Army.DEFAULT_MAX_MORALE
	army.morale = army.max_morale
	army.location_city = city_id
	army.move_from = city_id
	army.state = Army.State.IDLE
	armies.append(army)
	PrincePolitics.assign_new_army(self, army)
	return army


func active_army_count(nation_id: int) -> int:
	var count := 0
	for army in armies:
		if army.owner_nation == nation_id and army.size > 0:
			count += 1
	return count


func max_army_count(nation_id: int) -> int:
	if nation_id < 0 or nation_id >= nations.size():
		return 0
	return maxi(
		land_cities_of(nation_id).size() * ARMY_COUNT_LIMIT_PER_CITY,
		ARMY_COUNT_LIMIT_PER_CITY
	)


func effective_ai_aggression(nation_id: int) -> float:
	if nation_id < 0 or nation_id >= nations.size():
		return 1.0
	var nation := nations[nation_id]
	return clampf(
		nation.ai_aggression
			* RulerProfile.aggression_multiplier(nation),
		0.35, 1.85
	)


func effective_army_defense(army: Army) -> float:
	if army == null:
		return 0.0
	return army.combat_defense()


func nation_display_name(nation_id: int) -> String:
	return WorldNaming.nation_display_name(self, nation_id)


func city_display_name(city_id: int, include_kind: bool = false) -> String:
	return WorldNaming.city_display_name(self, city_id, include_kind)


static func edge_key(a: int, b: int) -> int:
	var lo := mini(a, b)
	var hi := maxi(a, b)
	return (lo << 32) | hi


func _edge_key(a: int, b: int) -> int:
	return edge_key(a, b)


## 取两城之间的边（不存在返回 null）
func edge_of(a: int, b: int) -> Edge:
	return edge_lookup.get(_edge_key(a, b), null)


func neighbors(city_id: int) -> Array[int]:
	return adjacency.get(city_id, [] as Array[int])

func strategic_neighbors(city_id: int) -> Array[int]:
	if not atlas_layout.is_empty(): return atlas_layout.settlement_adjacency.get(city_id,[] as Array[int])
	return neighbors(city_id)

func strategic_edge_of(a: int,b: int) -> Edge:
	var direct := edge_of(a,b)
	if direct!=null or atlas_layout.is_empty(): return direct
	var path: Array = atlas_layout.get("strategic_routes",{}).get("%d:%d"%[mini(a,b),maxi(a,b)],[])
	if path.is_empty(): return null
	var result := Edge.new(); result.city_a = mini(a,b); result.city_b = maxi(a,b); result.precise_distance = 0.; result.max_manpower = Edge.MAX_MANPOWER
	var risk := 0.
	for index in range(1,path.size()):
		var segment := edge_of(path[index-1],path[index])
		if segment==null: return null
		result.precise_distance += segment.distance_units(); risk += segment.distance_units()*segment.danger
		result.max_manpower = mini(result.max_manpower,segment.max_manpower); result.passing_count += segment.passing_count
	result.distance = maxi(1,ceili(result.precise_distance)); result.danger = risk/maxf(.000001,result.precise_distance); result.occupied = result.passing_count>0
	return result

func strategic_route_access(a: int,b: int,nation_id: int) -> bool:
	if atlas_layout.is_empty():
		var edge := edge_of(a,b); return edge!=null and edge.max_manpower>0
	var path: Array = atlas_layout.get("strategic_routes",{}).get("%d:%d"%[mini(a,b),maxi(a,b)],[])
	if path.is_empty():
		var edge := edge_of(a,b); return edge!=null and edge.max_manpower>0 and atlas_edge_access(edge,nation_id)
	for index in range(1,path.size()):
		var edge := edge_of(path[index-1],path[index])
		if edge==null or edge.max_manpower<=0 or not atlas_edge_access(edge,nation_id): return false
	return true


## Stable pairs of politically adjacent land cities. Direct LAND roads count;
## a dock contributes pairwise contacts between its immediate LANDING banks.
## RIVER/SEA edges and dock ownership are deliberately absent from the result.
func territorial_border_pairs() -> Array[Vector2i]:
	_ensure_territorial_border_cache()
	return _territorial_border_pairs.duplicate()


func territorial_border_neighbors(city_id: int) -> Array[int]:
	_ensure_territorial_border_cache()
	if city_id < 0 or city_id >= _territorial_border_adjacency.size():
		return [] as Array[int]
	return (_territorial_border_adjacency[city_id] as Array[int]).duplicate()


func cities_share_territorial_border(city_a: int, city_b: int) -> bool:
	if city_a == city_b:
		return false
	_ensure_territorial_border_cache()
	if city_a < 0 or city_a >= _territorial_border_adjacency.size():
		return false
	return (_territorial_border_adjacency[city_a] as Array[int]).has(city_b)


## 正容量 LANDING 直接连接到同一码头的陆岸。码头间 RIVER/SEA 边不会
## 进入该集合，因此它同时是政治接壤、行军和补给使用的本地渡口真源。
func local_crossing_banks(dock_id: int) -> Array[int]:
	_ensure_territorial_border_cache()
	return (
		(_local_crossing_banks_by_dock[dock_id] as Array[int]).duplicate()
		if _local_crossing_banks_by_dock.has(dock_id)
		else [] as Array[int]
	)


func local_crossing_dock_ids() -> Array[int]:
	_ensure_territorial_border_cache()
	var result: Array[int] = []
	for dock_value in _local_crossing_banks_by_dock:
		if (
			(_local_crossing_banks_by_dock[dock_value] as Array[int]).size()
			>= 2
		):
			result.append(int(dock_value))
	result.sort()
	return result


func is_local_crossing_transit(
	dock_id: int,
	bank_a: int,
	bank_b: int
) -> bool:
	if bank_a == bank_b:
		return false
	var banks := local_crossing_banks(dock_id)
	return banks.has(bank_a) and banks.has(bank_b)


## Physical edges supporting one political border contact. A direct land
## border has one edge; a local dock crossing has the two bank landing edges.
func territorial_border_support_edges(
	city_a: int, city_b: int
) -> Array[Edge]:
	var result: Array[Edge] = []
	if not cities_share_territorial_border(city_a, city_b):
		return result
	var direct := edge_of(city_a, city_b)
	if (
		direct != null
		and direct.kind == Edge.Kind.LAND
		and direct.max_manpower > 0
	):
		result.append(direct)
		return result
	var shared_docks: Array[int] = []
	for dock_id in local_crossing_dock_ids():
		if is_local_crossing_transit(dock_id, city_a, city_b):
			shared_docks.append(dock_id)
	if shared_docks.is_empty():
		return result
	result.append(edge_of(city_a, shared_docks[0]))
	result.append(edge_of(city_b, shared_docks[0]))
	return result


func _ensure_territorial_border_cache() -> void:
	var revision: Array[int] = [
		road_network_revision,
		cities.size(),
		edges.size(),
	]
	if _territorial_border_cache_revision == revision:
		return
	# 补给网络会在 WorkerThreadPool 中按国家并行构建。第一次读取拓扑时
	# 多个线程可能同时到达这里，必须保证懒缓存只由一个线程写入。
	_territorial_border_cache_mutex.lock()
	if _territorial_border_cache_revision == revision:
		_territorial_border_cache_mutex.unlock()
		return
	var pair_by_key := {}
	_local_crossing_banks_by_dock.clear()
	if not atlas_layout.is_empty():
		for pair in atlas_layout.territorial_pairs: _add_territorial_border_pair(pair_by_key,pair.x,pair.y)
	for edge in edges:
		if (
			edge == null
			or edge.kind != Edge.Kind.LAND
			or edge.max_manpower <= 0
			or not _valid_territorial_border_land_city(edge.city_a)
			or not _valid_territorial_border_land_city(edge.city_b)
		):
			continue
		_add_territorial_border_pair(pair_by_key, edge.city_a, edge.city_b)
	for dock in cities:
		if not dock.is_dock or not dock.politically_active:
			continue
		var banks: Array[int] = []
		for neighbor in neighbors(dock.id):
			var landing := edge_of(dock.id, neighbor)
			if (
				landing == null
				or landing.kind != Edge.Kind.LANDING
				or landing.max_manpower <= 0
				or not _valid_territorial_border_land_city(neighbor)
			):
				continue
			banks.append(neighbor)
		banks.sort()
		_local_crossing_banks_by_dock[dock.id] = banks
		for left_index in range(banks.size()):
			for right_index in range(left_index + 1, banks.size()):
				_add_territorial_border_pair(
					pair_by_key, banks[left_index], banks[right_index]
				)
	_territorial_border_pairs.clear()
	var pair_keys: Array = pair_by_key.keys()
	pair_keys.sort()
	for pair_key in pair_keys:
		_territorial_border_pairs.append(
			pair_by_key[pair_key] as Vector2i
		)
	_territorial_border_adjacency.clear()
	_territorial_border_adjacency.resize(cities.size())
	for city_id in range(cities.size()):
		_territorial_border_adjacency[city_id] = [] as Array[int]
	for pair in _territorial_border_pairs:
		(_territorial_border_adjacency[pair.x] as Array[int]).append(pair.y)
		(_territorial_border_adjacency[pair.y] as Array[int]).append(pair.x)
	for city_neighbors in _territorial_border_adjacency:
		(city_neighbors as Array[int]).sort()
	_territorial_border_cache_revision = revision
	_territorial_border_cache_mutex.unlock()


func _valid_territorial_border_land_city(city_id: int) -> bool:
	return (
		city_id >= 0
		and city_id < cities.size()
		and cities[city_id].politically_active
		and not cities[city_id].is_dock
	)


func _add_territorial_border_pair(
	pair_by_key: Dictionary, city_a: int, city_b: int
) -> void:
	if city_a == city_b:
		return
	var lo := mini(city_a, city_b)
	var hi := maxi(city_a, city_b)
	pair_by_key[edge_key(lo, hi)] = Vector2i(lo, hi)


func is_enemy(nation_a: int, nation_b: int) -> bool:
	if succession_identity_pair(nation_a, nation_b):
		return true
	if is_succession_identity(nation_a) or is_succession_identity(nation_b):
		return false
	return relation_between(nation_a, nation_b) == DiplomaticRelation.WAR


func is_succession_identity(nation_id: int) -> bool:
	return nation_id >= 0 and nation_id < nations.size() and nations[nation_id].succession_identity


func is_external_enemy(a: int, b: int) -> bool:
	return not is_succession_identity(a) and not is_succession_identity(b) and is_enemy(a, b)


func succession_conflict_for_identity(nation_id: int) -> SuccessionConflict:
	if succession_conflicts.has(nation_id):
		return succession_conflicts[nation_id]
	for value in succession_conflicts.values():
		var conflict := value as SuccessionConflict
		if conflict.rebel_nation_id == nation_id:
			return conflict
	return null


func succession_identity_pair(a: int, b: int) -> bool:
	var conflict := succession_conflict_for_identity(a)
	return conflict != null and conflict.launched() and ((a == conflict.nation_id and b == conflict.rebel_nation_id) or (b == conflict.nation_id and a == conflict.rebel_nation_id))


func financial_nation_of(nation_id: int) -> int:
	if not is_succession_identity(nation_id):
		return nation_id
	var conflict := succession_conflict_for_identity(nation_id)
	return conflict.nation_id if conflict != null else nation_id


func army_reserved_for_succession(army: Army) -> bool:
	var conflict := succession_conflict_for_identity(army.owner_nation)
	return conflict != null and conflict.side_for(army.id) != 0


func armies_hostile(a: Army, b: Army) -> bool:
	if succession_identity_pair(a.owner_nation, b.owner_nation):
		var conflict := succession_conflict_for_identity(a.owner_nation)
		var side_a := conflict.side_for(a.id)
		var side_b := conflict.side_for(b.id)
		return side_a > 0 and side_b > 0 and side_a != side_b
	return is_enemy(a.owner_nation, b.owner_nation)


func army_defends_city(army: Army, city_id: int) -> bool:
	for value in succession_conflicts.values():
		var conflict := value as SuccessionConflict
		if not conflict.launched() or city_id not in [conflict.capital_city_id, conflict.camp_city_id]:
			continue
		return conflict.side_for(army.id) == (2 if city_id == conflict.capital_city_id else 1)
	return has_military_access(army.owner_nation, cities[city_id].owner_nation)


func army_may_station(army: Army, city_id: int) -> bool:
	if city_id < 0 or city_id >= cities.size():
		return false
	var conflict := succession_conflict_for_identity(cities[city_id].owner_nation)
	if conflict != null and conflict.launched() and conflict.side_for(army.id) == 0 and army.owner_nation == conflict.nation_id:
		return true
	return has_military_access(army.owner_nation, cities[city_id].owner_nation)


func military_profile_for_army(army: Army) -> Variant:
	var conflict := succession_conflict_for_identity(army.owner_nation)
	if conflict != null and conflict.launched():
		var side := conflict.side_for(army.id)
		if side != 0:
			return PrincePolitics.profile(self, conflict.nation_id, conflict.challenger_person_id if side == 1 else conflict.crown_person_id)
	return nations[army.owner_nation]


func has_logistics_access(traveler: int, owner: int) -> bool:
	return has_military_access(financial_nation_of(traveler), financial_nation_of(owner))


func succession_supply_city(city_id: int) -> bool:
	for value in succession_conflicts.values():
		var conflict := value as SuccessionConflict
		if conflict.launched() and city_id in [conflict.capital_city_id, conflict.camp_city_id]:
			return true
	return false


func is_allied(nation_a: int, nation_b: int) -> bool:
	return (
		nation_a == nation_b
		or relation_between(nation_a, nation_b) == DiplomaticRelation.ALLIED
	)


## 共同防御联盟同时授予双向军事通行权；中立国不开放领土。
func has_military_access(traveler_nation: int, territory_owner: int) -> bool:
	return (
		traveler_nation == territory_owner
		or (
			traveler_nation >= 0
			and territory_owner >= 0
			and traveler_nation < nations.size()
			and territory_owner < nations.size()
			and is_allied(traveler_nation, territory_owner)
		)
	)


func relation_between(nation_a: int, nation_b: int) -> int:
	if nation_a == nation_b:
		return DiplomaticRelation.ALLIED
	if is_succession_identity(nation_a) or is_succession_identity(nation_b):
		return DiplomaticRelation.WAR if succession_identity_pair(nation_a, nation_b) else DiplomaticRelation.NEUTRAL
	if (
		nation_a < 0
		or nation_b < 0
		or nation_a >= nations.size()
		or nation_b >= nations.size()
	):
		# 非法/测试占位国家不得被视为可安全借道的中立方。
		return DiplomaticRelation.WAR
	return int(diplomatic_relations.get(
		_diplomacy_key(nation_a, nation_b),
		DiplomaticRelation.WAR
	))


func relation_since(nation_a: int, nation_b: int) -> int:
	return int(diplomatic_since_day.get(_diplomacy_key(nation_a, nation_b), 0))


func truce_until(nation_a: int, nation_b: int) -> int:
	return int(truce_until_day.get(_diplomacy_key(nation_a, nation_b), 0))


func war_objective(nation_a: int, nation_b: int) -> Dictionary:
	return war_objectives.get(_diplomacy_key(nation_a, nation_b), {})


func set_war_objective(
	attacker: int,
	defender: int,
	city_id: int,
	reason: String,
	war_id: int = -1
) -> int:
	if (
		attacker < 0 or attacker >= nations.size()
		or defender < 0 or defender >= nations.size()
		or not is_enemy(attacker, defender)
	):
		return -1
	var center_id := administrative_center_of(city_id)
	if center_id >= 0:
		city_id = center_id
	var key := _diplomacy_key(attacker, defender)
	if war_id < 0:
		war_id = int((war_objectives.get(key, {}) as Dictionary).get(
			"war_id", -1
		))
	if war_id < 0:
		war_id = int(war_relation_ids.get(key, -1))
	if war_id < 0:
		war_id = next_war_id
		next_war_id += 1
	else:
		next_war_id = maxi(next_war_id, war_id + 1)
	if int(war_relation_ids.get(key, -1)) != war_id:
		diplomacy_revision += 1
	war_relation_ids[key] = war_id
	if not war_chronicle_contexts.has(war_id) and not rebellions.has(attacker) and not rebellions.has(defender) and not is_succession_identity(attacker) and not is_succession_identity(defender):
		ChronicleRules.begin_war(self, war_id, [attacker], [defender])
	war_objectives[key] = {
		"attacker": attacker,
		"defender": defender,
		"war_id": war_id,
		"city_id": city_id,
		"administrative_center_city_id": city_id,
		"reason": reason,
		"started_day": day,
	}
	return war_id


func clear_war_objective(nation_a: int, nation_b: int) -> void:
	war_objectives.erase(_diplomacy_key(nation_a, nation_b))


func war_id_between(nation_a: int, nation_b: int) -> int:
	return int(war_relation_ids.get(_diplomacy_key(nation_a, nation_b), -1))


func merge_war_ids(keep_war_id: int, merged_war_id: int) -> void:
	if keep_war_id < 0 or merged_war_id < 0 or keep_war_id == merged_war_id:
		return
	if bool(vassal_conflicts.get(keep_war_id, {}).get("active", false)) or bool(vassal_conflicts.get(merged_war_id, {}).get("active", false)): return
	ChronicleRules.merge_war(self, keep_war_id, merged_war_id)
	for pair_value in campaign_pairs.values():
		var pair := pair_value as CoalitionCampaignPair
		if pair.war_id == merged_war_id:
			pair.war_id = keep_war_id
	for objective_key in war_objectives:
		var objective: Dictionary = war_objectives[objective_key]
		if int(objective.get("war_id", -1)) == merged_war_id:
			objective["war_id"] = keep_war_id
			war_objectives[objective_key] = objective
	for relation_key in war_relation_ids:
		if int(war_relation_ids[relation_key]) == merged_war_id:
			war_relation_ids[relation_key] = keep_war_id
	for army in armies:
		if army.campaign_war_id == merged_war_id:
			army.campaign_war_id = keep_war_id
	for front_value in campaign_fronts.values():
		var front := front_value as CoalitionCampaignFront
		if front != null and front.war_id == merged_war_id:
			front.war_id = keep_war_id
	diplomacy_revision += 1


func release_war_pool(war_id: int) -> void:
	if war_id < 0:
		return
	for nation in nations:
		release_nation_war_pool(nation.id, war_id)
	ChronicleRules.mark_pending(self, war_id)


func release_nation_war_pool(nation_id: int, war_id: int) -> void:
	if nation_id < 0 or nation_id >= nations.size() or war_id < 0:
		return
	for pair in campaign_pairs_for_nation(nation_id, war_id):
		pair.cooldown_until_by_nation.erase(nation_id)
		for slot in pair.battlefields:
			if int(slot["preferred_nation_id"]) == nation_id:
				slot["preferred_nation_id"] = -1
				slot["counterattack"] = false
				slot["awaiting_mobilization"] = false
		pair.side_a_nation_ids.erase(nation_id)
		pair.side_b_nation_ids.erase(nation_id)
		if pair.side_a_nation_ids.is_empty() or pair.side_b_nation_ids.is_empty():
			campaign_pairs.erase(pair.pair_id)
	_campaign_pair_revision.clear()
	for army in armies:
		if army.owner_nation == nation_id and army.campaign_war_id == war_id:
			army.campaign_war_id = -1
			if army.campaign_front_id >= 0:
				var front := campaign_front(army.campaign_front_id)
				if front != null:
					front.army_assignments.erase(army.id)
				army.campaign_front_id = -1
			if army.state not in [Army.State.FIGHTING, Army.State.RETREATING]:
				army.path.clear()
				army.ai_target_city = -1
				army.ai_order_until_day = day
	for front_value in campaign_fronts.values().duplicate():
		var front := front_value as CoalitionCampaignFront
		if front == null or front.war_id != war_id:
			continue
		front.participant_nation_ids.erase(nation_id)
		if front.participant_nation_ids.is_empty():
			release_campaign_front(front.front_id)


func transfer_army_ownership(army: Army, new_owner_id: int) -> bool:
	if (
		army == null
		or new_owner_id < 0
		or new_owner_id >= nations.size()
		or army.owner_nation == new_owner_id
	):
		return false
	var front := campaign_front(army.campaign_front_id)
	if front != null:
		front.army_assignments.erase(army.id)
	army.campaign_front_id = -1
	if (
		army.campaign_war_id >= 0
		and not nation_participates_in_war_id(
			new_owner_id, army.campaign_war_id
		)
	):
		army.campaign_war_id = -1
	if army.state not in [Army.State.FIGHTING, Army.State.RETREATING]:
		army.path.clear()
		army.ai_target_city = -1
		army.ai_order_until_day = day
	army.owner_nation = new_owner_id
	if not succession_identity_pair(new_owner_id, financial_nation_of(new_owner_id)) and not army_reserved_for_succession(army):
		army.political_person_id = -1
	army.funding_multiplier = Army.funding_from_payment(nations[new_owner_id].military_payment_ratio)
	army.battle_group_id = -1
	army.ruler_attack_multiplier = (
		RulerProfile.attack_multiplier(nations[new_owner_id])
	)
	army.ruler_defense_multiplier = (
		RulerProfile.defense_multiplier(nations[new_owner_id])
	)
	army.ruler_morale_multiplier = (
		RulerProfile.morale_multiplier(nations[new_owner_id])
	)
	return true


func nation_participates_in_war_id(nation_id: int, war_id: int) -> bool:
	if nation_id < 0 or nation_id >= nations.size() or war_id < 0:
		return false
	for other in nations:
		if (
			other.id != nation_id
			and war_id_between(nation_id, other.id) == war_id
			and is_enemy(nation_id, other.id)
		):
			return true
	return false


func can_declare_war(nation_a: int, nation_b: int) -> bool:
	return (
		not is_succession_identity(nation_a) and not is_succession_identity(nation_b)
		and nation_a != nation_b
		and nation_a >= 0
		and nation_b >= 0
		and nation_a < nations.size()
		and nation_b < nations.size()
		and nations[nation_a].alive
		and nations[nation_b].alive
		and relation_between(nation_a, nation_b) == DiplomaticRelation.NEUTRAL
		and day >= truce_until(nation_a, nation_b)
	)


func can_alliance_declare_war(
	nation_a: int,
	nation_b: int
) -> bool:
	if not can_declare_war(nation_a, nation_b):
		return false
	var attackers := alliance_bloc(nation_a)
	var defenders := alliance_bloc(nation_b)
	return can_alliance_blocs_declare_war(
		nation_a, nation_b, attackers, defenders
	)

## 使用本轮已构建的攻守集团完成宣战资格校验。
## 调用方必须先以当前外交版本构建 attackers/defenders；这里不再次运行并查集。
func can_alliance_blocs_declare_war(
	nation_a: int,
	nation_b: int,
	attackers: Array[int],
	defenders: Array[int]
) -> bool:
	if not can_declare_war(nation_a, nation_b):
		return false
	if attackers.is_empty() or defenders.is_empty():
		return false
	for attacker in attackers:
		for defender in defenders:
			if (
				attacker == defender
				or is_allied(attacker, defender)
				or (
					not is_enemy(attacker, defender)
					and (
						relation_between(attacker, defender)
							!= DiplomaticRelation.NEUTRAL
						or day < truce_until(attacker, defender)
					)
				)
			):
				return false
	return true


func suzerainty_cohesion(nation_id: int) -> float:
	if nation_id < 0 or nation_id >= nations.size():
		return 1.0
	var root := suzerainty_root(nation_id)
	if _suzerainty_cohesion_revision != ownership_revision:
		_rebuild_suzerainty_cohesion_cache()
	return float(_suzerainty_cohesion_by_root.get(root, 1.0))


func set_diplomatic_relation(
	nation_a: int,
	nation_b: int,
	relation: int,
	truce_days: int = 0
) -> bool:
	if (
		nation_a == nation_b
		or nation_a < 0
		or nation_b < 0
		or nation_a >= nations.size()
		or nation_b >= nations.size()
		or relation not in [
			DiplomaticRelation.NEUTRAL,
			DiplomaticRelation.WAR,
			DiplomaticRelation.ALLIED,
		]
	):
		return false
	var faction := VassalConflict.for_nation(self, nation_a)
	if not faction.is_empty() and (faction.central.has(nation_b) or faction.rebels.has(nation_b)) and nations[nation_a].alive and nations[nation_b].alive:
		var required := DiplomaticRelation.ALLIED if faction.central.has(nation_a) == faction.central.has(nation_b) else DiplomaticRelation.WAR
		if relation != required: return false
	# 活跃地方叛军的战争严格限定为母国独立战争，不能向第三国宣战，
	# 第三国也不能把叛军拖入另一场战争。
	if (
		relation == DiplomaticRelation.WAR
		and not _regional_rebellion_war_allowed(nation_a, nation_b)
	):
		return false
	var key := _diplomacy_key(nation_a, nation_b)
	var previous := relation_between(nation_a, nation_b)
	if previous == relation:
		return false
	# 地方叛乱是有最低持续时间的政治战争。把门禁放在关系真源，
	# 避免 AI 之外的脚本或调试入口绕过一年交战期直接改成和平/盟约。
	if (
		previous == DiplomaticRelation.WAR
		and relation != DiplomaticRelation.WAR
		and regional_rebellion_peace_locked(nation_a, nation_b)
	):
		return false
	diplomatic_relations[key] = relation
	diplomatic_since_day[key] = day
	if relation == DiplomaticRelation.WAR and previous != DiplomaticRelation.WAR:
		if not war_relation_ids.has(key):
			war_relation_ids[key] = next_war_id
			if not rebellions.has(nation_a) and not rebellions.has(nation_b) and nations[nation_a].name_kind != WorldNaming.KIND_REBEL and nations[nation_b].name_kind != WorldNaming.KIND_REBEL and not is_succession_identity(nation_a) and not is_succession_identity(nation_b):
				ChronicleRules.begin_war(self, next_war_id, [nation_a], [nation_b])
			next_war_id += 1
	if previous == DiplomaticRelation.WAR and relation != DiplomaticRelation.WAR:
		var finished_war_id := int(war_relation_ids.get(key, -1))
		war_relation_ids.erase(key)
		truce_until_day[key] = maxi(
			int(truce_until_day.get(key, 0)),
			day + maxi(truce_days, 0)
		)
		for participant in [nation_a, nation_b]:
			if not nation_participates_in_war_id(participant, finished_war_id):
				release_nation_war_pool(participant, finished_war_id)
		if finished_war_id >= 0 and not war_relation_ids.values().has(finished_war_id):
			release_war_pool(finished_war_id)
	diplomacy_revision += 1
	return true


func wars_of(nation_id: int) -> Array[int]:
	var result: Array[int] = []
	for other in nations:
		if other.id != nation_id and other.alive and not other.succession_identity and is_enemy(nation_id, other.id):
			result.append(other.id)
	return result


## Count war pools, not hostile member countries. Unidentified pairs remain
## separate so manual diplomatic fixtures cannot hide overextension.
func active_war_count(nation_id: int) -> int:
	var war_ids := {}
	for enemy_id in wars_of(nation_id):
		var war_id := war_id_between(nation_id, enemy_id)
		war_ids[war_id if war_id >= 0 else -enemy_id - 1] = true
	return war_ids.size()


## rebel_id 对应的地方叛乱母国；不是地方叛军时返回 -1。记录在叛乱结束后
## 仍保留，因此可供长期的母国敌视与历史解释使用。
func regional_rebellion_parent(rebel_id: int) -> int:
	if not rebellions.has(rebel_id):
		return -1
	return int((rebellions[rebel_id] as Dictionary).get("parent_id", -1))


func is_regional_rebellion_pair(nation_a: int, nation_b: int) -> bool:
	return (
		regional_rebellion_parent(nation_a) == nation_b
		or regional_rebellion_parent(nation_b) == nation_a
	)


## 活跃且双方仍存续的母国—地方叛军，在起兵后 360 天内不得结束战争。
## 旧档若缺 started_day，则以当前战争关系的起始日作为兼容回退。
func regional_rebellion_peace_locked(nation_a: int, nation_b: int) -> bool:
	var rebel_id := -1
	var parent_id := -1
	if regional_rebellion_parent(nation_a) == nation_b:
		rebel_id = nation_a
		parent_id = nation_b
	elif regional_rebellion_parent(nation_b) == nation_a:
		rebel_id = nation_b
		parent_id = nation_a
	if (
		rebel_id < 0
		or parent_id < 0
		or rebel_id >= nations.size()
		or parent_id >= nations.size()
		or not nations[rebel_id].alive
		or not nations[parent_id].alive
	):
		return false
	var record: Dictionary = rebellions[rebel_id]
	if not bool(record.get("active", false)):
		return false
	var started_day := int(record.get(
		"started_day", relation_since(parent_id, rebel_id)
	))
	return (
		day - started_day
			< RebellionSystem.REGIONAL_REBELLION_MIN_WAR_DAYS
	)


func allies_of(nation_id: int) -> Array[int]:
	var result: Array[int] = []
	for other in nations:
		if other.id != nation_id and other.alive and is_allied(nation_id, other.id):
			result.append(other.id)
	return result


## 当前联盟图中 nation_id 所在的确定性、冲突感知连通分量。按国家 id 顺序扫描
## ALLIED 边；只有两个既有分量之间不存在任何 WAR 对时才合并。这样普通链式联盟
## 仍组成一个集团，但互为敌国的两方不会经共同盟友被传递闭包错误地并入同一集团。
func alliance_bloc(
	nation_id: int,
	alive_only: bool = true
) -> Array[int]:
	var result: Array[int] = []
	if (
		nation_id < 0
		or nation_id >= nations.size()
		or (alive_only and not nations[nation_id].alive)
	):
		return result
	var data: Dictionary
	if atlas_layout.is_empty():
		data = _build_alliance_components(alive_only)
	else:
		var nation_rows := PackedInt32Array()
		for nation in nations:
			nation_rows.append(int(nation.alive))
			nation_rows.append(int(nation.succession_identity))
		var conflicts := []
		for key in succession_conflicts:
			var conflict := succession_conflicts[key] as SuccessionConflict
			conflicts.append([key, conflict.nation_id, conflict.rebel_nation_id, conflict.war_id])
		# Membership reads these exact inputs, not ownership, troops, stocks,
		# future truce dates or war-ID bookkeeping. Cover in-place mutations too.
		var token := var_to_bytes([nation_rows, diplomatic_relations, conflicts])
		_alliance_component_mutex.lock()
		var cached: Dictionary = _alliance_component_cache.get(alive_only, {})
		if cached.get("token", PackedByteArray()) != token:
			cached = {"token": token, "data": _build_alliance_components(alive_only)}
			_alliance_component_cache[alive_only] = cached
		data = cached["data"]
		_alliance_component_mutex.unlock()
	var parent: PackedInt32Array = data["parent"]
	var nation_root := nation_id
	while parent[nation_root] != nation_root:
		nation_root = parent[nation_root]
	for member in data["components"][nation_root]:
		result.append(int(member))
	return result


## Keep the original lexicographic conflict-aware union order. One build
## computes every observer's bloc; published arrays/dictionaries stay private.
func _build_alliance_components(alive_only: bool) -> Dictionary:
	var parent := PackedInt32Array()
	parent.resize(nations.size())
	parent.fill(-1)
	var components: Dictionary = {}
	for candidate_id in range(nations.size()):
		if alive_only and not nations[candidate_id].alive:
			continue
		parent[candidate_id] = candidate_id
		components[candidate_id] = [candidate_id] as Array[int]
	# (a,b) 以字典序遍历，所以在矛盾联盟图上选择保留哪条盟约也不依赖调用者。
	for nation_a in range(nations.size()):
		if parent[nation_a] < 0:
			continue
		for nation_b in range(nation_a + 1, nations.size()):
			if (
				parent[nation_b] < 0
				or relation_between(nation_a, nation_b)
					!= DiplomaticRelation.ALLIED
			):
				continue
			var root_a := nation_a
			while parent[root_a] != root_a:
				root_a = parent[root_a]
			var root_b := nation_b
			while parent[root_b] != root_b:
				root_b = parent[root_b]
			if root_a == root_b:
				continue
			var blocked := false
			for member_a in components[root_a]:
				for member_b in components[root_b]:
					if is_enemy(int(member_a), int(member_b)):
						blocked = true
						break
				if blocked:
					break
			if blocked:
				continue
			var kept_root := mini(root_a, root_b)
			var merged_root := maxi(root_a, root_b)
			var merged: Array[int] = []
			for member in components[kept_root]:
				merged.append(int(member))
			for member in components[merged_root]:
				merged.append(int(member))
			merged.sort()
			parent[merged_root] = kept_root
			components[kept_root] = merged
			components.erase(merged_root)
	return {"parent": parent, "components": components}


# ------------------------------------------------------------------ 宗藩关系
# 宗藩平时仍是对外联盟共同体；当宗主直辖法理陆城占比过低时，藩王可发动
# 严格双边的私人战争。战争作用域由 war_objectives 标记，联盟同步不得传播私人战争边。

## 藩王的宗主 id；不是藩王返回 -1。
func overlord_of(nation_id: int) -> int:
	var record: Dictionary = suzerainty.get(nation_id, {})
	return int(record.get("overlord_id", -1)) if not record.is_empty() else -1


## 直接藩王 id 列表（不含更下级），按 id 升序，确定性。
func subjects_of(overlord_id: int) -> Array[int]:
	var result: Array[int] = []
	for subject_id in suzerainty:
		if int(suzerainty[subject_id].get("overlord_id", -1)) == overlord_id:
			result.append(int(subject_id))
	result.sort()
	return result


## 藩王关系记录副本；不是藩王返回空字典。
func suzerainty_record(subject_id: int) -> Dictionary:
	return (suzerainty.get(subject_id, {}) as Dictionary).duplicate()


func is_vassal(nation_id: int) -> bool:
	return suzerainty.has(nation_id)


func is_overlord(nation_id: int) -> bool:
	return not subjects_of(nation_id).is_empty()


## a 与 b 是否互为直接宗主-藩属。宗藩的 ALLIED 纽带是政治义务、非普通盟约，
## 不得被普通外交（退盟/结盟/宣战/议和）随意改动；各外交收集器据此跳过这类对。
func is_suzerainty_pair(nation_a: int, nation_b: int) -> bool:
	return overlord_of(nation_a) == nation_b or overlord_of(nation_b) == nation_a


## 两国是否属于同一宗藩体系。兄弟藩王间的 ALLIED 同样是制度性关系，
## 不能因双方不是直接宗主—藩属就被普通结盟/退盟逻辑处理。
func is_same_suzerainty_system(nation_a: int, nation_b: int) -> bool:
	return (
		nation_a >= 0
		and nation_b >= 0
		and nation_a < nations.size()
		and nation_b < nations.size()
		and nation_a != nation_b
		and suzerainty_root(nation_a) == suzerainty_root(nation_b)
	)


## 藩王领土是否与本宗藩体系的任一敌国存在真实领土边界。
## 用于分封战争加成：接壤敌国的藩王须以自有军团参与共同战争，
## 非接壤藩王只提高贡赋、不承担前线。河运链仅供通行，不构成边界。
func vassal_borders_system_enemy(subject_id: int) -> bool:
	if not is_vassal(subject_id):
		return false
	for city in cities:
		if city.is_dock or city.owner_nation != subject_id:
			continue
		for neighbor in territorial_border_neighbors(city.id):
			var neighbor_owner := cities[neighbor].owner_nation
			if neighbor_owner >= 0 and is_enemy(subject_id, neighbor_owner):
				return true
	return false


## 藩王是否正处于与其宗主的削藩内战中。内战期间宗主↔藩王为 WAR（而非 ALLIED），
## 对外共同体因此自然解散（alliance_bloc 会把两者拆开）——攘外必先安内。
func is_in_civil_war(subject_id: int) -> bool:
	var record: Dictionary = suzerainty.get(subject_id, {})
	return not record.is_empty() and bool(record.get("civil_war", false))


## 发起削藩内战：把宗主↔藩王从 ALLIED 改为 WAR，并在记录上打内战标记。
## 反叛藩王随即退出共享粮仓、按其（含下级和平藩属）领土粮食产能占原粮池的比例
## 切分库存到自己新建的首都粮仓（自成一池），并在首都凭空动员一批「火星兵」满编
## 主战军团（普通数量 = ceil(0.1 × 反叛方陆城数)）作为起兵资本。
## uprising_multiplier 仅供削藩动作施加君主效果；自发反叛保持默认 1 倍。
## 返回是否成功（须是既有宗藩对且当前非内战）。
func plan_vassal_conflict(subject_id: int) -> Dictionary:
	return VassalConflict.plan(self, subject_id)

func start_civil_war(subject_id: int, uprising_multiplier: int = 1) -> bool:
	return VassalConflict.start(self, subject_id, uprising_multiplier)


## Validate one complete parent-controlled administrative state for political transfer.
func _regional_rebellion_members(parent_id: int, city_ids: Array[int]) -> Array[int]:
	var empty: Array[int] = []
	if city_ids.is_empty() or parent_id < 0 or parent_id >= nations.size():
		return empty
	var center_id := administrative_center_of(city_ids[0])
	if not is_zhou_city(center_id) or cities[center_id].is_dock or not cities[center_id].politically_active \
		or cities[center_id].owner_nation != parent_id \
		or administrative_center_of(nations[parent_id].capital_city_id) == center_id:
		return empty
	var expected: Array[int] = []
	for city_id in administrative_members(center_id):
		if cities[city_id].owner_nation == parent_id and cities[city_id].politically_active and not cities[city_id].is_dock:
			if cities[city_id].is_capital:
				return empty
			expected.append(city_id)
	var provided := city_ids.duplicate()
	provided.sort()
	return expected if provided == expected and expected.size() < land_cities_of(parent_id).size() else empty


## 地方叛乱事务：把完整行政州内的本国实控陆城转成新的反叛国。
## 实控先转给叛军，法理仍留在母国；只有未来和平承认才改变 recognized owner。
## 资源、人力和驻军从当地/母国守恒划转，并额外按削藩内战同一公式在首都
## 动员满编“火星兵”，让新生叛军具备实际作战能力。
func start_regional_rebellion(
	parent_id: int,
	city_ids: Array[int]
) -> int:
	if (
		parent_id < 0 or parent_id >= nations.size()
		or not nations[parent_id].alive
		or (
			rebellions.has(parent_id)
			and bool((rebellions[parent_id] as Dictionary).get(
				"active", false
			))
		)
		or city_ids.is_empty()
	):
		return -1
	var unique_ids := _regional_rebellion_members(parent_id, city_ids)
	if unique_ids.is_empty():
		return -1
	var allowed := {}
	for city_id in unique_ids:
		allowed[city_id] = true

	var parent := nations[parent_id]
	# 地方叛乱可能发生在和平藩王领内；它的库存真源是宗藩根粮池，
	# 不能从零库存的藩王中继首都取数。城市易主前冻结分母与库存。
	var food_holder_before := food_pool_holder(parent_id)
	var food_pool_stock_before := _food_pool_stock(food_holder_before)
	var food_pool_output_before := _food_pool_food_output(food_holder_before)
	var rebel := Nation.new()
	rebel.id = nations.size()
	# 地方叛军是独立政治实体，从全局色环选择与现存国家区分度最大的颜色，
	# 不沿用母国色，也不走藩王的宗主派生色。
	rebel.color = _derive_independent_nation_color(rebel.id)
	rebel.alive = true
	rebel.political_system = parent.political_system
	rebel.ai_aggression = 1.0
	if _random_ruler_profiles_enabled:
		RulerProfile.initialize_nation(
			rebel, world_seed, rebel.id + day * 97
		)
	else:
		# 兼容网格世界中的运行时新国家也保持中性；专项测试可显式覆写。
		rebel.ruler_archetype = RulerProfile.BALANCED
		rebel.ruler_traits.clear()
		rebel.trade_policy = RulerProfile.POLICY_BALANCED
	rebel.ruler_started_day = day
	rebel.name_kind = WorldNaming.KIND_REBEL
	nations.append(rebel)

	var parent_manpower_output := 0
	var rebel_manpower_output := 0
	var parent_gold_output := 0
	var rebel_gold_output := 0
	var rebel_food_output := 0
	for city in land_cities_of(parent_id):
		parent_manpower_output += city.manpower_per_month
		parent_gold_output += city.gold_per_month
		if allowed.has(city.id):
			rebel_manpower_output += city.manpower_per_month
			rebel_gold_output += city.gold_per_month
			rebel_food_output += city.food_per_half_year
	var transferred_manpower := _proportional_share(
		parent.manpower_pool, rebel_manpower_output, parent_manpower_output
	)
	var transferred_gold := _proportional_share(
		parent.treasury_gold, rebel_gold_output, parent_gold_output
	)
	var capital_id := administrative_center_of(unique_ids[0])
	var territory_operations: Array[Dictionary] = []
	for city_id in unique_ids:
		territory_operations.append({
			"city_id": city_id,
			"controller_id": rebel.id,
			"sponsor_id": rebel.id,
			"stock_policy": TerritoryStockDisposition.RETURN_TO_OLD_POOL,
			"reason": "regional_rebellion",
		})
	var territory_result := apply_territory_transaction(
		territory_operations, {rebel.id: capital_id}
	)
	if not bool(territory_result.get("ok", false)):
		nations.pop_back()
		return -1
	parent.manpower_pool -= transferred_manpower
	parent.treasury_gold -= transferred_gold
	add_manpower(rebel.id, transferred_manpower)
	rebel.treasury_gold = transferred_gold
	var food_share := _proportional_share(
		food_pool_stock_before, rebel_food_output, food_pool_output_before
	)
	if food_share > 0:
		var withdrawn_food := _withdraw_food_from_warehouses(
			nations[food_holder_before], food_share
		)
		cities[capital_id].food_storage += withdrawn_food
		nations[food_holder_before].granary_food -= withdrawn_food
		rebel.granary_food += withdrawn_food
	WorldNaming.assign_rebel_name(self, rebel.id, parent_id, unique_ids)
	FamilyTree.ensure_nation_lineage(self, rebel.id)
	# A new ruler needs a complete generation even when no regular army can
	# be recruited; uprising armies do not initialize political patrons.
	PrincePolitics.ensure_generation(self, rebel.id)
	_initialize_rebel_diplomacy(parent_id, rebel.id)
	set_diplomatic_relation(parent_id, rebel.id, DiplomaticRelation.WAR)

	# Local stationed forces defect; if none do, mobilize one regular command
	# unit from transferred manpower.
	var defected_armies: Array[Army] = []
	for army in armies:
		if (
			army.owner_nation == parent_id
			and army.state in [Army.State.IDLE, Army.State.RECOVERING]
			and not army.on_edge and allowed.has(army.location_city)
		):
			if transfer_army_ownership(army, rebel.id):
				defected_armies.append(army)
	for defected_army in defected_armies:
		if defected_army.max_size >= INITIAL_HEAVY_ARMY_SIZE:
			assign_main_army_to_independent_command(defected_army)
	if defected_armies.is_empty() and rebel.manpower_pool >= INITIAL_HEAVY_ARMY_SIZE:
		var uprising := create_army(
			rebel.id, capital_id, INITIAL_HEAVY_ARMY_SIZE, INITIAL_HEAVY_ARMY_SIZE
		)
		if uprising != null:
			rebel.manpower_pool -= INITIAL_HEAVY_ARMY_SIZE
			_initialize_army_attributes(uprising)
			if assign_main_army_to_independent_command(uprising) == null:
				armies.erase(uprising)
				rebel.manpower_pool += INITIAL_HEAVY_ARMY_SIZE
	# 与削藩内战共用同一火星军口径：ceil(0.1 × 叛军陆城数) 个满编
	# MAIN 战团。它是叛乱政治事件的额外动员，不替代当地驻军倒戈。
	_spawn_rebellion_uprising_armies(rebel.id)
	rebellions[rebel.id] = {
		"parent_id": parent_id,
		"started_day": day,
		"core_city_ids": unique_ids.duplicate(),
		"recognized": false,
		"active": true,
		"reason": "全州连续低忠诚起义",
	}
	parent.last_rebellion_day = day
	rebel.last_rebellion_day = day
	RegionalStrategy.update_target(self, rebel.id)
	return rebel.id


## 低忠诚地区已有存活政治目标时，不再创造匿名地方叛军，而是恢复/归附该国。
## 实控立即转给 target；法理本就属于 target 时清除占领声明，否则保留原法理并
## 明确标记 target 为占领方。地方资源和静止驻军守恒迁移，既有外交关系不改写。
func restore_regional_loyalty_target(
	parent_id: int,
	target_id: int,
	city_ids: Array[int]
) -> bool:
	if (
		parent_id < 0 or parent_id >= nations.size()
		or target_id < 0 or target_id >= nations.size()
		or parent_id == target_id
		or not nations[parent_id].alive
		or not nations[target_id].alive
		or city_ids.is_empty()
	):
		return false
	var unique_ids := _regional_rebellion_members(parent_id, city_ids)
	if unique_ids.is_empty() or cities[administrative_center_of(unique_ids[0])].loyalty_target_nation != target_id:
		return false

	var allowed := {}
	for city_id in unique_ids:
		allowed[city_id] = true
	if is_suzerainty_pair(parent_id, target_id):
		var subject_id := (
			parent_id if overlord_of(parent_id) == target_id else target_id
		)
		if not is_in_civil_war(subject_id):
			return false

	var parent := nations[parent_id]
	var target := nations[target_id]
	var parent_manpower_output := 0
	var moved_manpower_output := 0
	var parent_gold_output := 0
	var moved_gold_output := 0
	var moved_food_output := 0
	var food_holder_before := food_pool_holder(parent_id)
	var food_pool_stock_before := _food_pool_stock(food_holder_before)
	var food_pool_output_before := _food_pool_food_output(food_holder_before)
	for city in land_cities_of(parent_id):
		parent_manpower_output += city.manpower_per_month
		parent_gold_output += city.gold_per_month
		if allowed.has(city.id):
			moved_manpower_output += city.manpower_per_month
			moved_gold_output += city.gold_per_month
			moved_food_output += city.food_per_half_year
	var transferred_manpower := _proportional_share(
		parent.manpower_pool, moved_manpower_output, parent_manpower_output
	)
	var transferred_gold := _proportional_share(
		parent.treasury_gold, moved_gold_output, parent_gold_output
	)
	var transferred_food := _proportional_share(
		food_pool_stock_before, moved_food_output, food_pool_output_before
	)
	var territory_operations: Array[Dictionary] = []
	for city_id in unique_ids:
		territory_operations.append({
			"city_id": city_id,
			"controller_id": target_id,
			"sponsor_id": target_id,
			# 先把随城易主的粮仓库存完整归回旧粮池；下方再以事务前
			# 总库存为基数按产能比例划给目标，避免销毁后重复扣减。
			"stock_policy": TerritoryStockDisposition.RETURN_TO_OLD_POOL,
			"reason": "regional_loyalty_restored",
		})
	var territory_result := apply_territory_transaction(territory_operations)
	if not bool(territory_result.get("ok", false)):
		return false
	if (
		not is_suzerainty_pair(parent_id, target_id)
		and not is_enemy(parent_id, target_id)
	):
		set_diplomatic_relation(
			parent_id, target_id, DiplomaticRelation.WAR
		)
	parent.manpower_pool -= transferred_manpower
	parent.treasury_gold -= transferred_gold
	add_manpower(target_id, transferred_manpower)
	target.treasury_gold += transferred_gold
	if transferred_food > 0:
		var target_food_holder := food_pool_holder(target_id)
		var transferable_food := mini(
			transferred_food,
			maxi(
				food_storage_capacity(target_id)
					- _food_pool_stock(target_food_holder),
				0
			)
		)
		var withdrawn_food := _withdraw_food_from_warehouses(
			nations[food_holder_before], transferable_food
		)
		if withdrawn_food > 0 and deposit_food(target_id, withdrawn_food):
			nations[food_holder_before].granary_food -= withdrawn_food
	var restored_armies: Array[Army] = []
	for army in armies:
		if (
			army.owner_nation == parent_id
			and army.state in [Army.State.IDLE, Army.State.RECOVERING]
			and not army.on_edge and allowed.has(army.location_city)
		):
			if transfer_army_ownership(army, target_id):
				restored_armies.append(army)
	for restored_army in restored_armies:
		if restored_army.max_size >= INITIAL_HEAVY_ARMY_SIZE:
			assign_main_army_to_independent_command(restored_army)
	parent.last_rebellion_day = day
	target.last_rebellion_day = day
	return true


func recognize_regional_rebellion(rebel_id: int) -> bool:
	if not rebellions.has(rebel_id):
		return false
	var record: Dictionary = rebellions[rebel_id]
	if not bool(record.get("active", false)):
		return false
	var parent_id := int(record.get("parent_id", -1))
	if regional_rebellion_peace_locked(parent_id, rebel_id):
		return false
	var operations: Array[Dictionary] = []
	for city_value in record.get("core_city_ids", []):
		var city_id := int(city_value)
		if city_id < 0 or city_id >= cities.size():
			continue
		if cities[city_id].owner_nation == rebel_id:
			operations.append({
				"city_id": city_id,
				"legal_owner_id": rebel_id,
				"reset_political_target": true,
				"stock_policy": TerritoryStockDisposition.RETURN_TO_OLD_POOL,
				"reason": "regional_rebellion_recognized",
			})
	var changed := false
	if not operations.is_empty():
		var territory_result := apply_territory_transaction(operations)
		if not bool(territory_result.get("ok", false)):
			return false
		changed = bool(territory_result.get("changed", false))
	record["recognized"] = true
	record["active"] = false
	rebellions[rebel_id] = record
	var old_name := str(nations[rebel_id].name)
	var rebel_ruler_name := str(nations[rebel_id].ruler_name)
	var uprising_centers := _rebellion_center_names(record)
	WorldNaming.promote_special_nation_to_sovereign(self, rebel_id)
	changed = changed or str(nations[rebel_id].name) != old_name
	ChronicleRules.record_rebellion(self, rebel_id, parent_id, rebel_ruler_name, uprising_centers, true, str(nations[rebel_id].name))
	return changed


func suppress_regional_rebellion(rebel_id: int) -> bool:
	if not rebellions.has(rebel_id):
		return false
	var record: Dictionary = rebellions[rebel_id]
	if not bool(record.get("active", false)):
		return false
	var parent_id := int(record.get("parent_id", -1))
	if parent_id < 0 or parent_id >= nations.size():
		return false
	var rebel_ruler_name := str(nations[rebel_id].ruler_name)
	var uprising_centers := _rebellion_center_names(record)
	if not annex_nation(parent_id, rebel_id):
		return false
	set_diplomatic_relation(
		parent_id, rebel_id, DiplomaticRelation.NEUTRAL, DEFAULT_TRUCE_DAYS
	)
	record["active"] = false
	record["recognized"] = false
	rebellions[rebel_id] = record
	for city_value in record.get("core_city_ids", []):
		var city_id := int(city_value)
		if city_id >= 0 and city_id < cities.size():
			cities[city_id].loyalty_target_nation = parent_id
			cities[city_id].loyalty = 45.0
			cities[city_id].rebellion_progress = 0
			cities[city_id].rebellion_cooldown_until_day = (
				day + RebellionSystem.REBELLION_COOLDOWN_DAYS
			)
	ChronicleRules.record_rebellion(self, rebel_id, parent_id, rebel_ruler_name, uprising_centers, false, "")
	return true


func _rebellion_center_names(record: Dictionary) -> Array[String]:
	var result: Array[String] = []
	for value in record.get("core_city_ids", []):
		var city_id := int(value)
		var center := administrative_center_of(city_id)
		if center >= 0 and center < cities.size() and not result.has(str(cities[center].name)):
			result.append(str(cities[center].name))
	result.sort()
	return result


func prune_rebellions() -> bool:
	var changed := false
	for rebel_value in rebellions.keys():
		var rebel_id := int(rebel_value)
		var record: Dictionary = rebellions[rebel_id]
		if not bool(record.get("active", false)):
			continue
		var parent_id := int(record.get("parent_id", -1))
		var rebel_alive := (
			rebel_id >= 0 and rebel_id < nations.size()
			and nations[rebel_id].alive
		)
		var parent_alive := (
			parent_id >= 0 and parent_id < nations.size()
			and nations[parent_id].alive
		)
		if not rebel_alive:
			ChronicleRules.record_rebellion_external_end(
				self,
				rebel_id,
				parent_id,
				str(nations[rebel_id].ruler_name) if rebel_id >= 0 and rebel_id < nations.size() else "未知",
				_rebellion_center_names(record)
			)
			record["active"] = false
			rebellions[rebel_id] = record
			changed = true
		elif not parent_alive:
			changed = recognize_regional_rebellion(rebel_id) or changed
	return changed


## 地方叛乱战争在双方停战时结算：叛军仍持有任一核心城市即获得承认，
## 否则视为被镇压。削藩内战不进入此表，继续由原首都通吃规则处理。
func resolve_rebellion_peace(nation_a: int, nation_b: int) -> bool:
	if regional_rebellion_peace_locked(nation_a, nation_b):
		return false
	var rebel_id := -1
	for candidate in [nation_a, nation_b]:
		if (
			rebellions.has(candidate)
			and bool((rebellions[candidate] as Dictionary).get("active", false))
		):
			rebel_id = candidate
			break
	if rebel_id < 0:
		return false
	var record: Dictionary = rebellions[rebel_id]
	var parent_id := int(record.get("parent_id", -1))
	if parent_id not in [nation_a, nation_b]:
		return false
	var controls_core := false
	for city_value in record.get("core_city_ids", []):
		var city_id := int(city_value)
		if city_id >= 0 and city_id < cities.size() and cities[city_id].owner_nation == rebel_id:
			controls_core = true
			break
	return (
		recognize_regional_rebellion(rebel_id)
		if controls_core
		else suppress_regional_rebellion(rebel_id)
	)


func rebellion_structure_valid() -> bool:
	for rebel_value in rebellions:
		var rebel_id := int(rebel_value)
		var record: Dictionary = rebellions[rebel_id]
		var parent_id := int(record.get("parent_id", -1))
		if (
			rebel_id < 0 or rebel_id >= nations.size()
			or parent_id < 0 or parent_id >= nations.size()
			or rebel_id == parent_id
		):
			return false
		if bool(record.get("active", false)):
			if not nations[rebel_id].alive or not is_enemy(rebel_id, parent_id):
				return false
			for third in nations:
				if (
					third.id != rebel_id
					and third.id != parent_id
					and is_enemy(rebel_id, third.id)
				):
					return false
			for city_value in record.get("core_city_ids", []):
				var city_id := int(city_value)
				if city_id < 0 or city_id >= cities.size():
					return false
	return true


## 一个粮池（沿非内战宗藩边可达的成员集）领土陆城的半年粮食产能之和。
## 用作内战切分共享库存的守恒比例基数。
func _food_pool_food_output(holder_id: int) -> int:
	var total := 0
	for member_id in food_pool_members(holder_id):
		for city in land_cities_of(member_id):
			total += city.food_per_half_year
	return total


## 一个粮池的当前库存总量（持有者名下全部粮仓存量之和；藩属首都零库存不计）。
func _food_pool_stock(holder_id: int) -> int:
	var total := 0
	for warehouse in warehouse_cities_of(holder_id):
		total += warehouse.food_storage
	return total


## 反叛方脱离共享粮仓、自成一池：在其首都建独立粮仓，从原持有者粮仓扣除 share 并注入。
## 守恒：先从原持有者粮仓（按占比）扣，再存入反叛方首都，粮食总量不变。
## 叛乱起兵：反叛方首都凭空动员
## multiplier × ceil(0.1 × 反叛方陆城数) 个满编主战军团（火星兵）。
## 每支起兵军团都建立独立指挥单位。起兵是离散政治事件，属性沿用
## _initialize_army_attributes 的世界生成随机口径（确定性由 rng 序保证）。
func _spawn_rebellion_uprising_armies(
	rebel_id: int,
	multiplier: int = 1
) -> void:
	if rebel_id < 0 or rebel_id >= nations.size():
		return
	var capital_id := nations[rebel_id].capital_city_id
	if capital_id < 0 or capital_id >= cities.size():
		return
	var land_count := land_cities_of(rebel_id).size()
	if land_count <= 0:
		return
	var uprising_count := (
		maxi(multiplier, 1) * int(ceil(0.1 * float(land_count)))
	)
	for _index in range(uprising_count):
		var army := _spawn_uprising_army(rebel_id, capital_id)
		if army == null:
			return
		if assign_main_army_to_independent_command(army) == null:
			armies.erase(army)
			return


## 凭空动员一支满编主战军（绕过 create_army 的城市归属校验：火星兵可在被围/新夺首都起兵）。
## 突破 create_army 的国家军队数上限硬约束——起兵是剧情动员，不受常备军配额限制。
func _spawn_uprising_army(nation_id: int, city_id: int) -> Army:
	return _spawn_conjured_army(nation_id, city_id)


## 凭空动员一支满编主战军（不扣人力/金钱、不受军队数上限约束）。
## 仅用于叛乱等离散政治动员；常规生成与招募仍受按陆城数计算的实体上限约束。
func _spawn_conjured_army(
	nation_id: int,
	city_id: int
) -> Army:
	var army := Army.new()
	army.id = _next_army_id
	_next_army_id += 1
	army.owner_nation = nation_id
	army.max_size = INITIAL_HEAVY_ARMY_SIZE
	army.size = INITIAL_HEAVY_ARMY_SIZE
	army.max_morale = Army.DEFAULT_MAX_MORALE
	army.morale = army.max_morale
	army.location_city = city_id
	army.move_from = city_id
	army.state = Army.State.IDLE
	army.speed_factor = rng.randf_range(0.3, 0.9)
	army.attack = rng.randi_range(8, 15)
	army.defense = rng.randi_range(8, 15)
	armies.append(army)
	return army


## 结束削藩内战（不改变领土归属，仅复位关系）：宗主↔藩王恢复 ALLIED，清内战标记。
## 供藩王战败保留宗藩、或和平收场时调用；通吃吞并另由领土结算处理。
func end_civil_war(subject_id: int) -> bool:
	if not VassalConflict.for_nation(self, subject_id).is_empty(): return false
	if not suzerainty.has(subject_id) or not is_in_civil_war(subject_id):
		return false
	var overlord_id := int(suzerainty[subject_id]["overlord_id"])
	var proposed := suzerainty.duplicate(true)
	(proposed[subject_id] as Dictionary)["civil_war"] = false
	var operations: Array[Dictionary] = []
	# 预先收集内战临时占领，与粮池合并及政治边在同一次事务提交。
	for city in cities:
		var legal_owner := recognized_owner_of(city.id)
		if (
			city.owner_nation == legal_owner
			or city.owner_nation not in [subject_id, overlord_id]
			or legal_owner not in [subject_id, overlord_id]
			or city.occupation_sponsor_nation != city.owner_nation
		):
			continue
		operations.append({
			"city_id": city.id,
			"controller_id": legal_owner,
			"legal_owner_id": legal_owner,
			"sponsor_id": -1,
			"reset_political_target": true,
			"reason": "civil_war_ended",
			"stock_policy": TerritoryStockDisposition.MOVE_TO_NEW_POOL,
		})
	var result := apply_territory_transaction(
		operations, {}, -1, proposed
	)
	if not bool(result.get("ok", false)):
		return false
	return true


## 沿宗主链上溯到的最终宗主（自身不是藩王时返回自身）。含环保护。
func suzerainty_root(nation_id: int) -> int:
	var current := nation_id
	var guard := 0
	while suzerainty.has(current) and guard <= nations.size():
		current = int(suzerainty[current]["overlord_id"])
		guard += 1
	return current


func _rebuild_suzerainty_cohesion_cache() -> void:
	var total_by_root: Dictionary = {}
	var direct_by_root: Dictionary = {}
	for city in cities:
		if city.is_dock:
			continue
		var legal_owner := recognized_owner_of(city.id)
		if legal_owner < 0 or legal_owner >= nations.size():
			continue
		var root := suzerainty_root(legal_owner)
		total_by_root[root] = int(total_by_root.get(root, 0)) + 1
		if legal_owner == root:
			direct_by_root[root] = int(direct_by_root.get(root, 0)) + 1
	_suzerainty_cohesion_by_root.clear()
	for root_value in total_by_root:
		var root := int(root_value)
		var total := int(total_by_root[root])
		_suzerainty_cohesion_by_root[root] = (
			float(int(direct_by_root.get(root, 0))) / float(total)
			if total > 0
			else 1.0
		)
	_suzerainty_cohesion_revision = ownership_revision


## 每日推进宗藩体系的低凝聚力连续计时。恢复到阈值即清零；连续满一年时，
## 整个宗藩树同时解体。返回本日解体的原宗主根，按 id 升序。
func advance_suzerainty_dissolution() -> Array[int]:
	VassalConflict.reconcile(self)
	var active_roots := {}
	for subject_value in suzerainty:
		var subject_id := int(subject_value)
		if subject_id < 0 or subject_id >= nations.size():
			continue
		var root := suzerainty_root(subject_id)
		if root >= 0 and root < nations.size() and nations[root].alive:
			active_roots[root] = true
	for tracked_value in suzerainty_low_cohesion_since_day.keys():
		var tracked_root := int(tracked_value)
		if not active_roots.has(tracked_root):
			suzerainty_low_cohesion_since_day.erase(tracked_root)
	var roots: Array[int] = []
	roots.assign(active_roots.keys())
	roots.sort()
	var dissolved: Array[int] = []
	for root in roots:
		if not VassalConflict.for_nation(self, root).is_empty():
			suzerainty_low_cohesion_since_day.erase(root)
			continue
		if suzerainty_cohesion(root) >= VASSAL_DISSOLUTION_COHESION_THRESHOLD:
			suzerainty_low_cohesion_since_day.erase(root)
			continue
		if not suzerainty_low_cohesion_since_day.has(root):
			suzerainty_low_cohesion_since_day[root] = day
			continue
		if (
			day - int(suzerainty_low_cohesion_since_day[root])
			< VASSAL_SYSTEM_DISSOLUTION_DAYS
		):
			continue
		if _dissolve_suzerainty_system(root):
			dissolved.append(root)
			suzerainty_low_cohesion_since_day.erase(root)
	return dissolved


func suzerainty_dissolution_days_remaining(nation_id: int) -> int:
	if nation_id < 0 or nation_id >= nations.size():
		return -1
	var root := suzerainty_root(nation_id)
	if not suzerainty_low_cohesion_since_day.has(root):
		return -1
	return maxi(
		VASSAL_SYSTEM_DISSOLUTION_DAYS
			- (day - int(suzerainty_low_cohesion_since_day[root])),
		0
	)


## 把同一宗藩根下的全部层级同时升格为独立国家，并把全体原成员组成
## 两两结盟的大联盟。内部战争按解体时的实际控制确认领土后结束；共享粮仓
## 按各成员粮产拆分。
func _dissolve_suzerainty_system(root_id: int) -> bool:
	if (
		root_id < 0
		or root_id >= nations.size()
		or suzerainty_root(root_id) != root_id
	):
		return false
	var members := suzerainty_members(root_id)
	if members.size() <= 1:
		return false
	var member_set := {}
	for member_id in members:
		member_set[member_id] = true
	var food_members_by_holder := {}
	for member_id in members:
		if not nations[member_id].alive:
			continue
		var holder_id := food_pool_holder(member_id)
		if not food_members_by_holder.has(holder_id):
			food_members_by_holder[holder_id] = [] as Array[int]
		(food_members_by_holder[holder_id] as Array[int]).append(member_id)
	var food_split_plans: Array[Dictionary] = []
	var holder_ids: Array[int] = []
	holder_ids.assign(food_members_by_holder.keys())
	holder_ids.sort()
	for holder_id in holder_ids:
		var pool_members: Array[int] = food_members_by_holder[holder_id]
		pool_members.sort()
		var output_by_member := {}
		var total_output := 0
		for member_id in pool_members:
			var member_output := 0
			for city in land_cities_of(member_id):
				member_output += city.food_per_half_year
			output_by_member[member_id] = member_output
			total_output += member_output
		food_split_plans.append({
			"holder_id": holder_id,
			"members": pool_members,
			"stock": _food_pool_stock(holder_id),
			"total_output": total_output,
			"output_by_member": output_by_member,
		})
	var proposed := suzerainty.duplicate(true)
	for subject_value in suzerainty:
		var subject_id := int(subject_value)
		if member_set.has(subject_id):
			proposed.erase(subject_id)
	var territory_operations: Array[Dictionary] = []
	for city in cities:
		var legal_owner := recognized_owner_of(city.id)
		if (
			city.owner_nation == legal_owner
			or not member_set.has(city.owner_nation)
			or not member_set.has(legal_owner)
			or not member_set.has(city.occupation_sponsor_nation)
		):
			continue
		territory_operations.append({
			"city_id": city.id,
			"controller_id": city.owner_nation,
			"legal_owner_id": city.owner_nation,
			"sponsor_id": -1,
			"reset_political_target": true,
			"reason": "suzerainty_dissolution_occupation_recognized",
			"stock_policy": TerritoryStockDisposition.MOVE_TO_NEW_POOL,
		})
	var diplomacy_operations: Array[Dictionary] = []
	for first_index in range(members.size()):
		for second_index in range(first_index + 1, members.size()):
			var nation_a := members[first_index]
			var nation_b := members[second_index]
			diplomacy_operations.append({
				"nation_a": nation_a,
				"nation_b": nation_b,
				"relation": DiplomaticRelation.ALLIED,
				"truce_days": 0,
			})
	var result := apply_territory_transaction(
		territory_operations,
		{},
		-1,
		proposed,
		diplomacy_operations
	)
	if not bool(result.get("ok", false)) or not bool(result.get("changed", false)):
		return false
	for split_plan in food_split_plans:
		var holder_id := int(split_plan["holder_id"])
		var stock := int(split_plan["stock"])
		var total_output := int(split_plan["total_output"])
		var output_by_member: Dictionary = split_plan["output_by_member"]
		for member_value in split_plan["members"]:
			var member_id := int(member_value)
			if member_id == holder_id:
				continue
			var share := _proportional_share(
				stock, int(output_by_member.get(member_id, 0)), total_output
			)
			var capital_id := nations[member_id].capital_city_id
			if (
				share <= 0
				or capital_id < 0
				or capital_id >= cities.size()
				or not cities[capital_id].has_warehouse
			):
				continue
			var withdrawn := _withdraw_food_from_warehouses(
				nations[holder_id], share
			)
			cities[capital_id].food_storage += withdrawn
	for objective_key in war_objectives.keys():
		var objective: Dictionary = war_objectives[objective_key]
		if (
			member_set.has(int(objective.get("attacker", -1)))
			and member_set.has(int(objective.get("defender", -1)))
		):
			war_objectives.erase(objective_key)
	for member_id in members:
		var nation := nations[member_id]
		if member_set.has(nation.war_preparation_target_nation):
			nation.war_preparation_target_nation = -1
			nation.war_preparation_objective_city = -1
			nation.war_preparation_objective_center_city = -1
			nation.war_preparation_staging_city_id = -1
			nation.war_preparation_army_ids.clear()
			nation.war_preparation_started_day = -1
			nation.war_preparation_reason = ""
			nation.war_preparation_unready_since_day = -1
	refresh_derived()
	diplomatic_history.append({
		"day": day,
		"kind": "suzerainty_dissolved",
		"root_nation": root_id,
		"member_nations": members.duplicate(),
		"alliance_formed": true,
	})
	return true


## 无城控制者的对外领土接收回退。正常占领优先保留实际控制者；仅当控制者已
## 无城时沿非内战宗藩链寻找存活接收方。
func external_territory_recipient(nation_id: int) -> int:
	if nation_id < 0 or nation_id >= nations.size():
		return -1
	var current := nation_id
	var guard := 0
	while (
		suzerainty.has(current)
		and not is_in_civil_war(current)
		and guard <= nations.size()
	):
		var overlord_id := overlord_of(current)
		if (
			overlord_id < 0
			or overlord_id >= nations.size()
			or land_cities_of(overlord_id).is_empty()
		):
			break
		current = overlord_id
		guard += 1
	return current


## nation_id 所属宗藩体系的全部成员（含宗主与各级藩王），按 id 升序。
## 与 alliance_bloc 的区别：bloc 是对外军事共同体（对称 ALLIED 连通分量），
## 可能包含平等盟友；本方法只沿有向宗藩链聚合同一个宗主根下的成员。
func suzerainty_members(nation_id: int) -> Array[int]:
	var root := suzerainty_root(nation_id)
	var result: Array[int] = [root]
	var seen := {root: true}
	var cursor := 0
	while cursor < result.size():
		for subject_id in subjects_of(result[cursor]):
			if not seen.has(subject_id):
				seen[subject_id] = true
				result.append(subject_id)
		cursor += 1
	result.sort()
	return result


## 粮食共享池的持有者：沿「非内战」宗藩边上溯到的最顶端节点（遇到内战边即停，不跨越）。
## 语义：同一宗藩体系里所有和平成员共享持有者首都的唯一粮仓这一「共享粮仓」，藩王首都
## 只是零库存补给中继节点；削藩内战的反叛者与其宗主断开、自成一池（见 start_civil_war）。
## 独立国返回自身。含环保护。这是「共享粮仓」库存归属的单一真源。
func food_pool_holder(nation_id: int) -> int:
	nation_id = financial_nation_of(nation_id)
	var current := nation_id
	var guard := 0
	while (
		suzerainty.has(current)
		and not is_in_civil_war(current)
		and guard <= nations.size()
	):
		current = int(suzerainty[current]["overlord_id"])
		guard += 1
	return current


## holder 共享粮池的全部和平成员（holder + 其下沿非内战边可达的各级藩王），按 id 升序。
## 用于补给网络把成员首都注入为零损耗中继起点，以及内战切分时界定「反叛方 / 留守方」。
func food_pool_members(holder_id: int) -> Array[int]:
	var result: Array[int] = [holder_id]
	var seen := {holder_id: true}
	var cursor := 0
	while cursor < result.size():
		for subject_id in subjects_of(result[cursor]):
			# 内战边被切断：反叛藩王及其子树不属于宗主的共享池。
			if not seen.has(subject_id) and not is_in_civil_war(subject_id):
				seen[subject_id] = true
				result.append(subject_id)
		cursor += 1
	result.sort()
	return result


## 粮食上限按共享粮池全体和平成员的城市基础半年产量计算。
## 藩王查询时仍返回其根宗主共享粮仓的同一个上限。
func food_storage_capacity(nation_id: int) -> int:
	if nation_id < 0 or nation_id >= nations.size():
		return 0
	var holder_id := food_pool_holder(nation_id)
	var member_set := {}
	for member_id in food_pool_members(holder_id):
		member_set[member_id] = true
	var half_year_output := 0
	for city in cities:
		if not city.is_dock and member_set.has(city.owner_nation):
			half_year_output += maxi(city.food_per_half_year, 0)
	return half_year_output * FOOD_CAPACITY_HALF_YEARS


## 人力池不在宗藩间共享；宗主（或任一藩王）的容量包含自己及其和平藩属子树。
func manpower_pool_capacity(nation_id: int) -> int:
	if nation_id < 0 or nation_id >= nations.size():
		return 0
	var member_set := {}
	for member_id in food_pool_members(nation_id):
		member_set[member_id] = true
	var monthly_output := 0
	for city in cities:
		if not city.is_dock and member_set.has(city.owner_nation):
			monthly_output += maxi(city.manpower_per_month, 0)
	return monthly_output * INITIAL_MANPOWER_RESERVE_MONTHS


## Fresh base-output capacities for one synchronous batch; never retained across edits.
## Raw ownership and the scalar APIs' dock-only exclusion are intentional.
func base_resource_capacities() -> Dictionary:
	var output_by_owner := {}
	for city in cities:
		if city.is_dock:
			continue
		if not output_by_owner.has(city.owner_nation):
			output_by_owner[city.owner_nation] = [0, 0]
		var output: Array = output_by_owner[city.owner_nation]
		output[0] += maxi(city.manpower_per_month, 0)
		output[1] += maxi(city.food_per_half_year, 0)
	var manpower: Array[int] = []
	var food: Array[int] = []
	manpower.resize(nations.size())
	food.resize(nations.size())
	var food_by_holder := {}
	for nation in nations:
		var monthly_output := 0
		for member_id in food_pool_members(nation.id):
			monthly_output += int(output_by_owner.get(member_id, [0, 0])[0])
		manpower[nation.id] = monthly_output * INITIAL_MANPOWER_RESERVE_MONTHS
		var holder_id := food_pool_holder(nation.id)
		if not food_by_holder.has(holder_id):
			var half_year_output := 0
			for member_id in food_pool_members(holder_id):
				half_year_output += int(output_by_owner.get(member_id, [0, 0])[1])
			food_by_holder[holder_id] = half_year_output * FOOD_CAPACITY_HALF_YEARS
		food[nation.id] = int(food_by_holder[holder_id])
	return {"manpower": manpower, "food": food}


## Monthly admission uses one fresh capacity batch and retains national commit order.
func add_manpower_batch(amounts: Array[int]) -> Array[int]:
	assert(amounts.size() == nations.size())
	var capacities: Array[int] = base_resource_capacities().manpower
	var accepted: Array[int] = []
	for nation in nations:
		accepted.append(_add_manpower_with_capacity(nation.id, amounts[nation.id], capacities[nation.id]))
	return accepted


## 唯一的人力正向写入口。返回实际进入人力池的数量。
func add_manpower(nation_id: int, amount: int) -> int:
	if amount <= 0 or nation_id < 0 or nation_id >= nations.size():
		return 0
	return _add_manpower_with_capacity(nation_id, amount, manpower_pool_capacity(nation_id))


func _add_manpower_with_capacity(nation_id: int, amount: int, capacity: int) -> int:
	if amount <= 0:
		return 0
	var nation := nations[nation_id]
	var accepted := mini(amount, maxi(capacity - nation.manpower_pool, 0))
	nation.manpower_pool += accepted
	return accepted


## 领土和宗藩结构变化会降低容量；在月结算边界统一清除超额库存，
## 避免插入领土事务的多阶段守恒划转中间破坏账目。
func clamp_resource_capacities() -> void:
	var food_changed := false
	var capacities := base_resource_capacities()
	for nation in nations:
		nation.manpower_pool = clampi(
			nation.manpower_pool, 0, int(capacities.manpower[nation.id])
		)
		if food_pool_holder(nation.id) != nation.id:
			continue
		var excess := _food_pool_stock(nation.id) - int(capacities.food[nation.id])
		if excess > 0:
			_withdraw_food_from_warehouses(nation, excess)
			food_changed = true
	if food_changed:
		refresh_derived()


## holder 粮池里可作补给中继起点的藩王首都（不含 holder 自己首都，那是主源；不含被围首都）。
## 补给损耗场与网络缓存指纹共用此单一真源，保证「降损耗中继」与「缓存失效」判据一致。
func food_pool_relay_capitals(holder_id: int) -> Array[int]:
	var origins: Array[int] = []
	for member_id in food_pool_members(holder_id):
		if member_id == holder_id:
			continue
		var capital_id := nations[member_id].capital_city_id
		if (
			capital_id < 0
			or capital_id >= cities.size()
			or cities[capital_id].owner_nation != member_id
			or city_under_siege(capital_id)
		):
			continue
		origins.append(capital_id)
	origins.sort()
	return origins


## 宗藩结构不变量校验。任一破坏都表明分封/削藩逻辑有 bug，应在测试中断言。
func suzerainty_structure_valid() -> bool:
	return suzerainty_structure_error().is_empty()


func suzerainty_structure_error() -> String:
	for subject_value in suzerainty:
		var subject_id := int(subject_value)
		var record: Dictionary = suzerainty[subject_id]
		var overlord_id := int(record.get("overlord_id", -1))
		# 1. id 合法且宗主藩属互异。
		if (
			subject_id < 0
			or subject_id >= nations.size()
			or overlord_id < 0
			or overlord_id >= nations.size()
			or subject_id == overlord_id
		):
			return "无效宗藩边 subject=%d overlord=%d nations=%d" % [
				subject_id, overlord_id, nations.size(),
			]
		# 2. 关系随内战态：内战中宗主↔藩王须为 WAR（共同体解散、攘外必先安内），
		#    非内战的宗藩对须恒为 ALLIED（对外共同体化的前提）。
		var expected := (
			DiplomaticRelation.WAR
			if bool(record.get("civil_war", false))
			else DiplomaticRelation.ALLIED
		)
		if relation_between(subject_id, overlord_id) != expected:
			return "宗藩外交不一致 subject=%d overlord=%d expected=%d actual=%d civil_war=%s" % [
				subject_id,
				overlord_id,
				expected,
				relation_between(subject_id, overlord_id),
				str(bool(record.get("civil_war", false))),
			]
		# A vassal is a state-level polity, never a府-only fragment.
		var subject_has_center := false
		for center_value in administrative_center_city_ids:
			var center_id := int(center_value)
			if recognized_owner_of(center_id) == subject_id:
				subject_has_center = true
				break
		if not subject_has_center:
			var legal_land_count := 0
			for city in cities:
				if (
					not city.is_dock
					and recognized_owner_of(city.id) == subject_id
				):
					legal_land_count += 1
			return "藩王无法理州治 subject=%d overlord=%d land=%d legal_land=%d" % [
				subject_id,
				overlord_id,
				land_cities_of(subject_id).size(),
				legal_land_count,
			]
		# 3. 沿宗主链上溯必须在有限步内终止（无环、单一宗主）。
		var walker := overlord_id
		var guard := 0
		while suzerainty.has(walker):
			if walker == subject_id or guard > nations.size():
				return "宗藩链成环 subject=%d walker=%d guard=%d" % [
					subject_id, walker, guard,
				]
			walker = int(suzerainty[walker]["overlord_id"])
			guard += 1
	return ""


## 清理死亡国家（无城）或无法理州治藩国造成的悬空宗藩记录，保持不变量。
## 每 tick 领土结算后调用。
## - 死亡藩王：直接移除其记录（它已不存在）。
## - 无法理州治藩王：解除上级边，剩余属府成为独立主权领土。
## - 死亡宗主：其直接藩王上移一级（挂到宗主自己的宗主，无则升为独立主权），
##   宗藩链因此保持连续、无悬空、无环。
## 返回是否发生了任何清理（供调用方决定是否刷新缓存）。
func prune_dead_suzerainty() -> bool:
	# 运行时缺失法理数组属于损坏状态，不能把当前实控静默洗成法理。
	if recognized_city_owners.size() != cities.size():
		push_error("清理死亡宗藩失败：法理领土索引与城市数量不一致。")
		return false
	var final_city_counts: Array[int] = []
	final_city_counts.resize(nations.size())
	final_city_counts.fill(0)
	for city in cities:
		if (
			city.owner_nation >= 0
			and city.owner_nation < nations.size()
			and nations[city.owner_nation].alive
			and not city.is_dock
		):
			final_city_counts[city.owner_nation] += 1
	var final_legal_center_counts: Array[int] = []
	final_legal_center_counts.resize(nations.size())
	final_legal_center_counts.fill(0)
	for center_value in administrative_center_city_ids:
		var center_owner := recognized_owner_of(int(center_value))
		if center_owner >= 0 and center_owner < nations.size():
			final_legal_center_counts[center_owner] += 1
	var proposed := _normalized_suzerainty_for_territory(
		suzerainty, final_city_counts, final_legal_center_counts
	)
	if proposed == suzerainty:
		return _promote_independent_vassal_names()
	var operations: Array[Dictionary] = []
	# 灭亡藩王的法理在同一事务交给最近的存活祖先；sponsor 若指向
	# 死亡节点也同步转移，避免 phase 2 留下无效战争责任方。
	for city in cities:
		var former_id := recognized_owner_of(city.id)
		if (
			former_id < 0 or former_id >= nations.size()
			or final_city_counts[former_id] > 0
			or not suzerainty.has(former_id)
		):
			continue
		var successor := int(
			(suzerainty[former_id] as Dictionary)["overlord_id"]
		)
		var guard := 0
		while (
			successor >= 0
			and successor < nations.size()
			and final_city_counts[successor] <= 0
			and suzerainty.has(successor)
			and guard <= nations.size()
		):
			successor = int(
				(suzerainty[successor] as Dictionary)["overlord_id"]
			)
			guard += 1
		if successor < 0 or successor >= nations.size():
			continue
		var sponsor := city.occupation_sponsor_nation
		if sponsor == former_id:
			sponsor = successor
		if city.owner_nation == successor:
			sponsor = -1
		operations.append({
			"city_id": city.id,
			"legal_owner_id": successor,
			"sponsor_id": sponsor,
			"reset_political_target": true,
			"stock_policy": TerritoryStockDisposition.RETURN_TO_OLD_POOL,
			"reason": "recognized_territory_inherited",
		})
	var result := apply_territory_transaction(
		operations, {}, -1, proposed
	)
	if not bool(result.get("ok", false)):
		return false
	return true


## 修复旧档或领土事务留下的命名脱节：实际已无宗主边的存活国家不能继续
## 保留 vassal 身份和“王”后缀。放在每日宗藩清理中可覆盖所有独立路径。
func _promote_independent_vassal_names() -> bool:
	var changed := false
	for nation in nations:
		if (
			not nation.alive
			or suzerainty.has(nation.id)
			or str(nation.name_kind) != WorldNaming.KIND_VASSAL
		):
			continue
		WorldNaming.promote_vassal_to_sovereign(self, nation.id)
		FamilyTree.record_current_title(self, nation.id)
		changed = true
	return changed


## 分封：宗主 overlord_id 将 city_ids 划出，新建一个完整藩王 Nation。
## 长期主义切分：增量 A 只转移「领土 + 对外关系 + 派生资源」，军队不迁移
## （藩王首版无常备军，军队迁移涉及战团结构不变量，留待增量 B 专门处理）。
## 资源按迁出区在宗主总产能中的动态占比划转，全局守恒、无硬编码常量。
## 返回新藩王 id；输入非法（空区、含宗主首都、跨国、道路不连续保留给增量 B）
## 时返回 -1，不产生任何副作用。
func enfeoff(
	overlord_id: int,
	city_ids: Array[int],
	tribute_rate: float = DEFAULT_TRIBUTE_RATE
) -> int:
	# Vassal fiefs are administrative units: normalize any府-level request to
	# complete states before the closure/transaction code runs.
	city_ids = normalize_enfeoff_region(overlord_id, city_ids)
	if is_succession_identity(overlord_id):
		return -1
	if city_ids.is_empty():
		return -1
	if not _can_enfeoff(overlord_id, city_ids):
		return -1
	var overlord := nations[overlord_id]
	var enfeoffed_person := PrincePolitics.enfeoff_candidate(self, overlord_id)
	if enfeoffed_person < 0:
		return -1

	# 1. 按产能占比确定划转份额（迁出区 / 宗主全域），保证资源守恒。
	#    人力、金钱按各自产能占比划转；粮食不划转（归共享粮仓，见下）。
	var overlord_manpower_output := 0
	var overlord_gold_output := 0
	for city in land_cities_of(overlord_id):
		overlord_manpower_output += city.manpower_per_month
		overlord_gold_output += city.gold_per_month
	var moved_manpower_output := 0
	var moved_gold_output := 0
	for city_id in city_ids:
		moved_manpower_output += cities[city_id].manpower_per_month
		moved_gold_output += cities[city_id].gold_per_month
	var granted_manpower := _proportional_share(
		overlord.manpower_pool, moved_manpower_output, overlord_manpower_output
	)
	var granted_gold := _proportional_share(
		overlord.treasury_gold, moved_gold_output, overlord_gold_output
	)
	# 粮食归「共享粮仓」：分封不划走粮食库存，全体系粮食继续留在宗主根粮仓。
	# 藩王首都只作零库存补给中继节点，由领土事务统一建立，不切分库存。

	# 2. 建新藩王 Nation（完整实体，色调随宗主派生以体现同一政治共同体）。
	var subject := Nation.new()
	subject.id = nations.size()
	subject.color = _derive_vassal_color(overlord.color, subject.id)
	subject.alive = true
	subject.political_system = overlord.political_system
	subject.ai_aggression = 1.0
	subject.ruler_started_day = day
	nations.append(subject)

	# 3. 不预写 live 图；完整拟议图与封地迁移由同一事务提交。
	var proposed_suzerainty := suzerainty.duplicate(true)
	proposed_suzerainty[subject.id] = {
		"overlord_id": overlord_id,
		"tribute_rate": clampf(tribute_rate, 0.0, 1.0),
		"created_day": day,
		"last_centralization_day": -1,
		"civil_war": false,
	}
	var capital_candidates: Array[int] = []
	for city_id in city_ids:
		if (
			not cities[city_id].is_dock
			and is_zhou_city(city_id)
		):
			capital_candidates.append(city_id)
	if capital_candidates.is_empty():
		nations.pop_back()
		return -1
	EquivariantOrder.sort_city_ids(capital_candidates, self, subject.id)
	var capital_id := capital_candidates[0]
	var territory_operations: Array[Dictionary] = []
	for city_id in city_ids:
		territory_operations.append({
			"city_id": city_id,
			"controller_id": subject.id,
			"legal_owner_id": subject.id,
			"sponsor_id": -1,
			"reset_political_target": true,
			"stock_policy": TerritoryStockDisposition.RETURN_TO_OLD_POOL,
			"reason": "enfeoffment",
		})
	var territory_result := apply_territory_transaction(
		territory_operations, {subject.id: capital_id}, -1,
		proposed_suzerainty
	)
	if not bool(territory_result.get("ok", false)):
		nations.pop_back()
		return -1

	# 4. 划转人力与金钱（守恒：从宗主池扣除、注入藩王池）。
	overlord.manpower_pool -= granted_manpower
	add_manpower(subject.id, granted_manpower)
	overlord.treasury_gold -= granted_gold
	subject.treasury_gold = granted_gold

	# 5. 首都、零库存中继与封地存粮回流已由领土事务统一完成。
	WorldNaming.assign_vassal_name(self, subject.id, city_ids, true)
	FamilyTree.record_enfeoffment(self, overlord_id, subject.id, enfeoffed_person)

	# 5.5 分封不再创造或转移正规军。城市工事负责拖延，藩王须用自身资源
	#     建立第一个主战指挥单位；宗主的既有指挥单位保持完整。

	# 6. 外交：藩王继承宗主对每个第三方的关系，并与宗主结盟。
	#    这样 alliance_bloc 天然把宗藩聚为一体，对外 is_enemy 自动正确，
	#    且不会因缺省 key 让新藩王与未建交国凭空开战（relation_between 缺省=WAR）。
	_inherit_overlord_diplomacy(overlord_id, subject.id)

	# 7. 宗藩关系已在领土事务前写入，以参与最终粮池规划。
	for city_id in city_ids:
		var granted_city := cities[city_id]
		granted_city.loyalty_target_nation = subject.id
		granted_city.loyalty = maxf(granted_city.loyalty, 68.0)
		granted_city.loyalty_trend = 0.0
		granted_city.unrest = 100.0 - granted_city.loyalty
		granted_city.rebellion_progress = 0

	var suzerainty_error := suzerainty_structure_error()
	assert(
		suzerainty_error.is_empty(),
		"分封后宗藩结构不变量必须成立：" + suzerainty_error
	)
	assert(
		_battle_group_structure_valid(),
		"分封迁移军队后战团结构不变量必须成立"
	)
	RegionalStrategy.update_target(self, subject.id)
	EmpireStatus.reconcile(self)
	return subject.id


## Expand a proposed fief to complete administrative states.  A state is valid
## only when its center and every land member are still controlled and legally
## owned by the overlord; docks remain independent nodes and cannot silently
## become a府-only vassal.
func expand_enfeoff_to_administrative_states(
	overlord_id: int,
	proposed_city_ids: Array[int]
) -> Array[int]:
	if (
		overlord_id < 0
		or overlord_id >= nations.size()
		or proposed_city_ids.is_empty()
	):
		return [] as Array[int]
	var requested_centers := {}
	for city_id in proposed_city_ids:
		if (
			city_id < 0
			or city_id >= cities.size()
			or cities[city_id].is_dock
		):
			return [] as Array[int]
		var center_id := administrative_center_of(city_id)
		if center_id < 0:
			return [] as Array[int]
		requested_centers[center_id] = true
	var result := {}
	for center_value in requested_centers:
		var center_id := int(center_value)
		for member_id in administrative_members(center_id):
			if (
				cities[member_id].is_dock
				or cities[member_id].owner_nation != overlord_id
				or recognized_owner_of(member_id) != overlord_id
			):
				return [] as Array[int]
			result[member_id] = true
	var expanded: Array[int] = []
	for city_id_value in result:
		expanded.append(int(city_id_value))
	expanded.sort()
	return expanded


func normalize_enfeoff_region(
	overlord_id: int,
	proposed_city_ids: Array[int]
) -> Array[int]:
	var normalized := expand_enfeoff_to_administrative_states(
		overlord_id, proposed_city_ids
	)
	if normalized.is_empty():
		return normalized
	# A closure may add disconnected holdings from other states. Expand those
	# additions to complete states, then recompute the closure until stable.
	var guard := maxi(administrative_region_count, 1) + 1
	while guard > 0:
		guard -= 1
		var closure := enfeoff_region_closure(overlord_id, normalized)
		var next := expand_enfeoff_to_administrative_states(
			overlord_id, closure
		)
		if next.is_empty():
			return next
		if next == normalized:
			return normalized
		normalized = next
	return [] as Array[int]


## 把一次兼并追加到现有虚拟领土计划。draft 的五个字段均是完整快照：
## owners / legal / sponsors 为逐城最终值，operation_by_city 以 city_id 去重，
## proposed_suzerainty 为完整拟议宗藩图。函数只在全部校验与合成成功后替换
## draft 字段，因此失败不会留下半份兼并计划。
func append_annexation_to_territory_plan(
	draft: Dictionary,
	absorber: int,
	absorbed: int,
	stock_policy_overrides: Dictionary = {}
) -> bool:
	if (
		absorber < 0 or absorber >= nations.size()
		or absorbed < 0 or absorbed >= nations.size()
		or absorber == absorbed
		or not draft.has("owners")
		or not draft.has("legal")
		or not draft.has("sponsors")
		or not draft.has("operation_by_city")
		or not draft.has("proposed_suzerainty")
		or typeof(draft["owners"]) != TYPE_ARRAY
		or typeof(draft["legal"]) != TYPE_ARRAY
		or typeof(draft["sponsors"]) != TYPE_ARRAY
		or typeof(draft["operation_by_city"]) != TYPE_DICTIONARY
		or typeof(draft["proposed_suzerainty"]) != TYPE_DICTIONARY
	):
		return false
	var owner_values: Array = draft["owners"]
	var legal_values: Array = draft["legal"]
	var sponsor_values: Array = draft["sponsors"]
	if (
		owner_values.size() != cities.size()
		or legal_values.size() != cities.size()
		or sponsor_values.size() != cities.size()
	):
		return false
	for city_id in range(cities.size()):
		if (
			typeof(owner_values[city_id]) != TYPE_INT
			or typeof(legal_values[city_id]) != TYPE_INT
			or typeof(sponsor_values[city_id]) != TYPE_INT
		):
			return false
	var planned_owners: Array[int] = []
	var planned_legal: Array[int] = []
	var planned_sponsors: Array[int] = []
	planned_owners.assign(owner_values)
	planned_legal.assign(legal_values)
	planned_sponsors.assign(sponsor_values)
	var operation_by_city: Dictionary = (
		(draft["operation_by_city"] as Dictionary).duplicate(true)
	)
	var suzerainty_validation := _validated_suzerainty_snapshot(
		draft["proposed_suzerainty"] as Dictionary
	)
	if not bool(suzerainty_validation.get("ok", false)):
		return false
	var proposed_suzerainty: Dictionary = (
		suzerainty_validation["snapshot"] as Dictionary
	)

	# override 只对虚拟快照中仍由 absorbed 实控的城市有意义。
	for city_value in stock_policy_overrides:
		if typeof(city_value) != TYPE_INT:
			return false
		var city_id := int(city_value)
		var policy_value: Variant = stock_policy_overrides[city_value]
		if (
			city_id < 0
			or city_id >= cities.size()
			or cities[city_id].owner_nation != absorbed
			or typeof(policy_value) != TYPE_INT
			or int(policy_value) not in [
				TerritoryStockDisposition.RETURN_TO_OLD_POOL,
				TerritoryStockDisposition.MOVE_TO_NEW_POOL,
				TerritoryStockDisposition.CAPTURE_SPOILS,
				TerritoryStockDisposition.DESTROY,
			]
		):
			return false

	# 若胜者原是败方藩属，先解除该边；败方的其他直接藩属改挂胜者。
	if (
		proposed_suzerainty.has(absorber)
		and int((proposed_suzerainty[absorber] as Dictionary).get(
			"overlord_id", -1
		)) == absorbed
	):
		proposed_suzerainty.erase(absorber)
	var absorbed_children: Array[int] = []
	for subject_value in proposed_suzerainty:
		var subject_id := int(subject_value)
		if (
			subject_id != absorber
			and int((proposed_suzerainty[subject_id] as Dictionary).get(
				"overlord_id", -1
			)) == absorbed
		):
			absorbed_children.append(subject_id)
	for child_id in absorbed_children:
		(proposed_suzerainty[child_id] as Dictionary)["overlord_id"] = absorber
		(proposed_suzerainty[child_id] as Dictionary)["civil_war"] = false
	proposed_suzerainty.erase(absorbed)
	if not bool(_validated_suzerainty_snapshot(
		proposed_suzerainty
	).get("ok", false)):
		return false

	# 所有判断都读取 draft 的虚拟快照；同一城市只覆盖一条最终 operation。
	for city_id in range(cities.size()):
		var controlled_by_absorbed := planned_owners[city_id] == absorbed
		var legally_absorbed := planned_legal[city_id] == absorbed
		var sponsored_by_absorbed := planned_sponsors[city_id] == absorbed
		if not (
			controlled_by_absorbed
			or legally_absorbed
			or sponsored_by_absorbed
			or stock_policy_overrides.has(city_id)
		):
			continue
		var controller := absorber if controlled_by_absorbed else planned_owners[city_id]
		var legal_owner := absorber if legally_absorbed else planned_legal[city_id]
		var sponsor := absorber if sponsored_by_absorbed else planned_sponsors[city_id]
		if controller == legal_owner:
			sponsor = -1
		var operation: Dictionary = {}
		if operation_by_city.has(city_id):
			if typeof(operation_by_city[city_id]) != TYPE_DICTIONARY:
				return false
			operation = (operation_by_city[city_id] as Dictionary).duplicate(true)
		operation["city_id"] = city_id
		operation["controller_id"] = controller
		operation["legal_owner_id"] = legal_owner
		operation["sponsor_id"] = sponsor
		operation["reset_political_target"] = (
			bool(operation.get("reset_political_target", false))
			or legally_absorbed
		)
		operation["reason"] = "annexation"
		if stock_policy_overrides.has(city_id):
			# override 针对事务开始时由 absorbed 实控的库存；即使前序
			# draft 已先规划攻占该城，也必须覆盖已有 capture policy。
			operation["stock_policy"] = int(
				stock_policy_overrides[city_id]
			)
		elif not operation.has("stock_policy"):
			operation["stock_policy"] = (
				TerritoryStockDisposition.MOVE_TO_NEW_POOL
			)
		operation_by_city[city_id] = operation
		planned_owners[city_id] = controller
		planned_legal[city_id] = legal_owner
		planned_sponsors[city_id] = sponsor

	var absorber_has_city := false
	for owner_id in planned_owners:
		if owner_id == absorber:
			absorber_has_city = true
			break
	if not absorber_has_city:
		return false
	draft["owners"] = planned_owners
	draft["legal"] = planned_legal
	draft["sponsors"] = planned_sponsors
	draft["operation_by_city"] = operation_by_city
	draft["proposed_suzerainty"] = proposed_suzerainty
	return true


## 领土提交成功后的兼并收尾。这里只迁移无独立失败条件的军队、战团与资源；
## 城市、宗藩、首都、粮仓和库存已由 apply_territory_transaction 一次提交。
func finalize_annexation_after_territory_commit(
	absorber: int,
	absorbed: int
) -> void:
	if absorber >= 0 and absorbed >= 0 and absorber < nations.size() and absorbed < nations.size() and absorber != absorbed:
		_finalize_annexations(absorber, {absorbed: true})


func _finalize_annexations(absorber: int, absorbed_ids: Dictionary) -> void:
	var old_bindings := {}
	for army in armies:
		if absorbed_ids.has(army.owner_nation) and army.campaign_war_id >= 0:
			old_bindings[Vector2i(army.owner_nation, army.campaign_war_id)] = true
	for front in campaign_fronts.values():
		for member_id in front.participant_nation_ids:
			if absorbed_ids.has(member_id):
				old_bindings[Vector2i(member_id, front.war_id)] = true
	for binding: Vector2i in old_bindings:
		release_nation_war_pool(binding.x, binding.y)
	var group_mapping := {}
	for absorbed in absorbed_ids:
		for group in nations[absorbed].battle_groups:
			var old_key := Vector2i(absorbed, group.id)
			group.id = nations[absorber].next_battle_group_id
			nations[absorber].next_battle_group_id += 1
			group.owner_nation = absorber
			group_mapping[old_key] = group.id
			nations[absorber].battle_groups.append(group)
		nations[absorbed].battle_groups.clear()
		add_manpower(absorber, nations[absorbed].manpower_pool)
		nations[absorbed].manpower_pool = 0
		nations[absorber].treasury_gold += nations[absorbed].treasury_gold
		nations[absorbed].treasury_gold = 0
	for army in armies:
		if absorbed_ids.has(army.owner_nation) and army.size > 0:
			var old_group := Vector2i(army.owner_nation, army.battle_group_id)
			transfer_army_ownership(army, absorber)
			army.battle_group_id = int(group_mapping.get(old_group, -1))
		if absorbed_ids.has(army.occupation_claimant_nation):
			army.occupation_claimant_nation = absorber
		if army.owner_nation == absorber:
			army.ruler_attack_multiplier = RulerProfile.attack_multiplier(nations[absorber])
			army.ruler_defense_multiplier = RulerProfile.defense_multiplier(nations[absorber])
			army.ruler_morale_multiplier = RulerProfile.morale_multiplier(nations[absorber])
			army.funding_multiplier = Army.funding_from_payment(nations[absorber].military_payment_ratio)
	_reconcile_battles_after_annexation()
	RoyalTitles.annex(self, absorber, absorbed_ids)
	EmpireStatus.reconcile(self)
	VassalConflict.reconcile(self)


## 把 absorbed 国的全部领土、军队、战团、资源并入 absorber 国。普通兼并与
## 集团和平中的叛乱镇压共用同一 planner/finalizer，避免两套语义漂移。
func annex_nation(
	absorber: int,
	absorbed: int,
	expected_ownership_revision: int = -1,
	stock_policy_overrides: Dictionary = {}
) -> bool:
	return annex_nations(absorber, [absorbed], expected_ownership_revision, stock_policy_overrides)


func annex_nations(absorber: int, absorbed_nations: Array, expected_ownership_revision: int = -1, stock_policy_overrides: Dictionary = {}) -> bool:
	if absorber < 0 or absorber >= nations.size() or absorbed_nations.is_empty() or is_succession_identity(absorber):
		return false
	var absorbed_ids := {}
	for nation_id in absorbed_nations:
		if typeof(nation_id) != TYPE_INT or nation_id < 0 or nation_id >= nations.size() or nation_id == absorber or absorbed_ids.has(nation_id) or is_succession_identity(nation_id):
			return false
		absorbed_ids[nation_id] = true
	for city_id in stock_policy_overrides:
		if typeof(city_id) != TYPE_INT or city_id < 0 or city_id >= cities.size() or not absorbed_ids.has(cities[city_id].owner_nation):
			return false
		if typeof(stock_policy_overrides[city_id]) != TYPE_INT or int(stock_policy_overrides[city_id]) not in [TerritoryStockDisposition.RETURN_TO_OLD_POOL, TerritoryStockDisposition.MOVE_TO_NEW_POOL, TerritoryStockDisposition.CAPTURE_SPOILS, TerritoryStockDisposition.DESTROY]:
			return false
	var graph := suzerainty.duplicate(true)
	if graph.has(absorber) and absorbed_ids.has(int(graph[absorber].overlord_id)):
		graph.erase(absorber)
	for subject in graph.keys():
		if absorbed_ids.has(subject):
			graph.erase(subject)
		elif absorbed_ids.has(int(graph[subject].overlord_id)):
			graph[subject].overlord_id = absorber
			graph[subject].civil_war = false
	var operations: Array[Dictionary] = []
	for city in cities:
		var controlled := absorbed_ids.has(city.owner_nation)
		var legally_absorbed := absorbed_ids.has(recognized_owner_of(city.id))
		var sponsored := absorbed_ids.has(city.occupation_sponsor_nation)
		if not controlled and not legally_absorbed and not sponsored:
			continue
		var controller := absorber if controlled else city.owner_nation
		var legal := absorber if legally_absorbed else recognized_owner_of(city.id)
		operations.append({"city_id": city.id, "controller_id": controller, "legal_owner_id": legal,
			"sponsor_id": -1 if controller == legal else (absorber if sponsored else city.occupation_sponsor_nation),
			"reset_political_target": legally_absorbed, "reason": "annexation",
			"stock_policy": int(stock_policy_overrides.get(city.id, TerritoryStockDisposition.MOVE_TO_NEW_POOL))})
	var result := apply_territory_transaction(operations, {}, expected_ownership_revision, graph)
	if not result.ok:
		return false
	for nation_id in absorbed_ids:
		FamilyTree.ensure_nation_lineage(self, nation_id)
	_finalize_annexations(absorber, absorbed_ids)
	return true


func accept_submission(overlord_id: int, subject_id: int) -> bool:
	if overlord_id < 0 or subject_id < 0 or overlord_id >= nations.size() or subject_id >= nations.size():
		return false
	if is_succession_identity(overlord_id) or is_succession_identity(subject_id):
		return false
	if not nations[overlord_id].alive or not nations[subject_id].alive or is_vassal(subject_id) or suzerainty_root(overlord_id) == subject_id:
		return false
	var members := suzerainty_members(subject_id)
	for member_id in members:
		if not wars_of(member_id).is_empty() or is_in_civil_war(member_id) or rebellions.has(member_id) or nations[member_id].name_kind == WorldNaming.KIND_REBEL:
			return false
	var graph := suzerainty.duplicate(true)
	graph[subject_id] = {"overlord_id": overlord_id, "tribute_rate": DEFAULT_TRIBUTE_RATE,
		"created_day": day, "last_centralization_day": -1, "civil_war": false}
	var diplomacy: Array[Dictionary] = []
	var bloc := alliance_bloc(overlord_id)
	for member_id in members:
		for third in nations:
			if members.has(third.id) or not third.alive:
				continue
			diplomacy.append({"nation_a": member_id, "nation_b": third.id,
				"relation": DiplomaticRelation.ALLIED if bloc.has(third.id) else relation_between(overlord_id, third.id)})
	var result := apply_territory_transaction([], {}, -1, graph, diplomacy)
	if not result.ok:
		return false
	FamilyTree.ensure_nation_lineage(self, overlord_id)
	FamilyTree.ensure_nation_lineage(self, subject_id)
	WorldNaming.assign_submitted_vassal_name(self, subject_id)
	FamilyTree.record_current_title(self, subject_id)
	EmpireStatus.reconcile(self)
	return true


## 兼并可能让原战斗双方变成同国或不再敌对。Battle 持有 Army 引用，因此必须在
## owner 迁移的同一事务中解除这类战斗，不能留到下一回合继续互相造成伤亡。
func _reconcile_battles_after_annexation() -> void:
	for battle in battles:
		if battle.finished:
			continue
		battle.prune_dead()
		if battle.kind == Battle.Kind.SIEGE and not battle.side_a.is_empty():
			var besieger_nation := battle.side_a[0].owner_nation
			var merged: Array[Army] = []
			for army in battle.side_b:
				if army.owner_nation == besieger_nation:
					if not battle.side_a.has(army):
						battle.side_a.append(army)
					merged.append(army)
			for army in merged:
				battle.side_b.erase(army)
				battle.reinforce_fresh_b.erase(army)
				battle.routed_b.erase(army)
				battle.frontline_priority_b.erase(army)
			if battle.side_b.is_empty():
				battle.side_b_defends_city = false
				battle.reinforce_fresh_b.clear()
				battle.routed_b.clear()
				battle.frontline_priority_b.clear()
				battle.end_field_engagement()
		if _battle_has_hostile_sides(battle):
			continue
		battle.end_field_engagement()
		battle.invalidate_assault_dice()
		for army in battle.side_a + battle.side_b:
			army.battle_id = -1
			if army.state != Army.State.FIGHTING:
				continue
			army.state = (
				Army.State.MOVING
				if army.on_edge and army.move_to != -1
				else Army.State.IDLE
			)
		battle.finished = true
		battle.winner_side = 0


func _battle_has_hostile_sides(battle: Battle) -> bool:
	for army_a in battle.side_a:
		if army_a.size <= 0:
			continue
		for army_b in battle.side_b:
			if (
				army_b.size > 0
				and is_enemy(
					army_a.owner_nation,
					army_b.owner_nation
				)
			):
				return true
	if battle.kind == Battle.Kind.SIEGE and battle.city != null:
		for besieger in battle.side_a:
			if (
				besieger.size > 0
				and is_enemy(
					besieger.owner_nation,
					battle.city.owner_nation
				)
			):
				return true
	return false


## 和平撤藩：宗主直接吸收藩王全境，宗藩记录移除。返回是否成功。
## 用于藩王面对削藩选择不反抗（军力悬殊）时的和平收场。
func revoke_vassal(subject_id: int) -> bool:
	if not suzerainty.has(subject_id):
		return false
	var overlord_id := int(suzerainty[subject_id]["overlord_id"])
	if overlord_id < 0 or overlord_id >= nations.size():
		return false
	# 兼并原语会原子移除 subject 并把其直接藩王改投宗主。
	if not annex_nation(overlord_id, subject_id):
		return false
	prune_dead_suzerainty()
	assert(
		suzerainty_structure_valid(),
		"撤藩后宗藩结构不变量必须成立"
	)
	assert(
		_battle_group_structure_valid(),
		"撤藩合并军队后战团结构不变量必须成立"
	)
	return true


## 分封区域闭包：拟分封区域从宗主直辖领土移除后，所有无法再沿正容量道路连回
## 宗主首都的直辖飞地一并纳入封地。闭包不改变合法输入的城市，只补齐被切断部分。
func enfeoff_region_closure(
	overlord_id: int,
	city_ids: Array[int]
) -> Array[int]:
	if (
		overlord_id < 0
		or overlord_id >= nations.size()
		or not nations[overlord_id].alive
		or city_ids.is_empty()
	):
		return [] as Array[int]
	var capital_id := nations[overlord_id].capital_city_id
	if (
		capital_id < 0
		or capital_id >= cities.size()
		or cities[capital_id].owner_nation != overlord_id
	):
		return [] as Array[int]
	var region := {}
	for city_id in city_ids:
		if (
			city_id < 0
			or city_id >= cities.size()
			or region.has(city_id)
			or city_id == capital_id
			or cities[city_id].owner_nation != overlord_id
		):
			return [] as Array[int]
		region[city_id] = true
	var reachable := {capital_id: true}
	var queue: Array[int] = [capital_id]
	var cursor := 0
	while cursor < queue.size():
		var current := queue[cursor]
		cursor += 1
		for neighbor in neighbors(current):
			var edge := edge_of(current, neighbor)
			if (
				reachable.has(neighbor)
				or region.has(neighbor)
				or cities[neighbor].owner_nation
					!= overlord_id
				or edge == null
				or edge.max_manpower <= 0
			):
				continue
			reachable[neighbor] = true
			queue.append(neighbor)
	for city in cities:
		if (
			city.owner_nation == overlord_id
			and not city.is_dock
			and not reachable.has(city.id)
		):
			region[city.id] = true
	var result: Array[int] = []
	for city_id_value in region:
		result.append(int(city_id_value))
	result.sort()
	return result


## 分封合法性：宗主有效存活、区域非空且全部属于宗主实控与法理、不含宗主首都、
## 不得清空宗主陆地领土；传入区域必须已经包含其造成的全部直辖飞地。临时占领地
## 不能通过分封直接洗成新藩王法理，必须先由议和确认归宗主。
func _can_enfeoff(overlord_id: int, city_ids: Array[int]) -> bool:
	if (
		overlord_id < 0
		or overlord_id >= nations.size()
		or not nations[overlord_id].alive
		or city_ids.is_empty()
	):
		return false
	var seen := {}
	var granted_land := 0
	for city_id in city_ids:
		if (
			city_id < 0
			or city_id >= cities.size()
			or seen.has(city_id)
			or cities[city_id].is_dock
			or cities[city_id].owner_nation != overlord_id
			or recognized_owner_of(city_id) != overlord_id
			or cities[city_id].is_capital
		):
			return false
		seen[city_id] = true
		if not cities[city_id].is_dock:
			granted_land += 1
	if granted_land <= 0:
		return false
	var remaining_land := 0
	for city in land_cities_of(overlord_id):
		if not seen.has(city.id):
			remaining_land += 1
	if remaining_land <= 0:
		return false
	var closure := enfeoff_region_closure(
		overlord_id,
		city_ids
	)
	if closure.size() != seen.size():
		return false
	var closure_set := {}
	for city_id in closure:
		closure_set[city_id] = true
	for city_id in closure:
		if cities[city_id].is_dock:
			return false
		var center_id := administrative_center_of(city_id)
		if center_id < 0 or not closure_set.has(center_id):
			return false
		for member_id in administrative_members(center_id):
			if not closure_set.has(member_id):
				return false
	return true


## 按产能占比从一个整数资源池中切出应划转的整数份额（floor，保证不超发）。
## share 分母为 0 时返回 0。三种同质资源（人力/金钱/粮食）共用此逻辑。
func _proportional_share(pool: int, moved_output: int, total_output: int) -> int:
	if total_output <= 0 or pool <= 0 or moved_output <= 0:
		return 0
	var ratio := float(moved_output) / float(total_output)
	return mini(pool, int(floor(float(pool) * ratio)))


## 按确定性粮仓顺序扣除最多 amount 单位粮食，并返回实际扣除量。
## requested 不超过总库存时必须精确扣足；超出时扣尽现有库存。
func _withdraw_food_from_warehouses(overlord: Nation, amount: int) -> int:
	if overlord == null or amount <= 0:
		return 0
	var warehouses := warehouse_cities_of(overlord.id)
	var total := 0
	for warehouse in warehouses:
		total += warehouse.food_storage
	if total <= 0:
		return 0
	var remaining := mini(amount, total)
	var requested := remaining
	for warehouse in warehouses:
		if remaining <= 0:
			break
		var take := mini(remaining, warehouse.food_storage)
		warehouse.food_storage -= take
		remaining -= take
	# granary_food 是派生量，由 refresh_derived 统一重算，此处不手改。
	return requested - remaining


## 藩王色调从宗主派生：色相小幅偏移、降低明度/饱和度，体现「同一政治共同体、
## 内部多个实体」。id 仅参与小幅确定性微调，避免多个藩王完全同色。
func _derive_vassal_color(overlord_color: Color, subject_id: int) -> Color:
	var subject_hue_variance := fposmod(
		float(subject_id) * 1.61803398875,
		VASSAL_COLOR_SUBJECT_HUE_VARIANCE_DEGREES
	)
	var hue_span := maxf(
		NATION_COLOR_HUE_MAX - NATION_COLOR_HUE_MIN,
		0.0001
	)
	var hue_span_degrees := hue_span * 360.0
	var overlord_hue_progress := inverse_lerp(
		NATION_COLOR_HUE_MIN,
		NATION_COLOR_HUE_MAX,
		clampf(overlord_color.h, NATION_COLOR_HUE_MIN, NATION_COLOR_HUE_MAX)
	)
	var h := lerpf(
		NATION_COLOR_HUE_MIN,
		NATION_COLOR_HUE_MAX,
		fposmod(
			overlord_hue_progress
				+ (VASSAL_COLOR_HUE_OFFSET_DEGREES + subject_hue_variance)
				/ hue_span_degrees,
			1.0
		)
	)
	var s := clampf(
		overlord_color.s - VASSAL_COLOR_SATURATION_OFFSET,
		0.0,
		1.0
	)
	var v := clampf(
		overlord_color.v - VASSAL_COLOR_VALUE_OFFSET,
		0.0,
		1.0
	)
	return Color.from_hsv(
		clampf(h, NATION_COLOR_HUE_MIN, NATION_COLOR_HUE_MAX),
		clampf(s + 0.10, NATION_COLOR_SATURATION_MIN, NATION_COLOR_SATURATION_MAX),
		clampf(v * 0.85, NATION_COLOR_VALUE_MIN, NATION_COLOR_VALUE_MAX)
	)


## 为运行时新生的独立国家选择颜色。候选均来自固定色环，选择与所有现存
## 存活国家 hue 的最小环距最大者；平局由 world_seed 与 id 决定的起点稳定打破。
## 该算法不接收母国颜色，因此不会把地方叛军误画成母国或藩王的派生色。
func _derive_independent_nation_color(nation_id: int) -> Color:
	const CANDIDATE_COUNT: int = 72
	var start := posmod(world_seed + nation_id * 17, CANDIDATE_COUNT)
	var best_hue := 0.0
	var best_distance := -1.0
	for offset in range(CANDIDATE_COUNT):
		var candidate_index := (start + offset) % CANDIDATE_COUNT
		var candidate_hue := float(candidate_index) / float(CANDIDATE_COUNT)
		var nearest_distance := 0.5
		for existing in nations:
			if not existing.alive:
				continue
			var direct_distance := absf(candidate_hue - existing.color.h)
			nearest_distance = minf(
				nearest_distance, minf(direct_distance, 1.0 - direct_distance)
			)
		if nearest_distance > best_distance + 0.000001:
			best_distance = nearest_distance
			best_hue = candidate_hue
	return normalize_nation_color(Color.from_hsv(
		best_hue,
		0.30 + float(nation_id % 3) * 0.04,
		0.78 + float(nation_id % 4) * 0.035
	))


static func _circular_hue_distance(hue_a: float, hue_b: float) -> float:
	var direct := absf(hue_a - hue_b)
	return minf(direct, 1.0 - direct)


func _province_neighbors_for_sovereign_colors() -> Array[Vector2i]:
	if _province_neighbor_pairs_ready:
		return _province_neighbor_pairs
	_province_neighbor_pairs.clear()
	var seen := {}
	var width := province_map_size.x
	var height := province_map_size.y
	if width > 0 and height > 0 and province_ids.size() == width * height:
		for y in range(height):
			for x in range(width):
				var city_id := province_ids[y * width + x]
				if city_id < 0 or city_id >= cities.size():
					continue
				if x + 1 < width:
					_add_province_neighbor_pair(
						city_id, province_ids[y * width + x + 1], seen
					)
				if y + 1 < height:
					_add_province_neighbor_pair(
						city_id, province_ids[(y + 1) * width + x], seen
					)
	else:
		# 无省份栅格的轻量测试/旧地图退回交通图，正式地图不走此分支。
		for edge in edges:
			_add_province_neighbor_pair(edge.city_a, edge.city_b, seen)
	_province_neighbor_pairs.sort_custom(func(a: Vector2i, b: Vector2i) -> bool:
		return a.x < b.x or (a.x == b.x and a.y < b.y)
	)
	_province_neighbor_pairs_ready = true
	return _province_neighbor_pairs


func _add_province_neighbor_pair(
	city_a: int,
	city_b: int,
	seen: Dictionary
) -> void:
	if (
		city_a < 0 or city_a >= cities.size()
		or city_b < 0 or city_b >= cities.size()
		or city_a == city_b
	):
		return
	var lo := mini(city_a, city_b)
	var hi := maxi(city_a, city_b)
	var key := edge_key(lo, hi)
	if seen.has(key):
		return
	seen[key] = true
	_province_neighbor_pairs.append(Vector2i(lo, hi))


func _sovereign_color_graph() -> Dictionary:
	var graph := {}
	var territory_sizes := {}
	for city in cities:
		if city.is_dock or city.owner_nation < 0 or city.owner_nation >= nations.size():
			continue
		var root := suzerainty_root(city.owner_nation)
		if root < 0 or root >= nations.size():
			continue
		territory_sizes[root] = int(territory_sizes.get(root, 0)) + 1
		if not graph.has(root):
			graph[root] = {}
	for pair in _province_neighbors_for_sovereign_colors():
		var owner_a := cities[pair.x].owner_nation
		var owner_b := cities[pair.y].owner_nation
		if (
			owner_a < 0 or owner_a >= nations.size()
			or owner_b < 0 or owner_b >= nations.size()
		):
			continue
		var root_a := suzerainty_root(owner_a)
		var root_b := suzerainty_root(owner_b)
		if root_a == root_b or not graph.has(root_a) or not graph.has(root_b):
			continue
		(graph[root_a] as Dictionary)[root_b] = true
		(graph[root_b] as Dictionary)[root_a] = true
	return {"graph": graph, "territory_sizes": territory_sizes}


func _first_sovereign_hue_conflict(graph: Dictionary) -> Vector2i:
	var roots: Array = graph.keys()
	roots.sort()
	var minimum := ADJACENT_SOVEREIGN_MIN_HUE_DEGREES / 360.0
	for root_value in roots:
		var root := int(root_value)
		var neighbors: Array = (graph[root] as Dictionary).keys()
		neighbors.sort()
		for neighbor_value in neighbors:
			var neighbor := int(neighbor_value)
			if neighbor <= root:
				continue
			if (
				_circular_hue_distance(
					nations[root].color.h, nations[neighbor].color.h
				) + 0.000001 < minimum
			):
				return Vector2i(root, neighbor)
	return Vector2i(-1, -1)


func _nearest_compatible_sovereign_hue(
	root: int,
	graph: Dictionary
) -> float:
	var original_hue := nations[root].color.h
	var minimum := ADJACENT_SOVEREIGN_MIN_HUE_DEGREES / 360.0
	var positive_first := posmod(world_seed + root, 2) == 0
	for offset_degrees in range(181):
		var candidates: Array[float] = []
		candidates.append(original_hue)
		if offset_degrees > 0:
			var offset := float(offset_degrees) / 360.0
			candidates.clear()
			if positive_first:
				candidates.append(fposmod(original_hue + offset, 1.0))
				candidates.append(fposmod(original_hue - offset, 1.0))
			else:
				candidates.append(fposmod(original_hue - offset, 1.0))
				candidates.append(fposmod(original_hue + offset, 1.0))
		for candidate in candidates:
			var valid := true
			for neighbor_value in (graph[root] as Dictionary).keys():
				var neighbor := int(neighbor_value)
				if (
					_circular_hue_distance(
						candidate, nations[neighbor].color.h
					) + 0.000001 < minimum
				):
					valid = false
					break
			if valid:
				return candidate
	return -1.0


func _apply_global_sovereign_hue_palette(graph: Dictionary) -> bool:
	const PALETTE_SIZE: int = 24
	var roots: Array = graph.keys()
	roots.sort_custom(func(a: Variant, b: Variant) -> bool:
		var degree_a := (graph[int(a)] as Dictionary).size()
		var degree_b := (graph[int(b)] as Dictionary).size()
		return degree_a > degree_b or (degree_a == degree_b and int(a) < int(b))
	)
	var assigned_indices := {}
	for root_value in roots:
		var root := int(root_value)
		var unavailable := {}
		for neighbor_value in (graph[root] as Dictionary).keys():
			var neighbor := int(neighbor_value)
			if assigned_indices.has(neighbor):
				unavailable[int(assigned_indices[neighbor])] = true
		var best_index := -1
		var best_distance := INF
		var stable_start := posmod(world_seed + root * 17, PALETTE_SIZE)
		for candidate_index in range(PALETTE_SIZE):
			if unavailable.has(candidate_index):
				continue
			var candidate_hue := float(candidate_index) / float(PALETTE_SIZE)
			var distance := _circular_hue_distance(
				nations[root].color.h, candidate_hue
			)
			var stable_rank := posmod(candidate_index - stable_start, PALETTE_SIZE)
			var best_rank := posmod(best_index - stable_start, PALETTE_SIZE)
			if (
				distance < best_distance - 0.000001
				or (
					is_equal_approx(distance, best_distance)
					and (best_index < 0 or stable_rank < best_rank)
				)
			):
				best_distance = distance
				best_index = candidate_index
		if best_index < 0:
			return false
		assigned_indices[root] = best_index
	var changed := false
	for root_value in roots:
		var root := int(root_value)
		var replacement := (
			float(assigned_indices[root]) / float(PALETTE_SIZE)
		)
		var previous: Color = nations[root].color
		if _circular_hue_distance(previous.h, replacement) <= 0.000001:
			continue
		nations[root].color = Color.from_hsv(
			replacement, previous.s, previous.v, previous.a
		)
		changed = true
	return changed


## 保证视觉上共享省界的不同宗藩体系根至少相差 15 度。藩王仍由渲染层
## 从宗主色派生；本方法只在领土或宗藩结构变化时调用，不参与逐帧渲染。
func reconcile_adjacent_sovereign_colors() -> bool:
	var data := _sovereign_color_graph()
	var graph: Dictionary = data["graph"]
	var territory_sizes: Dictionary = data["territory_sizes"]
	var changed := false
	var remaining_conflicts := maxi(graph.size() * graph.size(), 1)
	while remaining_conflicts > 0:
		remaining_conflicts -= 1
		var conflict := _first_sovereign_hue_conflict(graph)
		if conflict.x < 0:
			return changed
		var root_a := conflict.x
		var root_b := conflict.y
		var size_a := int(territory_sizes.get(root_a, 0))
		var size_b := int(territory_sizes.get(root_b, 0))
		var victim := root_a if size_a < size_b else root_b
		if size_a == size_b:
			victim = maxi(root_a, root_b)
		var replacement := _nearest_compatible_sovereign_hue(victim, graph)
		if replacement < 0.0:
			victim = root_b if victim == root_a else root_a
			replacement = _nearest_compatible_sovereign_hue(victim, graph)
		if replacement < 0.0:
			var globally_changed := _apply_global_sovereign_hue_palette(graph)
			if _first_sovereign_hue_conflict(graph).x >= 0:
				push_warning("国家邻接图超过 24 色容量，无法满足 15 度色差。")
			return changed or globally_changed
		var previous: Color = nations[victim].color
		nations[victim].color = Color.from_hsv(
			replacement, previous.s, previous.v, previous.a
		)
		changed = true
	var globally_changed := _apply_global_sovereign_hue_palette(graph)
	return changed or globally_changed


## 军队是否静止驻扎在 nation_id 的领土内（可安全整体转隶）。
## 只认已停在城节点且处于静止态的军队；行军/战斗/边上驻防/撤退一律不迁移，
## 以免破坏 battle、边通行占用与撤退路线的连续性。
func _army_stationed_in_nation(army: Army, nation_id: int) -> bool:
	if army.on_edge or army.state not in [Army.State.IDLE, Army.State.RECOVERING]:
		return false
	var node := army.current_city_node()
	return (
		node >= 0
		and node < cities.size()
		and cities[node].owner_nation == nation_id
	)


## 让藩王继承宗主对每一个第三方国家的对外关系，并与宗主结盟。
func _inherit_overlord_diplomacy(overlord_id: int, subject_id: int) -> void:
	for third in nations:
		if third.id == subject_id or third.id == overlord_id:
			continue
		var inherited := relation_between(overlord_id, third.id)
		set_diplomatic_relation(subject_id, third.id, inherited)
	set_diplomatic_relation(
		subject_id,
		overlord_id,
		DiplomaticRelation.ALLIED
	)


## 地方叛军只建立与母国的独立战争；所有第三国统一为中立，不继承母国的
## 战争或盟约，也不会因同源关系自动与另一支叛军敌对。
func _initialize_rebel_diplomacy(parent_id: int, rebel_id: int) -> void:
	for third in nations:
		if third.id == rebel_id or third.id == parent_id:
			continue
		set_diplomatic_relation(
			rebel_id, third.id, DiplomaticRelation.NEUTRAL
		)


func _regional_rebellion_war_allowed(nation_a: int, nation_b: int) -> bool:
	for candidate in [nation_a, nation_b]:
		if not rebellions.has(candidate):
			continue
		var record: Dictionary = rebellions[candidate]
		if not bool(record.get("active", false)):
			continue
		var other := nation_b if candidate == nation_a else nation_a
		if other != int(record.get("parent_id", -1)):
			return false
	return true


func _diplomacy_key(nation_a: int, nation_b: int) -> String:
	var lo := mini(nation_a, nation_b)
	var hi := maxi(nation_a, nation_b)
	return "%d:%d" % [lo, hi]


func army_at_city(city_id: int) -> Army:
	## 返回驻扎在该城的第一支军队。恢复中的撤退军仍是守军，不能被视为空城。
	var found := armies_at_city(city_id)
	return found[0] if not found.is_empty() else null


func armies_at_city(city_id: int) -> Array[Army]:
	## 返回该城全部本国驻军；恢复中的撤退军同样必须参加守城。
	var result: Array[Army] = []
	var city_owner := cities[city_id].owner_nation
	for army in armies:
		if army.size <= 0 or army.owner_nation != city_owner:
			continue
		if army.location_city == city_id and army.state in [Army.State.IDLE, Army.State.RECOVERING]:
			result.append(army)
	result.sort_custom(func(a: Army, b: Army) -> bool:
		return EquivariantOrder.army_less(
			self,
			city_owner,
			a,
			b,
			city_id
		)
	)
	return result


func armies_available_to_defend_city(
	city_id: int
) -> Array[Army]:
	## 返回物理停留在城节点、可被攻城入口征召的本国军队。
	## 容量等待中的 MOVING/RETREATING 尚未上边，不能因任务状态而从战场消失。
	var result: Array[Army] = []
	var city_owner := cities[city_id].owner_nation
	for army in armies:
		if (
			army.size <= 0
			or army.owner_nation != city_owner
			or not army.is_at_city_node(city_id)
		):
			continue
		if army.state == Army.State.FIGHTING:
			var active_battle := battle_by_id(
				army.battle_id
			)
			if (
				active_battle != null
				and not active_battle.finished
				and active_battle.kind == Battle.Kind.SIEGE
				and active_battle.city != null
				and active_battle.city.id == city_id
				and active_battle.has_army(army)
			):
				continue
		result.append(army)
	result.sort_custom(func(a: Army, b: Army) -> bool:
		return EquivariantOrder.army_less(
			self,
			city_owner,
			a,
			b,
			city_id
		)
	)
	return result


## 新建一场战斗并登记，返回该 Battle（id 已分配）。
func new_battle(kind: int) -> Battle:
	var b := Battle.new()
	b.id = _next_battle_id
	_next_battle_id += 1
	b.kind = kind
	battles.append(b)
	return b


func battle_by_id(bid: int) -> Battle:
	if bid < 0:
		return null
	for b in battles:
		if b.id == bid:
			return b
	return null


## 该城是否正被围攻（存在以其为目标的进行中 SIEGE）。规格 R3：被围城=补给孤岛。
func city_under_siege(city_id: int) -> bool:
	for b in battles:
		if not b.finished and b.kind == Battle.Kind.SIEGE and b.city != null and b.city.id == city_id:
			return true
	return false


## 一次遍历 battles（O(B)）收集全部被围城 id 集合。供每 tick 对多城/多粮仓
## 反复判被围的结算路径共享，替代逐次 city_under_siege 的 O(城×B) 退化。
func besieged_city_ids() -> Dictionary:
	var result := {}
	for b in battles:
		if not b.finished and b.kind == Battle.Kind.SIEGE and b.city != null:
			result[b.city.id] = true
	return result


func recognized_owner_of(city_id: int) -> int:
	if city_id < 0 or city_id >= recognized_city_owners.size():
		return -1
	return recognized_city_owners[city_id]


## 按事务最终实控图选择确定性首都。只要仍拥有州治，首都就必须从州治中
## 选择；多个领土分量之间优先选择包含州治的最大分量。
func _planned_territory_capital(
	nation_id: int,
	planned_owners: Array[int],
	preferred_city_id: int = -1
) -> int:
	if (
		nation_id < 0
		or nation_id >= nations.size()
		or planned_owners.size() != cities.size()
	):
		return -1
	var candidates: Array[City] = []
	var has_owned_zhou := false
	for city in cities:
		if planned_owners[city.id] != nation_id or city.is_dock:
			continue
		candidates.append(city)
		has_owned_zhou = has_owned_zhou or is_zhou_city(city.id)
	if candidates.is_empty():
		return -1
	if (
		preferred_city_id >= 0
		and preferred_city_id < cities.size()
		and planned_owners[preferred_city_id] == nation_id
		and not cities[preferred_city_id].is_dock
		and (not has_owned_zhou or is_zhou_city(preferred_city_id))
	):
		return preferred_city_id
	var current := nations[nation_id].capital_city_id
	if (
		current >= 0
		and current < cities.size()
		and planned_owners[current] == nation_id
		and not cities[current].is_dock
		and (not has_owned_zhou or is_zhou_city(current))
	):
		return current
	var nearby := _nearby_capital(nation_id, candidates, current)
	if nearby >= 0:
		return nearby
	var best_component := _largest_owned_component(
		nation_id, candidates, has_owned_zhou
	)
	var capital_candidates: Array[City] = []
	for city in best_component:
		if not has_owned_zhou or is_zhou_city(city.id):
			capital_candidates.append(city)
	EquivariantOrder.sort_cities(capital_candidates, self, nation_id)
	return capital_candidates[0].id


func _nearby_capital(nation_id: int, owned_cities: Array[City], old_capital_id: int) -> int:
	var old_region := RegionalStrategy.city_region(self, old_capital_id)
	if old_region < 0:
		return -1
	var eligible := {}
	for city in owned_cities:
		if is_zhou_city(city.id) and RegionalStrategy.regions_are_adjacent(
			self, old_region, RegionalStrategy.city_region(self, city.id)
		):
			eligible[city.id] = true
	if eligible.is_empty():
		return -1
	var component := _largest_owned_component(nation_id, owned_cities, true, eligible)
	var options: Array[City] = []
	for city in component:
		if eligible.has(city.id):
			options.append(city)
	EquivariantOrder.sort_cities(options, self, nation_id)
	return options[0].id


## 规范化一份任意宗藩快照。事务只能接收完整最终图，不能让调用方通过提前
## 修改 live suzerainty 来影响规划。这里同时把 key 统一为 int 并拒绝环。
## validate_relations 只用于对 live 快照作一致性检查；拟议图的对应外交变化由
## 生命周期调用方在事务成功后无失败地落盘，不能用旧外交关系拒绝合法改图。
func _validated_suzerainty_snapshot(
	snapshot: Dictionary,
	validate_relations: bool = false
) -> Dictionary:
	var normalized := {}
	for subject_value in snapshot:
		if typeof(subject_value) != TYPE_INT:
			return {"ok": false, "error": "宗藩图包含非整数国家 id。"}
		var subject_id := int(subject_value)
		var record_value: Variant = snapshot[subject_value]
		if (
			subject_id < 0
			or subject_id >= nations.size()
			or typeof(record_value) != TYPE_DICTIONARY
		):
			return {"ok": false, "error": "宗藩图包含无效藩属记录。"}
		var record: Dictionary = record_value
		if not record.has("overlord_id"):
			return {"ok": false, "error": "宗藩记录缺少宗主 id。"}
		var overlord_id := int(record["overlord_id"])
		if (
			overlord_id < 0
			or overlord_id >= nations.size()
			or overlord_id == subject_id
		):
			return {"ok": false, "error": "宗藩图包含无效宗主。"}
		normalized[subject_id] = record.duplicate(true)
		if validate_relations:
			var expected_relation := (
				DiplomaticRelation.WAR
				if bool(record.get("civil_war", false))
				else DiplomaticRelation.ALLIED
			)
			if relation_between(subject_id, overlord_id) != expected_relation:
				return {
					"ok": false,
					"error": "现有宗藩图与外交关系不一致。",
				}
	for subject_value in normalized:
		var subject_id := int(subject_value)
		var walker := subject_id
		var seen := {}
		while normalized.has(walker):
			if seen.has(walker):
				return {"ok": false, "error": "宗藩图不能包含环。"}
			seen[walker] = true
			walker = int((normalized[walker] as Dictionary)["overlord_id"])
	return {"ok": true, "error": "", "snapshot": normalized}


## 根据最终领土一次性跳过死亡宗主，并删除死亡或无法理州治的藩属边。
## 跨过死亡节点的新边不继承旧内战；它是死亡清理后与存活祖先建立的新和平宗藩边。
func _normalized_suzerainty_for_territory(
	snapshot: Dictionary,
	final_city_counts: Array[int],
	final_legal_center_counts: Array[int]
) -> Dictionary:
	var result := {}
	for subject_value in snapshot:
		var subject_id := int(subject_value)
		if (
			final_city_counts[subject_id] <= 0
			or final_legal_center_counts[subject_id] <= 0
		):
			continue
		var record: Dictionary = snapshot[subject_id]
		var overlord_id := int(record["overlord_id"])
		var skipped_dead := false
		var guard := 0
		while (
			overlord_id >= 0
			and overlord_id < nations.size()
			and final_city_counts[overlord_id] <= 0
			and snapshot.has(overlord_id)
			and guard <= nations.size()
		):
			overlord_id = int(
				(snapshot[overlord_id] as Dictionary)["overlord_id"]
			)
			skipped_dead = true
			guard += 1
		if (
			overlord_id < 0
			or overlord_id >= nations.size()
			or final_city_counts[overlord_id] <= 0
			or overlord_id == subject_id
		):
			continue
		var final_record := record.duplicate(true)
		final_record["overlord_id"] = overlord_id
		if skipped_dead:
			final_record["civil_war"] = false
		result[subject_id] = final_record
	return result


## 按最终有城国家集合及任意宗藩快照解析粮池持有者。若宗主在本批失去
## 最后一城，跳过死亡宗主并接到仍存活的祖先；没有祖先时返回自身（自身
## 也死亡时返回 -1）。活节点上的内战边仍会截断共享关系。
func _planned_territory_food_pool_holder(
	nation_id: int,
	final_city_counts: Array[int],
	suzerainty_snapshot: Dictionary
) -> int:
	nation_id = financial_nation_of(nation_id)
	if (
		nation_id < 0
		or nation_id >= nations.size()
		or final_city_counts.size() != nations.size()
	):
		return -1
	var current := nation_id
	var holder := nation_id if final_city_counts[nation_id] > 0 else -1
	var guard := 0
	while suzerainty_snapshot.has(current) and guard <= nations.size():
		var record: Dictionary = suzerainty_snapshot[current]
		# 只有仍存活的子节点可以维持一条内战边；死亡中间节点会被 prune 掉。
		if (
			final_city_counts[current] > 0
			and bool(record.get("civil_war", false))
		):
			break
		var overlord_id := int(record.get("overlord_id", -1))
		if overlord_id < 0 or overlord_id >= nations.size():
			break
		if final_city_counts[overlord_id] > 0:
			holder = overlord_id
		current = overlord_id
		guard += 1
	return holder


## 运行期领土状态的唯一写入口。phase 1 只读旧快照并完整规划所有城市、政治
## 目标、首都、粮仓双向索引和库存账本；任一错误直接返回且没有副作用。phase 2
## 才一次提交整批结果，ownership_revision 与 refresh_derived 都只发生一次。
## operation 必须含 city_id；可含 controller_id、legal_owner_id、sponsor_id、
## reset_political_target、reason、stock_policy。另接受三个旧字段名别名。
## diplomatic_operations 每项必须含 nation_a、nation_b、relation，可选
## truce_days；显式外交边会和最终宗藩图要求的 WAR/ALLIED 边合并规划。
func apply_territory_transaction(
	operations: Array[Dictionary],
	preferred_capitals: Dictionary = {},
	expected_ownership_revision: int = -1,
	proposed_suzerainty: Variant = null,
	diplomatic_operations: Array[Dictionary] = [],
	expected_diplomacy_revision: int = -1
) -> Dictionary:
	# 乐观锁必须是入口第一项检查，冲突时连规划快照都不建立。
	if (
		expected_ownership_revision != -1
		and expected_ownership_revision != ownership_revision
	):
		return {
			"ok": false, "changed": false,
			"territory_changed": false,
			"political_changed": false,
			"diplomacy_changed": false,
			"error": "领土版本已变化，请重试。",
			"changed_city_ids": [] as Array[int],
		}
	if (
		expected_diplomacy_revision != -1
		and expected_diplomacy_revision != diplomacy_revision
	):
		return {
			"ok": false, "changed": false,
			"territory_changed": false,
			"political_changed": false,
			"diplomacy_changed": false,
			"error": "外交版本已变化，请重试。",
			"changed_city_ids": [] as Array[int],
		}
	if recognized_city_owners.size() != cities.size():
		return {
			"ok": false, "changed": false,
			"territory_changed": false,
			"political_changed": false,
			"diplomacy_changed": false,
			"error": "法理领土索引与城市数量不一致。",
			"changed_city_ids": [] as Array[int],
		}
	if (
		proposed_suzerainty != null
		and typeof(proposed_suzerainty) != TYPE_DICTIONARY
	):
		return {
			"ok": false, "changed": false,
			"territory_changed": false,
			"political_changed": false,
			"diplomacy_changed": false,
			"error": "proposed_suzerainty 必须是完整宗藩图。",
			"changed_city_ids": [] as Array[int],
		}

	# ------------------------------ phase 1a: 规范化并校验 operation。
	var operation_plan := TerritoryTransaction.plan_operations(
		cities,
		recognized_city_owners,
		nations.size(),
		operations,
		day,
		RebellionSystem.REBELLION_COOLDOWN_DAYS,
		TerritoryStockDisposition.RETURN_TO_OLD_POOL,
		[
			TerritoryStockDisposition.RETURN_TO_OLD_POOL,
			TerritoryStockDisposition.MOVE_TO_NEW_POOL,
			TerritoryStockDisposition.CAPTURE_SPOILS,
			TerritoryStockDisposition.DESTROY,
		] as Array[int]
	)
	if not bool(operation_plan.get("ok", false)):
		return operation_plan
	var planned_owners: Array[int] = operation_plan["planned_owners"]
	var planned_legal_owners: Array[int] = operation_plan["planned_legal_owners"]
	var planned_sponsors: Array[int] = operation_plan["planned_sponsors"]
	var normalized_operations: Array[Dictionary] = (
		operation_plan["normalized_operations"]
	)
	var changed_city_ids: Array[int] = operation_plan["changed_city_ids"]
	# ------------------------------ phase 1b: 最终三元组、首都、粮池。
	# 默认政治图中死亡藩属的法理随同一次事务归入最近的存活祖先。显式
	# overlay（如兼并）通常已由调用方给出更精确的法理 operation；这里只
	# 补齐仍指向死亡藩属的城市，避免图已清理而法理继承永远丢失。
	var suzerainty_plan := TerritoryTransaction.plan_suzerainty(
		cities,
		nations.size(),
		administrative_center_city_ids,
		planned_owners,
		planned_legal_owners,
		planned_sponsors,
		changed_city_ids,
		proposed_suzerainty,
		suzerainty,
		_validated_suzerainty_snapshot,
		_normalized_suzerainty_for_territory
	)
	if not bool(suzerainty_plan.get("ok", false)):
		return suzerainty_plan
	var final_city_counts: Array[int] = suzerainty_plan["final_city_counts"]
	var validated_requested_suzerainty: Dictionary = (
		suzerainty_plan["validated_requested_suzerainty"]
	)
	var planned_suzerainty: Dictionary = suzerainty_plan["planned_suzerainty"]
	var political_changed := bool(suzerainty_plan["changed"])
	# 宗藩边的外交态属于同一政治事务：拟议图中每条边按 civil_war
	# 归一为 WAR/ALLIED，phase 2 与 suzerainty 同批写入。非宗藩边不动。
	var diplomacy_plan := TerritoryTransaction.plan_diplomacy(
		planned_suzerainty,
		diplomatic_operations,
		nations.size(),
		diplomatic_relations,
		diplomatic_since_day,
		truce_until_day,
		day,
		DiplomaticRelation.NEUTRAL,
		DiplomaticRelation.WAR,
		DiplomaticRelation.ALLIED,
		regional_rebellion_peace_locked
	)
	if not bool(diplomacy_plan.get("ok", false)):
		return diplomacy_plan
	var planned_diplomatic_relations: Dictionary = (
		diplomacy_plan["planned_relations"]
	)
	var planned_diplomatic_since: Dictionary = diplomacy_plan["planned_since"]
	var planned_truce_until: Dictionary = diplomacy_plan["planned_truce"]
	var diplomacy_changed := bool(diplomacy_plan["changed"])
	var structure_plan := TerritoryTransaction.plan_structure(
		cities,
		nations,
		planned_owners,
		final_city_counts,
		planned_suzerainty,
		preferred_capitals,
		_planned_territory_capital,
		_planned_territory_food_pool_holder
	)
	if not bool(structure_plan.get("ok", false)):
		return structure_plan
	var planned_capitals: Array[int] = structure_plan["planned_capitals"]
	var final_pool_holders: Array[int] = structure_plan["final_pool_holders"]
	var planned_warehouse_flags: Array[bool] = (
		structure_plan["planned_warehouse_flags"]
	)

	# ------------------------------ phase 1c: 以旧快照计算库存账本。
	var food_plan := TerritoryTransaction.plan_food_ledger(
		cities,
		nations,
		normalized_operations,
		planned_owners,
		final_city_counts,
		validated_requested_suzerainty,
		final_pool_holders,
		planned_capitals,
		planned_warehouse_flags,
		TerritoryStockDisposition.RETURN_TO_OLD_POOL,
		TerritoryStockDisposition.MOVE_TO_NEW_POOL,
		TerritoryStockDisposition.CAPTURE_SPOILS,
		TerritoryStockDisposition.DESTROY,
		TERRITORY_CAPTURE_SPOILS_RATE,
		_planned_territory_food_pool_holder
	)
	if not bool(food_plan.get("ok", false)):
		return food_plan
	var planned_food: Array[int] = food_plan["planned_food"]

	var commit_layout := TerritoryTransaction.plan_commit_layout(
		cities,
		nations,
		planned_owners,
		changed_city_ids,
		planned_capitals,
		planned_warehouse_flags,
		planned_food
	)
	var planned_warehouse_ids: Array = commit_layout["planned_warehouse_ids"]
	var territory_changed := bool(commit_layout["territory_changed"])
	if not territory_changed and not political_changed and not diplomacy_changed:
		return {
			"ok": true, "changed": false,
			"territory_changed": false,
			"political_changed": false,
			"diplomacy_changed": false, "error": "",
			"changed_city_ids": [] as Array[int],
		}

	# ------------------------------ phase 2: 一次提交，不再包含可失败分支。
	return _commit_territory_transaction({
		"planned_owners": planned_owners,
		"planned_legal_owners": planned_legal_owners,
		"planned_sponsors": planned_sponsors,
		"planned_warehouse_flags": planned_warehouse_flags,
		"planned_food": planned_food,
		"normalized_operations": normalized_operations,
		"planned_capitals": planned_capitals,
		"planned_warehouse_ids": planned_warehouse_ids,
		"planned_suzerainty": planned_suzerainty,
		"planned_diplomatic_relations": planned_diplomatic_relations,
		"planned_diplomatic_since": planned_diplomatic_since,
		"planned_truce_until": planned_truce_until,
		"territory_changed": territory_changed,
		"political_changed": political_changed,
		"diplomacy_changed": diplomacy_changed,
		"changed_city_ids": changed_city_ids,
	})


func _commit_territory_transaction(plan: Dictionary) -> Dictionary:
	var planned_owners: Array[int] = plan["planned_owners"]
	var planned_legal_owners: Array[int] = plan["planned_legal_owners"]
	var planned_sponsors: Array[int] = plan["planned_sponsors"]
	var planned_warehouse_flags: Array[bool] = plan["planned_warehouse_flags"]
	var planned_food: Array[int] = plan["planned_food"]
	var planned_capitals: Array[int] = plan["planned_capitals"]
	for city_id in range(cities.size()):
		var city := cities[city_id]
		var previous_owner := city.owner_nation
		var continues_as_capital := (
			city.is_capital
			and previous_owner >= 0
			and previous_owner < planned_capitals.size()
			and planned_owners[city_id] == previous_owner
			and planned_capitals[previous_owner] == city_id
		)
		city.owner_nation = planned_owners[city_id]
		if city.owner_nation != previous_owner:
			city.administrative_rebellion_progress = 0
		recognized_city_owners[city_id] = planned_legal_owners[city_id]
		city.occupation_sponsor_nation = planned_sponsors[city_id]
		city.is_capital = false
		if not continues_as_capital:
			city.capital_since_day = -1
		city.has_warehouse = planned_warehouse_flags[city_id]
		city.food_storage = planned_food[city_id]
	var normalized_operations: Array[Dictionary] = plan["normalized_operations"]
	for normalized in normalized_operations:
		if not bool(normalized["reset_political_target"]):
			continue
		var city := cities[int(normalized["city_id"])]
		city.loyalty_target_nation = int(normalized["legal_owner_id"])
		city.loyalty_trend = 0.0
		city.unrest = 100.0 - city.loyalty
		city.rebellion_progress = 0
		city.administrative_rebellion_progress = 0
		city.rebellion_cooldown_until_day = int(normalized["cooldown_until"])
		city.last_loyalty_reason = str(normalized["reason"])
	var planned_warehouse_ids: Array = plan["planned_warehouse_ids"]
	for nation in nations:
		nation.capital_city_id = planned_capitals[nation.id]
		nation.warehouse_city_ids = (
			planned_warehouse_ids[nation.id] as Array[int]
		).duplicate()
		if nation.capital_city_id >= 0:
			var capital := cities[nation.capital_city_id]
			capital.is_capital = true
			if capital.capital_since_day < 0:
				capital.capital_since_day = day
	var planned_suzerainty: Dictionary = plan["planned_suzerainty"]
	suzerainty = planned_suzerainty.duplicate(true)
	diplomatic_relations = plan["planned_diplomatic_relations"]
	diplomatic_since_day = plan["planned_diplomatic_since"]
	truce_until_day = plan["planned_truce_until"]
	var territory_changed := bool(plan["territory_changed"])
	var political_changed := bool(plan["political_changed"])
	var diplomacy_changed := bool(plan["diplomacy_changed"])
	if territory_changed or political_changed:
		ownership_revision += 1
	if diplomacy_changed:
		_reconcile_atomic_war_relations()
		diplomacy_revision += 1
	refresh_derived()
	_promote_independent_vassal_names()
	if territory_changed or political_changed:
		reconcile_adjacent_sovereign_colors()
	var changed_city_ids: Array[int] = plan["changed_city_ids"]
	changed_city_ids.sort()
	return {
		"ok": true, "changed": true,
		"territory_changed": territory_changed,
		"political_changed": political_changed,
		"diplomacy_changed": diplomacy_changed, "error": "",
		"changed_city_ids": changed_city_ids,
	}


## 原子领土事务会整张替换外交关系，不能经过 set_diplomatic_relation 的
## 单边生命周期钩子。这里在最终外交图已经落定后统一同步战争 ID，并释放
## 已经不再参战国家的战争池，避免和平军队永久残留 campaign_war_id。
func _reconcile_atomic_war_relations() -> void:
	var ended_participants_by_war := {}
	for nation_a in range(nations.size()):
		for nation_b in range(nation_a + 1, nations.size()):
			var key := _diplomacy_key(nation_a, nation_b)
			var current := relation_between(nation_a, nation_b)
			if current == DiplomaticRelation.WAR:
				if not war_relation_ids.has(key):
					war_relation_ids[key] = next_war_id
					next_war_id += 1
			elif war_relation_ids.has(key):
				var finished_war_id := int(war_relation_ids.get(key, -1))
				war_relation_ids.erase(key)
				war_objectives.erase(key)
				if finished_war_id < 0:
					continue
				if not ended_participants_by_war.has(finished_war_id):
					ended_participants_by_war[finished_war_id] = {}
				var participants: Dictionary = ended_participants_by_war[
					finished_war_id
				]
				participants[nation_a] = true
				participants[nation_b] = true
	for war_value in ended_participants_by_war:
		var war_id := int(war_value)
		var participants: Dictionary = ended_participants_by_war[war_value]
		for participant_value in participants:
			var participant := int(participant_value)
			if not nation_participates_in_war_id(participant, war_id):
				release_nation_war_pool(participant, war_id)
		if not war_relation_ids.values().has(war_id):
			release_war_pool(war_id)


## 只转移城市实控及其战争结算责任方。
func transfer_city_control(
	city_id: int,
	controller_id: int,
	sponsor_id: int = -1,
	stock_policy: int = TerritoryStockDisposition.RETURN_TO_OLD_POOL,
	reason: String = "control_transfer"
) -> Dictionary:
	var normalized_sponsor := sponsor_id
	if (
		city_id >= 0
		and city_id < cities.size()
		and controller_id != recognized_owner_of(city_id)
		and normalized_sponsor == -1
	):
		normalized_sponsor = controller_id
	return apply_territory_transaction([{
		"city_id": city_id,
		"controller_id": controller_id,
		"sponsor_id": normalized_sponsor,
		"stock_policy": stock_policy,
		"reason": reason,
	}] as Array[Dictionary])


## 只迁移城市法理；可一并重置政治目标与叛乱进度。
func transfer_city_legal_title(
	city_id: int,
	legal_owner_id: int,
	reset_political_target: bool = true,
	stock_policy: int = TerritoryStockDisposition.RETURN_TO_OLD_POOL,
	reason: String = "legal_title_transfer"
) -> Dictionary:
	return apply_territory_transaction([{
		"city_id": city_id,
		"legal_owner_id": legal_owner_id,
		"reset_political_target": reset_political_target,
		"stock_policy": stock_policy,
		"reason": reason,
	}] as Array[Dictionary])


## 原子统一城市实控、法理与政治目标；调用方不得预先拆首都或粮仓。
func transfer_city_sovereignty(
	city_id: int,
	sovereign_id: int,
	reason: String = "sovereignty_transfer",
	stock_policy: int = TerritoryStockDisposition.RETURN_TO_OLD_POOL
) -> Dictionary:
	return apply_territory_transaction([{
		"city_id": city_id,
		"controller_id": sovereign_id,
		"legal_owner_id": sovereign_id,
		"sponsor_id": -1,
		"reset_political_target": true,
		"stock_policy": stock_policy,
		"reason": reason,
	}] as Array[Dictionary])


## 和平事务尾部兜底：只依据“战争结算责任方 sponsor ↔ 法理方”判断。
## controller 正在参与的另一场战争与本城占领无关，不能阻止该城恢复法理。
func normalize_peaceful_occupations(
	excluded_war_pairs: Dictionary = {}
) -> Array[int]:
	var operations: Array[Dictionary] = []
	for city in cities:
		var legal_owner := recognized_owner_of(city.id)
		if city.owner_nation == legal_owner:
			continue
		var sponsor := city.occupation_sponsor_nation
		if (
			sponsor >= 0
			and sponsor < nations.size()
			and excluded_war_pairs.has(edge_key(sponsor, legal_owner))
		):
			continue
		var sponsor_at_war := (
			sponsor >= 0
			and sponsor < nations.size()
			and nations[sponsor].alive
			and is_enemy(sponsor, legal_owner)
		)
		if sponsor_at_war:
			continue
		operations.append({
			"city_id": city.id,
			"controller_id": legal_owner,
			"legal_owner_id": legal_owner,
			"sponsor_id": -1,
			"reset_political_target": true,
			"reason": "peaceful_occupation_normalized",
			"stock_policy": TerritoryStockDisposition.MOVE_TO_NEW_POOL,
		})
	if operations.is_empty():
		return [] as Array[int]
	var result := apply_territory_transaction(operations)
	if not bool(result.get("ok", false)):
		return [] as Array[int]
	return result.get("changed_city_ids", []) as Array[int]


## 联盟整体议和确认两个集团之间的全部实际占领。实际控制者保留自己的占领成果，
## 不把盟军占领地错误归给发起议和的代表国。
func recognize_coalition_occupied_territory(
	bloc_a: Array[int],
	bloc_b: Array[int],
	settled_war_pairs: Dictionary = {}
) -> Array[int]:
	var side_a := {}
	var side_b := {}
	for nation_id in bloc_a:
		side_a[nation_id] = true
	for nation_id in bloc_b:
		side_b[nation_id] = true
	var operations: Array[Dictionary] = []
	for city in cities:
		var recognized_owner := recognized_owner_of(city.id)
		if city.owner_nation == recognized_owner:
			continue
		var occupying_side := -1
		var sponsor := city.occupation_sponsor_nation
		if (
			not settled_war_pairs.is_empty()
			and sponsor >= 0
			and sponsor < nations.size()
			and not settled_war_pairs.has(
				edge_key(sponsor, recognized_owner)
			)
		):
			continue
		if side_a.has(sponsor):
			occupying_side = 0
		elif side_b.has(sponsor):
			occupying_side = 1
		elif side_a.has(city.owner_nation):
			occupying_side = 0
		elif side_b.has(city.owner_nation):
			occupying_side = 1
		var recognized_side := -1
		if side_a.has(recognized_owner):
			recognized_side = 0
		elif side_b.has(recognized_owner):
			recognized_side = 1
		if (
			occupying_side < 0
			or recognized_side < 0
			or occupying_side == recognized_side
		):
			continue
		# 占领时已经冻结并写入实际控制者；和平只确认该控制者的
		# 法理，不能把藩王或盟友取得的战果重新上收到宗主。
		var recipient := city.owner_nation
		if recipient < 0:
			continue
		operations.append({
			"city_id": city.id,
			"controller_id": recipient,
			"legal_owner_id": recipient,
			"sponsor_id": -1,
			"reset_political_target": true,
			"reason": "coalition_territory_recognized",
			"stock_policy": TerritoryStockDisposition.MOVE_TO_NEW_POOL,
		})
	if operations.is_empty():
		return [] as Array[int]
	var result := apply_territory_transaction(operations)
	if not bool(result.get("ok", false)):
		return [] as Array[int]
	if bool(result.get("changed", false)):
		prune_dead_suzerainty()
	return result.get("changed_city_ids", []) as Array[int]


func cities_of(nation_id: int) -> Array[City]:
	var result: Array[City] = []
	for city in cities:
		if city.owner_nation == nation_id and not city.is_traffic:
			result.append(city)
	return result


func land_cities() -> Array[City]:
	var result: Array[City] = []
	for city in cities:
		if city.is_settlement():
			result.append(city)
	return result


func land_cities_of(nation_id: int) -> Array[City]:
	var result: Array[City] = []
	for city in cities:
		if city.owner_nation == nation_id and city.is_settlement():
			result.append(city)
	return result


## Applies an inventory delta to one city and keeps the owning nation's derived
## granary total synchronized without rescanning every city. Returns actual delta.
func change_city_food_storage(city_id: int, delta: int) -> int:
	if city_id < 0 or city_id >= cities.size() or delta == 0:
		return 0
	var city := cities[city_id]
	var raw_old := city.food_storage
	var new_storage := maxi(raw_old + delta, 0)
	var actual_delta := new_storage - raw_old
	city.food_storage = new_storage
	if (
		actual_delta != 0
		and city.has_warehouse
		and city.owner_nation >= 0
		and city.owner_nation < nations.size()
	):
		var owner := nations[city.owner_nation]
		owner.granary_food = maxi(owner.granary_food + actual_delta, 0)
	return actual_delta


func warehouse_cities_of(nation_id: int) -> Array[City]:
	var result: Array[City] = []
	if nation_id < 0 or nation_id >= nations.size():
		return result
	for city_id in nations[nation_id].warehouse_city_ids:
		if city_id < 0 or city_id >= cities.size():
			continue
		var city := cities[city_id]
		if (
			city.owner_nation == nation_id
			and not city.is_dock
			and city.has_warehouse
		):
			result.append(city)
	EquivariantOrder.sort_cities(result,self,nation_id)
	return result


## 将粮食汇入「共享粮仓」：藩王的粮食产出重定向到其宗藩体系的粮池持有者
## （food_pool_holder）首都粮仓，藩王首都不再持有独立库存（它只是补给中继节点）。
## 独立国 / 内战反叛方 holder 即自身，行为与旧版一致。若持有者首都暂不可用，回退到其
## 第一个有效粮仓。这是「一个宗主国内所有藩属共享粮仓」在库存写入侧的单一真源。
func deposit_food(nation_id: int, amount: int) -> bool:
	if amount <= 0 or nation_id < 0 or nation_id >= nations.size():
		return false
	var holder_id := food_pool_holder(nation_id)
	var nation := nations[holder_id]
	var target: City = null
	if nation.capital_city_id >= 0 and nation.capital_city_id < cities.size():
		var capital := cities[nation.capital_city_id]
		if (
			capital.owner_nation == holder_id
			and not capital.is_dock
			and capital.has_warehouse
		):
			target = capital
	if target == null:
		var warehouses := warehouse_cities_of(holder_id)
		if not warehouses.is_empty():
			target = warehouses[0]
	if target == null:
		return false
	var remaining_capacity := maxi(
		food_storage_capacity(holder_id) - _food_pool_stock(holder_id), 0
	)
	var actual := change_city_food_storage(
		target.id, mini(amount, remaining_capacity)
	)
	return actual > 0


func remove_warehouse(nation_id: int, city_id: int) -> void:
	if nation_id < 0 or nation_id >= nations.size():
		return
	var nation := nations[nation_id]
	nation.warehouse_city_ids.erase(city_id)
	if nation.capital_city_id == city_id:
		nation.capital_city_id = -1
	if city_id >= 0 and city_id < cities.size():
		cities[city_id].is_capital = false
		cities[city_id].capital_since_day = -1
		cities[city_id].has_warehouse = false


## 首都失守后迁都：只要仍拥有州治，就优先选择包含州治的最大连通领土分量，
## 并且只从该分量的州治中选首都。完全没有州治时才回退到普通陆城。
## 只有当前粮池持有者建立粮仓；和平藩王的新首都仍是零库存补给中继，不能因迁都
## 意外获得独立粮仓。削藩内战反叛方是自己的粮池持有者，仍会正常建立粮仓。
func relocate_capital(nation_id: int) -> int:
	if nation_id < 0 or nation_id >= nations.size():
		return -1
	var nation := nations[nation_id]
	var previous_capital_id := nation.capital_city_id
	var previous_capital_since := -1
	if previous_capital_id >= 0 and previous_capital_id < cities.size():
		previous_capital_since = cities[previous_capital_id].capital_since_day
		cities[previous_capital_id].capital_since_day = -1
	# 迁都入口同时修复旧档/编辑器留下的码头行政标记。码头可被占领和
	# 通行，但永远不能是首都或粮仓。
	for city in cities:
		if city.owner_nation != nation_id:
			continue
		city.is_capital = false
		city.capital_since_day = -1
		if city.is_dock:
			city.has_warehouse = false
			city.food_storage = 0
			nation.warehouse_city_ids.erase(city.id)
	var candidates: Array[City] = land_cities_of(nation_id)
	if candidates.is_empty():
		nation.capital_city_id = -1
		nation.warehouse_city_ids.clear()
		return -1
	var nearby := _nearby_capital(nation_id, candidates, previous_capital_id)
	var has_owned_zhou := false
	for city in candidates:
		has_owned_zhou = has_owned_zhou or is_zhou_city(city.id)
	if nearby < 0 and not has_owned_zhou and previous_capital_id >= 0 \
		and previous_capital_id < cities.size() \
		and cities[previous_capital_id].owner_nation == nation_id \
		and not cities[previous_capital_id].is_dock:
		nearby = previous_capital_id
	var capital: City
	if nearby >= 0:
		capital = cities[nearby]
	else:
		var best_component := _largest_owned_component(
			nation_id, candidates, has_owned_zhou
		)
		var zhou_candidates: Array[City] = []
		for city in best_component:
			if is_zhou_city(city.id):
				zhou_candidates.append(city)
		if not zhou_candidates.is_empty():
			best_component = zhou_candidates
		EquivariantOrder.sort_cities(best_component, self, nation_id)
		capital = best_component[0]
	nation.capital_city_id = capital.id
	capital.is_capital = true
	capital.capital_since_day = (
		previous_capital_since
		if capital.id == previous_capital_id and previous_capital_since >= 0
		else day
	)
	var owns_food_pool := food_pool_holder(nation_id) == nation_id
	if owns_food_pool:
		if not nation.warehouse_city_ids.has(capital.id):
			nation.warehouse_city_ids.append(capital.id)
		capital.has_warehouse = true
	else:
		nation.warehouse_city_ids.clear()
		capital.has_warehouse = false
		capital.food_storage = 0
	return capital.id


## 领土转移后的首都修复。国家仍有城市但首都已不归本国时立即迁都；无城则清空
## 首都与粮仓索引。调用者不需要依赖下一日的寻路或 AI 查询来被动修复悬空首都。
func ensure_valid_capital(nation_id: int) -> int:
	if nation_id < 0 or nation_id >= nations.size():
		return -1
	var nation := nations[nation_id]
	if nation.succession_identity:
		return -1
	var capital_id := nation.capital_city_id
	if (
		capital_id >= 0
		and capital_id < cities.size()
		and cities[capital_id].owner_nation == nation_id
		and not cities[capital_id].is_dock
		and cities[capital_id].is_capital
		and (
			is_zhou_city(capital_id)
			or not land_cities_of(nation_id).any(
				func(city: City) -> bool: return is_zhou_city(city.id)
			)
		)
	):
		return capital_id
	return relocate_capital(nation_id)


## 运行期领土事务不变量。覆盖实控/法理 ID、占领声明、国家存亡、首都与粮仓
## 的双向索引，以及和平宗藩共享粮仓约束。世界生成中间态可以暂不满足；每个完整
## 领土事务和每日 tick 结束后必须成立。
func territory_structure_valid() -> bool:
	if recognized_city_owners.size() != cities.size():
		return false
	var capital_count_by_nation := {}
	for city in cities:
		var owner := city.owner_nation
		var legal_owner := recognized_owner_of(city.id)
		if city.is_traffic:
			if owner!=-1 or legal_owner!=-1 or city.occupation_sponsor_nation!=-1 or city.politically_active or city.is_capital or city.has_warehouse or city.garrison_manpower!=0 or city.food_storage!=0 or city.manpower_per_month!=0 or city.gold_per_month!=0 or city.food_per_half_year!=0: return false
			continue
		if (
			owner < 0
			or owner >= nations.size()
			or legal_owner < 0
			or legal_owner >= nations.size()
			or city.occupation_sponsor_nation < -1
			or city.occupation_sponsor_nation >= nations.size()
		):
			return false
		if owner == legal_owner and city.occupation_sponsor_nation != -1:
			return false
		if (
			owner != legal_owner
			and (
				city.occupation_sponsor_nation < 0
				or city.occupation_sponsor_nation >= nations.size()
			)
		):
			return false
		if (
			city.loyalty_target_nation < 0
			or city.loyalty_target_nation >= nations.size()
			or city.rebellion_progress < 0
		):
			return false
		if city.is_capital:
			if city.is_dock or nations[owner].capital_city_id != city.id:
				return false
			capital_count_by_nation[owner] = (
				int(capital_count_by_nation.get(owner, 0)) + 1
			)
		if (
			city.has_warehouse
			and (
				city.is_dock
				or not nations[owner].warehouse_city_ids.has(city.id)
			)
		):
			return false
	for nation in nations:
		var has_city := not land_cities_of(nation.id).is_empty()
		if nation.alive != has_city:
			return false
		if nation.succession_identity:
			if nation.capital_city_id != -1 or not nation.warehouse_city_ids.is_empty() or nation.treasury_gold != 0 or nation.manpower_pool != 0:
				return false
			continue
		if not has_city:
			if (
				nation.capital_city_id != -1
				or not nation.warehouse_city_ids.is_empty()
			):
				return false
			continue
		var capital_id := nation.capital_city_id
		if (
			capital_id < 0
			or capital_id >= cities.size()
			or cities[capital_id].owner_nation != nation.id
			or cities[capital_id].is_dock
			or not cities[capital_id].is_capital
			or int(capital_count_by_nation.get(nation.id, 0)) != 1
		):
			return false
		var warehouse_seen := {}
		for warehouse_id in nation.warehouse_city_ids:
			if (
				warehouse_seen.has(warehouse_id)
				or warehouse_id < 0
				or warehouse_id >= cities.size()
				or cities[warehouse_id].owner_nation != nation.id
				or cities[warehouse_id].is_dock
				or not cities[warehouse_id].has_warehouse
			):
				return false
			warehouse_seen[warehouse_id] = true
		if food_pool_holder(nation.id) != nation.id:
			if (
				not nation.warehouse_city_ids.is_empty()
				or cities[capital_id].has_warehouse
				or cities[capital_id].food_storage != 0
			):
				return false
		elif (
			not cities[capital_id].has_warehouse
			or not nation.warehouse_city_ids.has(capital_id)
		):
			return false
	return true


## 返回本国按道路连通划分后的「最大连通分量」（城市列表）。同大小时按分量代表城
## 的势力局部物理序取更小者，保证确定性。仅用本国实控城 + 可通行边构成子图。
func _largest_owned_component(
	nation_id: int,
	owned_cities: Array[City],
	prefer_zhou_component: bool = false,
	required_city_ids: Dictionary = {}
) -> Array[City]:
	var owned := {}
	for city in owned_cities:
		owned[city.id] = true
	var visited := {}
	var best: Array[City] = []
	var best_rep := -1
	var best_has_zhou := false
	var best_has_required := false
	for city in owned_cities:
		if visited.has(city.id):
			continue
		var component: Array[City] = []
		var rep := city.id
		var queue: Array[int] = [city.id]
		visited[city.id] = true
		var cursor := 0
		while cursor < queue.size():
			var cid := queue[cursor]
			cursor += 1
			component.append(cities[cid])
			rep = mini(rep, cid)
			for neighbor in strategic_neighbors(cid):
				if visited.has(neighbor) or not owned.has(neighbor):
					continue
				if not strategic_route_access(cid,neighbor,nation_id):
					continue
				visited[neighbor] = true
				queue.append(neighbor)
		var component_has_zhou := false
		var component_has_required := false
		for member in component:
			component_has_zhou = component_has_zhou or is_zhou_city(member.id)
			component_has_required = component_has_required or required_city_ids.has(member.id)
		if (
			(
				not required_city_ids.is_empty()
				and component_has_required != best_has_required
				and component_has_required
			)
			or (
				(required_city_ids.is_empty() or component_has_required == best_has_required)
				and prefer_zhou_component
				and component_has_zhou != best_has_zhou
				and component_has_zhou
			)
			or (
				(required_city_ids.is_empty() or component_has_required == best_has_required)
				and (not prefer_zhou_component or component_has_zhou == best_has_zhou)
				and (
					component.size() > best.size()
					or (
						component.size() == best.size()
						and (best_rep < 0 or rep < best_rep)
					)
				)
			)
		):
			best = component
			best_rep = rep
			best_has_zhou = component_has_zhou
			best_has_required = component_has_required
	return best


## 刷新派生量：国家 granary_food（粮仓求和）与 alive（是否还有陆地城市）。
## 码头只是交通节点；即使仍被某国控制，也不能单独维持国家存续。
func refresh_derived() -> void:
	var city_defense_by_nation := PackedFloat64Array()
	var army_attack_by_nation := PackedFloat64Array()
	var army_defense_by_nation := PackedFloat64Array()
	var army_morale_by_nation := PackedFloat64Array()
	var funding_by_nation := PackedFloat64Array()
	city_defense_by_nation.resize(nations.size())
	army_attack_by_nation.resize(nations.size())
	army_defense_by_nation.resize(nations.size())
	army_morale_by_nation.resize(nations.size())
	funding_by_nation.resize(nations.size())
	for n in nations:
		n.granary_food = 0
		n.alive = false
		funding_by_nation[n.id] = Army.funding_from_payment(n.military_payment_ratio)
		var modifiers := RulerProfile.modifiers(n)
		city_defense_by_nation[n.id] = float(
			modifiers[RulerProfile.KEY_CITY_DEFENSE]
		)
		army_attack_by_nation[n.id] = float(
			modifiers[RulerProfile.KEY_ATTACK]
		)
		army_defense_by_nation[n.id] = float(
			modifiers[RulerProfile.KEY_DEFENSE]
		)
		army_morale_by_nation[n.id] = float(
			modifiers[RulerProfile.KEY_MORALE]
		)
	for city in cities:
		if city.owner_nation < 0 or city.owner_nation >= nations.size():
			city.ruler_city_defense_multiplier = 1.0
			continue
		var owner := nations[city.owner_nation]
		if not city.is_dock:
			owner.alive = true
		city.ruler_city_defense_multiplier = city_defense_by_nation[owner.id]
	for army in armies:
		if army.owner_nation < 0 or army.owner_nation >= nations.size():
			army.funding_multiplier = 1.0
			continue
		army.funding_multiplier = funding_by_nation[financial_nation_of(army.owner_nation)]
		army.ruler_attack_multiplier = army_attack_by_nation[
			army.owner_nation
		]
		army.ruler_defense_multiplier = army_defense_by_nation[
			army.owner_nation
		]
		army.ruler_morale_multiplier = army_morale_by_nation[
			army.owner_nation
		]
		if army_reserved_for_succession(army):
			var profile: Variant = military_profile_for_army(army)
			army.ruler_attack_multiplier = RulerProfile.attack_multiplier(profile)
			army.ruler_defense_multiplier = RulerProfile.defense_multiplier(profile)
			army.ruler_morale_multiplier = RulerProfile.morale_multiplier(profile)
	for n in nations:
		for warehouse in warehouse_cities_of(n.id):
			n.granary_food += warehouse.food_storage
		if not n.alive and n.strategic_region_anchor_city_id >= 0:
			n.strategic_region_anchor_city_id = -1
			regional_strategy_revision += 1
