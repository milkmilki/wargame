from pathlib import Path
import subprocess
name='scripts/core/pathfinding.gd';base=subprocess.check_output(['git','show','HEAD:'+name]).decode().replace('\r\n','\n')
old=Path('.dbg/supply-order-v22/pathfinding-before.gd.txt').read_text(encoding='utf-8-sig');new=Path('.dbg/supply-order-v22/pathfinding-after.gd.txt').read_text(encoding='utf-8-sig')
def field(s):start=s.index('static func _supply_loss_field(');return s[start:s.index('\n\n\n',start)]
assert base.count(field(old))==1
base=base.replace(field(old),field(new),1)
blob=subprocess.check_output(['git','hash-object','-w','--path='+name,'--stdin'],input=base.encode()).decode().strip();subprocess.run(['git','update-index','--cacheinfo','100644,'+blob+','+name],check=True)
name='run_tests.py';s=subprocess.check_output(['git','show','HEAD:'+name]).decode().replace('\r\n','\n');needle='"forecast_token_packing",';assert s.count(needle)==1;s=s.replace(needle,needle+' "supply_field_lazy_order",',1)
blob=subprocess.check_output(['git','hash-object','-w','--path='+name,'--stdin'],input=s.encode()).decode().strip();subprocess.run(['git','update-index','--cacheinfo','100644,'+blob+','+name],check=True)
subprocess.run(['git','add','tests/supply_field_lazy_order.gd','tests/support/supply_field_order_reference.gd'],check=True)
print('Staged only supply loss field and its tests.')
