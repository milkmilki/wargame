from pathlib import Path
import gzip,hashlib,json,shutil,statistics,subprocess
src=Path('.dbg/supply-order-v22');dest=Path('docs/atlas/evidence/supply_lazy_order_v22');dest.mkdir(parents=True,exist_ok=True)
def archive(folder,target):
 target.mkdir(parents=True,exist_ok=True)
 for p in folder.iterdir():
  if not p.is_file() or p.name=='paired-summary.json':continue
  if p.suffix=='.json':(target/p.name).write_text(json.dumps(json.loads(p.read_text(encoding='utf-8-sig')),separators=(',',':'))+'\n',encoding='utf-8')
  elif p.name.endswith('.gd.txt'):(target/(p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
  else:shutil.copyfile(p,target/p.name)
archive(src/'daily',dest/'daily');archive(src/'regression',dest/'working')
for p in src.iterdir():
 if p.is_file() and p.suffix in ['.txt','.json'] and not p.name.endswith('.gd.txt'):
  if p.suffix=='.json':(dest/p.name).write_text(json.dumps(json.loads(p.read_text(encoding='utf-8-sig')),separators=(',',':'))+'\n',encoding='utf-8')
  else:shutil.copyfile(p,dest/p.name)
helpers=dest/'helpers';helpers.mkdir(exist_ok=True)
for name in ['v22_supply_compare.py','v22_supply_daily.gd','v22_runtime_compare.py','v22_runtime.gd','state_codec.gd','v17_daily.gd','prepare_v22.py','stage_v22.py','record_v22.py']:
 (helpers/(name+'.gz')).write_bytes(gzip.compress((Path('.dbg')/name).read_bytes(),mtime=0))
pairs=json.loads((src/'daily/paired-summary.json').read_text());assert len(pairs)==5
assert all(a['sha256']==b['sha256'] for p in pairs for a,b in zip(p['before']['rows'],p['after']['rows']))
metrics={}
for k in ['mean_ms','p95_ms','peak_ms']:
 a=statistics.median(p['before'][k] for p in pairs);b=statistics.median(p['after'][k] for p in pairs);metrics[k]={'before':a,'after':b,'reduction_percent':(a-b)/a*100}
for k in ['ai','monthly','supply','supply_build_plans','supply_prepare','movement_battles']:
 metrics[k]={v:statistics.median(statistics.mean(r['profile'].get(k,0) for r in p[v]['rows'])/1000 for p in pairs) for v in ['before','after']}
sample=json.loads((src/'daily/after-22856.json').read_text());archives={};sources=dest/'sources';sources.mkdir(exist_ok=True)
for path,sha in sample['source_hashes'].items():
 raw=Path(path).read_bytes();assert hashlib.sha256(raw).hexdigest()==sha,path
 name=path.replace('/','__')+'.gz';(sources/name).write_bytes(gzip.compress(raw,mtime=0));archives[name]={'original_path':path,'sha256':sha}
raw=(src/'pathfinding-before.gd.txt').read_bytes();(sources/'pathfinding-before.gd.gz').write_bytes(gzip.compress(raw,mtime=0));archives['pathfinding-before.gd.gz']={'original_path':'scripts/core/pathfinding.gd','sha256':hashlib.sha256(raw).hexdigest(),'variant':'before'}
runtime=json.loads((src/'runtime-summary.json').read_text());assert len(runtime['after']['rows'])==35 and all(a['sha256']==b['sha256'] for a,b in zip(runtime['before']['rows'],runtime['after']['rows']))
working=json.loads((src/'regression-summary.json').read_text(encoding='utf-8-sig'));assert len(working['results'])==17 and all(r['ok'] for r in working['results'])
stage=Path('.dbg/v22-staged-verify/.dbg/regression');staged=json.loads((stage/'summary-selected.json').read_text(encoding='utf-8-sig'));assert len(staged['results'])==8 and all(r['ok'] for r in staged['results'])
target=dest/'staged';target.mkdir(exist_ok=True)
for r in staged['results']:shutil.copyfile(stage/(r['test']+'.log'),target/(r['test']+'.log.txt'))
shutil.copyfile(stage/'summary-selected.json',target/'summary.json')
summary={'date':'2026-10-11','base_commit':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'godot':'4.7.1.stable.official.a13da4feb','scope':'headless computation, not GUI frame rate','configuration':{'seed':1,'nations':40,'nodes':1192,'initial_armies':234,'trade':True,'rulers':True,'mask':{'south':20,'north':55,'west':-15,'east':145}},'days':[181,215],'frozen_file':'.dbg/daily-v9/frozen-day180.bin','frozen_file_sha256':hashlib.sha256(Path('.dbg/daily-v9/frozen-day180.bin').read_bytes()).hexdigest(),'initial_native_sha256':sample['initial_sha256'],'metrics':metrics,'equal_daily_states':175,'process_pairs':[{v:{k:val for k,val in p[v].items() if k!='rows'} for v in ['before','after']} for p in pairs],'runtime':{'days':35,'equal_daily_states':35,'before_pid':runtime['before']['pid'],'after_pid':runtime['after']['pid'],'workers':4,'note':'Inherited cumulative runtime peaks are not a new main-thread performance measurement.'},'tests':{'new_checks':1920,'working_passed':17,'staged_passed':8},'source_archives':archives,'limitations':['One seed, 35-day window and one monthly boundary. No long-run or GUI claim.','Maximum-day median increased 0.21%; two paired peaks decreased and three increased.','Measured working tree contains earlier pending functionality; staged-only validation is separate.']}
(dest/'summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n',encoding='utf-8');(dest/'.gitattributes').write_text('*.gz binary\n',encoding='utf-8')
print('V22 validated evidence saved',flush=True)
