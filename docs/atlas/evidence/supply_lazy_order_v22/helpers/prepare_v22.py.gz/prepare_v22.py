from pathlib import Path
r=Path.cwd();out=r/'.dbg/supply-order-v22';out.mkdir(exist_ok=True)
p=r/'scripts/core/pathfinding.gd';raw=p.read_bytes();(out/'pathfinding-before.gd.txt').write_bytes(raw)
s=raw.decode('utf-8-sig').replace('\r\n','\n');parts=[]
for name in ['_supply_loss_field','_heap_entry_less','_heap_push','_heap_pop']:
 start=s.index('static func '+name+'(');end=s.index('\n\n\n',start);part=s[start:end]
 for helper in ['_enemy_occupied_edge_keys','_local_crossing_transit_docks','_local_crossing_or_accessible_step','_supply_edge_loss']:part=part.replace(helper+'(', 'Pathfinding.'+helper+'(')
 parts.append(part)
(r/'tests/support/supply_field_order_reference.gd').write_text('extends RefCounted\n## Original eager full-map rank field from 37da4bb working baseline.\n\n'+'\n\n'.join(parts)+'\n',encoding='utf-8')
p=r/'run_tests.py';s=p.read_text(encoding='utf-8');s=s.replace('"forecast_token_packing",','"forecast_token_packing", "supply_field_lazy_order",',1);p.write_text(s,encoding='utf-8')
